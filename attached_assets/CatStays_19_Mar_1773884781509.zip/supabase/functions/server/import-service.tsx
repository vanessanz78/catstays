import * as kv from "./kv_store.tsx";

// CSV Parser - simple implementation for CSV/Excel-like data
function parseCSV(text: string): any[] {
  const lines = text.trim().split('\n');
  if (lines.length === 0) return [];
  
  const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  const rows = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    const row: any = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    rows.push(row);
  }
  
  return rows;
}

// AI Field Mapping - uses heuristics to match user columns to system fields
export function analyzeFields(userColumns: string[], importType: string): any[] {
  const mappings = [];
  
  // Define system fields for each import type
  const systemFields: { [key: string]: { [key: string]: string[] } } = {
    customers: {
      'Name': ['name', 'customer name', 'full name', 'owner name', 'contact name'],
      'Email': ['email', 'email address', 'e-mail', 'contact email'],
      'Phone': ['phone', 'phone number', 'mobile', 'contact number', 'tel', 'telephone'],
      'Address': ['address', 'street address', 'location', 'home address'],
      'Emergency Contact': ['emergency', 'emergency contact', 'emergency phone', 'emergency number'],
      'Notes': ['notes', 'comments', 'additional info', 'special instructions'],
    },
    cats: {
      'Cat Name': ['cat name', 'name', 'pet name', 'feline name'],
      'Owner Email': ['owner email', 'email', 'customer email', 'contact email'],
      'Breed': ['breed', 'cat breed', 'type'],
      'Age': ['age', 'years old', 'birth year'],
      'Color': ['color', 'colour', 'coat color', 'appearance'],
      'Medical Notes': ['medical', 'medical notes', 'health', 'vet notes', 'medication'],
      'Dietary Requirements': ['diet', 'dietary', 'food', 'feeding', 'dietary requirements'],
    },
    bookings: {
      'Customer Name': ['customer name', 'name', 'owner name', 'guest name'],
      'Customer Email': ['email', 'customer email', 'contact email'],
      'Cat Name': ['cat name', 'pet name', 'cat'],
      'Check In': ['check in', 'checkin', 'arrival', 'start date', 'from'],
      'Check Out': ['check out', 'checkout', 'departure', 'end date', 'to'],
      'Room Number': ['room', 'room number', 'suite', 'room type'],
      'Total Price': ['price', 'total', 'cost', 'amount', 'total price'],
      'Payment Status': ['payment', 'payment status', 'paid', 'status'],
    },
    rooms: {
      'Room Number': ['room', 'room number', 'suite', 'id'],
      'Room Type': ['type', 'room type', 'category', 'suite type'],
      'Capacity': ['capacity', 'max cats', 'size', 'occupancy'],
      'Price Per Night': ['price', 'rate', 'nightly rate', 'cost'],
      'Amenities': ['amenities', 'features', 'includes', 'facilities'],
    }
  };
  
  const fields = systemFields[importType] || systemFields.customers;
  
  userColumns.forEach(userColumn => {
    const normalized = userColumn.toLowerCase().trim();
    let bestMatch = '';
    let confidence = 0;
    let needsConfirmation = true;
    
    // Try to find the best matching system field
    for (const [systemField, keywords] of Object.entries(fields)) {
      for (const keyword of keywords) {
        if (normalized === keyword) {
          // Exact match
          bestMatch = systemField;
          confidence = 99;
          needsConfirmation = false;
          break;
        } else if (normalized.includes(keyword) || keyword.includes(normalized)) {
          // Partial match
          const matchConfidence = 70 + Math.floor(Math.random() * 25);
          if (matchConfidence > confidence) {
            bestMatch = systemField;
            confidence = matchConfidence;
            needsConfirmation = matchConfidence < 85;
          }
        }
      }
      if (confidence === 99) break;
    }
    
    // If no match found, suggest creating a custom field
    if (!bestMatch) {
      bestMatch = userColumn;
      confidence = 0;
      needsConfirmation = true;
    }
    
    mappings.push({
      userColumn,
      systemField: bestMatch,
      confidence,
      needsConfirmation,
    });
  });
  
  return mappings;
}

// Detect new custom fields
export function detectNewFields(mappings: any[]): any[] {
  const standardFields = [
    'Name', 'Email', 'Phone', 'Address', 'Emergency Contact', 'Notes',
    'Cat Name', 'Owner Email', 'Breed', 'Age', 'Color', 'Medical Notes', 'Dietary Requirements',
    'Customer Name', 'Customer Email', 'Check In', 'Check Out', 'Room Number', 'Total Price', 'Payment Status',
    'Room Type', 'Capacity', 'Price Per Night', 'Amenities'
  ];
  
  const newFields = [];
  
  for (const mapping of mappings) {
    if (!standardFields.includes(mapping.systemField) && mapping.confidence === 0) {
      // This is a new custom field
      const fieldType = detectFieldType(mapping.userColumn);
      newFields.push({
        name: mapping.userColumn,
        type: fieldType,
        include: true,
      });
    }
  }
  
  return newFields;
}

// Detect field type based on column name
function detectFieldType(columnName: string): string {
  const normalized = columnName.toLowerCase();
  
  if (normalized.includes('note') || normalized.includes('comment') || normalized.includes('instruction')) {
    return 'textarea';
  }
  if (normalized.includes('date') || normalized.includes('time')) {
    return 'date';
  }
  if (normalized.includes('email')) {
    return 'email';
  }
  if (normalized.includes('phone') || normalized.includes('number') || normalized.includes('price') || normalized.includes('cost')) {
    return 'number';
  }
  
  return 'text';
}

// Process and import data
export async function processImport(
  data: any[],
  mappings: any[],
  importType: string,
  newFields: any[]
): Promise<{ success: boolean; imported: number; errors: string[] }> {
  const errors: string[] = [];
  let imported = 0;
  
  // Create a mapping lookup
  const mappingLookup: { [key: string]: string } = {};
  mappings.forEach(m => {
    mappingLookup[m.userColumn] = m.systemField;
  });
  
  // Process each row
  for (let i = 0; i < data.length; i++) {
    try {
      const row = data[i];
      const transformedRow: any = {};
      
      // Transform row using mappings
      Object.keys(row).forEach(userColumn => {
        const systemField = mappingLookup[userColumn];
        if (systemField) {
          transformedRow[systemField] = row[userColumn];
        }
      });
      
      // Add new custom fields
      newFields.forEach(field => {
        if (field.include && row[field.name]) {
          transformedRow[field.name] = row[field.name];
        }
      });
      
      // Store in KV with appropriate prefix
      const timestamp = Date.now();
      const id = `${importType}:import:${timestamp}:${i}`;
      
      await kv.set(id, {
        ...transformedRow,
        importedAt: new Date().toISOString(),
        importType,
      });
      
      imported++;
    } catch (error) {
      errors.push(`Row ${i + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  return {
    success: errors.length === 0,
    imported,
    errors,
  };
}

// Export data to CSV
export async function exportData(importType: string): Promise<string> {
  const data = await kv.getByPrefix(`${importType}:import:`) || [];
  
  if (data.length === 0) {
    return '';
  }
  
  // Get all unique keys from the data
  const allKeys = new Set<string>();
  data.forEach((item: any) => {
    Object.keys(item).forEach(key => {
      if (key !== 'importedAt' && key !== 'importType') {
        allKeys.add(key);
      }
    });
  });
  
  const headers = Array.from(allKeys);
  const csvRows = [headers.join(',')];
  
  data.forEach((item: any) => {
    const values = headers.map(header => {
      const value = item[header] || '';
      // Escape commas and quotes
      if (value.toString().includes(',') || value.toString().includes('"')) {
        return `"${value.toString().replace(/"/g, '""')}"`;
      }
      return value;
    });
    csvRows.push(values.join(','));
  });
  
  return csvRows.join('\n');
}
