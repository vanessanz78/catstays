import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { sendBookingConfirmationEmail } from "./email-service.tsx";
import { analyzeFields, detectNewFields, processImport, exportData } from "./import-service.tsx";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-4cdbd524/health", (c) => {
  return c.json({ status: "ok" });
});

// Check availability endpoint
app.post("/make-server-4cdbd524/check-availability", async (c) => {
  try {
    const { checkIn, checkOut } = await c.req.json();
    
    // Validate dates
    if (!checkIn || !checkOut) {
      return c.json({ 
        success: false, 
        error: 'Check-in and check-out dates are required' 
      }, 400);
    }
    
    // TODO: Implement actual availability logic based on rooms and existing bookings
    // For now, return always available
    return c.json({ 
      success: true,
      available: true,
      message: 'Rooms are available for these dates'
    });
  } catch (error) {
    console.error('Error checking availability:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Customer login endpoint
app.post("/make-server-4cdbd524/customer-login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    // Validate input
    if (!email || !password) {
      return c.json({ 
        success: false, 
        error: 'Email and password are required' 
      }, 400);
    }
    
    // Look up customer by email
    const customerKey = `customer:${email}`;
    const customer = await kv.get(customerKey);
    
    if (!customer) {
      return c.json({ 
        success: false, 
        error: 'Invalid email or password' 
      }, 401);
    }
    
    // TODO: Implement proper password hashing and verification
    // For now, just check if password matches stored value
    if (customer.password !== password) {
      return c.json({ 
        success: false, 
        error: 'Invalid email or password' 
      }, 401);
    }
    
    // Get customer's cats
    const cats = await kv.getByPrefix(`cat:${email}:`) || [];
    
    // Get customer's past bookings to check insurance eligibility
    const bookings = await kv.getByPrefix(`booking:`) || [];
    const customerBookings = bookings.filter((b: any) => b.customer?.email === email);
    const hasReceivedIntroInsurance = customerBookings.some((b: any) => b.insurance);
    
    return c.json({ 
      success: true,
      profile: {
        id: customer.id || email,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        address: customer.address,
        cats: cats.map((cat: any) => ({
          id: cat.id,
          name: cat.name,
          age: cat.age,
          breed: cat.breed,
          notes: cat.notes
        })),
        hasReceivedIntroInsurance
      }
    });
  } catch (error) {
    console.error('Customer login error:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Create booking endpoint
app.post("/make-server-4cdbd524/create-booking", async (c) => {
  try {
    const bookingData = await c.req.json();
    
    // Validate required fields
    if (!bookingData.customer?.name || !bookingData.customer?.email || !bookingData.customer?.phone) {
      return c.json({ 
        success: false, 
        error: 'Customer name, email, and phone are required' 
      }, 400);
    }
    
    if (!bookingData.checkIn || !bookingData.checkOut) {
      return c.json({ 
        success: false, 
        error: 'Check-in and check-out dates are required' 
      }, 400);
    }
    
    if (!bookingData.cats || bookingData.cats.length === 0) {
      return c.json({ 
        success: false, 
        error: 'At least one cat is required' 
      }, 400);
    }
    
    if (!bookingData.rooms || bookingData.rooms.length === 0) {
      return c.json({ 
        success: false, 
        error: 'At least one room must be selected' 
      }, 400);
    }
    
    // Generate booking reference
    const reference = 'BK' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 5).toUpperCase();
    
    // Store booking in KV store
    const bookingId = `booking:${Date.now()}:${bookingData.customer.email}`;
    await kv.set(bookingId, {
      ...bookingData,
      reference,
      status: 'pending',
      createdAt: new Date().toISOString(),
    });
    
    // Update or create customer record
    const customerKey = `customer:${bookingData.customer.email}`;
    const existingCustomer = await kv.get(customerKey);
    
    if (!existingCustomer) {
      // New customer - create profile
      await kv.set(customerKey, {
        id: bookingData.customer.email,
        name: bookingData.customer.name,
        email: bookingData.customer.email,
        phone: bookingData.customer.phone,
        address: bookingData.customer.address,
        firstBookingDate: new Date().toISOString(),
        totalBookings: 1,
        // TODO: Store hashed password for returning customers
        password: 'temp123' // Placeholder
      });
      
      // Store cats
      for (const cat of bookingData.cats) {
        const catId = cat.id || `cat:${bookingData.customer.email}:${Date.now()}:${Math.random()}`;
        await kv.set(catId, {
          ...cat,
          id: catId,
          ownerId: bookingData.customer.email
        });
      }
    } else {
      // Update existing customer
      await kv.set(customerKey, {
        ...existingCustomer,
        totalBookings: (existingCustomer.totalBookings || 0) + 1,
        lastBookingDate: new Date().toISOString(),
        // Update contact info if changed
        phone: bookingData.customer.phone,
        address: bookingData.customer.address || existingCustomer.address,
      });
    }
    
    // TODO: Send email and SMS notifications
    console.log(`Booking ${reference} created for ${bookingData.customer.email}`);
    
    // TODO: Notify admin via portal
    
    return c.json({ 
      success: true,
      reference,
      bookingId,
      message: 'Booking request submitted successfully'
    });
  } catch (error) {
    console.error('Create booking error:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Get customer booking history
app.get("/make-server-4cdbd524/customers/:email/bookings", async (c) => {
  try {
    const email = c.req.param('email');
    const bookings = await kv.getByPrefix(`booking:`) || [];
    
    // Filter bookings for this customer
    const customerBookings = bookings.filter((b: any) => b.customerEmail === email);
    
    return c.json({ 
      success: true, 
      bookings: customerBookings,
      isReturningClient: customerBookings.length > 1
    });
  } catch (error) {
    console.error('Error fetching customer bookings:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Analyze fields endpoint
app.post("/make-server-4cdbd524/import/analyze", async (c) => {
  try {
    const { userColumns, importType } = await c.req.json();
    const mappings = analyzeFields(userColumns, importType);
    return c.json({ 
      success: true, 
      mappings
    });
  } catch (error) {
    console.error('Error analyzing import data:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Detect new fields endpoint
app.post("/make-server-4cdbd524/import/detect-new", async (c) => {
  try {
    const { mappings } = await c.req.json();
    const newFields = detectNewFields(mappings);
    return c.json({ 
      success: true, 
      newFields
    });
  } catch (error) {
    console.error('Error detecting new fields in import data:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Process import endpoint
app.post("/make-server-4cdbd524/import/process", async (c) => {
  try {
    const { data, mappings, importType, newFields } = await c.req.json();
    const result = await processImport(data, mappings, importType, newFields);
    return c.json({ 
      success: true, 
      ...result
    });
  } catch (error) {
    console.error('Error processing import data:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Export data endpoint
app.get("/make-server-4cdbd524/export/:importType", async (c) => {
  try {
    const importType = c.req.param('importType');
    const csvData = await exportData(importType);
    
    return new Response(csvData, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${importType}-export-${Date.now()}.csv"`,
      },
    });
  } catch (error) {
    console.error('Error exporting data:', error);
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }, 500);
  }
});

// Image upload endpoint
app.post("/make-server-4cdbd524/upload-image", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ success: false, error: 'No file provided' }, 400);
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      return c.json({ success: false, error: 'File must be an image' }, 400);
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return c.json({ success: false, error: 'File size must be less than 5MB' }, 400);
    }

    // Create Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    // Ensure bucket exists
    const bucketName = 'make-4cdbd524-website-images';
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      await supabase.storage.createBucket(bucketName, {
        public: false,
        fileSizeLimit: 5242880, // 5MB
      });
    }

    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${crypto.randomUUID()}.${fileExt}`;
    const filePath = `uploads/${fileName}`;

    // Convert File to ArrayBuffer then to Uint8Array
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);

    // Upload file to Supabase Storage
    const { data, error } = await supabase.storage
      .from(bucketName)
      .upload(filePath, uint8Array, {
        contentType: file.type,
        upsert: false,
      });

    if (error) {
      console.error('Error uploading image to Supabase Storage:', error);
      throw new Error(`Upload failed: ${error.message}`);
    }

    // Get signed URL (valid for 1 year)
    const { data: signedUrlData } = await supabase.storage
      .from(bucketName)
      .createSignedUrl(filePath, 31536000); // 1 year in seconds

    if (!signedUrlData) {
      throw new Error('Failed to generate signed URL');
    }

    console.log(`Image uploaded successfully: ${filePath}`);

    return c.json({
      success: true,
      url: signedUrlData.signedUrl,
      path: filePath,
    });
  } catch (error) {
    console.error('Error uploading image:', error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    }, 500);
  }
});

Deno.serve(app.fetch);