// Note: Resend integration is prepared but requires RESEND_API_KEY environment variable
// For now, we'll simulate email sending with console logging

interface BookingDetails {
  customerName: string;
  customerEmail: string;
  catName: string;
  checkIn: string;
  checkOut: string;
  roomType: string;
  totalPrice: number;
  isReturningClient: boolean;
  catteryName?: string;
}

export async function sendBookingConfirmationEmail(booking: BookingDetails) {
  const { customerName, customerEmail, catName, checkIn, checkOut, roomType, totalPrice, isReturningClient, catteryName = 'Deloraine Cattery' } = booking;

  const petcoverSection = isReturningClient 
    ? generateReturningClientPetcoverSection()
    : generateNewClientPetcoverSection();

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Booking Confirmation</title>
      <style>
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.6;
          color: #1F2A44;
          background-color: #F7F4EF;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 40px auto;
          background-color: #ffffff;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 12px rgba(31, 42, 68, 0.08);
        }
        .header {
          background: linear-gradient(135deg, #1F2A44 0%, #2a3a5a 100%);
          color: #ffffff;
          padding: 40px 30px;
          text-align: center;
        }
        .header h1 {
          margin: 0;
          font-family: 'Fraunces', serif;
          font-size: 28px;
          font-weight: 600;
        }
        .content {
          padding: 40px 30px;
        }
        .greeting {
          font-size: 18px;
          color: #1F2A44;
          margin-bottom: 20px;
        }
        .intro {
          color: #4a5568;
          margin-bottom: 30px;
          font-size: 16px;
        }
        .booking-details {
          background-color: #F7F4EF;
          border-radius: 12px;
          padding: 25px;
          margin-bottom: 30px;
        }
        .booking-details h2 {
          font-family: 'Fraunces', serif;
          font-size: 20px;
          color: #1F2A44;
          margin-top: 0;
          margin-bottom: 20px;
        }
        .detail-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid #e2d9cc;
        }
        .detail-row:last-child {
          border-bottom: none;
        }
        .detail-label {
          color: #718096;
          font-weight: 500;
        }
        .detail-value {
          color: #1F2A44;
          font-weight: 600;
        }
        .total-row {
          margin-top: 15px;
          padding-top: 15px;
          border-top: 2px solid #C86B3C;
        }
        .total-row .detail-label,
        .total-row .detail-value {
          font-size: 18px;
          color: #C86B3C;
        }
        .petcover-section {
          background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 100%);
          border: 2px solid #86efac;
          border-radius: 12px;
          padding: 30px;
          margin: 30px 0;
        }
        .petcover-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 20px;
        }
        .petcover-icon {
          width: 32px;
          height: 32px;
          background-color: #22c55e;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        }
        .petcover-header h3 {
          font-family: 'Fraunces', serif;
          font-size: 20px;
          color: #166534;
          margin: 0;
        }
        .petcover-content {
          color: #166534;
          line-height: 1.8;
          margin-bottom: 20px;
        }
        .petcover-content strong {
          color: #14532d;
        }
        .promo-box {
          background-color: #ffffff;
          border-radius: 8px;
          padding: 15px;
          margin: 20px 0;
          border-left: 4px solid #22c55e;
        }
        .promo-label {
          font-size: 12px;
          text-transform: uppercase;
          color: #16a34a;
          font-weight: 600;
          margin-bottom: 5px;
        }
        .promo-code {
          font-size: 20px;
          font-weight: 700;
          color: #14532d;
          font-family: monospace;
          letter-spacing: 2px;
        }
        .cta-button {
          display: inline-block;
          background-color: #22c55e;
          color: #ffffff;
          text-decoration: none;
          padding: 14px 28px;
          border-radius: 8px;
          font-weight: 600;
          font-size: 16px;
          margin: 10px 0;
          transition: background-color 0.2s;
        }
        .cta-button:hover {
          background-color: #16a34a;
        }
        .fine-print {
          font-size: 13px;
          color: #15803d;
          margin-top: 15px;
          line-height: 1.6;
        }
        .footer {
          background-color: #F7F4EF;
          padding: 30px;
          text-align: center;
          color: #718096;
          font-size: 14px;
        }
        .footer-info {
          margin-bottom: 15px;
        }
        .footer-contact {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #e2d9cc;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🐱 Booking Confirmed</h1>
        </div>
        
        <div class="content">
          <div class="greeting">
            Hello ${customerName},
          </div>
          
          <div class="intro">
            Thank you for choosing ${catteryName} for ${catName}'s stay! We're delighted to confirm your booking and look forward to welcoming your cat to our boutique cattery.
          </div>
          
          <div class="booking-details">
            <h2>Booking Details</h2>
            <div class="detail-row">
              <span class="detail-label">Cat Name</span>
              <span class="detail-value">${catName}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Check-in</span>
              <span class="detail-value">${checkIn}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Check-out</span>
              <span class="detail-value">${checkOut}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Room Type</span>
              <span class="detail-value">${roomType}</span>
            </div>
            <div class="detail-row total-row">
              <span class="detail-label">Total Price</span>
              <span class="detail-value">NZD $${totalPrice.toFixed(2)}</span>
            </div>
          </div>
          
          ${petcoverSection}
          
          <div style="margin-top: 30px; padding: 20px; background-color: #F7F4EF; border-radius: 8px;">
            <h3 style="font-family: 'Fraunces', serif; color: #1F2A44; margin-top: 0;">What to Bring</h3>
            <ul style="color: #4a5568; margin: 10px 0; padding-left: 20px;">
              <li>Current vaccination certificate</li>
              <li>Your cat's favorite food (if preferred)</li>
              <li>Any medications with clear instructions</li>
              <li>A comfort item (blanket or toy) if desired</li>
            </ul>
          </div>
          
          <div style="margin-top: 30px; color: #4a5568;">
            <p>If you have any questions or need to make changes to your booking, please don't hesitate to contact us.</p>
            <p style="margin-top: 25px;">We can't wait to meet ${catName}! 🐾</p>
            <p style="margin-top: 20px;">Warm regards,<br><strong>${catteryName} Team</strong></p>
          </div>
        </div>
        
        <div class="footer">
          <div class="footer-info">
            <strong>${catteryName}</strong><br>
            Premium Cat Boarding
          </div>
          <div class="footer-contact">
            📞 Contact us: info@delorainecattery.co.nz<br>
            🌐 Visit: www.delorainecattery.co.nz
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    // Log the email content for demo purposes
    console.log('📧 Booking confirmation email generated:');
    console.log(`To: ${customerEmail}`);
    console.log(`Subject: Booking Confirmed - ${catName}'s Stay at ${catteryName}`);
    console.log('HTML content generated successfully');
    
    // Note: To enable actual email sending, configure RESEND_API_KEY in environment variables
    // and uncomment the Resend integration code
    
    // For now, return success with the generated HTML for demo purposes
    return { 
      success: true, 
      data: { 
        id: `demo-${Date.now()}`,
        customerEmail,
        subject: `Booking Confirmed - ${catName}'s Stay at ${catteryName}`,
        htmlPreview: htmlContent
      } 
    };
  } catch (error) {
    console.error('Error in sendBookingConfirmationEmail:', error);
    throw error;
  }
}

function generateNewClientPetcoverSection(): string {
  return `
    <div class="petcover-section">
      <div class="petcover-header">
        <div class="petcover-icon">🛡️</div>
        <h3>Complimentary Pet Insurance for Your Stay</h3>
      </div>
      
      <div class="petcover-content">
        <p>As part of your booking with Deloraine Cattery, we're pleased to offer <strong>4 weeks of complimentary Petcover pet insurance</strong> for your cat.</p>
        
        <p>This policy provides additional peace of mind while your pet is staying with us and continues to protect them after they return home.</p>
        
        <p>To activate your free policy, simply follow the link below and enter your pet's details. It only takes a minute and your policy documents will be emailed to you immediately.</p>
        
        <div style="text-align: center; margin: 25px 0;">
          <a href="https://partners-nz.petcovergroup.com/nz/pet-business" class="cta-button">
            Activate Your Free Petcover Policy
          </a>
        </div>
        
        <div class="promo-box">
          <div class="promo-label">Promo code for cats over 12 months of age:</div>
          <div class="promo-code">CATTERY4WK</div>
        </div>
        
        <div class="fine-print">
          <p><strong>Important:</strong> The policy can be activated the day before, on the day of, or the day after your cat's stay.</p>
          
          <p>If you have any questions about the cover, the Petcover team can assist you directly.</p>
          
          <p>We're delighted to provide this additional protection as part of your cat's stay with us.</p>
        </div>
      </div>
    </div>
  `;
}

function generateReturningClientPetcoverSection(): string {
  return `
    <div class="petcover-section">
      <div class="petcover-header">
        <div class="petcover-icon">🛡️</div>
        <h3>Petcover Insurance Reminder</h3>
      </div>
      
      <div class="petcover-content">
        <p>As one of our returning clients, you may remember that we offer <strong>4 weeks of complimentary Petcover insurance</strong> for your cat when they stay with us.</p>
        
        <p>If you didn't activate the policy during your previous stay, you're welcome to take advantage of it this time.</p>
        
        <p>If you already used the free policy and would like to continue cover, Petcover also offers special discounted plans for existing customers.</p>
        
        <div style="text-align: center; margin: 25px 0;">
          <a href="https://partners-nz.petcovergroup.com/nz/pet-business" class="cta-button">
            Activate Your Complimentary Cover
          </a>
        </div>
        
        <div class="promo-box">
          <div class="promo-label">Promo code:</div>
          <div class="promo-code">CATTERY4WK</div>
        </div>
        
        <div class="fine-print">
          <p><strong>Note:</strong> The free policy can be activated the day before, on the day of, or the day after your cat's stay.</p>
          
          <p>We're happy to offer this additional protection to help keep your pet safe and covered beyond their visit.</p>
        </div>
      </div>
    </div>
  `;
}