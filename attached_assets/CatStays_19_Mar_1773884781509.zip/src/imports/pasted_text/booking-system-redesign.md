Redesign and upgrade the CatStays / StayDirect booking system into a premium, fully integrated booking + insurance experience.

This system must:

* feel like a high-end website (not a form)
* support new + returning customers
* reduce friction for returning users
* include a fully functional booking engine
* include optional pet insurance (PetCover-style)
* include full compliance capture
* be scalable for global insurance providers

---

## CORE PRINCIPLES

* Everything MUST inherit the host website theme (no default system colours)
* NO random AI colours (greens, purples, etc.)
* Clean, calm, premium UX
* Modular and scalable system
* No broken logic (pricing, eligibility, etc.)
* Returning users should move fast with minimal input

---

## PART 1: BOOKING FLOW STRUCTURE

STEP 1: Choose Your Stay

* Check-in date picker
* Check-out date picker
* CTA: “Check Availability”

IF available → continue

IMPORTANT:

* DO NOT show pricing at this stage

---

STEP 2: CUSTOMER TYPE (NEW VS EXISTING)

Display immediately after availability check:

“Have you booked with us before?”

Options:

* Existing Customer (Login)
* New Customer (Continue)

---

EXISTING CUSTOMER FLOW

Login:

* Email
* Password
* CTA: “Login & Continue”

After login:

Display message (top of screen, friendly tone):
“Welcome back — we’ve filled everything in for you”

Then:

* User is logged into client portal
* Taken directly back into booking flow

UX behaviour:

* All previously entered data is:

  * Auto-filled
  * Displayed in collapsed sections
  * Expandable if user wants to edit

User can access:

* Cat profiles
* Booking history
* Saved details

---

STEP 3: BOOKING DETAILS

Layout:

* Left: booking flow
* Right: pricing summary (ONLY place pricing appears)

---

DATES

* Pre-filled from availability
* Editable inline (calendar visible again)

---

CAT SELECTION

* Select existing cats
* Option: “+ Add New Cat”

Support:

* Multiple cats per room
* Assign cats across rooms

---

ROOM SELECTION

* Select room type
* Select room quantity
* Allow switching rooms before submission

---

PART 2: PET INSURANCE MODULE (CONDITIONAL)

LOGIC:

IF customer has already received introductory insurance previously:
→ DO NOT show module

IF customer has NOT:
→ Show module

---

INSURANCE CARD

Title:
“Protect your pet’s stay with complimentary introductory insurance”

* Show provider name
* Link to provider website

Toggle:
YES / NO

---

IF YES → EXPAND FLOW

---

FINAL CONFIRMATION (CRITICAL)

Title:
“This only takes 10 seconds. Please confirm the statements below”

Checklist (required):

☐ Pet is up to date with vaccinations and healthy
☐ No pre-existing conditions or medical history
☐ No existing insurance or prior introductory cover
☐ Owner has been informed of the cover
☐ Waiting periods understood:

* 3 days injury
* 7 days illness
* 12 months brachycephalic airway
* excess applies
  ☐ Information provided is accurate and complete

FINAL CHECKBOX:
☐ I confirm all statements above are true

CTA:
“Confirm Insurance Cover”

RULE:

* Button disabled until all boxes ticked

---

PART 3: PRICING SUMMARY (FIX REQUIRED)

Right-hand sticky panel ONLY

Must include:

* Room cost × nights
* Additional cats
* Extras if any

RULES:

* MUST calculate correctly
* NO incorrect totals
* NO negative values
* DO NOT show pricing earlier in flow

---

PART 4: SUBMIT BOOKING

CTA:
“Submit Booking Request”

---

PART 5: POST-SUBMISSION BEHAVIOUR

Customer receives:

* Email confirmation
* SMS notification (if enabled)
* Portal notification

---

PORTAL LOGIC

Booking appears under:
“New Bookings”

Status:

* Highlighted
* “Pending / Requires Acceptance”

User must:
→ Accept booking to confirm it

Also:

* Notification appears in alerts
* Visible immediately on login

---

PART 6: BACKEND + AUTOMATION

On booking submission:

1. Save booking

2. Send notifications:

   * Email
   * SMS (optional)
   * Portal alert

3. If insurance selected:

   * Save insurance request
   * Notify admin

---

PART 7: LIVE PREVIEW BUILDER

Preview must:

* show full booking experience
* allow full interaction
* include insurance flow

Left panel:

* controls content (Shopify-style editor)

---

PART 8: UX TONE

Tone:

* calm
* premium
* effortless

Use:

* soft cards
* smooth transitions
* inline validation

Avoid:

* harsh alerts
* clunky forms

---

SUCCESS CRITERIA

✔ Returning users skip friction
✔ Insurance shown only when eligible
✔ All compliance captured correctly
✔ Booking triggers notifications
✔ Portal shows pending bookings clearly
✔ Pricing is always correct
✔ No duplicate insurance issued
✔ Fully theme-aware design
✔ Premium seamless UX
