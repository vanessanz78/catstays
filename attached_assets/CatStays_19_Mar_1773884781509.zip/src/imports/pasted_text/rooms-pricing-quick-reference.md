# Rooms & Pricing - Quick Reference Guide

## 🎯 One-Minute Overview

**What:** Intelligent room and pricing configuration with auto-detected tax
**Why:** Minimize user effort, adapt globally, ensure accuracy
**How:** Smart defaults + real-time calculations + progressive disclosure

---

## 🚀 Quick Start

### For Developers

```tsx
import { RoomsPricingStep } from '../onboarding/RoomsPricingStep';

<RoomsPricingStep
  businessAddress="123 Queen St, Auckland, New Zealand"
  onComplete={(data) => console.log(data)}
/>
```

### For Testing

Visit: `/demo/rooms-pricing`

---

## 🌍 Tax Detection Cheat Sheet

| Country/Region | Tax Type | Default Rate | Label |
|----------------|----------|--------------|-------|
| New Zealand | GST | 15% | GST (New Zealand) |
| Australia | GST | 10% | GST (Australia) |
| UK | VAT | 20% | VAT (United Kingdom) |
| Ireland | VAT | 23% | VAT (Ireland) |
| France | VAT | 20% | VAT (France) |
| Germany | VAT | 19% | VAT (Germany) |
| Spain | VAT | 21% | VAT (Spain) |
| California, USA | Sales Tax | 7.25% | Sales Tax (California, USA) |
| Canada | GST/HST | 5% | GST/HST (Canada) |
| Generic USA | Sales Tax | 0% | Sales Tax (USA) |
| Unknown | Sales Tax | 0% | Sales Tax |

---

## 📋 Field Reference

### ROOMS
```
Room Type Name:        Text input (required)
Number of Rooms:       Number input (min: 1)
Max Cats per Room:     Number input (min: 1)
Shared Room:           Radio (Yes/No)
```

### PRICING
```
Pricing Type:          Radio (Per Day/Per Night)
Base Price:            Number input ($)
```

### TAX (AUTO-DETECTED)
```
Tax Label:             Auto-detected (can't change)
Tax Inclusive:         Radio (Yes/No)
Tax Rate:              Number input (%) - pre-filled, editable
```

### MULTI-CAT (OPTIONAL)
```
Enable Toggle:         Checkbox
Discount Per Cat:      Number input ($)
```

### ROOM RULES (OPTIONAL)
```
Enable Toggle:         Checkbox
Shared Adjustment:     Number input ($) - can be negative
Private Adjustment:    Number input ($) - can be positive
```

---

## 💰 Tax Calculation Examples

### Example 1: Tax Inclusive (NZ)
```
User enters: $45
Tax rate: 15% (GST)
Tax inclusive: Yes

Calculation:
Base = 45 / 1.15 = $39.13
Tax = 45 - 39.13 = $5.87
Total = $45.00
```

### Example 2: Tax Exclusive (UK)
```
User enters: £30
Tax rate: 20% (VAT)
Tax inclusive: No

Calculation:
Base = $30.00
Tax = 30 * 0.20 = £6.00
Total = 30 + 6 = £36.00
```

### Example 3: No Tax (Oregon, USA)
```
User enters: $40
Tax rate: 0% (no sales tax)
Tax inclusive: No

Calculation:
Base = $40.00
Tax = 0.00
Total = $40.00
```

---

## 🎨 UI Component Icons

```
🏠 Home          → Rooms section
💲 DollarSign    → Pricing section
🧾 Receipt       → Tax section
🐾 PawPrint      → Multi-cat section
📊 Users         → Room rules section
```

---

## 📦 Data Structure Quick View

```typescript
{
  rooms: [
    {
      id: "1",
      name: "Private Suite",
      numberOfRooms: 5,
      maxCatsPerRoom: 1,
      isShared: false
    }
  ],
  pricingType: "per_day",
  basePrice: 45,
  taxType: "GST",
  taxLabel: "GST (New Zealand)",
  taxRate: 15,
  taxInclusive: true,
  country: "New Zealand",
  multiCatDiscount: false,
  discountPerCat: 0,
  roomPricingRules: false,
  sharedPriceAdjustment: 0,
  privatePriceAdjustment: 0
}
```

---

## 🔧 Common Tasks

### Adding a New Country

**File:** `/src/app/utils/taxDetection.ts`

```typescript
// Add to detectTaxFromAddress function
if (
  addressLower.includes('singapore') || 
  addressLower.includes('sg')
) {
  return {
    taxType: 'GST',
    taxLabel: 'GST (Singapore)',
    defaultRate: 8,
    country: 'Singapore',
  };
}
```

### Updating a Tax Rate

```typescript
// Find the country section
if (addressLower.includes('new zealand')) {
  return {
    taxType: 'GST',
    taxLabel: 'GST (New Zealand)',
    defaultRate: 15,  // <-- Update this
    country: 'New Zealand',
  };
}
```

### Customizing Colors

```tsx
// In RoomsPricingStep.tsx
className="bg-[#C46A3A]"  // Terracotta (primary actions)
className="bg-[#4F6F5A]"  // Sage (success states)
className="bg-[#0A1128]"  // Navy (text)
className="bg-[#F8F7F5]"  // Cream (backgrounds)
```

---

## 🐛 Troubleshooting

### Tax not detecting correctly?
1. Check address string format
2. Verify keywords in taxDetection.ts
3. Test with multiple address formats
4. Check browser console for errors

### Calculation showing wrong numbers?
1. Verify tax rate is correct
2. Check tax-inclusive toggle state
3. Ensure basePrice > 0
4. Review calculateTaxBreakdown function

### Animations not smooth?
1. Check for CSS conflicts
2. Verify Tailwind classes are applied
3. Test in different browsers
4. Reduce animation duration if needed

### Component not receiving data?
1. Verify businessAddress prop is passed
2. Check onComplete callback
3. Inspect localStorage for saved data
4. Review React DevTools

---

## 📱 Responsive Breakpoints

```css
Mobile:   < 768px   (single column, stacked)
Tablet:   768-1024px (mixed layout)
Desktop:  > 1024px  (full features)
```

---

## ✅ Pre-Launch Checklist

- [ ] All tax rates verified and current
- [ ] Test with 10+ different addresses
- [ ] Verify calculations for edge cases
- [ ] Check responsive design on mobile
- [ ] Validate form error handling
- [ ] Test with screen readers
- [ ] Verify data saving/loading
- [ ] Run performance tests
- [ ] Check browser compatibility
- [ ] Review microcopy for clarity

---

## 📊 Success Metrics to Track

1. **Tax Detection Accuracy:** Target >95%
2. **Setup Time:** Target <3 minutes
3. **Completion Rate:** Target >85%
4. **Support Tickets:** Target <1% for tax issues
5. **User Satisfaction:** Target >90% "easy to use"

---

## 🔗 Related Files

### Core Implementation
- `/src/app/pages/onboarding/RoomsPricingStep.tsx` - Main component
- `/src/app/utils/taxDetection.ts` - Tax logic

### Demo & Testing
- `/src/app/pages/demo/RoomsPricingDemo.tsx` - Interactive demo
- `/demo/rooms-pricing` - Live demo route

### Documentation
- `/src/imports/pasted_text/rooms-pricing-implementation-summary.md` - Full docs
- `/src/imports/pasted_text/rooms-pricing-quick-reference.md` - This file

---

## 💡 Pro Tips

### For Optimal User Experience
1. Always pre-fill with smart defaults
2. Show live calculations immediately
3. Use progressive disclosure for advanced features
4. Provide clear microcopy at every step
5. Allow easy override of auto-detected values

### For Developers
1. Keep tax detection logic separate
2. Make calculations pure functions
3. Use TypeScript for type safety
4. Add comprehensive error handling
5. Test edge cases thoroughly

### For Product Managers
1. Monitor tax detection accuracy
2. Track completion rates by country
3. Gather feedback on pricing setup
4. A/B test different default values
5. Iterate based on support tickets

---

## 🎓 Training Resources

### For Support Team
- **Demo link:** `/demo/rooms-pricing`
- **Test accounts:** Use addresses from different countries
- **Common questions:** See troubleshooting section
- **Escalation:** Tax rate disputes require manual verification

### For Sales Team
- **Key selling points:** Auto-detection, global support, flexibility
- **Demo script:** Start with location selector, show live calculations
- **Competitive advantage:** Most competitors require manual tax setup
- **ROI:** Saves 5-10 minutes per onboarding

---

## 🚀 Quick Deployment Guide

### Development
```bash
npm run dev
# Visit: http://localhost:3000/demo/rooms-pricing
```

### Testing
```bash
# Unit tests
npm run test -- taxDetection

# E2E tests
npm run test:e2e -- rooms-pricing
```

### Production
```bash
# Build
npm run build

# Deploy
npm run deploy
```

---

## 📞 Support Contacts

### For Technical Issues
- **Developer:** Check GitHub issues
- **Documentation:** See full implementation summary
- **Slack:** #catstays-dev channel

### For Product Questions
- **Product Lead:** Review user feedback
- **UX Designer:** Check user testing results
- **Analytics:** Review completion metrics

---

## 🎯 Remember

**Core Philosophy:**
> "This system already understands my business"

**User Goal:**
> Complete setup quickly with minimal thinking

**Business Goal:**
> High completion rate, low support burden

**Technical Goal:**
> Clean, maintainable, extensible code

---

## ✨ That's It!

You now have everything you need to:
- ✅ Implement the component
- ✅ Test thoroughly
- ✅ Deploy confidently
- ✅ Support effectively
- ✅ Iterate intelligently

**Happy coding! 🐾**
