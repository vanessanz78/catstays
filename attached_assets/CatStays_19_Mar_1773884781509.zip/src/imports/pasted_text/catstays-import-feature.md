Design a feature for **CatStays admin dashboard** called:

Smart Import & Data Setup

This allows new users to import their existing business data when onboarding.

---

OVERVIEW

The feature should allow importing:

• Customers
• Cats (pets)
• Bookings (past and future)
• Rooms / enclosures
• Custom fields

The experience must feel **simple, guided, and intelligent**, not technical.

---

SCREEN 1 — IMPORT DASHBOARD

Title:
Import Your Existing Data

Subtext:
Upload your files and we’ll automatically organise everything for you.

Display 4 large cards:

Import Customers
Import Cats
Import Bookings
Import Rooms

Each card has:

• icon
• short description
• "Upload File" button

Include drag-and-drop upload zone.

Supported formats:
CSV, Excel

---

SCREEN 2 — AI PROCESSING

After upload, show loading state:

Title:
We’re organising your data…

Subtext:
Our AI is matching your columns to the right fields.

Include animated progress indicator.

---

SCREEN 3 — FIELD MAPPING (AI-ASSISTED)

Title:
Review & Confirm Your Data

Display a table preview.

Left column:
User’s uploaded column names

Right column:
Matched system fields

Examples:

Customer Name → Name
Phone Number → Phone
Cat Name → Pet Name
Arrival Date → Check-in Date

Each row has dropdown to adjust mapping.

---

SMART AI FEATURES

Highlight AI suggestions:

“Auto-matched with 92% confidence”

Flag unclear fields:

“Not sure about this — please confirm”

---

SCREEN 4 — NEW FIELD CREATION

If data contains fields not in system:

Show section:

New Fields Detected

Examples:

• Feeding Instructions
• Vet Contact
• Medication Notes

Options:

✔ Add to system
✔ Ignore

If added:

These become new dynamic fields in the database and UI.

---

SCREEN 5 — DATA PREVIEW

Show preview of imported data:

Customers
Cats
Bookings

Allow user to:

• edit rows inline
• remove incorrect entries

---

SCREEN 6 — CONFIRM IMPORT

Title:
Ready to Import

Summary:

• 120 customers
• 85 cats
• 240 bookings

Button:

Import Everything

---

SCREEN 7 — SUCCESS STATE

Title:
Your Data Is Ready

Subtext:
Everything has been successfully imported and organised.

Buttons:

Go to Dashboard
View Customers
View Bookings

---

EXPORT FEATURE

Add export functionality in settings.

Title:
Export Your Data

Options:

Export Customers
Export Cats
Export Bookings

Formats:

CSV
Excel

Include button:

Download Data

---

UX STYLE

Keep design:

• clean
• warm
• non-technical
• reassuring

Use CatStays brand:

Navy #1F2A44
Terracotta #C86B3C
Soft backgrounds

Use rounded cards and soft shadows.

---

KEY EXPERIENCE GOAL

The user should feel:

“I just uploaded everything and it magically worked.”

Avoid technical language like:

“database schema” or “field mapping”

Instead use:

“Match your information”
“Review your details”
“Add missing info”
