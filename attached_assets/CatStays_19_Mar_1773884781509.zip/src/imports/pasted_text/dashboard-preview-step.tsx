Ah, I understand! You want a prompt to use in the OTHER Figma session to locate the dashboard there and link it to Step 5. Here's the diagnostic and implementation prompt:

Prompt for Other Figma Session
I need to locate my existing cattery dashboard and link it to Step 5 of my onboarding wizard. Please help me find it and connect them.

Part 1: Locate the Dashboard (Diagnostic)
First, please search for the dashboard files:

Check for these dashboard files:

/src/app/pages/admin/Dashboard.tsx
/src/app/pages/admin/ModernDashboard.tsx
/src/app/pages/admin/Bookings.tsx
Any other files in /src/app/pages/admin/ directory
Search for dashboard components:

Search for files containing "AdminDashboard"
Search for files containing "arrivals" and "departures"
Search for files containing "swipeable" or "date navigation"
Check the routes:

Look at /src/app/routes.tsx or /src/app/routes.ts
Show me all routes that start with /admin
List the entire admin directory:

Show me all files in /src/app/pages/admin/
Please do these searches first and tell me what you find. Don't make any changes yet.

Part 2: Once Dashboard is Found
After you've confirmed the dashboard exists, please:

Create a device preview component at /src/app/pages/onboarding/DashboardPreviewStep.tsx with this code:
import { useState } from 'react';
import { Smartphone, Tablet, Laptop } from 'lucide-react';
import { Button } from '../../components/ui/button';
// IMPORTANT: Import whatever the actual dashboard component is named
// Could be: AdminDashboard, Dashboard, ModernDashboard, etc.
import { AdminDashboard } from '../admin/Dashboard'; // <-- Adjust this import based on what you find

type DeviceType = 'mobile' | 'tablet' | 'laptop';

export function DashboardPreviewStep() {
  const [device, setDevice] = useState<DeviceType>('mobile');

  const deviceFrames = {
    mobile: {
      width: 375,
      height: 667,
      scale: 0.8,
      borderRadius: '36px',
      padding: '16px',
      bezel: true
    },
    tablet: {
      width: 768,
      height: 1024,
      scale: 0.5,
      borderRadius: '24px',
      padding: '24px',
      bezel: true
    },
    laptop: {
      width: 1440,
      height: 900,
      scale: 0.4,
      borderRadius: '12px',
      padding: '0px',
      bezel: false
    }
  };

  const currentDevice = deviceFrames[device];

  return (
    <div className="space-y-6">
      {/* Device Selector */}
      <div className="flex justify-center gap-3">
        <Button
          onClick={() => setDevice('mobile')}
          variant={device === 'mobile' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'mobile' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          Mobile
        </Button>
        <Button
          onClick={() => setDevice('tablet')}
          variant={device === 'tablet' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'tablet' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Tablet className="w-4 h-4" />
          Tablet
        </Button>
        <Button
          onClick={() => setDevice('laptop')}
          variant={device === 'laptop' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'laptop' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Laptop className="w-4 h-4" />
          Laptop
        </Button>
      </div>

      {/* Device Preview Frame */}
      <div className="flex justify-center items-center py-8">
        <div 
          className="relative bg-white shadow-2xl"
          style={{
            width: `${currentDevice.width * currentDevice.scale}px`,
            height: `${currentDevice.height * currentDevice.scale}px`,
            borderRadius: currentDevice.borderRadius,
            border: currentDevice.bezel ? '8px solid #1a1a1a' : '1px solid #e5e5e5',
            overflow: 'hidden'
          }}
        >
          {/* Device Notch (for mobile only) */}
          {device === 'mobile' && (
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-[#1a1a1a] rounded-b-2xl z-10" />
          )}

          {/* Scrollable Dashboard Content */}
          <div 
            className="w-full h-full overflow-auto"
            style={{
              transform: `scale(${currentDevice.scale})`,
              transformOrigin: 'top left',
              width: `${currentDevice.width}px`,
              height: `${currentDevice.height}px`,
            }}
          >
            <AdminDashboard />
          </div>
        </div>
      </div>

      {/* Info Text */}
      <div className="bg-[#0A1128]/5 rounded-2xl p-6 text-center max-w-2xl mx-auto">
        <p className="text-[#0A1128]/70">
          This is what you and your staff will see when you click <strong>"Staff Login"</strong> on your website.
          The dashboard is fully responsive and works beautifully on any device.
        </p>
      </div>
    </div>
  );
}
Find the OnboardingWizard at /src/app/pages/onboarding/OnboardingWizard.tsx

Add the import at the top of OnboardingWizard.tsx:

import { DashboardPreviewStep } from './DashboardPreviewStep';
Find Step 5 in the OnboardingWizard and replace its content with:
{/* Step 5: Dashboard Preview */}
{step === 5 && (
  <div className="max-w-6xl mx-auto">
    <Card className="border-2 shadow-2xl rounded-3xl overflow-hidden">
      <CardHeader className="bg-gradient-to-br from-white to-[#F8F7F5] p-8">
        <CardTitle className="text-3xl font-serif text-[#0A1128] mb-2">
          Your Staff Dashboard
        </CardTitle>
        <CardDescription className="text-lg text-[#0A1128]/70">
          Manage arrivals, departures, and payments from anywhere
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-8">
        <DashboardPreviewStep />

        <div className="flex justify-between mt-8">
          <Button 
            onClick={handleBack}
            variant="outline"
            className="rounded-xl"
          >
            Back
          </Button>
          <Button 
            onClick={handleNext}
            className="bg-[#0A1128] hover:bg-[#0A1128]/90 text-white rounded-xl px-8"
          >
            Continue
          </Button>
        </div>
      </CardContent>
    </Card>
  </div>
)}
Test it:
Navigate to /onboarding
Go through to Step 5
Toggle between Mobile/Tablet/Laptop views
Verify the dashboard renders correctly
Important Notes:
If the dashboard component has a different name (like ModernDashboard or just Dashboard), adjust the import in DashboardPreviewStep.tsx accordingly
If the dashboard is at a different path, update the import path
If Step 5 is actually a different step number, adjust the step === 5 condition
Make sure the dashboard component is exported properly from its file
What to Report Back:
Please tell me:

✅ or ❌ - Does /src/app/pages/admin/Dashboard.tsx exist?
✅ or ❌ - What is the exact component name exported?
✅ or ❌ - Does the OnboardingWizard exist?
What is the current content of Step 5?
