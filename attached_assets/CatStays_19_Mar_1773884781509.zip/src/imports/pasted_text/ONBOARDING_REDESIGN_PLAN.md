# CatStays Onboarding Redesign - Implementation Plan

## Status: IN PROGRESS

## Overview
This document outlines the comprehensive redesign of the CatStays onboarding flow to be more logical, state-driven, and conversion-optimized.

---

## ✅ COMPLETED

### 1. Account Created Screen Redesign
- **Location:** `/src/app/pages/onboarding/OnboardingWizard.tsx` (Step 1)
- **Changes:**
  - Warm, premium design with paw icon and soft glow
  - Elegant typography using Playfair Display
  - Terracotta accents for brand consistency
  - Soft info card for email confirmation
  - Encouraging microcopy
  - Resend email functionality
  - Removed demo/technical elements

---

## 🎯 HIGH PRIORITY - TO IMPLEMENT

### 2. Step 3: Import or Start (Redesign)
**Current State:** Mixed layout with import field at top, "or start from scratch" at bottom
**Target State:** Two equal, prominent options presented side-by-side

**Changes Needed:**
```tsx
// Two-column grid layout
<div className="grid md:grid-cols-2 gap-6">
  {/* Option 1: Import from Website */}
  <div className="border-2 border-sage/20 rounded-2xl p-8 hover:border-sage/40 transition-all cursor-pointer">
    <div className="w-16 h-16 rounded-full bg-sage/10 flex items-center justify-center mx-auto mb-4">
      <Download className="w-8 h-8 text-sage" />
    </div>
    <h3>Import from Existing Website</h3>
    <p>We'll extract your logo, images, and content automatically</p>
    <Input placeholder="https://yourwebsite.com" />
    <Button>Import Now</Button>
  </div>

  {/* Option 2: Start from Scratch */}
  <div className="border-2 border-[#C46A3A]/20 rounded-2xl p-8 hover:border-[#C46A3A]/40 transition-all cursor-pointer">
    <div className="w-16 h-16 rounded-full bg-[#C46A3A]/10 flex items-center justify-center mx-auto mb-4">
      <Sparkles className="w-8 h-8 text-[#C46A3A]" />
    </div>
    <h3>Start from Template</h3>
    <p>Choose from beautiful pre-designed templates</p>
    <Button>Browse Templates</Button>
  </div>
</div>
```

### 3. Step 4: Website Builder with Live Preview (Major Change)
**Current State:** Single column with color pickers and form fields
**Target State:** Split-screen editor with live preview

**Layout:**
```
┌─────────────────────────────────────┐
│  LEFT PANEL (40%)    │ RIGHT (60%)  │
│  ─────────────────   │ ─────────    │
│  Brand Settings      │              │
│  - Logo Upload       │   LIVE       │
│  - Colors            │   WEBSITE    │
│  - Fonts             │   PREVIEW    │
│                      │              │
│  Layout Settings     │   (Fully     │
│  - Template Choice   │   Rendered)  │
│  - Section Editor    │              │
│                      │              │
│  Content             │   Scrollable │
│  - Hero Text         │              │
│  - About Section     │              │
└─────────────────────────────────────┘
```

**Implementation:**
- Use collapsible accordion sections for controls
- Real-time preview updates (debounced)
- Click-to-edit sections in preview
- Template selector with 3-5 options

### 4. Step 5: Integrate RoomsPricingStep
**Status:** Component exists at `/src/app/pages/onboarding/RoomsPricingStep.tsx`
**Action:** Replace current "Booking Rules" step with RoomsPricingStep component

**Changes:**
```tsx
// Import the component
import { RoomsPricingStep } from './RoomsPricingStep';

// In Step 5, replace content with:
<RoomsPricingStep
  businessAddress={data.location}
  onComplete={(pricingData) => {
    setData({ ...data, ...pricingData });
    handleNext();
  }}
  data={{
    rooms: data.rooms || [],
    pricingType: data.pricingType || 'per_night',
    multiCatDiscount: data.multiCatDiscount,
    taxRate: data.taxRate,
    pricesIncludeTax: data.pricesIncludeTax
  }}
/>
```

### 5. Step 8: Add Module Upsell (NEW STEP)
**Location:** Before current "Publish" step
**Purpose:** Smart upsell of premium features

**Design:**
```tsx
<CardHeader>
  <CardTitle>Enhance Your Cattery</CardTitle>
  <CardDescription>Add premium features to delight your customers</CardDescription>
</CardHeader>

<CardContent>
  <div className="grid md:grid-cols-2 gap-6">
    {[
      { 
        name: 'CatStays Photo Updates',
        description: 'AI-generated captions from your cat\'s perspective',
        price: '+$10/month',
        icon: Camera
      },
      {
        name: 'SMS Notifications',
        description: 'Automated booking confirmations and reminders',
        price: '+$5/month',
        icon: MessageSquare
      },
      {
        name: 'Daycare Module',
        description: 'Accept day-visit bookings alongside boarding',
        price: '+$15/month',
        icon: Sun
      },
      {
        name: 'Grooming Add-ons',
        description: 'Offer grooming services during stays',
        price: '+$10/month',
        icon: Scissors
      }
    ].map((module) => (
      <div className="border-2 rounded-2xl p-6 hover:border-sage transition-all">
        <div className="flex items-start justify-between mb-4">
          <module.icon className="w-8 h-8 text-sage" />
          <Badge>{module.price}</Badge>
        </div>
        <h4 className="font-semibold mb-2">{module.name}</h4>
        <p className="text-sm text-forest/70 mb-4">{module.description}</p>
        <Button variant="outline" size="sm">Add to Plan</Button>
      </div>
    ))}
  </div>

  <div className="mt-8 text-center">
    <Button variant="ghost" onClick={handleNext}>
      Skip for now
    </Button>
  </div>
</CardContent>
```

### 6. Step 10: Success Screen Redesign (Ownership Moment)
**Current State:** Generic success message
**Target State:** Celebratory, actionable, ownership-focused

**Design:**
```tsx
<div className="text-center py-12">
  {/* Celebration Animation */}
  <div className="relative w-32 h-32 mx-auto mb-6">
    <div className="absolute inset-0 bg-gradient-to-br from-[#C46A3A]/20 to-sage/20 rounded-full blur-2xl animate-pulse"></div>
    <div className="relative w-32 h-32 rounded-full bg-gradient-to-br from-[#C46A3A] to-sage flex items-center justify-center">
      <Cat className="w-16 h-16 text-white" />
    </div>
  </div>

  {/* Headline */}
  <h1 className="text-5xl font-serif mb-4" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
    Your cattery is live 🐾
  </h1>
  <p className="text-xl text-forest/70 mb-8">
    You're now ready to accept your first booking
  </p>

  {/* URL Display with Copy */}
  <div className="max-w-2xl mx-auto mb-8">
    <Label className="text-sm text-forest/60 mb-2 block">Your Website URL</Label>
    <div className="flex items-center gap-3 bg-cream-dark rounded-2xl p-4 border-2 border-sage/20">
      <Globe className="w-6 h-6 text-sage" />
      <code className="text-2xl font-mono text-forest flex-1">
        {data.subdomain}.catstays.app
      </code>
      <Button 
        variant="outline" 
        size="sm"
        onClick={() => {
          navigator.clipboard.writeText(`${data.subdomain}.catstays.app`);
          // Show toast
        }}
      >
        <Copy className="w-4 h-4 mr-2" />
        Copy
      </Button>
    </div>
  </div>

  {/* Instructions */}
  <div className="bg-gradient-to-br from-blue-50 to-cream rounded-2xl p-8 max-w-2xl mx-auto mb-8">
    <h3 className="font-semibold text-forest mb-3">This is your website and your dashboard</h3>
    <p className="text-forest/70 mb-4">Use this link to:</p>
    <ul className="space-y-2 text-left max-w-md mx-auto">
      <li className="flex items-center gap-3">
        <Check className="w-5 h-5 text-sage" />
        <span>Accept bookings from customers</span>
      </li>
      <li className="flex items-center gap-3">
        <Check className="w-5 h-5 text-sage" />
        <span>Manage your calendar and rooms</span>
      </li>
      <li className="flex items-center gap-3">
        <Check className="w-5 h-5 text-sage" />
        <span>Track payments and revenue</span>
      </li>
      <li className="flex items-center gap-3">
        <Check className="w-5 h-5 text-sage" />
        <span>Send photo updates to customers</span>
      </li>
    </ul>
  </div>

  {/* Primary CTA */}
  <Button
    size="lg"
    className="bg-[#C46A3A] hover:bg-[#A85A30] text-white rounded-xl px-12 py-7 text-xl shadow-2xl hover:shadow-xl hover:scale-105 transition-all"
    onClick={() => window.location.href = `https://${data.subdomain}.catstays.app`}
  >
    <Rocket className="w-6 h-6 mr-3" />
    Go to My Website
  </Button>

  {/* Secondary Actions */}
  <div className="mt-6 flex items-center justify-center gap-4 text-sm">
    <button className="text-sage hover:underline">
      Share on social media
    </button>
    <span className="text-forest/30">•</span>
    <button className="text-sage hover:underline">
      Download marketing materials
    </button>
  </div>
</div>
```

---

## 🔧 STATE MANAGEMENT FIXES (Critical)

### Problem: Data persists across sessions incorrectly

**Current Issues:**
1. LocalStorage key `petstays_onboarding` is global
2. No user-specific data isolation
3. No automatic cleanup on new email or logout

**Solution:**
```tsx
// Use email-based storage keys
const STORAGE_KEY_PREFIX = 'catstays_onboarding_';

const getStorageKey = (email: string) => {
  return `${STORAGE_KEY_PREFIX}${btoa(email)}`; // Base64 encode email
};

// Save progress
const handleSaveProgress = () => {
  if (data.email) {
    const storageKey = getStorageKey(data.email);
    localStorage.setItem(storageKey, JSON.stringify({
      step,
      data,
      timestamp: Date.now()
    }));
  }
};

// Load progress
useEffect(() => {
  const email = getCurrentUserEmail(); // Get from auth context
  if (email) {
    const storageKey = getStorageKey(email);
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const { step: savedStep, data: savedData } = JSON.parse(saved);
      setStep(savedStep);
      setData(savedData);
    }
  }
}, []);

// Clear on logout
const handleLogout = () => {
  if (data.email) {
    const storageKey = getStorageKey(data.email);
    localStorage.removeItem(storageKey);
  }
  // Clear auth
  localStorage.removeItem('catstays_account');
  navigate('/');
};
```

---

## 🔐 LOGIN SYSTEM IMPROVEMENTS

### Smart Routing Based on Onboarding Status

**Location:** `/src/app/pages/CustomerLogin.tsx`

```tsx
const handleLoginSuccess = async (email: string) => {
  // Check if user exists in backend
  const user = await getUserByEmail(email);
  
  if (!user.onboardingComplete) {
    // Resume onboarding at last saved step
    navigate('/onboarding');
  } else {
    // Go to their dashboard
    navigate(`/${user.subdomain}/admin`);
  }
};
```

### Customer Dashboard Access
- Pattern: `{subdomain}.catstays.app/admin`
- Requires authentication
- Shows their business dashboard

### Platform Admin Access (Already Implemented)
1. `admin.catstays.app`
2. Hidden logo 5-click trigger
3. Keyboard shortcut (Ctrl+Shift+A)

---

## 📊 STEP FLOW SUMMARY

### New Flow (10 Steps):
1. **Account Creation** ✅ (Redesigned)
2. **Cattery Details** (Keep existing, minor cleanup)
3. **Import or Start** 🎯 (Redesign - equal options)
4. **Website Builder** 🎯 (Major change - split screen with live preview)
5. **Booking Setup** 🎯 (Integrate RoomsPricingStep component)
6. **Dashboard Preview** (Keep existing, add "Preview" label)
7. **Website Preview** (Keep existing, enhance with click-to-edit)
8. **Module Upsell** 🎯 (NEW - premium features)
9. **Publish** (Keep existing)
10. **Success** 🎯 (Redesign - ownership moment)

---

## 🎨 UX PRINCIPLES

### Core Guidelines:
- ✅ No dead-end screens
- ✅ No data collection before account creation
- ✅ Everything saved + resumable
- ✅ Live preview always visible when designing
- ✅ User always feels: "This is my system"

### Avoid:
- ❌ Duplicate steps
- ❌ Disconnected flows
- ❌ Confusing navigation
- ❌ System/technical language
- ❌ Overwhelming choices

---

## 🚀 IMPLEMENTATION PRIORITY

### Phase 1 (Immediate):
1. ✅ Account Created Screen
2. 🎯 Success Screen (Step 10)
3. 🎯 Module Upsell (Step 8)

### Phase 2 (High Impact):
4. 🎯 Integrate RoomsPricingStep (Step 5)
5. 🎯 Import or Start redesign (Step 3)

### Phase 3 (Complex):
6. 🎯 Website Builder with Live Preview (Step 4)
7. 🎯 State management fixes
8. 🎯 Login routing improvements

---

## 📝 NOTES

- All color changes use brand palette: Navy (#0A1128), Terracotta (#C46A3A), Cream (#F8F7F5)
- Typography: Playfair Display (headings), Inter (body)
- All animations should be subtle and smooth
- Mobile-first responsive design
- Accessibility: ARIA labels, keyboard navigation, color contrast

---

**Last Updated:** March 17, 2026
**Status:** Phase 1 in progress
