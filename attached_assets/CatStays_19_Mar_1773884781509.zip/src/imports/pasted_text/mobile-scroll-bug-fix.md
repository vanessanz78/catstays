Fix the critical issue where clicking ANY element inside the mobile staff dashboard causes the browser to scroll to the top of the onboarding page.

This is a ROOT BUG. Do not patch symptoms. Identify and eliminate the cause.

---

## PROBLEM

* Clicking inside mobile preview triggers scroll to top of browser
* Prevents testing navigation, drawers, forms
* Breaks app usability completely

---

## STEP 1 — FIND THE TRIGGER (MANDATORY DEBUG)

Search the entire codebase for:

* window.scrollTo
* scrollIntoView
* autoFocus on inputs
* anchor links (#)
* form submissions without preventDefault
* navigation calls (navigate, router.push, redirect)
* useEffect hooks that trigger on click/state change

Log EVERY click inside the mobile preview:

console.log("CLICK EVENT", event.target)

Also log:

console.log("SCROLL TRIGGERED")

Identify EXACTLY what function fires before scroll happens.

---

## STEP 2 — STOP PAGE NAVIGATION COMPLETELY

Inside mobile preview:

* REMOVE all anchor tags (<a href="#">)
* Replace with buttons or divs
* Remove ANY navigation that affects parent page

ALL navigation must be LOCAL STATE ONLY.

---

## STEP 3 — BLOCK EVENT BUBBLING TO PARENT

At the root mobile app container:

On ALL click/touch events:

event.stopPropagation()

Also block:

event.preventDefault() (where needed)

Ensure NO event reaches onboarding container.

---

## STEP 4 — DISABLE FORM DEFAULT BEHAVIOUR

For ALL forms:

onSubmit = (e) => {
e.preventDefault()
}

Forms must NOT trigger page reload or scroll.

---

## STEP 5 — REMOVE AUTO SCROLLING BEHAVIOUR

Delete:

* scrollIntoView calls
* focus() calls that shift viewport
* autoFocus attributes

Inputs must NOT move viewport.

---

## STEP 6 — FORCE ISOLATED APP SCROLL SYSTEM

Create structure:

RootContainer:

* overflow: hidden

AppScrollContainer:

* height: 100%
* overflow-y: auto

ALL scrolling must exist ONLY inside AppScrollContainer.

---

## STEP 7 — LOCK SCROLL POSITION

After any click:

DO NOT:

* reset scroll
* re-render parent
* trigger layout shift

Scroll position must remain EXACTLY where user is.

---

## STEP 8 — REMOVE RE-MOUNTING OF APP

Ensure:

* Mobile preview is NOT re-rendering on click
* No parent state is changing that remounts app

If app remounts → scroll resets

Fix by isolating state inside mobile app.

---

## STEP 9 — HARD TEST CONDITIONS

After fix:

✔ Click buttons → NO scroll jump
✔ Open drawers → stays in place
✔ Click inputs → no reposition
✔ Navigate tabs → no page movement
✔ Scroll stays inside phone

---

## FINAL RULE

The mobile preview must behave like a native app — completely isolated from the onboarding page.

NO interaction inside the mobile view may EVER affect the browser scroll.
