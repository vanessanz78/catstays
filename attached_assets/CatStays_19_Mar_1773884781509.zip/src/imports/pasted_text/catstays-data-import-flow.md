Enhance the CatStays post-publish experience by introducing a smart, optional data import flow AFTER subscription and site goes live.

---

CORE PRINCIPLE:

Users should ONLY be asked to import sensitive data AFTER:
- they have paid
- they trust the system
- they see their live website

---

INSERT NEW STEP:

Immediately AFTER:

→ “Your cattery is live 🐾” success screen

---

NEW SECTION / FOLLOW-UP SCREEN:

TITLE:
Bring your data with you

SUBTITLE:
Move your existing customers, pets, and bookings into CatStays in minutes

---

TONE:

Reassuring  
Optional  
Low pressure  
Simple  

---

PRIMARY QUESTION:

Would you like to import your existing data now?

---

CTA OPTIONS:

Primary:
Import My Data

Secondary:
I’ll do this later

---

SUPPORTING MICROCOPY:

You can import your data anytime from your dashboard settings.

---

PART 1: IMPORT FLOW (WHEN CLICKED)

STEP 1 — Upload

TITLE:
Upload your file

OPTIONS:
- Drag & drop file
- Upload CSV / Excel

ACCEPTED TYPES:
.csv, .xlsx

---

STEP 2 — AI PROCESSING (KEY DIFFERENTIATOR)

TITLE:
We’re organising your data

SHOW:
Loading / progress animation

MICROCOPY:

Our AI is mapping your data automatically  
No manual setup required

---

LOGIC:

System should automatically detect:
- customers
- pets
- bookings
- dates
- contact info

NO manual field mapping required

---

STEP 3 — REVIEW (LIGHTWEIGHT)

TITLE:
Quick review

SHOW SUMMARY:

- X Customers found
- X Pets found
- X Bookings found

Optional expandable view:
→ preview rows

---

CTA:

Import Data

---

SECONDARY OPTION:

Back / Cancel

---

STEP 4 — SUCCESS

TITLE:
Your data has been imported 🎉

SUBTEXT:

Everything is now ready inside your dashboard

---

CTA:

Go to Dashboard

---

PART 2: SETTINGS INTEGRATION (IMPORTANT)

Inside customer dashboard:

Create:

→ Settings → Data

---

ADD SECTION:

Data Import & Export

---

FEATURES:

BUTTONS:

Import Data  
Export Data  

---

EXPORT OPTIONS:

Allow user to export:

- Customers
- Pets
- Bookings
- Full dataset

---

FORMAT:

CSV / Excel

---

PART 3: UX SAFETY + TRUST

Add reassurance:

Your data is private and secure  
Only you can access it

---

PART 4: EDGE CASE HANDLING

If file unclear:

Show:

“We couldn’t fully recognise your data — review suggested mappings”

BUT keep this minimal — AI-first approach

---

PART 5: OPTIONAL NICE TOUCH

If user skips import:

Show subtle reminder later in dashboard:

“Import your existing data to get started faster”

---

GOAL:

Make migration feel:
- effortless
- safe
- optional
- intelligent

User should feel:

“I don’t have to rebuild everything — this just works”

---

AVOID:

- manual mapping forms
- overwhelming options
- forcing import before trust is built