Redesign the Petstays onboarding and website creation flow to prioritise importing an existing cattery website and generating a complete preview before subscription.

The onboarding experience should feel similar to Shopify or Squarespace and focus on reducing effort for the user.

Users should be able to import their existing website, customise it visually, preview the result, save progress, and return later before subscribing.

-----------------------------------------------------

STEP 1 – CREATE ACCOUNT

User enters:

Business name
Email
Password

The system automatically generates a subdomain preview.

Example:

businessname.petstays.nz

However the website is not yet live.

-----------------------------------------------------

STEP 2 – IMPORT EXISTING WEBSITE (PRIORITY STEP)

This should be the primary onboarding step.

Display a field:

"Enter your current website"

Example input:

mycattery.com

The system uses AI to scan the website and automatically extract:

Logo
Primary colours
Secondary colours
Fonts
Hero images
Room photos
Page headings
Body copy
Contact information

The system then generates a complete Petstays website using this information.

If the user does not have a website they can skip this step and choose a template.

-----------------------------------------------------

STEP 3 – WEBSITE BUILDER

Show a visual website builder where the generated website is displayed.

The interface should show:

Left side panel – editing tools
Right side – live website preview

Editable elements:

Logo
Hero image
Room images
Colours
Fonts
Text content
Testimonials
About text

Include AI content suggestions under headings so users can regenerate or refine text.

Changes should update the preview instantly.

The layout structure should remain fixed to maintain professional design.

-----------------------------------------------------

STEP 4 – LIVE PREVIEW MODE

Allow users to preview their generated website as if it were live.

Example preview URL:

preview.petstays.nz/businessname

Show a banner:

"Preview Mode – your site is not yet live."

Users can navigate their preview website including:

Homepage
Rooms page
Booking page
Contact page
Blog page

-----------------------------------------------------

STEP 5 – SAVE PROGRESS

Users must be able to save their website setup without subscribing.

Add a button:

Save My Site

When saved:

The website configuration is stored.

Users can return later to continue editing.

Display confirmation:

"Your Petstays website has been saved."

If they leave the onboarding process they can log back in and continue.

-----------------------------------------------------

STEP 6 – REMINDER SYSTEM

If users save but do not subscribe, the system should send reminder emails.

Examples:

"Your Petstays website is ready to launch."

"You’re one step away from launching your cattery website."

Reminders may include preview links.

-----------------------------------------------------

STEP 7 – BUSINESS CONFIGURATION

User enters:

Number of rooms
Room types
Pricing per cat
Discount rules
Opening hours
Cleaning buffer time
Deposit amount

Show previews of how this affects the booking system.

-----------------------------------------------------

STEP 8 – BOOKING SYSTEM PREVIEW

Allow users to preview:

Customer booking flow
Calendar availability
Admin dashboard
Room planner

This helps demonstrate the full value of the system.

-----------------------------------------------------

STEP 9 – SUBSCRIPTION

Display the Petstays subscription plan.

Plan:

Petstays Platform
$49 per month

Include Stripe checkout.

-----------------------------------------------------

STEP 10 – PUBLISH WEBSITE

After payment the system activates the site.

Example:

deloraine.petstays.nz

The website becomes publicly accessible and the admin dashboard becomes active.

Users may optionally connect their own domain later.

-----------------------------------------------------

DESIGN GOALS

The onboarding flow should feel friendly, guided and effortless.

Users should feel like their website is almost finished automatically.

Focus on:

Minimal typing
AI automation
Visual editing
Instant previews
Clear progress indicators

Use warm colours and friendly pet-themed design elements rather than corporate SaaS styling.

The experience should make cattery owners feel excited about launching their new website.