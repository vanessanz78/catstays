Design a high-performance, visually clean, drag-and-drop room booking calendar for CatStays inspired by Pet Revelations, but modernised and more intuitive.

---

CORE GOAL:

Allow cattery owners to:
- visually manage occupancy
- drag bookings between rooms
- optimise space like Tetris
- quickly access booking + pet details

---

LAYOUT STRUCTURE:

FULL WIDTH CALENDAR VIEW

TOP BAR:

- Today button
- Date selector
- View toggle (Week / Fortnight / Month-lite)
- Arrows (← →) for horizontal navigation
- Search bar (optional)

---

MAIN GRID:

HORIZONTAL AXIS:
→ Dates (scrollable left/right)

VERTICAL AXIS:
→ Rooms

---

SCROLLING:

- Horizontal scroll (trackpad swipe)
- Arrow buttons for navigation
- Sticky left column (room names always visible)
- Sticky top row (dates always visible)

---

ROOM COLUMN (LEFT SIDE):

Display:
- Room name
- Room type (optional)
- Capacity indicator (e.g. 1 cat / 3 cats)

---

DATE HEADER:

- Day + date
- Highlight “Today”
- Weekend subtle tint

---

BOOKING TILES (CRITICAL DESIGN)

Each booking = horizontal bar spanning dates

CONTENT INSIDE TILE:

- Cat name(s) (pill style per cat)
- Owner name (small text)
- Date range (optional subtle)
- Info icon (ⓘ)

---

CAT PILLS:

Each cat:
→ individual clickable pill

Click:
→ opens pet profile

---

COLOUR SYSTEM:

- Confirmed booking → primary colour (e.g. green/blue)
- Unpaid → subtle warning indicator
- Multi-room booking → segmented style
- Hover → slight glow

---

INTERACTION — DRAG & DROP (CORE FEATURE)

User can:

CLICK + HOLD booking tile  
→ drag vertically into another room

---

DROP BEHAVIOUR:

IF valid space:
→ snap into place
→ auto-update booking room

IF conflict:
→ show visual warning (red highlight)

---

SMART AUTO SHIFT:

When dropped:
→ system recalculates availability
→ shifts booking cleanly

---

TETRIS UX:

- Allow quick visual rearrangement
- No popups required
- Fast + responsive

---

MULTI-ROOM SPLIT BOOKINGS (ADVANCED)

Allow booking to:

→ be split across multiple rooms

Example:
Room A → 2 nights  
Room B → 3 nights

---

VISUAL:

Split tile into segments:
- Connected visually
- Slight divider between segments

---

EDITING SPLIT:

Drag edge of booking:
→ split at selected date

OR:
Right-click / menu:
→ “Split booking”

---

MERGE OPTION:

Allow merging segments back

---

BOOKING INFO PANEL

Click info icon OR tile:

→ opens floating panel

SHOW:

- Owner name
- Cat(s)
- Dates
- Room allocation(s)
- Payment status

CTA:
View full booking →

---

MICRO INTERACTIONS:

- Smooth drag animation
- Snap-to-grid effect
- Hover highlight on valid drop zones
- Subtle shadow while dragging

---

EMPTY SPACE UX:

Show:
“Available”

Light dotted background

---

PERFORMANCE:

- Must handle high-density bookings
- Smooth scrolling
- No lag during drag

---

MOBILE / TABLET (OPTIONAL):

- Horizontal swipe enabled
- Tap → drag mode
- Simplified interactions

---

GOAL:

User feels:

“I can see EVERYTHING at a glance”  
“I can fix my schedule in seconds”  
“I’m in control during peak chaos”

---

AVOID:

- cluttered visuals
- heavy modals
- slow drag interactions
- rigid booking logic

---

INSPIRATION:

Pet Revelations calendar  
But cleaner, smoother, more modern, more intuitive