The current design system and UI review appears to reference a food discovery app (Füdi). 

Please refocus the entire platform on the Petstays cat boarding SaaS product instead.

Petstays is a multi-tenant booking and management platform for boutique catteries.

Each cattery has:
- a public website
- an online booking system
- a customer portal
- an admin dashboard

Example tenant:
deloraine.petstays.nz

The system must support:

ADMIN FEATURES
- Daily dashboard showing:
  Arrivals Today
  Departures Today
  Currently Boarding
  Outstanding Payments

This dashboard must be the first screen shown to the admin.

The interface should prioritise speed, minimal loading, and simple card layouts because the user may have slow internet.

BOOKING SYSTEM
Bookings include:

Owner Name
Cat Name
Arrival Date + Time
Departure Date + Time
Room Assignment
Number of Cats
Payment Status
Deposit Status

Rooms include:
Private Rooms
Indoor Rooms
Communal Rooms

Room scheduling must support time-based turnover to allow cleaning buffers.

ADMIN DASHBOARD REQUIREMENTS
The dashboard must include:

Swipe left/right to move between days
Quick check-in and check-out buttons
Payment status indicators
Outstanding payment alerts
Currently boarding list
Clickable cat and owner records for quick editing

SECONDARY DASHBOARD
Business analytics should be placed in a separate "Insights" page including:

Occupancy forecast
Rooms booked
Cats boarding
Revenue reports
Promotional triggers

WEBSITE GENERATOR
Each cattery can generate a website automatically by:

Importing their existing website URL
Extracting logos, colours, images and copy
Generating a new Petstays website

Users can edit:

Logo
Hero images
Colours
Fonts
Text content

LIVE PREVIEW
The website builder should include a live preview panel.

Users can navigate the preview before publishing.

SAVE PROGRESS
Users can save their website and return later before subscribing.

REMINDER SYSTEM
If a user saves but does not subscribe, reminder emails should be triggered.

SUBSCRIPTION
Petstays costs $49/month.

After payment the website becomes live at:

businessname.petstays.nz

DESIGN STYLE
The UI should feel:

Warm
Pet-friendly
Premium but calm
Minimal and clean

Use soft colours, rounded cards, cat-themed micro-illustrations and gentle shadows.

Avoid generic SaaS dashboard styling.

The interface should feel welcoming and suitable for boutique pet boarding businesses.