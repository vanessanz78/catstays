Redesign the Notifications UI for mobile to use a bottom sheet (drawer) instead of a wide modal overlay.

The current notification panel is too wide, misaligned, and cuts off content. Replace it with a properly structured mobile-first interaction.

---

## CORE CHANGE

Replace the current full-width modal with a bottom sheet (slide-up drawer).

This should behave like a native mobile notifications panel.

---

## DRAWER BEHAVIOUR

* Opens from bottom of screen

* Slides up smoothly

* Covers approximately 70–85% of screen height

* Leaves a small portion of background visible at top

* Background overlay:

  * Black with 20–30% opacity
  * Covers full screen behind drawer

---

## LAYOUT + WIDTH FIX

* Drawer must be anchored to full phone viewport (not parent container)

* Left and right edges aligned perfectly with screen

* Internal content constrained with padding:

  * 16–20px left/right padding

* DO NOT allow content to overflow or clip

* Ensure all text (including “Notifications”) is fully visible

---

## HEADER DESIGN

Top of drawer includes:

* Drag handle (centered)
* Title: “Notifications”
* Right side:

  * “Mark all read”
  * Close (X)

Header layout:

* Use horizontal auto layout
* Space-between alignment
* Ensure safe padding on both sides

---

## NOTIFICATION LIST

Each notification item:

* Left: icon (fully visible, not cut off)
* Middle:

  * Title (e.g. “New Booking”)
  * Description (e.g. “Sarah Johnson booked…”)
  * Timestamp
* Right:

  * Unread indicator (dot)

Fix current issues:

* Icons must not be clipped
* Text must wrap properly
* No content should touch screen edges

---

## SCROLL BEHAVIOUR

* Notifications list scrolls vertically inside drawer
* Header stays fixed at top
* Drawer height remains stable

---

## DISMISS INTERACTIONS

User can close drawer by:

* Tapping X
* Swiping down
* Tapping outside (overlay)

---

## VISUAL STYLE

* Rounded top corners (24px)
* Clean card spacing
* Soft dividers between items
* Maintain brand colours (NO random AI colours)

---

## DO NOT USE

* Full-width modal
* Desktop-style popups
* Edge-to-edge text with no padding
* Any layout where content is clipped or cut off

---

## SUCCESS CRITERIA

✔ Notifications open as bottom drawer
✔ Fully readable (no clipped text)
✔ Icons fully visible
✔ Proper padding on both sides
✔ Smooth mobile-native interaction
✔ Easy to dismiss
✔ Feels like a modern mobile app
