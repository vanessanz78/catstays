Extend the final onboarding success screen to include a premium "Marketing Kit Generator" that automatically creates branded marketing materials for each cattery business.

This must feel polished, exciting, and valuable — like the user just received a complete business starter kit.

---

## SCREEN TITLE

"You're Live! 🎉"

Subtext:
"Your website is ready — now start promoting your cattery"

Primary CTA:
[ View Your Website ]

Secondary Section:
"Your Marketing Kit"

---

## CORE SYSTEM LOGIC

All marketing materials MUST dynamically inherit:

* Business name (from onboarding)
* Logo (if uploaded)
* Brand colours (from selected theme)
* Fonts (match website typography)
* Address
* Contact details
* Services offered
* Room types
* Pricing (if available)
* Images (hero + gallery if available)

If data is missing:
→ Use clean placeholders (never empty or broken layouts)

---

## MARKETING KIT GRID (CARD LAYOUT)

Display each asset as a card with:

* Preview thumbnail
* Title
* Short description
* Download button

Grid spacing: 16–20px
Cards: rounded corners, soft shadows, clean layout

---

## ASSET 1 — FLYER (A4 PRINT)

Title: "Flyer"
Description: "Perfect for vet clinics, pet shops, and local promotion"

Preview: A4 vertical layout

Structure:

1. Header

   * Logo
   * Business name
   * Optional tagline ("A safe, loving home for your cat")

2. Hero Image (cat or property)

3. About Section

   * Auto-generated summary

4. Services

   * Boarding, day care, special care

5. Rooms & Facilities

   * Pulled from room types
   * Icons for features

6. Pricing Snapshot

   * e.g. "From $25/night"

7. Opening Hours

8. CTA Section

   * "Book your cat’s stay today"

9. Footer

   * Address
   * Phone
   * Email
   * Website

Style:

* Matches website colours
* Soft cards, rounded edges
* Premium spacing

Export:

* PDF (print-ready)

---

## ASSET 2 — BUSINESS CARD

Title: "Business Card"
Description: "Hand out to customers and partners"

Preview: front + back

Front:

* Logo centered
* Business name
* Tagline

Back:

* Phone
* Email
* Website
* Address

Style:

* Minimal
* Brand colours
* Clean typography

Export:

* PDF (multi-card print layout)

---

## ASSET 3 — SOCIAL POST (INSTAGRAM / FACEBOOK)

Title: "Social Post"
Description: "Share your cattery online"

Size: 1080x1080

Design:

* Background: hero image

* Overlay: subtle brand colour gradient

* Headline:
  "Now Taking Bookings"

* Subtext:
  "Safe, loving care for your cat"

* CTA:
  "Book now at [website]"

* Logo in corner

Export:

* PNG

---

## ASSET 4 — STORY SET (INSTAGRAM STORIES)

Title: "Story Pack"
Description: "Promote your cattery in stories"

Size: 1080x1920

Slides:

1. Intro

   * Logo + name

2. Services

   * Icons + short text

3. Rooms Preview

   * Images

4. CTA

   * "Book your cat’s stay today"

Export:

* Multiple PNG slides

---

## ASSET 5 — SHARE CARD (LINK PREVIEW)

Title: "Share Card"
Description: "Perfect for Facebook, messages, and sharing"

Design:

* Hero image background
* Business name
* Tagline
* Website URL
* "Book Now" CTA

Export:

* PNG

---

## UX INTERACTIONS

Each card includes:

[ Preview ]
[ Download ]

Optional future:
[ Regenerate Design ]

---

## VISUAL STYLE RULES

* Must match selected website theme exactly
* Use same colours, fonts, and spacing system
* No generic templates
* Clean, modern, premium aesthetic
* Soft shadows, rounded cards

---

## EMPTY / FALLBACK STATES

If no logo:
→ Use styled text logo

If no images:
→ Use elegant neutral placeholders

If no pricing:
→ Hide pricing section gracefully

---

## SUCCESS CRITERIA

✔ Feels like a premium business toolkit
✔ Fully branded automatically
✔ Print-ready + digital-ready
✔ Looks professionally designed
✔ No broken layouts or missing data
✔ User is excited to download and use assets
