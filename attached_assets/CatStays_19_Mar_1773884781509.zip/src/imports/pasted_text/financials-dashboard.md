Perfect! ✅ Routes fixed - Deloraine demo moved to /professional

Now here's your comprehensive prompt for building the Financials dashboard page:

📊 FINANCIALS DASHBOARD - FIGMA MAKE PROMPT
Build a comprehensive Financials page at /dashboard/financials for the StayDirect Platform that helps single-property vacation rental hosts track all financial aspects of their direct booking business.

DESIGN AESTHETIC
Clean modern SaaS design with warm boutique hospitality vibes
Rounded corners, soft shadows, warm neutral grays (#484848, #717171, #EBEBEB), generous whitespace
Background: #FAFAF8
Brand colors: Coral (#FF5A5F), Teal (#00A699), Purple (#7B61FF), Gold (#FFB400)
Use the existing dashboard layout with DashboardNav sidebar
CORE SECTIONS
1. FINANCIAL OVERVIEW CARDS (Top of page - 4 cards in a row)

Total Revenue YTD: Show total booking revenue with % change vs previous year, use teal accent
Net Profit: Revenue minus expenses with profit margin %, use gold accent
OTA Commission Saved: Calculate 15-20% of revenue that would've gone to OTAs, use coral accent with celebration icon
Average Booking Value: Total revenue / number of bookings, use purple accent
2. REVENUE TRACKING

Interactive chart showing revenue over time (use recharts library)
Toggle views: Monthly, Quarterly, Yearly
Breakdown by: Direct bookings, Repeat guests, New guests
Ability to see revenue by month with hover tooltips
3. EXPENSE MANAGEMENT

Categorized expense tracking table with add/edit/delete functionality
Categories: Property maintenance, Cleaning, Utilities, Marketing, Supplies, Insurance, Platform fees, Other
Each expense entry: Date, Category, Description, Amount, Tax deductible (checkbox), Receipt upload button
Filter by date range and category
Running total at bottom
4. PROFIT & LOSS STATEMENT

Revenue section: Booking revenue, Add-on sales (airport transfers, cleaning upgrades, etc.), Total revenue
Cost of Goods Sold: Cleaning per booking, Consumables, Direct booking costs
Operating Expenses: By category with subtotals
Net Income: Bold callout with profit margin %
Export buttons: PDF, CSV, Excel
Date range selector (MTD, QTD, YTD, Custom)
5. TAX MANAGEMENT

Tax summary card showing: GST/VAT collected, Tax-deductible expenses, Estimated tax liability
New Zealand specific: Show 15% GST calculations
Quarterly tax summary view
Download tax report button for accountant
Notes section for tax-related reminders
6. COMMISSION SAVINGS CALCULATOR (Highlight section with celebration theme)

Interactive calculator showing:
"If you used Airbnb" column vs "With StayDirect" column
Annual revenue input
Airbnb fee (15%) vs StayDirect fee ($69-109/month depending on plan)
Annual savings in LARGE bold numbers with party emoji 🎉
Graph showing cumulative savings over 1, 3, 5 years
Testimonial quote: "I saved $12,450 in my first year by going direct" - Host name
7. PAYMENT PROCESSING

Integration status with Stripe
Transaction fees summary: Stripe fees (2.9% + 30¢), total fees paid
Payout schedule and history
Link to connect/manage Stripe account
8. FINANCIAL REPORTS

Quick report cards for:
Monthly financial summary
Year-end tax summary
Expense breakdown by category
Revenue by source analysis
Each card has "Generate Report" button and "Schedule Recurring" option
Recently generated reports list with download links
9. SETTINGS & INTEGRATIONS

Currency selector (NZD default)
Tax rate setting (15% for NZ, customizable)
Accounting software integrations: Xero, QuickBooks (coming soon badges)
Receipt email forwarding address
Fiscal year setting
KEY FUNCTIONALITY
All financial data persists in backend (use Supabase KV store)
Real-time calculations and updates
Export functionality (CSV, PDF) for all reports
Date range filters throughout
Mobile responsive tables with horizontal scroll
Empty states with helpful onboarding messages for new users
Sample data toggle to see what it looks like with activity
UI PATTERNS TO USE
Use Card components with elevated variants for main sections
Badge components for categories and status indicators
Stat cards with large numbers and comparison arrows (↑ ↓)
Data tables with sortable columns
Modal dialogs for adding/editing expenses
Toast notifications for successful actions
Loading skeletons while fetching data
INTEGRATIONS
Pull booking revenue from existing bookings system
Connect to Stripe for payment processing data
Export to accounting software (future)
Receipt OCR scanning (future - show "Coming Soon" badge)
EMPTY STATES
When no expenses: "No expenses tracked yet. Add your first expense to start building your financial records."
When no bookings: "Your revenue will appear here once you receive your first booking."
Helpful tips and getting started guidance
CALL-TO-ACTION
Prominent "Add Expense" button
"Download Tax Report" button
"Export to Excel" for all data tables
"Connect Stripe" if not connected
"Upgrade Plan" if on Simple plan (Financials only available on Professional/Premium)
MICROCOPY
Use warm, encouraging language: "You've saved $X by going direct! 🎉"
Educational tooltips: "Tax deductible expenses reduce your taxable income"
Celebration messaging when milestones hit
Helpful hints throughout
Build this at /dashboard/financials with full dashboard navigation, persistent data storage, and export capabilities.