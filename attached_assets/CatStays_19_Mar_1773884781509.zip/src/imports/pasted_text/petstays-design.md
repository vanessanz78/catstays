Design a SaaS platform called Petstays.

Petstays is a white-label booking and management system for boutique cat boarding businesses and catteries.

The main domain is:

petstays.nz

Each cattery receives its own automatically generated subdomain:

businessname.petstays.nz

Example:

deloraine.petstays.nz

Each cattery operates independently with separate rooms, customers, bookings, pricing and payments.

The platform automatically generates a website, booking system and management dashboard for each cattery.

Design the interface mobile-first but responsive for tablet and desktop.

The visual style should feel calm, modern, premium, and welcoming, appropriate for luxury cat boarding.

The platform should prioritise simplicity, speed and automation.

-----------------------------------------------------

PLATFORM MARKETING WEBSITE

Design the public marketing site for Petstays.

Pages:

Home
Features
Pricing
Demo
Sign Up
Login

Messaging should focus on:

"Run your cattery from one dashboard."

Highlight key features:

Website generator
Booking system
Room planner
AI cat updates
Occupancy health meter
Last-minute promotion automation
Customer reminders
Mobile dashboard

Pricing:

Single subscription plan
$49 per month.

-----------------------------------------------------

SIGNUP AND ONBOARDING FLOW

Design a simple onboarding wizard for new catteries.

Step 1 — Create Account

Fields:

Business name
Owner name
Email
Password

Step 2 — Create Subdomain

The system automatically generates a subdomain:

businessname.petstays.nz

Example:

deloraine.petstays.nz

Allow user to edit if needed.

Step 3 — Import Existing Website (optional)

User can paste their current website URL.

Example:

mycattery.com

AI scans the site and extracts:

logo
colours
fonts
images
page headings
text content

The platform then generates a new Petstays website using this information.

Step 4 — Website Customisation

User can visually edit the generated website.

Editable items:

logo
hero image
room photos
colour scheme
font style
headline text
body text

Provide AI caption suggestions for each section.

Users can edit or regenerate text.

Layout and page structure remain fixed to keep design simple and professional.

Step 5 — Business Settings

User configures:

Number of rooms
Room types
Pricing
Opening hours
Cleaning buffer time
Deposit rules
Discount rules
Cancellation policy

Step 6 — Payment Setup

Connect Stripe.

Allow additional payment options:

bank transfer
cash (manual entry)

Step 7 — Publish Website

When user clicks "Publish":

The website becomes live on:

businessname.petstays.nz

Example:

deloraine.petstays.nz

Users may optionally connect their own domain later.

Example:

booking.mycattery.com

-----------------------------------------------------

TENANT WEBSITE STRUCTURE

Each cattery automatically receives a website with the following pages:

Home
About
Rooms
Booking
Contact
Blog
Customer Login

The homepage includes:

Hero section
Rooms overview
Testimonials
Instant availability widget
Social media carousel
Last-minute cat holiday banner

-----------------------------------------------------

BOOKING SYSTEM

Customers can:

Check availability
Book stays
Manage bookings
Upload vaccination record
View cat updates
View Stay Story timeline

Example pricing structure for first tenant (Deloraine):

1 cat = $20/day + GST
2 cats sharing room = $36/day + GST
3 cats sharing room = $54/day + GST

Long stay discounts:

15+ days = 5%
30+ days = 10%
60+ days = 15%

Optional add-ons:

Vet transport
Airport transport
Medication administration
Brushing
Out-of-hours drop-off

$50 deposit required for bookings.

Stripe integration for payments.

-----------------------------------------------------

ROOM TYPES

Private Rooms
Indoor Rooms
Communal Rooms

Private and indoor rooms are for cats from the same household.

Communal rooms may contain multiple cats from different owners.

Rooms are numbered rather than named.

Example:

Room 1
Room 2
Room 3

Customers may have preferred rooms but availability is determined by schedule and cleaning buffer.

-----------------------------------------------------

ADMIN MOBILE DASHBOARD

Design a fast mobile dashboard allowing the owner to manage the cattery quickly.

Show:

Arrivals today
Departures today
Cats currently boarding
Rooms occupied vs available
Outstanding balances
Next week occupancy health meter

Each booking card shows:

Cat name
Owner name
Room number
Arrival or departure time
Payment status

Quick actions:

Check In
Check Out
Send Payment Request

Interaction rules:

Tap cat name → open cat record
Tap owner name → open customer record
Tap booking → open full booking

Allow swipe gestures:

Swipe left → next day
Swipe right → previous day

Navigation uses a right-side hamburger menu.

-----------------------------------------------------

CALENDAR AND ROOM PLANNER

Design two booking views.

Standard calendar view showing:

arrivals
departures
active stays

Horizontal room planner view.

Rows = rooms
Columns = dates and times

Bookings appear as draggable blocks.

Include cleaning buffer between bookings.

Highlight conflicts or overlaps.

Communal rooms show capacity instead of individual room blocks.

-----------------------------------------------------

OCCUPANCY HEALTH METER

Display booking health.

Example:

Next Week Occupancy

Rooms booked: 9 / 17
Cats booked: 14

Colour states:

Green – healthy
Amber – moderate
Red – low occupancy

When occupancy is low show a prompt:

"You have empty rooms next week. Run a Last-Minute Cat Holiday promotion?"

-----------------------------------------------------

LAST-MINUTE CAT HOLIDAY PROMOTIONS

If rooms remain empty within the next 3–5 days the system can generate promotions.

Admin sets:

discount percentage
eligible room types
date range

The system automatically generates:

SMS campaign
Email campaign
Homepage banner
Social media post

Admin simply reviews and approves.

-----------------------------------------------------

AI CAT UPDATE SYSTEM

Admin can take a photo of a cat and generate updates.

Two styles:

Owner message written from the cat's perspective.

Example:

"Hi Mum! I'm enjoying my luxury holiday at the cattery today."

Social media caption promoting the cattery.

Updates can be sent via:

SMS
Email
Facebook
Instagram
TikTok
Website feed

-----------------------------------------------------

STAY STORY TIMELINE

Each cat stay builds a timeline of photos and updates.

Example:

Arrival
Bird watching
Playtime
Brushing
Departure

Owners can view the timeline in their account.

-----------------------------------------------------

PETCOVER INSURANCE

Offer 4 weeks complimentary Petcover insurance when booking.

Customers activate via a link.

Cattery receives 10% commission on policies purchased.

-----------------------------------------------------

TESTIMONIAL SYSTEM

After checkout send a feedback request.

Positive feedback can be approved by admin and displayed as testimonials on the website.

-----------------------------------------------------

ACCOUNTING

Track:

Revenue
Payments
GST
Expenses

Allow receipt photo capture.

Generate GST reports and export to Xero.

-----------------------------------------------------

INSTALLABLE MOBILE WEB APP

Design the system as a Progressive Web App with:

Add to home screen
Push notifications
Camera access
Swipe gestures

-----------------------------------------------------

SAAS ARCHITECTURE

The platform must support multiple catteries.

Each cattery has:

Separate customers
Separate rooms
Separate bookings
Separate pricing
Separate payment accounts

All data is isolated per organisation.

-----------------------------------------------------

KEY UX GOALS

Owners should be able to:

Create bookings in under 10 seconds
Check cats in and out instantly
See outstanding balances immediately
Swipe between days
Manage the entire cattery from a phone dashboard

Generate all screens, flows, UI components and layouts needed to support this platform.