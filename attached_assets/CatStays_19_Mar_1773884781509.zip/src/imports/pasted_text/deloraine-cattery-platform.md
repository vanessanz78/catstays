Design a complete digital platform for **Deloraine Cattery**, a boutique cat boarding business in Whangārei, New Zealand.

Start by analysing and visually replicating the existing website:
https://delorainecattery.com

Recreate the layout, typography, colours and overall visual style so the new platform feels like a natural extension of the current website.

Then expand it into a fully integrated platform including:

- Public website
- Customer booking system
- Admin/staff dashboard
- Fast mobile dashboard
- Calendar and room planner
- Occupancy health meter
- Last-minute promotion automation
- AI cat update system
- Stay Story timeline
- Social media publishing system
- Blog generator
- Messaging centre (email + SMS)
- Internal accounting with GST tracking
- Customer engagement and rebooking automation
- Petcover insurance integration
- Review/testimonial system
- Installable mobile web app (PWA)
- SaaS-ready multi-cattery architecture foundations

The interface should feel calm, premium, warm and welcoming, presenting Deloraine Cattery as a luxury holiday retreat for cats.

Design mobile-first but responsive for tablet and desktop.

The system is designed for a boutique cattery boarding around 14–21 cats per week, so the interface should prioritise speed, clarity, minimal taps, and very fast loading on weak internet.

-----------------------------------
PUBLIC WEBSITE
-----------------------------------

Replicate the structure and style of DeloraineCattery.com.

Pages include:
- Home
- About the cattery
- Rooms and facilities
- Booking page
- Contact page
- Blog
- Customer login

Add a custom social media carousel on the homepage.

This carousel displays posts created inside the system rather than embedding Instagram or Facebook feeds.

Each post shows:
- cat photo
- caption
- cat name
- posting date

Posts created in the admin dashboard can optionally be pushed to:
- Facebook
- Instagram
- TikTok
- Website homepage carousel

Also include:
- a homepage occupancy/promo banner area
- featured testimonials section
- instant availability widget
- last-minute cat holiday offer block

-----------------------------------
INSTANT AVAILABILITY WIDGET
-----------------------------------

Design a very simple conversion-focused widget for the website:

Fields:
- arrival date
- departure date
- number of cats
- preferred room type (optional)

Output:
- available
- limited availability
- waitlist available

Primary CTA:
- Reserve now
- Join waitlist

This should feel frictionless and fast.

-----------------------------------
CUSTOMER LOGIN AREA
-----------------------------------

Customers can:
- create account
- log in
- book a stay
- manage bookings
- view payments
- receive cat updates
- view their cat’s Stay Story timeline
- access last-minute offers
- see testimonial/review requests
- activate Petcover offer

Minimal required fields:

Customer:
- name
- mobile number

Optional:
- email
- address
- secondary phone

Cat:
- cat name (required)

Optional:
- vaccination date
- flea treatment date
- worm treatment date
- vaccination upload

Keep forms minimal and uncluttered.

-----------------------------------
ROOM TYPES AND RULES
-----------------------------------

There are:
- 17 Private Rooms
- 8 Indoor Rooms
- 25 Communal Rooms

Private and Indoor rooms:
- used only for cats from the same household sharing a room

Communal rooms:
- can contain multiple cats from different owners

Private rooms and indoor rooms are numbered only, not named:
- Room 1 to Room 17 etc.

Support preferred room logic:
- a customer may prefer a room
- room preference is not guaranteed
- system should suggest preferred room when available

-----------------------------------
BOOKING LOGIC
-----------------------------------

Pricing:
- 1 cat = $20/day + GST
- 2 cats sharing = $36/day + GST
- 3 cats sharing = $54/day + GST

Discounts:
- 15+ days = 5%
- 30+ days = 10%
- 60+ days = 15%

Special discount:
- NDHB / Te Whatu Ora staff = 15%

Additional fees:
- Vet transport $50
- Airport transport $50
- Medication administration $2 each
- Brushing $2/day
- Out-of-hours drop-off $35

Deposit:
- $50 deposit required on booking

Stripe payment integration.

If payment is made via Stripe, payment status should update automatically.

Support payment methods:
- Stripe/card
- bank transfer
- cash/manual payment

-----------------------------------
OPENING HOURS AND TIME SLOT RULES
-----------------------------------

Check-in and check-out times are only available during:

Morning:
- 9:00am to 10:30am

Afternoon:
- 4:30pm to 6:00pm

Closed:
- Sunday mornings
- Christmas Day
- Boxing Day
- New Year’s Day
- 1 January

Use 15-minute increments for booking time slots.

Important:
build in room turnaround logic.

If a cat departs at 9:30am and a room needs cleaning time, the next arrival in that room cannot be booked until after a 15-minute cleaning buffer, such as 9:45am.

Design the system so room availability is based on:
- room
- date
- exact time
- cleaning/turnaround buffer

Show room overlap conflicts visually in the calendar and booking flow.

If a preferred room is blocked by departure timing, the system should suggest another suitable room automatically.

-----------------------------------
FAST ADMIN MOBILE DASHBOARD
-----------------------------------

Design a single-screen mobile-first dashboard optimised for speed.

This is the most important screen.

It should show:
- arrivals for selected day
- departures for selected day
- cats currently boarding
- rooms occupied vs available
- outstanding balances
- overdue or unpaid arrivals today
- next week occupancy health meter
- quick actions

The dashboard should support:
- swipe left/right to move to previous day / next day
- fast loading
- minimal taps
- card-level actions

Each arrival/departure card should show:
- cat name
- owner name
- room number
- arrival or departure time
- payment status badge

Actions visible directly on card:
- Check in
- Check out
- Send payment request

Important interaction:
- tap cat name opens cat mini-profile
- tap owner name opens customer mini-profile
- tap booking card opens full booking

Mini-profile views should allow very quick edit actions without opening the full booking:
- edit phone
- edit email
- update vaccination date
- take photo of vaccination record
- save notes

Use a right-side hamburger menu drawer for navigation.

-----------------------------------
PAYMENT VISIBILITY
-----------------------------------

Outstanding balances must be visible on the front dashboard without opening a booking.

Examples:
- ARRIVING TODAY – NOT PAID
- Deposit unpaid
- Balance due before arrival
- Paid in full

Create a dedicated Outstanding Payments section showing:
- owner
- cat
- amount owing
- arrival date
- payment method status

Stripe payments should instantly show as paid when successful.

-----------------------------------
CALENDAR SYSTEM
-----------------------------------

Design two calendar views.

1. Standard calendar
Shows:
- arrivals
- departures
- active stays
- occupancy indicators

2. Horizontal room planner
Rows = rooms
Columns = dates and times

Bookings appear as draggable blocks.

Admin can:
- move bookings between rooms
- adjust dates and times
- see cleaning buffer blocks
- see room overlap conflicts
- identify gaps
- optimise room allocation

Filters:
- private
- indoor
- communal

For private/indoor rooms, use exact time and cleaning buffer logic.

For communal rooms, design a different capacity-style planner:
- show total communal capacity
- show cats allocated to communal area by date/time
- show available communal spots

-----------------------------------
OCCUPANCY HEALTH METER
-----------------------------------

Create a health meter that monitors occupancy for:
- today
- this week
- next week

Examples:
- Rooms booked: 8 / 17
- Cats booked: 14
- Status: healthy / moderate / low

Colour states:
- green
- amber
- red

If occupancy drops below a threshold, the system should trigger a prompt:

“You have low occupancy next week. Would you like to run a Last-Minute Cat Holiday promotion?”

Design this as:
- alert card
- quick action button
- preview promotion modal

-----------------------------------
LAST-MINUTE CAT HOLIDAY AUTOMATION
-----------------------------------

When occupancy is low or rooms are empty within 3–5 days, the system can auto-generate a promotion.

Admin can configure:
- discount percentage
- valid dates
- eligible room types
- target audience

Target audience should prioritise:
- recent customers
- repeat customers
- preferred guest list
- not inactive customers from years ago

The system automatically generates:
- SMS campaign
- email campaign
- homepage banner
- social media post
- booking page promo block

Messages should be AI-written and ready for approval with minimal editing.

CTA should be simple and direct.

Example SMS:
“Last-minute luxury cat holiday — 15% off this week. Reply with your preferred ARRIVE and LEAVE dates.”

Example email:
“Luxury Cat Holiday — 15% Off This Week at Deloraine Cattery.”

Design a workflow where AI writes everything and the admin just:
- previews
- approves
- sends

Also store the offer inside the customer portal.

-----------------------------------
AI CAT UPDATE SYSTEM
-----------------------------------

Create a feature called Cat Update.

Admin can:
- open booking
- take a photo of the cat
- AI generates captions

Two caption styles:
1. owner update written from the cat’s perspective
2. social media caption promoting the cattery

Outputs can be sent to:
- email owner
- SMS owner
- Facebook
- Instagram
- TikTok
- website carousel

The owner update should feel like a luxury holiday postcard from the cat.

-----------------------------------
STAY STORY TIMELINE
-----------------------------------

Each booking automatically builds a Stay Story timeline.

Example:
- Arrival – settled into room
- Bird watching
- Brushing session
- Departure

Owners can view the timeline inside their login.

At checkout they receive a shareable summary:
“Your Cat’s Holiday Story”

Include:
- photos
- captions
- key moments

-----------------------------------
REBOOKING ENGINE
-----------------------------------

Design customer retention features.

At checkout or after checkout, the system prompts:
- Invite back for school holidays
- Invite back for Christmas
- Rebook same dates next year
- Send anniversary reminder

Track:
- repeat guests
- preferred room
- favourite patterns
- recent customers
- rebooking opportunities

This should be a very low-friction “one-tap rebook” system.

-----------------------------------
SOCIAL MEDIA MANAGER
-----------------------------------

Design a publishing interface with:
- upload photo
- AI caption generator
- schedule post
- publish immediately
- select platforms

Platforms:
- Facebook
- Instagram
- TikTok
- Website feed

Posts automatically appear in the website carousel.

-----------------------------------
BLOG GENERATOR
-----------------------------------

Design a blog system where AI suggests topical blog ideas relevant to cats and boarding.

Examples:
- cat health advice
- flea and worm prevention
- boarding preparation tips
- holiday travel advice for cat owners

AI generates a draft blog.

Admin can:
- review
- edit
- approve
- publish

Posts appear on the website blog page signed:
“Vanessa — Deloraine Cattery”

-----------------------------------
PETCOVER INTEGRATION
-----------------------------------

Integrate Petcover New Zealand.

Offer customers:
- 4 weeks complimentary Petcover insurance when booking

Show the offer during booking confirmation and in customer portal.

Message example:
“Your cat’s stay includes a complimentary 4-week Petcover insurance offer.”

Customer can click to activate cover.

Deloraine Cattery receives 10% commission on converted policies.

-----------------------------------
REVIEW / TESTIMONIAL SYSTEM
-----------------------------------

Design a post-checkout feedback workflow.

When admin clicks Check Out, the system sends:
- thank-you message
- request for feedback
- request for testimonial/review

Design this as two layers:

1. Private feedback collection
Customer can leave a rating and comments.

2. Publishable testimonial workflow
If feedback is positive, admin can request permission to feature it on website as a testimonial.

The website should have a testimonials section, not a “show every review automatically” model.

Allow admin to:
- approve testimonials for homepage
- approve testimonials for booking page
- tag by service or room type

-----------------------------------
INTERNAL ACCOUNTING
-----------------------------------

Create a lightweight accounting module.

Track:
- booking revenue
- payments
- GST collected
- expenses

Allow receipt capture by phone camera.

Expense categories:
- Food
- Cleaning
- Vet
- Maintenance
- Supplies
- Utilities
- Insurance
- Marketing

GST periods:
- 1 April to 30 September
- 1 October to 31 March

Reports:
- GST summary
- revenue report
- profit and loss
- export to CSV
- export to Xero

-----------------------------------
MESSAGING CENTRE
-----------------------------------

Messages linked to bookings.

Types:
- booking confirmation
- deposit request
- balance reminder
- cat updates
- promotional messages
- feedback request
- testimonial request

Channels:
- email
- SMS

Design message history by customer and by booking.

-----------------------------------
ADMIN PERMISSIONS
-----------------------------------

Roles:
- Owner
- Staff

Owner:
- full access

Staff:
- can view bookings
- can check cats in/out
- can view customer details
- can view booking price
- cannot access accounting, tax, or high-level reports

-----------------------------------
LOW INTERNET / OFFLINE-FIRST UX
-----------------------------------

Because internet at the cattery can be weak, design the app to feel fast and resilient.

Show UI patterns for:
- cached data
- offline-friendly dashboard
- instant card loading
- background sync
- lightweight screens
- minimal loading states

Prioritise:
- today
- next 7 days
- recent customers
- current boarders

-----------------------------------
INSTALLABLE MOBILE WEB APP
-----------------------------------

Design the platform as a Progressive Web App with:
- add to home screen
- push notifications
- camera access
- swipe gestures
- fast mobile controls

-----------------------------------
SAAS-READY FOUNDATIONS
-----------------------------------

Design settings and structure so this system could later become a SaaS platform for boutique catteries worldwide without affecting Deloraine Cattery’s own operation.

Conceptually support:
- multiple cattery organisations
- separate branding per cattery
- separate room setups
- separate pricing rules
- separate Stripe/Xero integrations
- separate staff accounts
- isolated data per cattery

Include a high-level “organisation settings” area in the admin design to hint at future SaaS scalability.

-----------------------------------
KEY UX GOALS
-----------------------------------

The owner should be able to:
- create a booking in under 10 seconds
- instantly see who is arriving and departing
- instantly see who owes money
- check cats in and out with one tap
- move through days by swiping
- resolve room conflicts quickly
- send promotions with almost no writing
- approve AI-generated content quickly
- keep the whole operation running from one phone screen

Generate the full set of screens, flows, UI components and responsive layouts required to support this platform.