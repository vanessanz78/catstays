Fix the mobile preview so it is a fully isolated, non-scrolling parent-safe viewport and eliminate ALL causes of scroll-to-top and right-alignment overflow.

This is a ROOT SYSTEM FIX. Do not patch components. Fix architecture.

---

## CRITICAL PROBLEMS

1. Clicking ANY element inside the mobile preview scrolls the OUTER page to the top
2. The mobile UI is shifted to the right (overflow issue)
3. Drawers cannot be tested because scroll resets instantly
4. The preview behaves like a webpage, not an embedded app

---

## GOAL

The mobile preview must behave like a REAL app inside a locked viewport:

* No interaction can scroll the onboarding page
* No interaction can reset scroll position
* All scrolling is inside the phone only
* Layout is perfectly centered with no overflow
* Drawers open and stay visible

---

## STEP 1 — CREATE HARD ISOLATED APP CONTAINER

Wrap the entire mobile preview in a NEW root container:

Properties:

* position: relative
* height: fixed (device height)
* width: 100%
* overflow: hidden
* contain: layout paint size (STRICT containment)

This container MUST block interaction with parent page.

---

## STEP 2 — CREATE INTERNAL SCROLL LAYER

Inside the container create:

AppScrollContainer

Properties:

* height: 100%
* overflow-y: auto
* overflow-x: hidden
* position: relative

ALL screens must render inside this container.

This is the ONLY scrollable area.

---

## STEP 3 — COMPLETELY DISABLE PARENT SCROLL TRIGGERS

REMOVE globally:

* window.scrollTo
* scrollIntoView
* autoFocus on inputs
* anchor links (#)
* any navigation that reloads or remounts page
* any routing that affects onboarding page

PREVENT:

* click events from bubbling to parent
* focus events from shifting viewport

The onboarding page must NEVER move.

---

## STEP 4 — FORCE LOCAL NAVIGATION ONLY

All interactions must stay INSIDE AppScrollContainer:

* buttons
* tabs
* cards
* drawers
* forms

Do NOT:

* navigate page
* re-render parent
* reset scroll

---

## STEP 5 — FIX RIGHT ALIGN (HARD WIDTH RESET)

Create ONE universal layout wrapper used on ALL screens:

* width: 100%
* max-width: 100%
* padding-left: 16px
* padding-right: 16px
* box-sizing: border-box

REMOVE everywhere:

* fixed pixel widths larger than container
* translateX
* negative margins
* any width causing overflow

---

## FORCE THIS RULE:

*Nothing may exceed the width of its parent container.*

---

## STEP 6 — ADD OVERFLOW CLIPPING SAFETY

On root app container:

* overflow-x: hidden

This ensures NOTHING can render off-screen.

---

## STEP 7 — FIX DRAWER SYSTEM (TESTABLE)

Drawers must render inside app container:

* position: absolute
* bottom: 0
* width: 100%
* max-width: 100%

When open:

* lock AppScrollContainer (no scroll behind)
* allow scroll INSIDE drawer only

---

## STEP 8 — SCROLL POSITION MUST PERSIST

After ANY interaction:

* scroll position must remain unchanged
* user must stay exactly where they are

NO automatic repositioning allowed.

---

## STEP 9 — DEBUG MODE (MANDATORY)

Temporarily:

* outline root container
* outline scroll container
* outline inner layout wrapper

CHECK:

* nothing spills outside
* no right shift
* no horizontal overflow
* clicks do NOT move page

---

## FINAL SUCCESS CRITERIA

✔ Clicking inside app NEVER scrolls onboarding page
✔ App keeps its own scroll position
✔ No jumping to top EVER
✔ Layout is perfectly centered
✔ No content cut off on right
✔ No horizontal overflow
✔ Drawers open and stay visible
✔ App behaves like native mobile UI
