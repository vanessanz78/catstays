Fix the global layout so the entire app is perfectly centered within the mobile device frame and no content is pushed to the right.

This is a ROOT CONTAINER issue, not a component spacing issue.

---

## ACTUAL PROBLEM

* The app content is wider than the mobile frame
* It is anchored to the left instead of centered
* This creates the illusion of left padding and right overflow
* Some elements extend beyond the right edge of the device

---

## GLOBAL FIX (DO THIS FIRST)

Identify the main app wrapper (entire screen content).

Apply:

* Width: 100% (Fill container)

* Max width: match mobile frame width exactly

* Constraints:

  * Left: 0
  * Right: 0

* Ensure the container is CENTERED within the phone frame

---

## REMOVE ALL WIDTH BREAKING ISSUES

Remove from ALL layers:

* Fixed widths larger than parent
* Any width like 360px, 380px, etc. that exceeds frame
* translateX / position offsets
* negative margins

Everything must respect parent width.

---

## ADD ONE CONSISTENT PADDING SYSTEM

Create ONE parent content container inside the screen:

* Padding-left: 16px (or 20px)
* Padding-right: 16px (or 20px)

IMPORTANT:

* Do NOT apply padding individually to every card
* Padding must come from ONE shared parent container

---

## FIX CHILD COMPONENTS

For ALL elements:

* Buttons
* Cards
* Tabs (Arrivals / Departures / Occupied)
* Sections

Set:

* Width: 100% of parent container
* No fixed widths
* No overflow beyond container

---

## CHECK AUTO LAYOUT

Ensure:

* Parent layout = vertical auto layout
* Children align = stretch
* Spacing is consistent

For row elements (tabs/cards):

* Use equal distribution
* Ensure total width + gaps does not exceed container

---

## DEBUG STEP (MANDATORY)

Temporarily:

* Add a visible border or background to the main container
* This lets you SEE if anything is spilling outside

Fix anything that crosses that boundary

---

## WHAT NOT TO DO

* Do NOT “nudge” things left manually
* Do NOT fix individual cards only
* Do NOT adjust margins randomly

This must be solved at the container level.

---

## SUCCESS CRITERIA

✔ Equal padding on left and right
✔ No content cut off on the right
✔ Entire app visually centered
✔ No horizontal overflow anywhere
✔ All elements align perfectly within grid
✔ Layout feels balanced and clean
