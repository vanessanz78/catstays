Fix the left-hand navigation menu so it behaves like a proper mobile app drawer with fully isolated scrolling and no background bleed.

This is a GLOBAL drawer/menu fix.

---

## PROBLEM

Current issues:

* Menu scrolls AND the background page scrolls at the same time
* Content behind the menu becomes visible when scrolling
* Menu items disappear into transparency at the bottom
* The menu does not have a defined scroll boundary
* The menu width is too wide and feels heavy
* Header is not properly fixed
* The interaction feels broken and non-native

---

## GOAL

Create a clean, minimal, native-style left drawer menu:

* Narrow width (not full screen)
* Fixed header at top
* Scrollable menu content ONLY inside drawer
* Background fully locked when open
* No transparency or bleed
* No scrolling past menu content

---

## DRAWER STRUCTURE (REQUIRED)

Mobile App Container

* Screen Content (locked when menu open)
* Overlay Layer

  * Dim Background (click to close optional)
  * Left Drawer Menu

---

## DRAWER WIDTH

Make drawer narrower and elegant:

* Width: 75% max (or ~280px)
* Do NOT exceed this width
* Anchor to left: 0

---

## BACKGROUND OVERLAY

Behind the drawer:

* Add dim overlay (bg-black/30)
* Cover entire phone screen
* Prevent interaction with background

---

## SCROLL LOCK (CRITICAL)

When menu is open:

* Disable ALL scrolling on background content
* Only allow scroll inside the menu

Apply:

* background container: overflow hidden
* menu container: overflow-y auto

User must NOT be able to scroll the page behind the menu

---

## MENU SCROLL BEHAVIOUR

Menu must:

* scroll vertically within itself only
* STOP scrolling at the last item
* NOT reveal any background content

No “scroll bleed” allowed.

---

## MENU HEADER (FIXED)

Top of menu:

* Fixed header (position: sticky or fixed)
* White background
* Contains:

  * "Dashboard" title
  * optional settings icon
  * REMOVE the X button (not needed)

Header must remain visible while scrolling menu

---

## MENU CONTENT

Scrollable list below header:

* Room Planner
* Bookings
* Customers
* Smart Import
* Accounting
* Messages
* etc.

Each item:

* icon + title + subtitle
* clean spacing
* no overflow

---

## BOTTOM BOUNDARY FIX

The menu must have a hard bottom boundary:

* content container ends cleanly
* no transparency fade
* no disappearing text
* no overlap with background

If content exceeds height:
→ scroll inside menu ONLY

If content is shorter:
→ no extra scroll

---

## CLOSE BEHAVIOUR

Menu closes by:

* tapping outside (overlay)
  OR
* selecting a menu item

No need for visible X button

---

## VISUAL CLEANUP

* Solid white background (no transparency)
* subtle shadow on right edge of drawer
* smooth slide-in animation from left
* no layout shifting of underlying screen

---

## SUCCESS CRITERIA

✔ Menu is narrow and clean
✔ Header stays fixed at top
✔ Menu scrolls independently
✔ Background does NOT scroll at all
✔ No content bleed or transparency issues
✔ No scrolling past bottom of menu
✔ No text disappearing under overlay
✔ Feels like native iOS/Android drawer
✔ Entire interaction is smooth and controlled
