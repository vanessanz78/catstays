Enhance authentication, onboarding continuity, admin access, and post-publish handoff for CatStays SaaS platform.

---

CORE SYSTEM OVERVIEW:

We now support THREE access pathways:

1. CUSTOMER LOGIN (cattery owners)
2. HIDDEN ADMIN LOGIN (logo click)
3. DIRECT ADMIN URL (admin.catstays.app)

All flows must be clearly separated and logically consistent.

---

PART 1: CUSTOMER LOGIN (PRIMARY FLOW)

HEADER BUTTON:
“Sign In” → routes to:
→ /login

---

LOGIN PAGE:

Heading:
Welcome back

Subheading:
Continue setting up your cattery or access your dashboard

FIELDS:
- Email
- Password

CTA:
Continue Setup

---

LOGIN LOGIC:

IF onboarding NOT complete:
→ Resume onboarding at last saved step

IF onboarding complete:
→ Redirect to:
→ theirname.catstays.app/admin

---

SAVE STATE REQUIREMENT:

System must store:
- Last completed step
- All entered data
- Selected plan

On login:
→ Restore exact position in flow

---

MICROCOPY:

Below CTA:
“Pick up right where you left off”

---

PART 2: ADMIN ACCESS (3 METHODS)

METHOD 1 — HIDDEN CLICK:

Trigger:
Click CatStays logo (cat inside heart house) 5 times within 3 seconds

→ Open admin login modal

---

METHOD 2 — KEYBOARD SHORTCUT:

CMD + SHIFT + A (Mac)  
CTRL + SHIFT + A (Windows)

→ Open admin login modal

---

METHOD 3 — DIRECT URL:

→ admin.catstays.app

This routes directly to:
→ Admin login page

---

ADMIN LOGIN PAGE:

Heading:
CatStays Admin

Subheading:
Manage your platform, customers, and growth

FIELDS:
- Email
- Password

CTA:
Login to Admin

---

AFTER LOGIN:
→ /platform-admin

---

IMPORTANT:

Admin dashboard = SaaS metrics ONLY  
DO NOT include:
- bookings
- cats
- rooms

---

PART 3: CUSTOMER DASHBOARD ACCESS

Each customer has their own unique environment:

→ theirname.catstays.app

This is:
- Their website
- Their booking system
- Their admin dashboard

---

LOGIN BEHAVIOUR:

Customers log in via:
→ theirname.catstays.app/login

NOT the main CatStays site

---

PART 4: POST-PUBLISH HANDOFF (VERY IMPORTANT UX MOMENT)

After user clicks “Publish Website”:

Show SUCCESS SCREEN (celebration moment)

---

SCREEN CONTENT:

Headline:
Your cattery is live 🐾

Subheadline:
Your website and booking system are ready to go

---

SHOW THEIR URL PROMINENTLY:

Example:
whiskerhaven.catstays.app

Styled as:
- Large
- Clickable
- Copy button

---

SECTION: “How to access your system”

Copy:

This is now your website and your dashboard.

In future, access everything here:
→ whiskerhaven.catstays.app

---

INSTRUCTIONS:

- Use this link to manage bookings
- This is where your customers will book
- Bookmark it for easy access

---

LOGIN INFO:

You’ll log in using the email and password you just created.

---

CTA BUTTONS:

Primary:
Go to My Website

Secondary:
Copy Link

Optional:
Open Dashboard

---

OPTIONAL NICE TOUCH:

Small note:
“We’ve saved your progress — you can always log back in anytime”

---

PART 5: EDGE CASE — USER RETURNS LATER

If user logs in again:

IF not published:
→ Resume onboarding

IF published:
→ Go to their dashboard

---

GOAL:

Create a system that feels:
- Seamless
- Professional
- Ownership-driven

User should feel:
“This is my system now”

---

AVOID:

- Confusing login paths
- Losing onboarding progress
- Users not knowing where to go after publish