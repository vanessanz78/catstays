Fix the Booking Details drawer (bottom sheet) so it behaves correctly as a mobile overlay component.

---

## ISSUE 1: DRAWER MISALIGNED (SHIFTED RIGHT)

Problem:

* Drawer is not centered in the phone frame
* Right edge is too close to screen edge
* Left side has extra margin
* Rounded corners appear off
* Close (X) button is hard against the right edge

Fix:

* Ensure the drawer container is:

  * Horizontally centered within the device frame
  * Left and right margins are equal

* Set constraints:

  * Left: 0
  * Right: 0
  * Width: Fill container

* Add consistent internal padding:

  * Left padding: 16–20px
  * Right padding: 16–20px

* Ensure header row (title + X button):

  * Uses auto layout (horizontal)
  * Space between alignment
  * X button sits inside padding (not touching edge)

* Ensure border radius:

  * Top-left: 24px
  * Top-right: 24px
  * Bottom corners: 0

---

## ISSUE 2: DRAWER POSITIONING (ANCHORING WRONG)

Problem:

* Drawer is anchored to “Departures Today” card
* Instead of the full screen
* It does NOT behave like a bottom sheet
* It does NOT slide up from bottom of device

Fix:

* Move drawer OUT of the “Departures Today” frame

* Place it at the top level inside the phone screen frame

* Set positioning:

  * Position: Absolute
  * Bottom: 0
  * Left: 0
  * Right: 0

* Width:

  * Fill container

* Height:

  * Hug contents OR fixed height (e.g. 80% of screen)

---

## INTERACTION BEHAVIOUR (IMPORTANT)

* On tap of an arrival/departure card:
  → Open overlay

* Drawer should:

  * Slide up from bottom
  * Use Smart Animate
  * Ease out (200–300ms)

* Add background overlay:

  * Full screen dim layer (black at 20–30% opacity)
  * Positioned behind drawer

---

## SCROLL + CONTENT BEHAVIOUR

* Drawer content should scroll independently

* Keep bottom actions fixed:

  * “Call Owner”
  * “Edit”

* Ensure safe area spacing at bottom

---

## VISUAL POLISH

* Add small drag handle at top (centered)
* Maintain consistent spacing between sections
* Ensure all content aligns to same padding grid

---

## SUCCESS CRITERIA

✔ Drawer is perfectly centered
✔ Equal left/right margins
✔ X button sits inside padding
✔ Drawer is anchored to screen bottom (not card)
✔ Slides up like a native mobile bottom sheet
✔ Background overlay appears correctly
✔ Content scrolls independently
✔ Feels like a premium mobile app interaction
