Redesign the Petstays SaaS website and onboarding experience to feel like a premium modern software platform built specifically for boutique catteries.

The website should be conversion-focused and clearly communicate the value of the platform: helping cattery owners get more bookings, reduce admin work, and manage their business easily.

Use a calm premium design style with soft colours, rounded cards, and generous spacing.

COLOUR SYSTEM

Primary: Deep Sage (#4F6F5A)
Accent: Terracotta (#D98C6A)
Background: Soft Cream (#FAF7F2)
Text: Charcoal (#2E2E2E)
Secondary Accent: Dusty Rose (#E7C9C4)

Use soft shadows and modern SaaS styling.

HOMEPAGE STRUCTURE

Hero Section

Headline:
Run Your Entire Cattery From One Simple Dashboard

Subheadline:
Create a website, accept bookings online, manage rooms, track payments and send photo updates — all in one platform built specifically for catteries.

Primary CTA:
Start Free Trial

Secondary CTA:
Watch Demo

Show product mockups including the dashboard, booking calendar, and website builder.

Trust Section

Display social proof such as:

500+ catteries using Petstays
10,000+ bookings processed
98% customer satisfaction

Problem Section

Title:
Running a Cattery Shouldn't Be This Hard

Show common pain points:

Manual spreadsheets
Endless booking phone calls
Chasing payments
Constant update requests from owners
No professional booking website

Then show Petstays solving each problem.

How Petstays Works

Three steps with visuals.

Create Your Website  
Import an existing website or generate a new one automatically.

Accept Online Bookings  
Customers check real-time availability and book directly.

Manage Everything  
Mobile dashboard for arrivals, departures, payments and updates.

Product Features

Display a grid showing:

Beautiful Booking Website
Real-Time Availability Calendar
Mobile Dashboard
Automated Photo Updates
Payment Processing
Room Planner
Customer Database
Business Analytics

Use real UI previews rather than generic icons.

Dashboard Preview

Show realistic screens:

Arrivals Today
Room Planner
Payment Tracking
Weekly Occupancy

Customer Results

Add statistics such as:

40% increase in bookings
5 hours saved per week
24/7 automated booking system

Pricing Section

Create three pricing tiers.

Starter Plan
$29/month
Booking website
Online bookings
Availability calendar
Customer database

Growth Plan (Most Popular)
$49/month
Everything in Starter
Mobile dashboard
Payment processing
Photo updates
Room planner
Business analytics

Pro Plan
$79/month
Everything in Growth
Multi-location support
Advanced reporting
Custom branding
Priority support

FAQ Section

Include questions such as:

Do I need a website?
Can customers pay deposits online?
Can I import my existing bookings?
Is there a free trial?

Final CTA

Headline:
Start Running Your Cattery the Smart Way

Button:
Start Free Trial

ONBOARDING FLOW

Create a multi-step onboarding experience.

Step 1
Welcome screen introducing Petstays setup.

Step 2
Enter cattery details such as name, location, rooms and pricing.

Step 3
Import existing website by entering URL.

Automatically pull logos, images and text.

Step 4
Choose website style and brand colours.

Provide live preview.

Step 5
Set booking rules such as check-in time and deposit requirements.

Step 6
Show dashboard preview and quick tour.

Step 7
Allow full website preview before publishing.

Buttons:
Edit Website
Save For Later
Publish Website

Step 8
Publishing prompts the user to start a free trial or enter payment details.

Allow saving projects so users can return later.

Send reminder emails if setup is incomplete.

Design should feel friendly, trustworthy, and polished like modern SaaS platforms such as Shopify or Notion.