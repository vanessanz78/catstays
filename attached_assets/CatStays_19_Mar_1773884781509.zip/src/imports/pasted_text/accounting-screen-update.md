Refine and complete the Accounting screen to align with the dashboard design system and implement full functionality for transactions, filtering, exporting, and invoicing.

This includes visual fixes and functional behaviour.

---

## PART 1 — FIX COLOUR SYSTEM (ALIGN TO BRAND)

PROBLEM:

* Green and orange cards feel too saturated and off-brand
* Do not match overall dashboard tone

---

GOAL:
Use softer, consistent, brand-aligned colours.

---

## UPDATE COLOURS:

Paid:

* Use softer green (less saturated)
* Match existing success colour used elsewhere

Pending:

* Use muted orange or neutral tone
* Not bright/neon

Overdue (in list):

* Keep red but soften slightly for consistency

Cards should feel:

* calm
* premium
* consistent with dashboard

---

## PART 2 — FIX FILTER CHIP SPACING

PROBLEM:

* Filter chips (All / Paid / Pending / Overdue) have no vertical spacing

---

## FIX:

Add spacing:

* margin-top: 12–16px
* margin-bottom: 12–16px

Ensure:

* chips are not touching elements above/below
* consistent spacing across screens

---

## PART 3 — MAKE TRANSACTION CARDS CLICKABLE

GOAL:
Each transaction card opens full details.

---

## ON CARD CLICK:

Open drawer:

Title:
"Transaction Details"

---

## DRAWER CONTENT:

* Customer Name
* Amount
* Status (paid / pending / overdue)
* Payment Method (card / bank / cash)
* Date paid
* Invoice number
* Associated booking:

  * Cat name
  * Room
  * Dates

---

## ACTIONS:

* Mark as Paid (if pending)
* Edit Invoice
* Close

---

## DRAWER RULES:

* opens from bottom
* scrollable internally
* does NOT move background
* stays within mobile viewport

---

## PART 4 — EXPORT BUTTON (MAKE FUNCTIONAL)

GOAL:
Allow export of transaction data

---

## ON CLICK "Export":

Open drawer or modal:

Options:

* Export as CSV
* Export as PDF

Optional filters:

* Date range
* Status (paid / pending / overdue)

---

## ACTION:

"Download Report"

Show confirmation:
"Export successful"

---

## PART 5 — CREATE INVOICE (DEFINE FUNCTION)

GOAL:
Create a clear and usable invoice flow

---

## ON CLICK "Create Invoice":

Open drawer:

Step 1 — Select Customer:

* searchable dropdown

Step 2 — Add Details:

* Amount
* Description
* Payment status (paid / pending)
* Due date

Step 3 — Link Booking (optional):

* select booking from list

---

## ACTIONS:

* Cancel
* Create Invoice

---

## RESULT:

* invoice appears in transactions list
* updates totals (paid/pending)

---

## PART 6 — VIEW REPORTS (DEFINE FUNCTION)

GOAL:
Provide simple financial overview

---

## ON CLICK "View Reports":

Open new screen or drawer:

Show:

* Total revenue
* Paid vs pending vs overdue
* Date filters (weekly / monthly)
* Simple chart (optional)

---

## PART 7 — UX POLISH

* Add hover/active states for cards
* Smooth transitions for drawers
* Keep spacing consistent with other screens

---

## SUCCESS CRITERIA

✔ Colours match dashboard theme
✔ Chips have proper spacing
✔ Cards open detailed transaction view
✔ Export button works with options
✔ Create Invoice flow is clear and usable
✔ View Reports shows meaningful data
✔ No layout or scroll issues
✔ Feels like a real accounting tool
