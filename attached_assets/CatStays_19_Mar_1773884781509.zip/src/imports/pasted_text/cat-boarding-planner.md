Prompt for Cat Boarding Room Planner with Dynamic Pricing Calendar
Build a comprehensive Room Management & Dynamic Pricing System for a cat boarding facility. The system should manage multiple rooms (kennels/suites) with booking calendars, dynamic pricing rules, and analytics.

Context & Requirements:
Business Model: Cat boarding facility with multiple rooms of different types (Standard Kennel, Deluxe Suite, Premium Suite, etc.). Each room has its own pricing, availability calendar, and booking history.

Design Aesthetic: Clean, modern SaaS interface with soft, warm colors that evoke trust and care. Use rounded corners (rounded-xl, rounded-2xl), soft shadows, generous whitespace, and a calming color palette featuring sage green (#8FBC8F), warm coral (#FF7F7F), soft blue (#87CEEB), and lavender (#E6E6FA).

Core Features to Build:
1. Room Management Dashboard
Room List View with cards showing:
Room name/number
Room type (Standard, Deluxe, Premium)
Current occupancy status (Available/Occupied/Cleaning)
Base daily rate
Current guest (cat name) if occupied
Upcoming reservations count
Revenue this month
Add/Edit Room functionality with:
Room name
Room type selection
Base daily rate
Maximum occupancy (single cat vs multi-cat rooms)
Amenities (window view, play area, premium bedding, etc.)
Room size (square feet)
Active/Inactive toggle
2. Multi-Room Pricing Calendar
Create a horizontal timeline calendar (like a Gantt chart) showing:

Y-axis: List of all rooms (one row per room)
X-axis: Timeline showing dates (scrollable, shows 14-30 days at a time)
Visual representation:
Empty cells = Available (white/light background)
Booked cells = Show cat's name + owner + color-coded by room type
Blocked cells = Cleaning/maintenance (diagonal stripes pattern)
Hover shows booking details (cat name, owner, check-in/out dates, price, special needs)
Color-coding by booking status:
Confirmed bookings: Solid sage green (#8FBC8F)
Pending bookings: Soft yellow (#FFF4B7)
Checked-in (current): Bright coral (#FF7F7F)
Cleaning/Turnover: Light gray with stripes
Interactive features:
Click empty cell to create new booking
Click booking to view/edit details
Drag edges to extend/shorten stay
Right-click for context menu (Cancel, Modify, Block room)
Navigation:
Previous/Next week/month buttons
Jump to date picker
Today button
Zoom in/out (day view, week view, month view)
3. Dynamic Pricing Rules Engine
Build a rules system that automatically adjusts room rates:

Pricing Rule Types:

Base Rate: Default daily rate per room type
Peak Season Premium: Holiday periods (Christmas, Easter, Summer holidays) +30-50%
Weekend Premium: Friday-Sunday +20%
Last-Minute Discount: Bookings within 3 days -15%
Extended Stay Discount: 7+ days -10%, 14+ days -20%
Multi-Cat Discount: 2+ cats in same room -$5/day per additional cat
Off-Peak Discount: Slow periods (Jan-Feb, post-holidays) -20%
Gap Filler: Fill 1-2 day gaps between bookings -25%
Weekday Discount: Monday-Thursday (non-holiday) -15%
Holiday Premium Events: Specific dates (New Year's Eve, Thanksgiving, etc.) with custom multipliers
Rules Management Interface:

Enable/disable each rule
Set percentage adjustments or fixed dollar amounts
Set date ranges for seasonal rules
Set priority/order of rule application
Visual indicators showing which rules are active
Test pricing calculator (input dates, see final price breakdown)
Rule Priority Logic:

Holiday/Special Event pricing (highest priority)
Seasonal adjustments
Weekend premiums
Extended stay discounts
Last-minute/gap filler discounts
Base rate (fallback)
4. Pricing Calendar View (Individual Room)
For each room, show a monthly calendar grid with:

Color-coded pricing heat map:
Dark green (150%+): Peak pricing
Sage green (120-149%): Premium pricing
Light green (100-119%): Base pricing
Light yellow (90-99%): Light discount
Soft coral (<90%): Discount pricing
Gray: Booked (show booking price)
Daily price displayed in each cell
Sparkle icon if pricing rules are active
Booked dates grayed out with guest info
Month navigation
Legend explaining color coding
5. Booking Management
Create/Edit Booking Modal:

Guest (cat owner) information autocomplete
Cat details (name, age, breed, special needs, medical notes)
Room selection (show available rooms for date range)
Check-in/Check-out date pickers
Number of nights (auto-calculated)
Pricing breakdown:
Base rate × nights
Applied discounts/premiums (itemized)
Add-ons (premium food, playtime, grooming)
Subtotal
Tax
Total
Special requests/notes
Emergency contact
Veterinarian contact
Status (Confirmed, Checked-in, Checked-out, Cancelled)
Add-ons & Services:

Premium food (+$8/day)
Extended playtime (+$12/session)
Grooming (+$35)
Medication administration (+$5/day)
Daily photo updates (+$5/day)
Private outdoor time (+$10/session)
6. Analytics Dashboard
Key Metrics (30/60/90 day views):

Overall Occupancy Rate (percentage + visual gauge)
Occupancy by Room Type (breakdown)
Revenue: Confirmed vs Potential
Average Daily Rate (ADR) across all rooms
Revenue Per Available Room (RevPAR)
Average Length of Stay
Booking Lead Time (how far in advance)
Cancellation Rate
Repeat Guest Rate
Most Popular Room Types
Revenue by Add-on Service
Visual Charts:

Occupancy trend line graph (6-month history)
Revenue bar chart by month
Room type popularity pie chart
Booking source breakdown (website, phone, repeat guest, referral)
Daily rate heat map calendar
AI Recommendations Section:

Suggest pricing adjustments based on occupancy
Identify slow periods needing promotions
Recommend optimal room rates
Flag upcoming gaps that need filling
Suggest bundled packages
7. Special Events & Peak Periods
Add holiday/event dates with custom pricing
Minimum stay requirements for peak periods
Visual timeline of upcoming events
Automatic price adjustments when events are active
Examples: Christmas holidays, Spring break, Local cat shows, etc.
8. Room Status Board (Operations View)
Quick visual board showing:

Arriving Today: List of check-ins with preparation status
Departing Today: List of check-outs
Currently Occupied: All rooms with guest names
Cleaning Queue: Rooms pending turnover
Maintenance Required: Flagged issues
Available Now: Ready to book
9. Data Persistence & Integration
LocalStorage for prototype/demo
All bookings, rooms, pricing rules, and settings persist
Import/export booking data (CSV)
Print views for daily schedules
Quick stats on dashboard
Technical Requirements:
Frontend:

React with TypeScript
React Router for navigation
Date handling: date-fns or Day.js
State management: React hooks (useState, useEffect)
LocalStorage for data persistence
Responsive design (mobile-friendly)
Components to Create:

RoomManagementPage.tsx - Main dashboard
RoomCalendarTimeline.tsx - Gantt-style multi-room calendar
RoomPricingCalendar.tsx - Individual room pricing calendar
PricingRulesEngine.tsx - Rules management
BookingModal.tsx - Create/edit bookings
AnalyticsDashboard.tsx - Metrics and charts
RoomStatusBoard.tsx - Operations view
Navigation.tsx - Sidebar with sections
Data Structures:

interface Room {
  id: string;
  name: string;
  type: 'standard' | 'deluxe' | 'premium';
  baseRate: number;
  maxOccupancy: number;
  amenities: string[];
  status: 'available' | 'occupied' | 'cleaning' | 'maintenance';
  size: number;
  active: boolean;
}

interface Booking {
  id: string;
  roomId: string;
  catName: string;
  ownerName: string;
  ownerEmail: string;
  ownerPhone: string;
  checkIn: string;
  checkOut: string;
  numberOfNights: number;
  basePrice: number;
  finalPrice: number;
  appliedDiscounts: string[];
  addOns: AddOn[];
  status: 'pending' | 'confirmed' | 'checked_in' | 'checked_out' | 'cancelled';
  specialNeeds: string;
  emergencyContact: string;
  vetContact: string;
}

interface PricingRule {
  id: string;
  name: string;
  type: 'weekend' | 'seasonal' | 'last_minute' | 'extended_stay' | 'gap_filler' | 'holiday';
  enabled: boolean;
  multiplier?: number;
  fixedAmount?: number;
  dateRange?: { start: string; end: string };
  daysThreshold?: number;
  minNights?: number;
  daysOfWeek?: number[];
}
UI/UX Design Guidelines:
Color Palette:

Primary: Sage Green (#8FBC8F) - calming, natural
Accent: Warm Coral (#FF7F7F) - friendly, energetic
Secondary: Soft Blue (#87CEEB) - trust, cleanliness
Tertiary: Lavender (#E6E6FA) - premium, soothing
Neutrals: Warm grays (#F5F5F0, #E8E8E3, #707070)
Success: Forest Green (#228B22)
Warning: Soft Yellow (#FFD700)
Danger: Soft Red (#DC143C)
Typography:

Headings: Bold, clear hierarchy
Body: 14-16px, comfortable reading
Use icons from Lucide React
Spacing:

Generous padding (p-6, p-8)
Card-based layouts with rounded-2xl borders
Consistent gaps (gap-4, gap-6)
Key User Flows:
Create New Booking:

View calendar → Click empty date/room → Select dates → Choose room → Enter cat/owner info → Review pricing → Confirm
Adjust Pricing:

Go to Pricing page → View rules → Enable/disable rules → Add seasonal events → See calendar update in real-time
Check-In Guest:

View arriving today → Click booking → Verify details → Change status to "Checked In" → Assign room if not already
View Analytics:

Analytics page → Select date range → View occupancy trends → Review pricing effectiveness → Read AI recommendations
Future Enhancements (Optional):
Email/SMS confirmations and reminders
Online booking widget for website
Pet parent portal (view booking, upload photos)
Daily photo sharing
Medication scheduling and tracking
Waitlist management
Integration with POS for payments
Staff assignment and scheduling
Veterinary integration
Reporting and export features
Build this as a fully functional web application with all features working, data persisting to localStorage, and a beautiful, intuitive interface that cat boarding facility owners would love to use daily. 🐱✨