# Premium Upsell Screen - Documentation

## Overview
Premium pre-publish upsell screen that feels helpful, not salesy. Shows value through visual previews and makes add-ons feel like obvious choices.

**Route:** `/upsell`

---

## Design Philosophy

### Psychology Principles

**Goal:** User thinks "Well... I'd be silly not to add this"

**NOT:** High-pressure sales tactics

**Approach:**
1. **Show, don't tell** - Visual UI previews of each feature
2. **Value-first** - Benefits before pricing
3. **No commitment pressure** - Easy skip option
4. **Social proof** - Savings & satisfaction stats
5. **Make it feel obvious** - Features look essential when you see them

---

## Layout Architecture

### Full-Page Centered Design
```
┌─────────────────────────────────────────────────┐
│                   HEADER                        │
│         Badge + Title + Subtitle                │
│                                                 │
│              FEATURE GRID (2x2)                 │
│                                                 │
│              PRICING SUMMARY                    │
│                                                 │
│                   CTAs                          │
│                                                 │
│              TRUST FOOTER                       │
└─────────────────────────────────────────────────┘
```

**Container:** Max-width 5xl, centered, padding 6
**Background:** Cream (#F8F7F5)
**Spacing:** Generous (mb-12, gap-6)

---

## Header Section

### Badge
- **Style:** Rounded pill
- **Icon:** Sparkles ✨
- **Text:** "Recommended for you"
- **Colors:** Terracotta bg (#C46A3A/10), Terracotta text
- **Psychology:** Creates urgency without pressure

### Title
```
"Enhance your cattery experience"
```
- **Font:** Playfair Display, 5xl, bold
- **Color:** Navy (#0A1128)
- **Tone:** Aspirational, premium

### Subtitle
```
"Add powerful features to delight your customers and save time"
```
- **Font:** Inter, xl
- **Color:** Gray-600
- **Tone:** Benefit-focused (customers + time savings)

---

## Feature Cards (2x2 Grid)

### 4 Premium Features

#### 1. SMS Updates 📱
**Icon:** MessageCircle  
**Title:** "SMS Updates"  
**Description:** "Send booking reminders and updates automatically"  
**Price:** +$10/month

**Visual Preview:**
```
Mini SMS inbox showing:
- "Booking confirmed" (green dot, 2:34 PM)
- "Reminder: Pick-up" (blue dot, Yesterday)
```
**Value:** Automation + customer communication

---

#### 2. Pet Updates 📸
**Icon:** Camera  
**Title:** "Pet Updates"  
**Description:** "Share photos and updates with owners during their stay"  
**Price:** +$15/month

**Visual Preview:**
```
Mini social card showing:
- Avatar "F" (Fluffy)
- Cat photo in sunny spot
- Caption: "Having a purrfect nap in the sunny spot! 😺"
- Timestamp: "2 hours ago"
```
**Value:** Customer delight + differentiation

---

#### 3. Daycare Module ☀️
**Icon:** Sun  
**Title:** "Daycare Module"  
**Description:** "Manage day stays alongside overnight bookings"  
**Price:** +$10/month

**Visual Preview:**
```
Mini dashboard showing:
- "Today's Daycare - 4 cats"
- 4 colored badges: M, T, B, L
- Times: "Drop-off: 8:00 AM | Pick-up: 6:00 PM"
```
**Value:** Revenue expansion + flexibility

---

#### 4. Grooming Module ✨
**Icon:** Sparkles  
**Title:** "Grooming Module"  
**Description:** "Offer grooming services and bookings"  
**Price:** +$10/month

**Visual Preview:**
```
Mini service menu showing:
- Bath & Brush - $35
- Nail Trim - $15
- Full Groom - $65
```
**Value:** Additional revenue + convenience

---

## Feature Card Anatomy

### Structure
```
┌─────────────────────────────────────┐
│  [✓ Selected Badge]        (top-right if selected)
│                                     │
│  [Icon]  Title                      │
│          Description                │
│                                     │
│  ┌─────────────────────────┐       │
│  │   VISUAL PREVIEW        │       │
│  │   (Mini UI Snippet)     │       │
│  └─────────────────────────┘       │
│                                     │
│  ────────────────────────────      │
│  +$XX/month        [Toggle]         │
└─────────────────────────────────────┘
```

### States

**Unselected (Default):**
- Border: Gray-200 (1px)
- Background: White
- Icon background: Terracotta/10, Terracotta text
- Hover: Shadow-lg

**Selected:**
- Border: Terracotta ring-2
- Background: White
- Icon background: Terracotta solid, White text
- Checkmark badge: Top-right corner
- Shadow: xl

**Click Behavior:**
- Click anywhere on card → toggles selection
- Smooth 300ms transition
- Toggle animates left/right

### Toggle Switch
- **Off:** Gray-200 background, white knob (translate-x-1)
- **On:** Terracotta background, white knob (translate-x-6)
- **Size:** h-6 w-11, knob h-4 w-4
- **Animation:** Transform transition

---

## Visual Previews

### Design Principles
1. **Realistic mini UIs** - Actual component snippets, not icons
2. **Recognizable patterns** - Familiar UI elements
3. **Data-rich** - Show real content, not placeholders
4. **Color-coded** - Use brand colors where relevant
5. **Scannable** - Easy to understand at a glance

### SMS Preview
- **Style:** White card, gray border
- **Elements:** Green/blue status dots, timestamps
- **Font sizes:** 9-10px (micro)
- **Shows:** Message thread UI

### Pet Updates Preview
- **Style:** Gradient background (purple-pink)
- **Elements:** Avatar, photo, caption, timestamp
- **Image:** Actual cat photo (Unsplash)
- **Shows:** Social media-style update

### Daycare Preview
- **Style:** White card, gray border
- **Elements:** Count badge, colored name initials, times
- **Shows:** Dashboard-style data

### Grooming Preview
- **Style:** Gradient background (amber-orange)
- **Elements:** Service list, prices
- **Shows:** Menu/pricing interface

---

## Pricing Summary Card

### Layout
```
┌─────────────────────────────────────────────┐
│  Your plan                    Breakdown      │
│  $XX/month                                   │
│                              Base plan: $69  │
│                              Add-ons (+X): +$XX
│                              ───────────     │
│                              Total: $XX      │
│                                              │
│  ✓ Smart choice! These features save 5+     │
│    hours/week and increase satisfaction 40%  │
└─────────────────────────────────────────────┘
```

### Components

**Left Side:**
- "Your plan" (gray-500, small)
- **Total price** (4xl, bold, navy)
- "/month" (xl, gray-400)

**Right Side:**
- Base plan: $69 (gray-500 label, gray-900 value)
- Add-ons (X): +$XX (gray-500 label, terracotta value)
- Border top separator
- **Total: $XX** (xl, bold, navy)

### Dynamic Behavior
- Starts at $69 (base only)
- Updates instantly when toggling features
- Shows add-on count in parentheses
- Breakdown only appears if add-ons selected

### Savings Message
**Appears when:** Any feature selected  
**Style:** Green-50 bg, green-200 border, green-900 text  
**Icon:** Check (green-600)  
**Text:**
```
"Smart choice! These features typically save 5+ hours per week 
and increase customer satisfaction by 40%."
```

**Psychology:** 
- Social proof
- Quantified benefits
- Reinforces smart decision
- Not salesy, factual tone

---

## Call-to-Action Buttons

### Primary CTA
**Dynamic Text:**
- If features selected: "Upgrade & Continue"
- If no features: "Continue with Base Plan"

**Style:**
- Background: Terracotta (#C46A3A)
- Hover: Darker terracotta (#A85A30)
- Size: Large (px-8 py-6, text-lg)
- Border radius: xl
- Shadow: lg → xl on hover
- Icon: ArrowRight (translates right on hover)

**Group Hover Effect:**
- Arrow slides right 4px
- Shadow increases
- Smooth transition

### Secondary CTA
**Text:** "Skip for now"

**Conditional Display:**
- Only shows if features selected
- Gives easy out
- Reduces pressure

**Style:**
- Variant: Ghost (no background)
- Color: Gray-600 → Gray-900
- Size: Large (px-8 py-6, text-lg)
- No shadow

**Psychology:**
- Permission to decline
- Reduces buyer's remorse
- Makes primary CTA less threatening

---

## Trust Footer

### Content
```
✓ Cancel anytime • ✓ 14-day free trial • ✓ No setup fees
```

**Style:**
- Text: sm, gray-500
- Centered
- Margin top: 8
- Checkmarks inline

**Purpose:**
- Reduces risk perception
- Addresses objections
- No commitment anxiety

---

## Interaction States

### Feature Selection
1. **Click card** → Toggles selection
2. **Visual feedback:** 
   - Ring appears (300ms transition)
   - Icon background changes color
   - Checkmark badge animates in
   - Toggle switch slides
3. **Pricing updates** → Instant calculation
4. **CTA updates** → Text changes if needed

### Hover Effects
- **Card:** Shadow increases
- **Toggle:** Cursor pointer
- **Primary CTA:** Shadow grows, arrow moves
- **All transitions:** 200-300ms

### Focus States
- Keyboard navigable
- Focus rings on interactive elements
- Tab order: Cards → Toggles → CTAs

---

## State Management

### Component State
```typescript
const [selectedFeatures, setSelectedFeatures] = useState<Set<string>>(new Set());
```

**Features array:**
```typescript
interface Feature {
  id: string;          // 'sms', 'updates', 'daycare', 'grooming'
  icon: LucideIcon;
  title: string;
  description: string;
  price: number;       // Monthly add-on cost
  preview: ReactNode;  // Visual UI preview
}
```

### Calculations
```typescript
const basePlan = 69;
const totalAddonCost = features
  .filter(f => selectedFeatures.has(f.id))
  .reduce((sum, f) => sum + f.price, 0);
const totalCost = basePlan + totalAddonCost;
```

**Real-time:** Updates on every toggle

---

## Pricing Breakdown

### Base Plan
**Cost:** $69/month  
**Includes:**
- Website builder
- Booking system
- Calendar management
- Customer portal
- Email notifications
- Basic reports

### Add-ons
1. **SMS Updates:** +$10/month
2. **Pet Updates:** +$15/month (most popular)
3. **Daycare Module:** +$10/month
4. **Grooming Module:** +$10/month

### Example Totals
- Base only: $69/month
- Base + SMS: $79/month
- Base + Pet Updates: $84/month
- Base + All 4: $114/month
- Sweet spot (Base + SMS + Updates): $94/month

---

## Psychological Triggers

### 1. Visual Value Demonstration
**How:** Mini UI previews show actual feature
**Effect:** "I can see exactly what I'm getting"

### 2. Benefit-Driven Descriptions
**How:** Every description focuses on outcome
**Effect:** "This solves a real problem I have"

### 3. Social Proof
**How:** Savings message with specific stats
**Effect:** "Other catteries are benefiting from this"

### 4. Loss Aversion
**How:** Show what they're missing visually
**Effect:** "I might regret not adding this"

### 5. Easy Reversal
**How:** "Skip for now" + "Cancel anytime"
**Effect:** "I'm not locked in, so it's safe"

### 6. Price Anchoring
**How:** Show add-ons relative to base plan
**Effect:** "+$10 seems small compared to $69"

### 7. Bundle Perception
**How:** See all features at once
**Effect:** "This is a complete solution"

### 8. Instant Gratification
**How:** Toggle = immediate visual feedback
**Effect:** "I'm in control and can see results"

---

## Conversion Optimization

### High-Converting Elements
1. ✅ **Visual previews** (not abstract icons)
2. ✅ **Toggles** (easy interaction)
3. ✅ **Dynamic pricing** (transparency)
4. ✅ **Benefit focus** (not feature list)
5. ✅ **Social proof** (stats)
6. ✅ **Risk reduction** (trust footer)
7. ✅ **Easy decline** (skip button)

### A/B Test Ideas
- Reorder features by popularity
- Highlight "Most Popular" badge
- Add customer testimonials
- Show "X% of catteries add this"
- Include ROI calculator
- Video preview on hover

---

## User Flow Integration

### Where It Appears
**Step 1:** User completes onboarding wizard  
**Step 2:** User designs website in builder  
**Step 3:** User clicks "Publish Website"  
**→ UPSELL SCREEN APPEARS** (before publish confirmation)  
**Step 4:** User selects add-ons (or skips)  
**Step 5:** Publish success screen

### Flow Logic
```
Publish Button Clicked
  ↓
Upsell Screen (/upsell)
  ↓
[User selects features + "Upgrade & Continue"]
  OR
[User clicks "Skip for now"]
  ↓
Publish Success Screen (/publish-success)
  ↓
Admin Dashboard (/admin)
```

---

## Copy Writing Principles

### Tone
- **Helpful:** "Enhance your cattery experience"
- **Aspirational:** "Delight your customers"
- **Practical:** "Save time"
- **No pressure:** "Skip for now"

### Word Choice
- ✅ "Enhance" not "Upgrade"
- ✅ "Add" not "Buy"
- ✅ "Recommended" not "Required"
- ✅ "Smart choice" not "Limited time"
- ✅ "Skip" not "No thanks"

### Benefit Structure
**Format:** [Action] + [Outcome]
- "Send reminders automatically" (Action + Automation)
- "Share photos during their stay" (Action + Timing)
- "Manage day stays" (Action + Scope)
- "Offer grooming services" (Action + Revenue)

---

## Accessibility

### Keyboard Navigation
- Tab through feature cards
- Space/Enter to toggle
- Tab to primary CTA
- Tab to secondary CTA
- Escape to skip (future)

### Screen Readers
- Card labels: "SMS Updates feature, $10 per month"
- Toggle state: "Selected" / "Not selected"
- Price updates: Announced on change
- CTA: Clear action description

### Focus Management
- Visible focus rings
- Logical tab order
- No focus traps
- Skip links available

### Color Contrast
- All text meets WCAG AA
- Icons have sufficient contrast
- Selected state clearly visible
- Toggle states distinguishable

---

## Responsive Behavior

### Desktop (md+)
- 2x2 grid of feature cards
- Horizontal button layout
- Full pricing breakdown visible

### Tablet (sm to md)
- 2x2 grid maintained
- Slightly reduced padding
- Buttons stack vertically

### Mobile (< sm)
- Single column (1x4)
- Cards full width
- Pricing summary simplified
- Buttons full width, stacked

---

## Technical Implementation

### Component Structure
```
UpsellScreen
├── Header (badge, title, subtitle)
├── Feature Grid
│   ├── Feature Card 1 (SMS)
│   │   ├── Icon + Title
│   │   ├── Description
│   │   ├── Visual Preview
│   │   └── Price + Toggle
│   ├── Feature Card 2 (Pet Updates)
│   ├── Feature Card 3 (Daycare)
│   └── Feature Card 4 (Grooming)
├── Pricing Summary
│   ├── Total Display
│   ├── Breakdown Table
│   └── Savings Message (conditional)
├── CTA Buttons
│   ├── Primary (dynamic text)
│   └── Secondary (conditional)
└── Trust Footer
```

### State Flow
```typescript
// Initial state
selectedFeatures = new Set()

// User clicks card or toggle
toggleFeature('sms')
  → selectedFeatures.add('sms') or .delete('sms')
  → Component re-renders
  → Pricing recalculates
  → CTA text updates
  → Savings message appears/disappears

// User clicks CTA
if (selectedFeatures.size > 0) {
  // Save selections to backend
  // Navigate to /publish-success
} else {
  // Navigate to /publish-success (base plan only)
}
```

### Performance
- No API calls on mount
- Instant toggle response
- Optimized re-renders (memo if needed)
- Lazy-loaded images in previews
- Smooth 60fps animations

---

## Backend Integration (Future)

### Save Selected Add-ons
```typescript
POST /api/subscription/add-ons
{
  features: ['sms', 'updates'],
  totalCost: 94,
  effectiveDate: '2026-03-17'
}
```

### Subscription Update
- Update Stripe subscription
- Prorate charges
- Send confirmation email
- Enable features in admin panel

---

## Analytics Events

### Track These Interactions
1. **upsell_screen_viewed** - Screen loads
2. **feature_toggled** - User selects/deselects
   - feature_id
   - action (selected/deselected)
3. **upsell_completed** - User clicks upgrade
   - features_selected
   - total_cost
4. **upsell_skipped** - User skips
5. **card_clicked** - User interacts with specific feature
6. **toggle_clicked** - Direct toggle interaction

### Success Metrics
- **Conversion rate:** % who select 1+ features
- **Average add-ons:** Mean number selected
- **Revenue impact:** Average monthly increase
- **Most popular:** Which feature selected most
- **Skip rate:** % who decline

---

## Copy Variations (Future Testing)

### Alternative Headlines
- "Make your cattery stand out"
- "Upgrade your customer experience"
- "Add premium features"
- "Power up your booking system"

### Alternative CTAs
- "Add features & publish"
- "Upgrade my plan"
- "Yes, add these features"
- "Complete setup"

### Alternative Savings Messages
- "Catteries with these features earn 30% more"
- "Save 5+ hours every week on admin"
- "Customers rate catteries with updates 4.8/5"
- "99% of premium users recommend these"

---

## Edge Cases

### No Features Selected
- CTA reads "Continue with Base Plan"
- No "Skip for now" button
- No savings message
- Pricing shows $69 only

### All Features Selected
- Total: $114/month
- Maximum value message appears
- Checkmarks on all cards
- All toggles on

### Single Feature Selected
- Breakdown shows base + 1 add-on
- Savings message still appears
- Skip button visible

---

## Future Enhancements

### Phase 2
- [ ] Video previews on hover
- [ ] "Most Popular" badges
- [ ] Customer testimonials
- [ ] Live demo links
- [ ] Annual billing discount option

### Phase 3
- [ ] Custom package builder
- [ ] "Catteries like you chose..." social proof
- [ ] ROI calculator per feature
- [ ] Chat support integration
- [ ] A/B testing framework

### Phase 4
- [ ] Personalized recommendations (ML)
- [ ] Usage-based suggestions
- [ ] Bundle discounts
- [ ] Limited-time offers
- [ ] Referral incentives

---

## Design System

### Colors
- **Primary:** #C46A3A (Terracotta)
- **Navy:** #0A1128
- **Cream:** #F8F7F5
- **Success:** Green-50, Green-200, Green-600, Green-900
- **Gray Scale:** 100, 200, 400, 500, 600, 900

### Typography
- **Headings:** Playfair Display (5xl bold, xl semibold)
- **Body:** Inter (xl, base, sm)
- **Micro:** 8px, 9px, 10px (in previews)

### Spacing
- **Section gaps:** mb-12, mb-8, mb-6
- **Card padding:** p-6
- **Grid gap:** gap-6
- **Button padding:** px-8 py-6

### Shadows
- **Cards:** shadow-lg
- **Selected:** shadow-xl
- **Pricing:** shadow-lg
- **Hover:** shadow-2xl

### Borders
- **Default:** border-gray-200 (1px)
- **Selected:** ring-2 ring-[#C46A3A]
- **Radius:** rounded-xl (cards), rounded-lg (previews)

---

## Success Criteria

### User Experience
- ✅ Feels helpful, not pushy
- ✅ Clear value demonstrated
- ✅ Easy to understand pricing
- ✅ No decision paralysis
- ✅ Smooth interactions

### Business Metrics
- Target: 40%+ conversion rate (1+ feature)
- Target: 2.2 average features selected
- Target: $25+ average monthly increase
- Target: < 5% skip rate

### Quality Indicators
- No confusion in user testing
- Positive sentiment in feedback
- High confidence in decision
- Low regret/cancellation rate

---

**Status:** ✅ Fully Implemented  
**Route:** `/upsell`  
**Created:** March 17, 2026

---

## Quick Reference

**Access:** `/upsell`

**Features:**
1. SMS Updates (+$10)
2. Pet Updates (+$15)
3. Daycare Module (+$10)
4. Grooming Module (+$10)

**Base Plan:** $69/month  
**Max Total:** $114/month (all features)

**Key Psychology:**
- Show value visually
- Make it feel obvious
- Easy to decline
- Risk-free

**Conversion Goal:** "Well... I'd be silly not to add this"
