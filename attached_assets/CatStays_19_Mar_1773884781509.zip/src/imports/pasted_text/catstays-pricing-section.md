Figma Design Prompt: CatStays Emotional Pricing Section

OVERVIEW
Design a warm, calm, premium pricing section for CatStays — a boutique cattery platform built by a real cattery owner. This should feel human, trustworthy, and simple. Avoid corporate SaaS vibes. No clutter, no overwhelming comparison tables.

STYLE

* Boutique, calm, minimal
* Emotion-led, not feature-heavy
* Soft spacing, airy layout
* Subtle elegance

BRAND TOKENS

* Navy: #0A1128
* Terracotta: #C46A3A
* Soft beige background: #F8F7F5
* Card background: #F1ECE8
* Radius: 16–20px
* Shadow: soft, warm
* Heading font: Playfair Display
* Body font: Inter

---

SECTION HEADER (CENTERED)

Headline:
"Simple pricing, built for real cattery life"

Subheading:
"Start where you are. Grow when you’re ready. No limits on rooms, no pressure to upgrade."

Small trust line:
"Built from real experience running a cattery since 2014"

---

PRICING CARDS (3 CARDS SIDE-BY-SIDE)

All cards equal height, soft rounded corners, generous padding.
Middle card slightly elevated and highlighted.

---

CARD 1 — STARTER

Title:
"Starter"

Price:
"$29"
Small text:
"/month"

Tagline:
"A calm, simple way to run your cattery"

Features:

* Online bookings
* Customer & cat profiles
* Calendar management
* Email confirmations
* Mobile dashboard

CTA:
"Start Free Trial"

---

CARD 2 — PROFESSIONAL (MOST POPULAR)

Badge:
"Most Popular"

Title:
"Professional"

Price:
"$69"
Small text:
"/month"

Tagline:
"Where your cattery starts to flow"

Features:

* Everything in Starter
* Unlimited bookings
* Daily photo updates
* Automated reminders
* Priority support

CTA:
"Start Free Trial"

STYLE:

* Slightly larger or lifted card
* Subtle terracotta outline or glow
* Badge in terracotta pill

---

CARD 3 — PREMIUM

Title:
"Premium"

Price:
"$99"
Small text:
"/month"

Tagline:
"For catteries ready to grow and expand"

Features:

* Everything in Professional
* Daycare module
* Grooming module
* Advanced automation
* VIP support

CTA:
"Start Free Trial"

---

BOTTOM TRUST SECTION

Centered text below cards:

"No contracts. No surprises. Just a better way to run your cattery."

Optional secondary line:
"Switch in minutes with AI-powered data import"

---

MICRO UX DETAILS

* Add subtle paw icons as bullet points
* Gentle hover effect (card lifts slightly)
* CTA buttons terracotta with white text
* Keep spacing generous and calming
* Avoid comparison tables

---

GOAL

User should feel:
"This feels simple. I trust this. I know exactly which one I want."

---

END
