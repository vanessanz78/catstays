Fix the left-hand menu drawer so scrolling is fully contained within the menu and cannot bleed into the background or overlay.

This is a GLOBAL scroll containment fix.

---

## PROBLEM

* Menu scroll stops before reaching full content
* Scrolling on the right (frosted overlay) continues scrolling the page
* Two scroll areas exist (menu + background)
* User can “escape” the menu scroll
* Menu does not feel anchored to the phone

---

## GOAL

* Only ONE scrollable area when menu is open → the menu itself
* Menu scroll reaches the true bottom of menu content
* Background (including frosted overlay) must NOT scroll at all
* User cannot scroll past the menu content under any condition

---

## ROOT FIX — SINGLE SCROLL SYSTEM

When menu is open:

* Disable ALL scrolling on:

  * Mobile app content
  * Background page
  * Frosted overlay

Only allow scrolling inside:
→ Menu content container

---

## MENU STRUCTURE (REQUIRED)

Drawer (fixed, left)

* Header (fixed / sticky top)
* Scroll Container (THIS is the only scrollable area)

Overlay (right side)

* covers full screen
* NO scroll allowed

---

## SCROLL RULES

Menu Scroll Container:

* height: full available height (screen minus header)
* overflow-y: auto
* overflow-x: hidden

Must:

* scroll smoothly
* reach the LAST menu item
* STOP at the last item (no extra scroll space)

---

## CRITICAL FIX — REMOVE SCROLL FROM OVERLAY

Overlay (frosted area on right):

* MUST NOT scroll
* MUST NOT pass scroll events through
* MUST NOT allow page scroll underneath

Apply:

* overflow: hidden
* block pointer scroll events OR prevent propagation

---

## BACKGROUND LOCK (VERY IMPORTANT)

When menu is open:

* Entire app behind menu = locked
* No vertical movement allowed anywhere except menu

Apply to app container:

* overflow: hidden

---

## BOTTOM BOUNDARY FIX

Menu must have a HARD STOP at the bottom:

* no transparency fade
* no content sliding underneath
* no disappearing text
* no additional scroll beyond last item

---

## TOUCH / SCROLL BEHAVIOUR

User experience must be:

* drag inside menu → menu scrolls
* drag outside menu → NOTHING happens
* no “scroll leaking” to background

---

## HEADER BEHAVIOUR

* Header stays fixed at top of menu
* Does not scroll away

---

## VISUAL STRUCTURE

Menu:

* solid background (white)
* full height of screen
* anchored top to bottom

Overlay:

* dim background
* completely static

---

## DEBUG STEP (MANDATORY)

Temporarily:

* highlight menu scroll container
* highlight overlay

Test:

* scroll inside menu → works fully
* scroll outside menu → nothing moves
* reach bottom → stops cleanly

---

## SUCCESS CRITERIA

✔ Menu scroll reaches full content
✔ Menu stops cleanly at bottom
✔ Background does NOT scroll
✔ Frosted overlay does NOT scroll
✔ No scroll bleed anywhere
✔ Menu feels anchored and stable
✔ Entire interaction feels like native app drawer
