Enhance the Calendar and introduce a Room Planner system to make bookings fully interactive, visual, and operational.

This is a functional UX upgrade, not just visual.

---

## PART 1 — CALENDAR INTERACTION (ARRIVALS & DEPARTURES)

PROBLEM:

* Calendar shows dots (green = arrivals, blue = departures)
* No way to see WHAT those dots represent
* No actionable detail when tapping a date

GOAL:

* Make each date interactive
* Show all arrivals and departures for that selected date
* Allow quick access to booking details

---

## CALENDAR BEHAVIOUR

When user taps a date:

1. Highlight selected date (already exists)
2. Trigger a content update BELOW the calendar
3. Show a structured list of bookings for that date

---

## BOOKINGS LIST SECTION (BELOW CALENDAR)

Add a new section directly below the calendar:

Title:

* "Bookings for March 18" (dynamic based on selected date)

Split into two sections:

1. ARRIVALS
2. DEPARTURES

---

## BOOKING CARD DESIGN

Each booking appears as a card:

Card content:

* Cat Name (bold)
* Owner Name
* Room Number
* Time (arrival or departure time)
* Status badge (paid / unpaid)

Optional:

* small colored indicator:

  * green = arrival
  * blue = departure

---

## INTERACTION

* Clicking a booking card opens Booking Details Drawer
* Drawer uses existing global drawer system

---

## EMPTY STATE

If no bookings:

* Show message:
  "No arrivals or departures for this date"

---

## DEFAULT STATE

* On first load, auto-select today’s date
* Show today’s arrivals/departures immediately

---

## PART 2 — ROOM PLANNER (DRAG & DROP OCCUPANCY)

GOAL:
Create a visual room allocation planner to optimise occupancy.

This must feel like a lightweight scheduling board.

---

## LAYOUT STRUCTURE

Create new screen or section: "Room Planner"

Structure:

* Horizontal axis = Dates (e.g. Mar 18 → Mar 25)
* Vertical axis = Rooms (Room 1 → Room 20)

This creates a grid.

---

## BOOKING BLOCKS

Each booking is shown as a colored block spanning dates.

Example:

* Booking from Mar 18 → Mar 21
* Block spans across those date columns

Block content:

* Cat Name
* Optional: Owner initials

---

## COLOUR SYSTEM

Use color to indicate status:

* Paid → green or brand color
* Unpaid → orange/red
* Optional: different subtle shades per booking

---

## DRAG & DROP BEHAVIOUR

User must be able to:

1. Drag booking blocks vertically (change room)
2. Snap into empty room slots
3. Prevent overlap with existing bookings

---

## VALIDATION RULES

* Cannot place booking on occupied slot
* Cannot break booking date range
* Must stay within available dates

---

## INTERACTION DETAILS

* Tap block → opens Booking Details Drawer
* Dragging shows preview ghost block
* Snap animation when placed
* Visual highlight of valid drop zones

---

## GRID DESIGN

* Each cell = small square (like calendar cells)
* Booking blocks fill across multiple cells
* Subtle grid lines for clarity

---

## OPTIONAL UX ENHANCEMENTS

* Hover / tap shows tooltip with booking info
* “Auto optimise” button (future feature)
* Filter by:

  * arrivals
  * departures
  * unpaid

---

## SCROLLING

* Horizontal scroll for dates
* Vertical scroll for rooms
* Must stay inside mobile container

---

## SUCCESS CRITERIA

✔ Tapping calendar date shows full booking list
✔ Users can clearly see arrivals & departures
✔ Booking cards open drawer on click
✔ Room planner visually shows all bookings
✔ Drag and drop works smoothly
✔ No overlaps allowed
✔ Easy to reorganise rooms for max occupancy
✔ Feels like a real operational tool, not just UI
