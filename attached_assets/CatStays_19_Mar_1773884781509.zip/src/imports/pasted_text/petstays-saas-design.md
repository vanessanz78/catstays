Design a modern SaaS dashboard and website builder interface for a pet boarding platform called “PetStays”.

The system allows pet boarding businesses to create and manage their own websites using a visual editor.

STYLE
Clean modern SaaS UI similar to:
- Webflow
- Shopify
- Wix
- Squarespace

Use a light UI with soft greys, white backgrounds, subtle shadows, rounded corners, and modern sans-serif typography.

Primary brand color: soft blue
Secondary accent: warm orange

---

MAIN PRODUCT STRUCTURE

Create two main sections:

1) WEBSITE EDITOR (for Pet Boarding Businesses)
2) PLATFORM ADMIN DASHBOARD (for the platform owner)

---

SECTION 1 — WEBSITE EDITOR

Layout similar to modern website builders.

Page structure:

Top bar:
- Logo (PetStays)
- Save button
- Preview button
- Publish button
- Undo / Redo
- Device view toggle (Desktop / Tablet / Mobile)

Left Sidebar Navigation (collapsible):

Sections:

Pages
- Home
- About
- Services
- Pricing
- Gallery
- Contact
- Booking Page

Content Blocks
- Hero Section
- Image Gallery
- Testimonials
- Pricing Tables
- FAQ
- Call To Action
- Contact Form

Design Settings
- Colors
- Typography
- Button styles
- Logo upload
- Background styles

Booking Settings
- Boarding options
- Pricing
- Availability calendar
- Pet types allowed
- Capacity limits

Media Library
- Upload images
- Pet photos
- Gallery manager

SEO Settings
- Page titles
- Meta descriptions
- Social sharing image

---

Center Canvas (Website Preview)

Large editable preview of the website.

Users can click sections directly to edit:
- Text
- Images
- Layout
- Buttons
- Booking widgets

Show editable bounding boxes on hover.

---

Right Properties Panel

When an element is selected show editing controls:

For text:
- Font
- Size
- Color
- Alignment

For images:
- Replace image
- Crop
- Border radius

For sections:
- Background color
- Padding
- Layout
- Container width

---

SECTION 2 — PLATFORM ADMIN DASHBOARD (Owner Control Panel)

This is the backend dashboard for the PetStays platform owner.

Left Navigation:

Dashboard
Users / Businesses
Websites
Bookings
Emails
CRM
Payments
Analytics
Support Tickets
Settings

---

Dashboard Overview Page

Show metrics:

Total Websites Created
Active Pet Businesses
Monthly Revenue
New Signups
Bookings Processed

Include charts and KPI cards.

---

Users / Businesses

Table showing all businesses using the platform.

Columns:
- Business Name
- Owner Name
- Email
- Website URL
- Plan Type
- Status
- Date Joined

Actions:
- View profile
- Edit website
- Login as user
- Suspend account

---

Website Management

List of all websites created on the platform.

Show:
- Website preview thumbnail
- Business name
- Domain
- Last edited date
- Status (Published / Draft)

Admin can:
- Open website editor
- Edit website on behalf of user
- Reset website template

---

CRM

Full CRM view for businesses.

Customer profiles include:
- Pet owner name
- Email
- Phone
- Pets
- Booking history
- Notes

---

Emails

Email campaign manager.

Features:
- Send updates to all businesses
- Send onboarding emails
- Automated booking notifications

---

Analytics

Graphs showing:

User growth
Bookings per month
Revenue
Website traffic

---

UX NOTES

Design the interface so:

- The left navigation is collapsible
- Panels can expand or collapse
- The layout feels like Webflow or Shopify
- Everything feels intuitive and modular

Include example screens:

1) Website Builder UI
2) Dashboard Overview
3) User Management Table
4) Website Editor Canvas
5) CRM Customer Profile
6) Analytics Page