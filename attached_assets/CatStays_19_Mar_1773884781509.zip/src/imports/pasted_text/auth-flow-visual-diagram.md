# CatStays Authentication Flow - Visual Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    CATSTAYS AUTHENTICATION SYSTEM                │
│                    3 Distinct Access Pathways                    │
└─────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════
                     PATHWAY 1: CUSTOMER LOGIN
═══════════════════════════════════════════════════════════════════

┌─────────────────┐
│  User arrives   │
│   at /login     │
└────────┬────────┘
         │
         ▼
┌────────────────────────────────────────┐
│       CUSTOMER LOGIN PAGE              │
│                                        │
│  🐱❤️ CatStays Logo                    │
│                                        │
│  "Welcome back"                        │
│  "Continue setting up your cattery     │
│   or access your dashboard"            │
│                                        │
│  [Email field]                         │
│  [Password field]                      │
│                                        │
│  [ Continue Setup → ]                  │
│                                        │
│  "Pick up right where you left off"   │
│                                        │
│  Don't have an account? Start trial   │
└────────┬───────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  CHECK localStorage:                │
│  'onboarding_progress'              │
│  {                                  │
│    currentStep: 4,                  │
│    published: false,                │
│    businessName: "Whisker Haven",   │
│    ...                              │
│  }                                  │
└─────────┬───────────────────────────┘
          │
          │
    ┌─────┴─────┐
    │           │
    ▼           ▼
┌───────┐   ┌────────┐
│  NOT  │   │ ALREADY │
│PUBLISH│   │PUBLISHED│
│  ED   │   │         │
└───┬───┘   └───┬────┘
    │           │
    ▼           ▼
┌────────────┐ ┌──────────────────────┐
│ /onboarding│ │ subdomain.catstays.  │
│ ?step=4    │ │ app/admin            │
│            │ │                      │
│ Resume at  │ │ Go to their          │
│ last step  │ │ dashboard            │
└────────────┘ └──────────────────────┘


═══════════════════════════════════════════════════════════════════
                    PATHWAY 2: ADMIN ACCESS
═══════════════════════════════════════════════════════════════════

┌──────────────────────────────────────────────────────────────┐
│                   METHOD 1: LOGO CLICK                        │
└──────────────────────────────────────────────────────────────┘

    User on marketing page
           │
           ▼
    ┌──────────────┐
    │ Click logo   │
    │ 5 times      │
    │ within 3s    │
    └──────┬───────┘
           │
           ▼
    ┌──────────────┐
    │ Click count  │
    │ tracker      │
    │ useAdminAcc. │
    └──────┬───────┘
           │
      ┌────┴────┐
      │ Count=5?│
      └────┬────┘
           │ YES
           ▼
    ┌────────────────────┐
    │ Open Admin Login   │
    │ Modal              │
    └────────────────────┘


┌──────────────────────────────────────────────────────────────┐
│              METHOD 2: KEYBOARD SHORTCUT                      │
└──────────────────────────────────────────────────────────────┘

    User on any page
           │
           ▼
    ┌──────────────┐
    │ Press:       │
    │ ⌘+Shift+A    │
    │ OR           │
    │ Ctrl+Shift+A │
    └──────┬───────┘
           │
           ▼
    ┌──────────────┐
    │ keydown      │
    │ listener     │
    │ useAdminAcc. │
    └──────┬───────┘
           │
           ▼
    ┌────────────────────┐
    │ Open Admin Login   │
    │ Modal              │
    └────────────────────┘


┌──────────────────────────────────────────────────────────────┐
│                 METHOD 3: DIRECT URL                          │
└──────────────────────────────────────────────────────────────┘

    User navigates to:
    admin.catstays.app
           │
           ▼
    ┌────────────────────┐
    │ /platform/         │
    │ admin-login        │
    │                    │
    │ Full-page admin    │
    │ login screen       │
    └────────┬───────────┘
             │
             ▼
    [Same login form as modal]


┌──────────────────────────────────────────────────────────────┐
│                   ADMIN LOGIN SCREEN                          │
└──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────┐
    │  🛡️ Shield Icon              │
    │                              │
    │  "CatStays Admin"            │
    │  "Manage your platform,      │
    │   customers, and growth"     │
    │                              │
    │  🔒 Secure Admin Access      │
    │                              │
    │  [Email field]               │
    │  [Password field]            │
    │                              │
    │  [ Login to Admin → ]        │
    │                              │
    │  Admin access only •         │
    │  Unauthorized prohibited     │
    └──────────┬───────────────────┘
               │
               ▼
    ┌──────────────────────────────┐
    │  /platform/dashboard         │
    │                              │
    │  SaaS Metrics ONLY:          │
    │  • Total customers           │
    │  • Active subscriptions      │
    │  • MRR / ARR                 │
    │  • Churn rate                │
    │  • Usage analytics           │
    │                              │
    │  NO booking/cat/room data    │
    └──────────────────────────────┘


═══════════════════════════════════════════════════════════════════
                 PATHWAY 3: POST-PUBLISH SUCCESS
═══════════════════════════════════════════════════════════════════

┌─────────────────┐
│ User completes  │
│ onboarding      │
│ Steps 1-7       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ User clicks     │
│ "Publish        │
│  Website"       │
└────────┬────────┘
         │
         ▼
┌──────────────────────────────────────────────────────────────┐
│              POST-PUBLISH SUCCESS SCREEN                      │
│                                                               │
│               ✨ Sparkles Icon (pulse animation)             │
│                                                               │
│           "Your cattery is live 🐾"                          │
│    "Your website and booking system are ready to go"         │
│                                                               │
│  ╔════════════════════════════════════════════════╗          │
│  ║   🌐 YOUR WEBSITE                              ║          │
│  ║                                                ║          │
│  ║   whiskerhaven.catstays.app     [📋 Copy]     ║          │
│  ║                                                ║          │
│  ║   ✓ Link copied to clipboard!                 ║          │
│  ╚════════════════════════════════════════════════╝          │
│                                                               │
│  ╔════════════════════════════════════════════════╗          │
│  ║ ❤️ How to access your system                  ║          │
│  ║                                                ║          │
│  ║ This is now your website AND your dashboard.  ║          │
│  ║                                                ║          │
│  ║ In future, access everything here:            ║          │
│  ║ → whiskerhaven.catstays.app                   ║          │
│  ║                                                ║          │
│  ║ 📊 Use this link to manage bookings           ║          │
│  ║ 📅 This is where customers will book          ║          │
│  ║ 🔖 Bookmark it for easy access                ║          │
│  ║                                                ║          │
│  ║ Login: Use the email/password you created     ║          │
│  ╚════════════════════════════════════════════════╝          │
│                                                               │
│           [  🌐 Go to My Website  ]  (primary)               │
│                                                               │
│      [📋 Copy Link]    [📊 Open Dashboard]  (secondary)      │
│                                                               │
│  "We've saved your progress — log back in anytime"          │
│                                                               │
└───────────────────────────────────────────────────────────────┘
         │
         │
    ┌────┴────┐
    │         │
    ▼         ▼
┌────────┐ ┌──────────┐
│ Visit  │ │  Open    │
│ Website│ │Dashboard │
└────────┘ └──────────┘


═══════════════════════════════════════════════════════════════════
                    DATA FLOW & STATE MANAGEMENT
═══════════════════════════════════════════════════════════════════

┌──────────────────────────────────────────────────────────────┐
│                    localStorage STRUCTURE                     │
└──────────────────────────────────────────────────────────────┘

{
  "onboarding_progress": {
    
    // Step tracking
    "currentStep": 5,                    ← Last completed step
    
    // Account info (Step 1)
    "email": "owner@whiskerhaven.com",
    "name": "Jane Smith",
    "password": "[hashed]",
    
    // Business info (Step 2)
    "businessName": "Whisker Haven",     ← Used for subdomain
    "phone": "+64 21 123 4567",
    "address": "123 Main St, Auckland",
    
    // Plan selection (Step 3)
    "selectedPlan": "professional",
    
    // Website data (Step 4)
    "websiteData": {
      "heroTitle": "Welcome to Whisker Haven",
      "aboutText": "Premium cat boarding...",
      "images": [...]
    },
    
    // Rooms configuration (Step 5)
    "roomsData": [
      { "name": "Deluxe Suite", "price": 45, ... }
    ],
    
    // Pricing & policies (Step 6)
    "pricingData": {
      "checkInTime": "2:00 PM",
      "checkOutTime": "11:00 AM",
      ...
    },
    
    // Status flags
    "published": false,                  ← Changes to true on publish
    "subdomain": "whiskerhaven",         ← Generated from businessName
    "publishedDate": null,
    "lastSaved": "2024-03-17T10:30:00Z"
  }
}


┌──────────────────────────────────────────────────────────────┐
│              AUTO-SAVE ON EVERY STEP CHANGE                   │
└──────────────────────────────────────────────────────────────┘

    User changes step
           │
           ▼
    ┌──────────────┐
    │ useEffect    │
    │ [currentStep]│
    └──────┬───────┘
           │
           ▼
    ┌──────────────┐
    │ Gather all   │
    │ form data    │
    └──────┬───────┘
           │
           ▼
    ┌──────────────┐
    │ localStorage │
    │ .setItem()   │
    └──────┬───────┘
           │
           ▼
    Progress saved! ✓


═══════════════════════════════════════════════════════════════════
                     CUSTOMER SUBDOMAIN ACCESS
═══════════════════════════════════════════════════════════════════

        Customer visits their subdomain:
        whiskerhaven.catstays.app
                    │
                    ▼
        ┌───────────────────────┐
        │  Route based on path: │
        └───────────┬───────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
    ┌──────┐  ┌────────┐  ┌────────┐
    │  /   │  │ /rooms │  │ /admin │
    │      │  │        │  │        │
    │ HOME │  │ ROOMS  │  │ LOGIN  │
    │ PAGE │  │ LIST   │  │ FIRST  │
    └──────┘  └────────┘  └───┬────┘
                              │
                              ▼
                         ┌────────────┐
                         │ Check auth │
                         └─────┬──────┘
                               │
                          ┌────┴────┐
                          │         │
                          ▼         ▼
                     ┌────────┐ ┌──────────┐
                     │ LOGGED │ │ REDIRECT │
                     │   IN   │ │ TO LOGIN │
                     └───┬────┘ └──────────┘
                         │
                         ▼
                    ┌─────────────────┐
                    │ ADMIN DASHBOARD │
                    │                 │
                    │ • Bookings      │
                    │ • Calendar      │
                    │ • Customers     │
                    │ • Rooms         │
                    │ • Settings      │
                    └─────────────────┘


═══════════════════════════════════════════════════════════════════
                    COMPLETE USER JOURNEY MAP
═══════════════════════════════════════════════════════════════════

DAY 1: DISCOVERY & SIGNUP
─────────────────────────
  User sees ad
      ↓
  Visits catstays.app
      ↓
  Clicks "Start Free Trial"
      ↓
  /signup page
      ↓
  Creates account (Step 1)
      ↓
  Email confirmation sent
      ↓
  Progress saved: step=1


DAY 1: PARTIAL ONBOARDING (INTERRUPTED)
────────────────────────────────────────
  Email confirmed
      ↓
  Returns to onboarding
      ↓
  Completes Steps 2-3
      ↓
  Gets phone call, closes browser
      ↓
  Progress saved: step=3


DAY 2: RESUME & COMPLETE
─────────────────────────
  Opens email with link
      ↓
  Clicks "Continue Setup"
      ↓
  Lands at /login
      ↓
  Enters credentials
      ↓
  System checks: published=false, step=3
      ↓
  Redirects to /onboarding?step=4
      ↓
  Sees progress restored
      ↓
  Completes Steps 4-7
      ↓
  Clicks "Publish Website"
      ↓
  SUCCESS SCREEN! 🎉
      ↓
  Copies URL, shares with team
      ↓
  Clicks "Go to My Website"
      ↓
  Sees live site
      ↓
  Bookmarks URL


DAY 3+: REGULAR USAGE
─────────────────────
  Opens bookmark: whiskerhaven.catstays.app
      ↓
  Navigates to /admin
      ↓
  Logs in (if needed)
      ↓
  Manages bookings
      ↓
  Checks calendar
      ↓
  Responds to customers


═══════════════════════════════════════════════════════════════════
                      ADMIN TEAM WORKFLOW
═══════════════════════════════════════════════════════════════════

  Admin needs to check platform metrics
      ↓
  Option 1: Press Cmd+Shift+A
  Option 2: Click logo 5 times
  Option 3: Go to admin.catstays.app
      ↓
  Admin login modal/page opens
      ↓
  Enters admin credentials
      ↓
  Authenticated via separate admin system
      ↓
  Redirected to /platform/dashboard
      ↓
  Views SaaS metrics:
    • Total customers: 1,247
    • Active subscriptions: 1,189
    • MRR: $35,670
    • Churn rate: 2.3%
    • New signups this week: 23
      ↓
  Reviews customer health scores
      ↓
  Exports analytics report
      ↓
  Logs out


═══════════════════════════════════════════════════════════════════
                        SECURITY BOUNDARIES
═══════════════════════════════════════════════════════════════════

┌──────────────────────────────────────────────────────────────┐
│                   CUSTOMER AUTHENTICATION                     │
│                                                               │
│  • Email + password                                           │
│  • JWT tokens (production)                                    │
│  • Access to THEIR subdomain only                             │
│  • Can manage THEIR data only                                 │
│  • Cannot see other customers                                 │
│  • Cannot access platform metrics                             │
└──────────────────────────────────────────────────────────────┘
                               ≠
┌──────────────────────────────────────────────────────────────┐
│                    ADMIN AUTHENTICATION                       │
│                                                               │
│  • Separate credentials                                       │
│  • Hidden access methods                                      │
│  • Access to platform dashboard                               │
│  • Can see ALL customer metrics                               │
│  • CANNOT manage individual bookings                          │
│  • Role-based permissions                                     │
└──────────────────────────────────────────────────────────────┘


═══════════════════════════════════════════════════════════════════
                         EDGE CASES HANDLED
═══════════════════════════════════════════════════════════════════

1. USER LOSES EMAIL CONFIRMATION
   → "Resend confirmation" link on login page
   → Email confirmation is optional (account still works)

2. USER FORGETS SUBDOMAIN
   → Email reminder sent after publish
   → "What's my URL?" link in account settings
   → Listed in their account dashboard

3. USER TRIES TO PUBLISH TWICE
   → "Already published" message
   → Option to "Visit your site" or "Edit settings"

4. ADMIN ACCIDENTALLY TRIGGERS MODAL
   → Easy to close (click outside or ESC key)
   → No harm done

5. USER BOOKMARKS WRONG URL
   → catstays.app/login still works
   → Redirects to correct subdomain after login

6. SUBDOMAIN NAME CONFLICT
   → Auto-append number (whiskerhaven2)
   → Suggest alternative names
   → User can customize

7. USER CHANGES BUSINESS NAME AFTER PUBLISH
   → Subdomain stays the same (no breaking change)
   → Display new name on site
   → Option to request subdomain change (support ticket)


═══════════════════════════════════════════════════════════════════
                           HAPPY PATHS
═══════════════════════════════════════════════════════════════════

✅ New user completes entire onboarding in one session
✅ User pauses midway, returns days later, resumes seamlessly
✅ User publishes, shares URL, visits site, manages bookings
✅ Admin checks metrics via keyboard shortcut
✅ User loses bookmark, goes to /login, gets redirected correctly
✅ Multiple team members can access same subdomain
✅ Customer books via public website, owner sees it in dashboard
✅ User feels ownership and confidence throughout


═══════════════════════════════════════════════════════════════════
                          SUCCESS!
═══════════════════════════════════════════════════════════════════

    The system is:
    
    🎯 Seamless     - No confusion, no lost progress
    🔒 Secure       - Customer/admin separation
    🎨 Branded      - Consistent CatStays design
    🎉 Delightful   - Celebration moments
    💪 Empowering   - Users feel ownership
    
    Users think: "This is MY system now."
    
    Mission accomplished. 🐾
```
