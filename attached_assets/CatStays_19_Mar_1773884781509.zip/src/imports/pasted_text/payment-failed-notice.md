Design a premium, calm, reassuring lock screen for CatStays when a subscription payment has failed and the account is paused.

---

GOAL:

This is NOT a scary error screen.

It should feel:
- calm
- reassuring
- easy to fix
- professional

User should feel:
“I just need to update my payment and I’m back in”

---

LAYOUT:

Centered card on soft background

Background:
- Light beige or soft gradient
- Slight blur overlay behind

Card:
- Rounded (20px radius)
- Soft shadow
- Generous padding

---

ICON:

Top of card:
- Subtle lock icon or pause icon
- Warm, not harsh (terracotta or muted tone)

---

HEADLINE:

Your account is temporarily paused

---

SUBHEADLINE:

We couldn’t process your subscription payment.

---

BODY TEXT:

To restore access to your website, bookings, and dashboard,
simply update your payment details below.

---

REASSURANCE LINE (IMPORTANT):

Your data is safe and will be restored as soon as payment is completed.

---

PRIMARY CTA:

Restore Access

(Button style: terracotta, prominent)

---

SECONDARY CTA:

Update Payment Method

(Subtle button or link)

---

OPTIONAL SMALL LINK (LOW PRIORITY):

View plans

(This opens upgrade page — do NOT push heavily)

---

FOOTNOTE:

You have 30 days to restore access before your data is permanently removed.

---

VISUAL DETAILS:

- Soft transitions
- No harsh red errors
- Avoid aggressive warning language
- Maintain brand warmth

---

ANIMATION:

- Fade in gently
- Slight scale-up for card
- Calm, not abrupt

---

GOAL:

Feels like:
A gentle pause — not a punishment

Avoid:
- “ERROR”
- “FAILED”
- “URGENT ACTION REQUIRED”
- aggressive red UI