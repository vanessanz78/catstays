Figma Design Prompt: CatStays Pricing Section (Boutique Cattery SaaS)

Overview:
Design a clean, modern, premium pricing section for CatStays, a boutique cattery management platform. The goal is simplicity, clarity, and emotional ease — no overwhelm, no complex tables. This should feel calming, trustworthy, and premium.

Brand Direction:

* Style: Warm, boutique, minimal
* Tone: Calm, friendly, professional
* Avoid: clutter, comparison tables, corporate SaaS feel

Brand Tokens:

* Primary navy: #0A1128
* Terracotta: #C46A3A
* Light background: #F8F7F5
* Soft beige cards: #F1ECE8
* Text primary: #0A1128
* Text secondary: #6B6B6B
* Accent (buttons): terracotta
* Border radius: 16–20px
* Shadows: very soft, warm
* Font pairing:

  * Headings: Playfair Display or similar elegant serif
  * Body: Inter or similar clean sans-serif

Layout Structure:

1. SECTION HEADER (centered)
   Headline:
   "Simple pricing for modern catteries"

Subheading:
"Everything you need to run your cattery — with no limits, no surprises, and no seasonal upgrades."

Value Highlight (small pill or line under subheading):
"No limits on rooms. No penalties for growth."

---

2. PRICING CARDS (3 columns, centered)

Cards should be slightly rounded, soft shadows, equal height.
Middle card highlighted slightly (scale 1.03 or subtle border glow).

---

CARD 1 — ESSENTIAL

Title:
"Essential"

Price:
"$49"
Small text: "/month"

Tagline:
"Everything you need to run your cattery"

Features:

* Booking system
* Customer & pet profiles
* Calendar management
* Website included
* Email confirmations & reminders
* AI data import

CTA Button:
"Start Free Trial"

Style:

* Background: soft beige
* Button: terracotta fill, white text

---

CARD 2 — PLUS (MOST POPULAR)

Badge:
"Most Popular"

Title:
"Plus"

Price:
"$69"
Small text: "/month"

Tagline:
"A better experience for you and your customers"

Features:

* Everything in Essential
* SMS notifications
* Pet updates (photos & messages)
* Automated reminders
* Smart workflows

CTA Button:
"Start Free Trial"

Style:

* Slightly elevated card
* Subtle terracotta border or glow
* Badge in terracotta pill

---

CARD 3 — COMPLETE

Title:
"Complete"

Price:
"$99"
Small text: "/month"

Tagline:
"For catteries offering more services"

Features:

* Everything in Plus
* Daycare module
* Grooming module
* Advanced automation
* Priority support

CTA Button:
"Start Free Trial"

Style:

* Same as Essential but slightly darker accent

---

3. TRUST LINE (below pricing cards)

Centered small text:
"Start your free trial. No credit card required."

Optional secondary line:
"Switch in minutes with AI-powered data import."

---

4. OPTIONAL VISUAL ELEMENTS

* Soft cat illustration or line icon accents
* Subtle paw icon bullets instead of standard dots
* Gentle hover states (lift + shadow)

---

UX NOTES:

* Keep whitespace generous
* Avoid comparison tables
* Make decisions feel effortless
* Focus on emotional clarity, not feature overload

---

GOAL:

User should instantly think:
"This is simple. I understand it. I know which one I want."

---

END
