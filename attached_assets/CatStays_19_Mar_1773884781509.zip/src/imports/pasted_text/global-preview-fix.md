Fix the routing, layout containment, and bookings navigation system so ALL pages render inside the mobile preview frame and are consistently centered.

This is a GLOBAL system fix — not page-by-page tweaks.

---

## PART 1: FIX OVERVIEW BREAKING OUT OF PREVIEW

Problem:

* Clicking “Overview” opens a full-size page outside the preview pane
* Breaks onboarding experience

Fix:

* Ensure ALL menu items (including Overview) use the SAME routing system as other working tabs

* Overview must:
  → render inside the preview frame (right panel)
  → NOT open a new window, route, or context

* Use internal preview routing:
  /overview
  /arrivals
  /departures
  /bookings
  /accounting

* Clicking Overview:
  → replaces preview content ONLY
  → keeps builder layout intact

---

## PART 2: GLOBAL PREVIEW CONTAINER RULE (CRITICAL)

ALL pages must render inside ONE shared container.

Create a single parent structure:

Preview Frame (mobile device)

* App Container (THIS CONTROLS EVERYTHING)

  * Header
  * Page Content (dynamic)

App Container rules:

* Width: 100%
* Max width: mobile frame width
* Center horizontally
* No overflow allowed

EVERY page (Overview, Bookings, Accounting, etc.) must render inside this container.

---

## PART 3: FIX “SHIFTED TO THE RIGHT” ISSUE (GLOBAL)

Problem:

* All pages are slightly pushed to the right
* Content overflows mobile frame

Fix at ROOT level:

* Remove:

  * fixed widths larger than container
  * translateX / margin offsets
  * nested frames exceeding width

* Apply:

Main App Container:

* Width: Fill container
* Constraints: left 0, right 0
* Horizontal padding: 16–20px

ALL child components:

* Width: 100%
* No fixed pixel widths beyond container

NO element should ever exceed screen width.

---

## PART 4: BOOKINGS TAB STRUCTURE

Upgrade “Bookings” menu item into a structured page with internal tabs.

---

## BOOKINGS PAGE LAYOUT

Header:
“Bookings”

Below header → tab switcher:

Tabs:

* Latest Bookings
* All Bookings

---

## TAB 1: LATEST BOOKINGS

* Shows most recent bookings first
* Sorted by newest → oldest

Each item:

* Cat name
* Owner name
* Dates
* Room
* Status (paid/unpaid)

Use same card style as arrivals

---

## TAB 2: ALL BOOKINGS

* Full list of bookings

* Also sorted by most recent first

* Includes search or filter (optional future enhancement)

---

## NEW BOOKING BUTTON

Add:
“+ New Booking” button at top of Bookings page

Behaviour:

* Opens booking creation flow (drawer or full screen inside preview)
* Must stay inside preview (NOT new page)

---

## INTERACTION RULES

* Switching tabs:
  → instant switch
  → no page reload

* Tabs must:
  → stay within same screen
  → not navigate away

---

## PART 5: CONSISTENCY ACROSS ALL PAGES

Ensure ALL pages:

* Overview
* Arrivals / Departures
* Bookings
* Accounting

Follow SAME rules:

✔ Render inside preview container
✔ Centered within mobile frame
✔ No horizontal overflow
✔ Same padding system
✔ Same width behaviour

---

## DO NOT

* Do NOT open new windows for any menu item
* Do NOT create separate layout systems per page
* Do NOT allow any component to exceed screen width
* Do NOT fix this page-by-page — fix the shared container

---

## SUCCESS CRITERIA

✔ Overview stays inside preview (no breakout)
✔ All pages centered correctly
✔ No content pushed off to the right
✔ Bookings page includes:

* Latest bookings tab
* All bookings tab
  ✔ New Booking button works inside preview
  ✔ Entire app feels like one contained mobile system
  ✔ No layout inconsistencies between pages
