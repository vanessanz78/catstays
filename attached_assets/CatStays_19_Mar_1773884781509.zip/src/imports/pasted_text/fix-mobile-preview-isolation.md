Fix the mobile preview so it behaves as a completely isolated, self-contained app viewport inside the onboarding page.

This is a GLOBAL interaction and containment fix.
Do not apply page-by-page tweaks.
Do not restyle components only.
Fix the preview architecture.

--------------------------------------------------
MAIN PROBLEM
--------------------------------------------------

The mobile app preview is not behaving like an isolated embedded app.

Current broken behaviour:
- Clicking any element inside the mobile preview scrolls the OUTER onboarding page back to the top
- Interactions inside the phone are affecting the parent browser/page instead of staying inside the phone viewport
- I cannot stay positioned on the rendered mobile dashboard
- I cannot test drawers properly because every interaction jumps me out of context
- Some screens/drawers are still wider than the phone and shifted right
- The preview does not behave like a real app inside a device frame

This must be fixed globally.

--------------------------------------------------
GOAL
--------------------------------------------------

The phone preview must behave like a fully embedded mobile app running inside a contained viewport.

That means:
- all interactions happen inside the phone frame
- all scrolling happens inside the phone frame
- drawers open inside the phone frame
- clicking buttons must NOT scroll the onboarding page
- clicking buttons must NOT reset the preview to the top
- the preview must keep its own local scroll position
- the parent onboarding page should remain completely still while interacting with the phone

--------------------------------------------------
REQUIRED ARCHITECTURE
--------------------------------------------------

Create one isolated mobile preview container and make every preview route/screen render inside it.

Required structure:

Onboarding Page
- Onboarding content
- Mobile Preview Wrapper
  - Device Frame
    - Mobile App Viewport
      - Active Screen Content
      - Overlay Layer
        - Drawers
        - Popovers
        - Modals

The Mobile App Viewport must be the ONLY interactive surface for the previewed app.

--------------------------------------------------
MOBILE APP VIEWPORT RULES
--------------------------------------------------

The Mobile App Viewport must:

- have a fixed height equal to the visible phone screen area
- have overflow-y: auto
- have overflow-x: hidden
- have position: relative
- clip all child content to the phone frame
- contain all routing, scrolling, drawers, and state changes locally

Nothing inside the preview should ever scroll the parent onboarding page.

--------------------------------------------------
STOP THE JUMP-TO-TOP BUG
--------------------------------------------------

Remove any parent-level scroll reset behaviour.

Prevent ALL of the following from affecting the outer page:
- route changes inside preview
- button clicks inside preview
- anchor links inside preview
- focus events inside preview
- drawer open/close actions
- tab switches inside preview
- form input focus inside preview

Specifically:
- remove any window.scrollTo(0,0)
- remove any scrollIntoView on preview interactions
- remove any autoFocus that shifts the page
- prevent anchor/default navigation behaviour
- preserve local preview scroll position on every interaction

The onboarding page must NOT move when interacting inside the phone.

--------------------------------------------------
ISOLATE PREVIEW ROUTING
--------------------------------------------------

All preview navigation must stay inside the Mobile App Viewport only.

Examples:
- Overview
- Bookings
- Accounting
- Arrivals
- Departures
- Occupancy
- Drawers
- New Booking flow

All of these must render INSIDE the phone viewport only.

Do NOT:
- navigate the parent page
- re-render the onboarding page from top
- mount screens outside the phone frame
- open separate full-page preview windows

--------------------------------------------------
GLOBAL DRAWER / OVERLAY FIX
--------------------------------------------------

All drawers must be rendered inside a shared overlay layer inside the Mobile App Viewport.

Correct structure:
Mobile App Viewport
- Screen content
- Overlay Layer
  - dim background
  - drawer

All drawers must:
- open from bottom of the phone screen
- stay clipped inside the phone frame
- never exceed phone width
- never shift to the right
- never render outside the phone
- trap interaction while open
- lock background scrolling inside the preview only

When drawer is open:
- screen content behind drawer must not scroll
- onboarding page must not scroll
- only the drawer content may scroll

--------------------------------------------------
GLOBAL WIDTH / CENTERING FIX
--------------------------------------------------

Fix the right-shift issue at the root level.

The mobile app content is currently wider than the device viewport.
That is why it looks like there is left padding and no right padding.

Fix:
- create one shared inner content container for all screens
- width: 100%
- max width: 100% of phone viewport
- box-sizing: border-box
- horizontal padding: 16px or 20px
- no child component may exceed this width

Remove globally:
- negative margins
- translateX offsets
- manual nudging
- widths larger than parent
- any layout that causes right overflow

Every screen must be centered within the phone.
Equal left and right spacing everywhere.

--------------------------------------------------
SCROLL CONTAINMENT
--------------------------------------------------

The preview must own its own scroll.

Required behaviour:
- user scrolls inside phone → only phone content scrolls
- user taps button inside phone → page does not jump
- user opens drawer → drawer scroll is local
- user closes drawer → returns to same position inside phone
- onboarding page behind remains static

The preview must remember its local scroll state while testing.

--------------------------------------------------
INTERACTION RULES
--------------------------------------------------

Inside the phone:
- buttons act like app buttons, not page anchors
- tabs switch local content only
- cards open local drawers only
- menu items change local preview route only

Do not allow any interaction inside the phone to affect:
- browser window scroll
- onboarding page scroll
- outer layout position
- page-level routing

--------------------------------------------------
DEBUG / VALIDATION STEP
--------------------------------------------------

Temporarily add visible debug boundaries to verify containment:

- outline the Mobile App Viewport
- outline the shared inner content container
- outline the overlay layer

Confirm:
- nothing spills outside the phone frame
- no screen is wider than viewport
- all drawers stay inside phone
- all interactions remain local

Once confirmed, remove debug outlines.

--------------------------------------------------
SUCCESS CRITERIA
--------------------------------------------------

This fix is only complete if ALL are true:

- Clicking inside the phone never scrolls the onboarding page to the top
- The mobile preview keeps its own local scroll position
- Every screen renders fully inside the phone frame
- All drawers open and remain inside the phone frame
- No content is pushed to the right
- Equal left and right margins everywhere
- No horizontal overflow
- The phone preview behaves like a real embedded mobile app
- I can fully test interactions without losing my place