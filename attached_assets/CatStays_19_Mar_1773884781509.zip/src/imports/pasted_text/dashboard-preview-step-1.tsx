Step 1: Replace the DashboardPreviewStep.tsx file
In the other Figma session, completely replace /src/app/pages/onboarding/DashboardPreviewStep.tsx with this:

import { useState } from 'react';
import { Smartphone, Tablet, Laptop } from 'lucide-react';
import { Button } from '../../components/ui/button';
// This imports YOUR EXISTING dashboard - the one with arrivals/departures/swipeable dates
import { AdminDashboard } from '../admin/Dashboard';

type DeviceType = 'mobile' | 'tablet' | 'laptop';

export function DashboardPreviewStep() {
  const [device, setDevice] = useState<DeviceType>('mobile');

  const deviceFrames = {
    mobile: {
      width: 375,
      height: 667,
      scale: 0.8,
      borderRadius: '36px',
      padding: '16px',
      bezel: true
    },
    tablet: {
      width: 768,
      height: 1024,
      scale: 0.5,
      borderRadius: '24px',
      padding: '24px',
      bezel: true
    },
    laptop: {
      width: 1440,
      height: 900,
      scale: 0.4,
      borderRadius: '12px',
      padding: '0px',
      bezel: false
    }
  };

  const currentDevice = deviceFrames[device];

  return (
    <div className="space-y-6">
      {/* Device Selector */}
      <div className="flex justify-center gap-3">
        <Button
          onClick={() => setDevice('mobile')}
          variant={device === 'mobile' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'mobile' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          Mobile
        </Button>
        <Button
          onClick={() => setDevice('tablet')}
          variant={device === 'tablet' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'tablet' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Tablet className="w-4 h-4" />
          Tablet
        </Button>
        <Button
          onClick={() => setDevice('laptop')}
          variant={device === 'laptop' ? 'default' : 'outline'}
          className={`rounded-xl gap-2 ${
            device === 'laptop' 
              ? 'bg-[#0A1128] hover:bg-[#0A1128]/90 text-white' 
              : 'border-[#0A1128]/20 text-[#0A1128] hover:bg-[#0A1128]/5'
          }`}
        >
          <Laptop className="w-4 h-4" />
          Laptop
        </Button>
      </div>

      {/* Device Preview Frame */}
      <div className="flex justify-center items-center py-8">
        <div 
          className="relative bg-white shadow-2xl"
          style={{
            width: `${currentDevice.width * currentDevice.scale}px`,
            height: `${currentDevice.height * currentDevice.scale}px`,
            borderRadius: currentDevice.borderRadius,
            border: currentDevice.bezel ? '8px solid #1a1a1a' : '1px solid #e5e5e5',
            overflow: 'hidden'
          }}
        >
          {/* Device Notch (for mobile only) */}
          {device === 'mobile' && (
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-[#1a1a1a] rounded-b-2xl z-10" />
          )}

          {/* Scrollable Dashboard Content */}
          <div 
            className="w-full h-full overflow-auto"
            style={{
              transform: `scale(${currentDevice.scale})`,
              transformOrigin: 'top left',
              width: `${currentDevice.width}px`,
              height: `${currentDevice.height}px`,
            }}
          >
            <AdminDashboard />
          </div>
        </div>
      </div>

      {/* Info Text */}
      <div className="bg-[#0A1128]/5 rounded-2xl p-6 text-center max-w-2xl mx-auto">
        <p className="text-[#0A1128]/70">
          This is what you and your staff will see when you click <strong>"Staff Login"</strong> on your website.
          The dashboard is fully responsive and works beautifully on any device.
        </p>
      </div>
    </div>
  );
}
Step 2: Verify the import is correct
The key line is:

import { AdminDashboard } from '../admin/Dashboard';
This should point to YOUR existing dashboard at /src/app/pages/admin/Dashboard.tsx

If it doesn't work, ask the AI to check:

Is the file at /src/app/pages/admin/Dashboard.tsx?
What is the exported component name? (Look for export function AdminDashboard() or export default function Dashboard())
If it's exported differently, change the import to match. For example:

If it's export default function Dashboard(), use: import Dashboard from '../admin/Dashboard'; and change <AdminDashboard /> to <Dashboard />
Quick Verification Prompt
After pasting the code above, ask the AI this in the other session:

"I just replaced DashboardPreviewStep.tsx with new code. Please verify:

Does /src/app/pages/admin/Dashboard.tsx exist?
What is the exact export statement in that file? (show me line with 'export')
Try to navigate to /onboarding Step 5 - what do you see? Does it show the dashboard with arrivals, departures, and payment badges?"
This should fix it! The critical part is that import statement - it MUST point to your existing dashboard, not create a new one. 🎯