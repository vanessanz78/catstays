Refactor the onboarding “Rooms + Pricing” step to be flexible, intelligent, and globally adaptive based on the user’s business location.

---

CORE GOAL:

Create a system that:
- Adapts to different cattery setups
- Automatically adjusts tax logic based on location
- Minimises user input and thinking

User should feel:
“This system already understands my business”

---

PREREQUISITE:

Use the Business Address entered earlier in onboarding.

System must extract:
- Country
- Region (if available)

---

SECTION 1: ROOMS

TITLE:
Your Rooms

SUBTEXT:
Set up the types of rooms you offer

---

DEFAULT:

Show 1 room type card

---

ROOM TYPE CARD:

Fields:

1. Room Type Name  
(“Private Room”, “Family Room”, etc.)

2. Number of Rooms  

3. Max Cats per Room  

4. Toggle:
Shared Room?

[ ] Yes — cats may share  
[ ] No — private only  

---

ADD BUTTON:

+ Add another room type

Limit:
Max 3 room types

---

UX:

- Smooth add/remove animations
- Clean stacked layout

---

SECTION 2: PRICING

TITLE:
Your Pricing

---

PART 1: PRICING TYPE

Label:
How do you charge?

● Per Day  
○ Per Night  

---

PART 2: BASE PRICE

Label:
Price per cat

Input:
$ amount

---

SECTION 3: SALES TAX (AUTO-DETECTED)

TITLE:
Sales Tax

---

PART 1: AUTO DETECTION (VERY IMPORTANT)

System automatically detects tax type based on address:

Examples:

IF Country = New Zealand:
→ Label = GST  
→ Default rate = 15%

IF Country = Australia:
→ Label = GST  
→ Default rate = 10%

IF Country = UK / EU:
→ Label = VAT  
→ Default rate = 20% (or region-based)

IF Country = USA:
→ Label = Sales Tax  
→ Default rate = blank or region-specific

---

DISPLAY:

Label dynamically updates:

Example:
“GST (New Zealand)”
“VAT (United Kingdom)”
“Sales Tax (California, USA)”

---

PART 2: INCLUDE TAX TOGGLE

Label:
Does your price include [AUTO TAX NAME]?

● Yes — included  
○ No — added on top  

---

PART 3: TAX RATE FIELD

Label:
[TAX NAME] rate (%)

Auto-filled with default if known

User can override

---

HELP TEXT:

“Based on your location — you can adjust if needed”

---

PART 4: LIVE PRICE CALCULATION

Dynamic preview updates in real-time.

---

CASE 1: TAX INCLUDED

User enters:
$23 (incl GST 15%)

System calculates:
- Base: $20.00  
- Tax: $3.00  
- Total: $23.00  

---

CASE 2: TAX EXCLUDED

User enters:
$20

System calculates:
- Tax: $3.00  
- Total: $23.00  

---

DISPLAY FORMAT:

$20.00 + $3.00 GST = $23.00 total

---

UI:

- Show in soft card
- Highlight total
- Clear breakdown

---

SECTION 4: MULTI-CAT PRICING

TITLE:
Multi-cat setup

---

TOGGLE:
Offer multi-cat discounts?

[ ] Yes  
[ ] No  

---

IF YES:

Field:
Discount per additional cat

---

SECTION 5: ROOM PRICING RULES

TITLE:
Room pricing rules

---

TOGGLE:
Different pricing for shared vs private?

[ ] Yes  
[ ] No  

---

IF YES:

Shared room adjustment:
“- $5 per cat”

Private room adjustment:
“+ $10 per cat”

---

SECTION 6: UX DESIGN

- Use card-based layout
- Icons:
  🏠 Rooms  
  💲 Pricing  
  🧾 Tax  
  🐾 Multi-cat  

- Progressive reveal (toggles expand sections)
- Keep layout clean and fast

---

SECTION 7: MICROCOPY

Rooms:
“Start simple — you can refine this later”

Pricing:
“You can update pricing anytime”

Tax:
“We’ve pre-filled this based on your location”

---

SECTION 8: DATA STRUCTURE

ROOMS:
- name
- number_of_rooms
- max_cats_per_room
- is_shared

PRICING:
- pricing_type
- base_price

TAX:
- tax_type (GST/VAT/Sales Tax)
- tax_rate
- tax_inclusive
- calculated_tax_amount
- total_price
- country

MULTI-CAT:
- multi_cat_discount

ROOM RULES:
- shared_price_adjustment
- private_price_adjustment

---

SECTION 9: BEHAVIOUR

- Auto-detect tax from address
- Pre-fill intelligently
- Allow manual override
- Real-time calculation updates
- Smooth UI transitions

---

SECTION 10: GLOBAL FLEXIBILITY

System must support:
- NZ (GST)
- AU (GST)
- UK/EU (VAT)
- US (Sales Tax)
- Other countries (fallback = “Sales Tax”)

---

GOAL:

User completes setup quickly with minimal thinking.

They feel:
“This system just gets it”

---

AVOID:

- forcing tax knowledge
- manual calculations
- rigid structures

---

RESULT:

A globally intelligent onboarding experience that adapts to each business automatically.