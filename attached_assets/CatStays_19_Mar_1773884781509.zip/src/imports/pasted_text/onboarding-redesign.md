Redesign the signup and onboarding entry experience to feel like a seamless, premium transition — not a separate page.

---

CORE CHANGE:

Replace the current full-page signup screen with a MODAL OVERLAY that appears on top of the existing website.

BACKGROUND BEHAVIOUR:
- Dim the background (dark overlay at 40–60%)
- Slight blur effect on the website behind
- Maintain visible context of the page they came from
- Prevent full page navigation

ANIMATION:
- Modal fades + scales in (soft zoom, 0.95 → 1)
- Smooth transition (300–400ms ease)
- Feels calm and premium, not abrupt

---

ENTRY LOGIC (VERY IMPORTANT):

CASE 1 — USER CLICKS “START FREE TRIAL” (no plan selected):
- Show generic signup modal
- No plan pre-selected
- Messaging: “Start your free trial”

CASE 2 — USER CLICKS A PRICING PLAN (Starter / Professional / Premium):
- Modal MUST dynamically reflect selected plan
- Highlight selected plan at top of modal

---

MODAL STRUCTURE:

TOP SECTION:
- Small CatStays logo
- Plan badge (if selected):
  Example:
  “Professional Plan — $69/month”

HEADLINE:
IF PLAN SELECTED:
Start your free trial with [Plan Name]

IF NO PLAN:
Start your free trial

SUBTEXT:
No credit card required • 14-day free trial

---

PLAN CONFIRMATION BLOCK (ONLY IF PLAN SELECTED):

Card-style section:
- Plan name
- Price
- Bullet list of inclusions

Example:
What you’ll get:
✔ Unlimited bookings  
✔ Automated reminders  
✔ Daily cat updates  
✔ Priority support  

Small text under:
You can change or upgrade anytime

---

FORM SECTION:

Fields:
- Business Name
- Your Name
- Email
- Password

CTA BUTTON:
IF PLAN SELECTED:
Start [Plan Name] Setup

IF NO PLAN:
Continue to Setup

---

TRANSITION AFTER SIGNUP:

DO NOT jump to a new page abruptly.

Instead:
- Modal expands into onboarding flow
- Progress bar animates in
- Step 1 begins smoothly

---

ONBOARDING FLOW CONNECTION:

IF PLAN WAS SELECTED:
- Lock in selected features visually
- Show small label throughout onboarding:
  “You’re setting up: Professional Plan”

IF NO PLAN:
- Default to Starter (free/basic)
- At final step, introduce upgrade prompt

---

UPGRADE MOMENT (END OF FLOW):

If user started without plan:

Show upgrade screen:
“Unlock more features in seconds”

Options:
- Upgrade to Professional ($69)
- Upgrade to Premium ($99)

Copy:
Add automated updates, reminders, and more — without changing your setup.

---

DESIGN STYLE:

- Rounded modal (16–20px radius)
- Soft shadow (premium feel)
- Terracotta primary button
- Navy headings
- Warm neutral background

---

GOAL:

The experience should feel like:
- One continuous journey
- Calm, guided, and intentional
- Premium SaaS onboarding (like Stripe / Linear)

Avoid:
- Hard page reloads
- Losing context
- Generic signup feeling