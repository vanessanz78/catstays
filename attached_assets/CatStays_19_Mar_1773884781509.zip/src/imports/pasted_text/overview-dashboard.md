Restore and enhance the Overview screen inside the mobile dashboard preview without breaking the preview containment.

---

## PROBLEM

The Overview screen was previously richer and included:

* Insights section
* Upgrade plan prompt
* Additional summary / guidance content

After fixing preview containment, these sections were removed or replaced with a simplified layout.

We need to RESTORE these sections without breaking layout or responsiveness.

---

## GOAL

Rebuild the Overview screen as a complete dashboard including:

1. Summary Stats (existing)
2. Recent Activity (existing)
3. Insights (restore)
4. Upgrade Plan / Monetisation (restore)
5. Maintain full mobile containment

---

## SECTION 1 — KEEP EXISTING

Keep:

* Revenue
* Bookings
* Customers
* Occupancy

Keep layout as 2x2 grid cards

---

## SECTION 2 — RECENT ACTIVITY (KEEP + ENHANCE)

Keep current activity feed

Enhance:

* Show max 3–5 items
* Add "View All" link (already present)
* Ensure proper spacing and scroll inside container

---

## SECTION 3 — INSIGHTS (RESTORE)

Add new section BELOW Recent Activity:

Title: "Insights"

Content examples:

* "Your occupancy is up 12% this month"
* "You have 3 unpaid bookings"
* "Weekend bookings are your busiest period"

Design:

* Card style container
* Soft background (light neutral)
* Icon + short insight text
* Optional trend indicators (↑ ↓)

---

## SECTION 4 — UPGRADE / MONETISATION (RESTORE)

Add section BELOW Insights:

Title: "Grow your business"

Content:

* Short message:
  "Unlock automated reminders, reporting, and more"

* CTA button:
  "Upgrade Plan"

Design:

* Slightly highlighted card (subtle gradient or tint)
* Rounded corners
* Clear call-to-action button

---

## SECTION 5 — SCROLL STRUCTURE (IMPORTANT)

Ensure:

* Entire Overview screen scrolls vertically INSIDE mobile container
* No content is cut off
* No scroll jumping to top

---

## SECTION 6 — DO NOT BREAK EXISTING FIXES

Maintain:

* Mobile preview containment
* Centered layout
* No overflow
* No scroll reset bug

---

## LAYOUT ORDER (FINAL)

1. Header (Overview)
2. Stats cards (2x2)
3. Recent Activity
4. Insights
5. Upgrade Plan

---

## SUCCESS CRITERIA

✔ Overview feels like a complete dashboard again
✔ Insights + upgrade sections are visible
✔ Everything scrolls smoothly inside mobile
✔ No layout shift or overflow
✔ No content lost
✔ Maintains clean, premium mobile UX
