Redesign the entire CatStays onboarding, signup, and website creation flow to be logical, state-driven, and conversion-optimised.

---

CORE PROBLEM:

Current issues:
- Redundant pre-signup popup (business name capture does nothing)
- Data is cached incorrectly and persists across new sessions
- No true account creation before onboarding
- Disjointed flow between signup → onboarding → preview → dashboard
- No clear ownership moment

---

CORE PRINCIPLE:

Account FIRST → then onboarding → then build → then preview → then dashboard → then publish

---

PART 1: REMOVE REDUNDANT SCREEN

DELETE:
Initial popup asking for cattery name

REASON:
- No account exists yet
- Data is not saved
- No way to recover
- Creates friction with no value

---

PART 2: NEW SIGNUP ENTRY POINT

When user clicks:
→ “Start Free Trial”

OPEN:
→ Signup modal

FIELDS:
- Full Name
- Email
- Password

CTA:
Create My Account →

---

AFTER SUBMIT:

Show:
→ Account Created screen (email confirmation)

Then:

AFTER EMAIL CONFIRMATION:
→ Enter onboarding

---

IMPORTANT:

NO onboarding before account exists

---

PART 3: STATE MANAGEMENT (CRITICAL FIX)

System must:

- Clear cached session when:
  - new email used
  - logout occurs

- Persist data ONLY per user account

STORE:
- onboarding progress
- selected plan
- entered data

On login:
→ Resume EXACT last step

---

PART 4: NEW ONBOARDING FLOW (SIMPLIFIED + LOGICAL)

STEP 1:
Import or Start

Options:
- Import from existing website (URL input)
- Start from scratch

---

STEP 2:
Cattery Details

- Business name
- Location (auto address lookup)
- Phone
- Email

---

STEP 3:
Website Builder (MAJOR CHANGE)

Split screen layout:

LEFT PANEL (controls):
- Logo upload
- Brand colours
- Fonts
- Heading styles
- Layout style (template options)

Sections:
- Collapsible groups (Brand / Layout / Content)

RIGHT PANEL:
→ LIVE WEBSITE PREVIEW

- Fully rendered site
- Scrollable
- Realistic layout

INTERACTION:
- Click any section → edit inline
- Changes reflect instantly

---

TEMPLATES:

Offer 3–5 starter templates:
- Boutique luxury
- Clean modern
- Playful family

---

PART 4: BOOKING RULES (MOVE PRICING HERE)

Move ALL pricing + capacity into this step

Rename:
→ Booking Setup

---

ROOM SETUP:

Ask:
“How many room types do you offer?”

Default:
1 room type

Allow:
+ Add up to 3 room types

For each room type:
- Name (editable)
- Number of rooms
- Max cats per room
- Shared room toggle

---

PRICING:

- Price input
- Toggle:
  Per Day / Per Night

---

MULTI-CAT LOGIC:

Toggle:
Multi-cat discount?

IF ON:
- % or fixed discount

---

TAX LOGIC (AUTO BY LOCATION):

Based on address:

- NZ → GST
- AU → GST
- EU → VAT
- US → Sales Tax

---

TOGGLE:

Prices include tax?

IF ON:
→ reverse calculate tax portion

IF OFF:
→ add tax on top

---

SHOW LIVE CALCULATION:

Example:
$30 → $34.50 incl GST (15%)

---

PART 5: DASHBOARD PREVIEW (NOT REAL DASHBOARD)

Instead of “Dashboard Overview” page:

Create:

→ Interactive Dashboard Preview

User can:
- click around
- explore bookings UI
- see system

BUT:
Label clearly:
“Preview of your dashboard”

---

PART 6: WEBSITE PREVIEW (KEY MOMENT)

Before publish:

Show FULL WEBSITE:

- Real layout
- Images (use placeholders if none)
- Fully scrollable

Allow:
- Click sections → edit

NO navigation away

---

PART 7: MODULE UPSELL (SMART TIMING)

Before publish:

Screen:
Enhance Your Cattery

Options:
- SMS updates
- Pet updates
- Daycare module
- Grooming module

Show:
- visual preview of each

CTA:
Add to my plan

OR:
Skip for now

---

PART 8: PUBLISH FLOW

Final screen:

Ready to go live?

CTA:
Publish My Website

---

PART 9: SUCCESS SCREEN (OWNERSHIP MOMENT)

Headline:
Your cattery is live 🐾

Subheadline:
You’re now ready to accept your first booking

---

SHOW URL:

yourname.catstays.app

Large
Copy button

---

INSTRUCTIONS:

This is your website and your dashboard.

Use this link to:
- accept bookings
- manage your business

---

CTA:
Go to My Website

---

NOTE:

If custom domain:
“Your domain may take a few minutes to connect”

---

PART 10: LOGIN SYSTEM (CLARITY FIX)

HEADER:
Sign In → /login

---

LOGIN BEHAVIOUR:

IF onboarding incomplete:
→ resume onboarding

IF complete:
→ go to their site dashboard

---

CUSTOMER DASHBOARD:

theirname.catstays.app/admin

---

FOOTER (ALL PAGES):

Add:
Admin Login

→ links to admin.catstays.app

---

PART 11: ADMIN ACCESS (YOU)

3 methods:

1. admin.catstays.app  
2. hidden logo 5-click trigger  
3. keyboard shortcut  

---

ADMIN DASHBOARD:

- users
- subscriptions
- revenue
- funnel

NO bookings or cats

---

PART 12: KEY UX PRINCIPLES

- No dead-end screens
- No data before account creation
- Everything saved + resumable
- Live preview always visible when designing
- User always feels:
  “This is my system”

---

GOAL:

A seamless SaaS experience that feels:
- premium
- intuitive
- emotionally rewarding
- easy to complete

Avoid:
- duplicate steps
- disconnected flows
- confusing navigation