Enhance the “Start from scratch / Start from template” section to become a functional template selection experience that feeds directly into the live website builder.

---

CORE GOAL:

Transform this step into:
- visual
- inspiring
- interactive

User should feel:
“I’m choosing what my website will look like”

---

TRIGGER BEHAVIOUR:

When user clicks:
→ “Start from Template” (or “Start from Scratch”)

DO NOT go to a form.

Instead:
→ Navigate to TEMPLATE SELECTION SCREEN

---

SCREEN: TEMPLATE SELECTION

TITLE:

Choose your starting style

SUBTITLE:

Pick a design to get started — you can customise everything later

---

LAYOUT:

Grid of 6 template cards (2 rows x 3 columns)

Each card:
- Rounded corners
- Subtle shadow
- Hover lift effect

---

TEMPLATE CARDS (6 OPTIONS):

1. Boutique Luxury
- Large hero image
- Elegant serif headings
- Minimal layout
- Soft neutral tones

2. Clean Modern
- Simple grid layout
- Sans-serif fonts
- Balanced spacing
- Clear CTAs

3. Playful Family
- Bright colours
- Rounded elements
- Friendly typography
- More personality

4. Image Focused
- Full-width photography
- Gallery-heavy
- Minimal text

5. Split Layout
- Text left, image right
- Structured sections
- Informational feel

6. Classic Service
- Traditional stacked layout
- Header, services, pricing, contact
- Familiar structure

---

EACH CARD INCLUDES:

- Thumbnail preview (mini website)
- Template name
- Short descriptor

---

INTERACTION:

Click template →
→ instantly loads that template
→ transitions into WEBSITE BUILDER

---

PART 2: WEBSITE BUILDER (CONNECTED FLOW)

After template selection:

Open full-screen builder:

LEFT PANEL:
- Branding (logo, colours, fonts)
- Layout options
- Section toggles
- Content editing

RIGHT PANEL:
→ LIVE WEBSITE PREVIEW

- Fully rendered
- Scrollable
- Real content

---

IMPORTANT BEHAVIOUR:

If user came from:
→ URL Import

Then:

- System auto-fills content into DEFAULT template
- Still land on builder screen
- Show banner:

“We’ve imported your content — feel free to change your design”

---

ALLOW TEMPLATE SWITCHING:

Inside builder:

Add:
“Change Template” button

→ opens template selector again

→ preserves content
→ swaps layout only

---

TRANSITION:

Use smooth animation:

Template grid → zoom into selected → becomes full site preview

---

MICROCOPY (IMPORTANT):

Reassure user:

“You can change this anytime”

---

GOAL:

User feels:

“I’ve just chosen my website design”
“I can already see it coming together”

---

AVOID:

- sending user into forms immediately
- static template selection with no feedback
- losing imported data when switching templates

---

RESULT:

A seamless flow:

Start → Choose design → See it live → Edit instantly

Like:
Shopify / Squarespace level experience