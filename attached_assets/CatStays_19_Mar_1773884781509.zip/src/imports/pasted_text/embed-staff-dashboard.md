Update the onboarding builder experience so the Staff Dashboard (admin panel) is fully rendered INSIDE the website preview frame (mock Chrome browser), not as a separate page or external window.

---

## GOAL

Create a seamless, fully interactive embedded preview where:

* The staff dashboard loads inside the preview pane
* It behaves like a real, live application
* It does NOT open in a new tab, modal, or external route
* It maintains the illusion of “this is your live website”

---

## CURRENT ISSUE

* Staff login redirects to a separate screen or context
* Breaks onboarding flow
* Removes user from builder experience
* Dashboard is not contained within preview frame

---

## REQUIRED BEHAVIOUR

When user clicks “Staff Login” inside preview:

→ Load the dashboard INSIDE the preview frame (right panel)

NOT:

* New window
* Full page redirect
* Overlay modal

YES:

* Replace preview content with dashboard UI
* Maintain browser chrome (top bar with URL)
* Maintain builder layout (left editor + right preview)

---

## PREVIEW FRAME RULES

The preview frame must behave like an embedded browser:

* Acts as a container for ALL routes:

  * Homepage
  * Booking flow
  * Client portal
  * Staff dashboard

* Dashboard must:

  * Fully render inside this frame
  * Be scrollable within frame only
  * Be clickable and interactive

---

## ROUTING LOGIC (CRITICAL)

Implement internal routing within preview container:

* Use a “virtual routing” system scoped to preview

* Example routes:

  * / → homepage
  * /booking → booking flow
  * /portal → client portal
  * /staff → staff dashboard

* Clicking “Staff Login”:
  → switches preview route to /staff
  → does NOT affect outer app

---

## LAYOUT STRUCTURE

Keep existing builder layout:

LEFT:

* Website builder controls (editing panel)

RIGHT:

* Preview frame (mock Chrome window)

Inside preview frame:

* Render full dashboard UI

---

## INTERACTION REQUIREMENTS

* All dashboard elements must be clickable:

  * Navigation
  * Cards
  * Buttons
  * Tables
  * Alerts

* Scrolling must be contained within preview frame

* No interaction should break out into parent app

---

## VISUAL CONSISTENCY

* Maintain Chrome-style header (URL bar, controls)

* Update URL text dynamically:
  e.g. catstays.app/staff

* Dashboard must inherit:

  * Same design system
  * Same spacing
  * Same typography

---

## STATE HANDLING

* Maintain session state inside preview
* If logged in:
  → stay in dashboard view
* If refreshed:
  → return to homepage preview

---

## UX GOAL

User should feel like:

“I’m editing my website AND using it live at the same time”

No context switching
No broken flow
No external navigation

---

## SUCCESS CRITERIA

✔ Staff dashboard loads inside preview frame
✔ No new tabs or redirects
✔ Fully interactive UI inside preview
✔ Routing contained within preview
✔ Builder (left panel) always visible
✔ Scroll + interactions isolated to preview
✔ Feels like a real embedded web app
