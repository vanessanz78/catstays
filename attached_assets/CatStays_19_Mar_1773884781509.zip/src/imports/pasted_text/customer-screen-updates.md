Fix the Customers screen and underlying layout system to resolve right-alignment issues, enable live search, and implement a fully functional add/edit customer drawer with stable interaction.

This is both a GLOBAL layout fix and a FEATURE implementation.

---

## PART 1 — FIX RIGHT-SHIFT / OFF-SCREEN ISSUE (CRITICAL)

PROBLEM:

* Entire screen content is pushed to the right
* Right side is cut off
* Appears like left padding but is actually overflow

ROOT CAUSE:

* Content width exceeds mobile viewport
* No proper container constraint system

---

## GLOBAL FIX (APPLY TO ALL SCREENS)

Create ONE shared layout wrapper used across ALL screens:

* width: 100%
* max-width: 100%
* padding-left: 16px (or 20px)
* padding-right: 16px (or 20px)
* box-sizing: border-box

ALL components must live inside this wrapper.

---

## REMOVE ALL BREAKING STYLES

Remove globally:

* fixed widths larger than parent
* translateX / positioning offsets
* negative margins
* width values like 360px / 380px exceeding viewport
* anything causing horizontal overflow

---

## CHILD COMPONENT RULES

For ALL elements (cards, inputs, buttons):

* width: 100%
* no overflow outside container
* respect parent padding

---

## DEBUG STEP (MANDATORY)

Temporarily outline container:

* confirm NOTHING exceeds it
* fix anything spilling outside

---

## SUCCESS (LAYOUT)

✔ Equal padding left & right
✔ No content cut off
✔ Perfect centering
✔ No horizontal scroll

---

## PART 2 — LIVE CUSTOMER SEARCH (SMART FILTER)

GOAL:
Search must filter customers instantly as user types.

---

## SEARCH INPUT BEHAVIOUR

As user types:

* filter results in real-time (no button required)

Search must match ANY of:

* Customer name
* Email
* Phone number
* Cat names

---

## SEARCH LOGIC

* case-insensitive
* partial matches allowed
* search across all fields simultaneously

Example:
Typing "emma" returns:

* Emma Wilson
* customers with cat named Emma

---

## EMPTY STATE

If no matches:

Show:
"No customers found"

---

## PART 3 — ADD CUSTOMER (DRAWER)

Clicking "Add" button opens drawer

---

## DRAWER CONTENT

Fields:

Customer Info:

* Name
* Email
* Phone

Cat Info:

* Cat name(s)
* Special notes (optional)

---

## DRAWER BEHAVIOUR

* slides up from bottom
* stays inside mobile frame
* scrollable internally
* background locked

---

## ACTIONS

Bottom buttons:

* Cancel
* Save Customer

On Save:

* add to customer list instantly

---

## PART 4 — EDIT CUSTOMER (CARD CLICK)

Clicking a customer card:

* opens SAME drawer
* pre-filled with that customer’s data

User can:

* edit fields
* save changes

---

## PART 5 — INPUT STABILITY (NO JUMPING)

CRITICAL FIX:

When typing or focusing inputs:

* screen must NOT scroll to top
* screen must NOT shift
* drawer must remain stable

---

## REMOVE THESE BEHAVIOURS

* autoFocus causing scroll jump
* scrollIntoView
* window.scrollTo
* parent page scroll triggers

---

## EXPECTED INPUT EXPERIENCE

* tap field → cursor appears
* type normally
* scroll manually if needed
* no automatic repositioning

---

## PART 6 — DRAWER SCROLL CONTROL

* only drawer scrolls
* background content does NOT move
* drawer has its own scroll container

---

## SUCCESS (CUSTOMERS)

✔ Search filters instantly across all fields
✔ Add button opens working drawer
✔ New customers save correctly
✔ Clicking a card opens edit drawer
✔ Edits save and update list
✔ No jumping when typing
✔ Drawer stays stable
✔ All interactions feel smooth and native

---

## FINAL SUCCESS CRITERIA

✔ Layout fully centered (no right shift)
✔ Search is fast and intuitive
✔ Add/edit flow works end-to-end
✔ No scroll bugs
✔ No overflow anywhere
✔ Feels like a real mobile app
