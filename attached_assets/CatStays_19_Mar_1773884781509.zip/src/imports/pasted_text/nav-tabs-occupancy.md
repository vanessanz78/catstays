Upgrade the Arrivals / Departures / Occupied cards to function as anchor navigation tabs and add a new Occupancy section to the page.

The goal is fast, one-tap navigation within a single scrolling screen.

---

## CORE BEHAVIOUR

Convert the three summary cards into interactive anchor tabs:

* Arrivals
* Departures
* Occupied

These must NOT navigate to new pages.

Instead:
→ Smooth scroll to the corresponding section on the same screen

---

## ANCHOR SCROLL LOGIC

1. ARRIVALS

* Scroll to “Arrivals Today” section
* If already in view → no movement

2. DEPARTURES

* Scroll to “Departures Today” section

3. OCCUPIED

* Scroll to new “Occupancy” section (to be added below)

---

## SCROLL BEHAVIOUR

* Smooth animated scroll (not jumpy)
* Align section header neatly below top navigation
* Do not cut off titles when scrolling

---

## ACTIVE STATE (IMPORTANT)

The cards should reflect the current section in view:

* Highlight active tab (e.g. filled or elevated style)
* Only one tab active at a time

Example:

* Viewing arrivals → Arrivals card highlighted
* Viewing departures → Departures card highlighted

---

## ADD NEW SECTION: OCCUPANCY

Create a new section BELOW Departures:

Title:
“Occupancy”

Content ideas:

* Grid or list of rooms
* Show:

  * Room number
  * Status (occupied / available)
  * Cat name (if occupied)
  * Time or booking reference

Example layout:
Room 1 — Occupied (Whiskers)
Room 2 — Available
Room 3 — Occupied (Milo)

---

## LAYOUT RULES

* Match same card style as Arrivals/Departures sections
* Use consistent padding (16–20px)
* Keep visual hierarchy clean

---

## INTERACTION DETAILS

* Tapping a tab:
  → scrolls to section
  → updates active state

* Scrolling manually:
  → updates active tab automatically

---

## DO NOT

* Do NOT navigate to new pages
* Do NOT reload screen
* Do NOT use modal/drawer for this

---

## SUCCESS CRITERIA

✔ Tabs scroll to correct sections
✔ Smooth scrolling behaviour
✔ Active tab updates based on position
✔ Occupancy section exists and is visible
✔ All sections aligned correctly
✔ No content overlap or clipping
✔ Feels fast and intuitive on mobile
