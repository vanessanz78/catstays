Fix the layout so ALL content sits correctly within the mobile screen frame and does not overflow to the right.

The current issue is NOT just spacing — elements are wider than the mobile frame and are incorrectly constrained, causing them to render outside the visible screen.

---

## CORE PROBLEM

* Main content is shifted to the right
* Elements extend beyond the phone frame boundary
* Right edge content is being cut off
* Some cards/divs are physically positioned outside the mobile viewport
* Likely caused by incorrect width settings and constraints

---

## REQUIRED FIX (STRUCTURE FIRST)

Ensure ALL content is properly contained within the mobile screen frame.

1. Select the main content wrapper (entire page content)
2. Set:

* Width: Fill container (NOT fixed width)
* Max width: match mobile frame width
* Constraints:

  * Left: 0
  * Right: 0

3. Ensure NO element exceeds 100% width of parent

---

## REMOVE OFFSET / MISALIGNMENT

* Remove any:

  * negative margins
  * translateX values
  * manual positioning offsets
  * fixed pixel widths larger than the phone frame

Everything must align to the parent frame grid.

---

## APPLY CONSISTENT PAGE PADDING

Add a global horizontal padding:

* 16px or 20px on left
* 16px or 20px on right

Apply this to a single parent container (NOT individually on every card)

---

## CARD + COMPONENT RULES

For ALL cards (arrivals, stats, buttons, etc.):

* Width: 100% of parent container
* Do NOT use fixed widths like 320px, 360px, etc.
* Do NOT position using absolute offsets unless required

---

## HEADER + BUTTON FIX

* “New Booking” button must:

  * Align within same padding grid
  * Not overflow right edge
  * Match width of content container

---

## GRID + AUTO LAYOUT

Use Auto Layout correctly:

* Vertical stack for page
* Consistent spacing between sections
* No manual positioning

For row elements (e.g. stats cards):

* Use equal distribution
* Ensure total width does not exceed container

---

## DEBUG STEP (IMPORTANT)

Temporarily:

* Add a visible background color to the mobile frame
* Add outline/border to main content container

This ensures you can visually confirm nothing exceeds bounds

---

## WHAT NOT TO DO

Do NOT:

* “nudge” elements left manually
* apply random margin fixes
* adjust individual components without fixing parent container

This must be solved at the layout system level.

---

## SUCCESS CRITERIA

✔ No content extends outside mobile frame
✔ Equal left/right margins across entire screen
✔ All elements respect parent container width
✔ No horizontal scrolling
✔ Layout feels centered and balanced
✔ Cards align perfectly within grid
✔ Entire UI fits cleanly inside device mock
