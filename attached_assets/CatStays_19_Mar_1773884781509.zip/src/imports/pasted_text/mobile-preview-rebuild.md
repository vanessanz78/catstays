Rebuild the mobile preview system from scratch as a fully isolated embedded app viewport.

Do NOT attempt to patch or modify the existing preview.
Replace it entirely with a clean architecture.

--------------------------------------------------
GOAL
--------------------------------------------------

The mobile preview must behave exactly like a real mobile app running inside a device frame.

- All interactions stay inside the phone
- All scrolling stays inside the phone
- No interaction affects the parent onboarding page
- No jumping to top ever
- No content overflow
- All drawers, screens, and navigation are contained

--------------------------------------------------
NEW STRUCTURE (REQUIRED)
--------------------------------------------------

Onboarding Page
- Static onboarding content (non-interactive)
- Centered Mobile Preview Wrapper
  - Device Frame (visual phone)
    - Mobile App Container (THIS IS THE APP)
      - Screen Renderer (handles all pages)
      - Overlay Layer (drawers, modals)

--------------------------------------------------
MOBILE APP CONTAINER (CRITICAL)
--------------------------------------------------

Create a single container that acts as the app.

Properties:
- fixed height (match phone screen)
- width: 100%
- overflow-y: auto
- overflow-x: hidden
- position: relative
- background: app background
- fully clipped inside phone frame

This container must:
- own ALL scrolling
- own ALL interactions
- own ALL routing
- prevent ANY interaction leaking to parent

--------------------------------------------------
REMOVE ALL BROKEN BEHAVIOUR
--------------------------------------------------

Completely remove from the system:

- window.scrollTo
- scroll-to-top on navigation
- anchor links (#)
- autoFocus causing jumps
- scrollIntoView
- parent-level routing for preview actions
- any logic that reloads or resets the page

Nothing inside the preview should ever affect the onboarding page.

--------------------------------------------------
LOCAL ROUTING SYSTEM
--------------------------------------------------

Implement a simple internal screen switcher inside the Mobile App Container.

Examples of screens:
- Overview
- Arrivals
- Departures
- Occupancy
- Bookings
- Accounting

Switch screens INSIDE the container only.

Do NOT:
- reload page
- scroll page
- navigate browser
- mount outside container

--------------------------------------------------
GLOBAL OVERLAY SYSTEM (DRAWERS FIX)
--------------------------------------------------

Inside the Mobile App Container create:

Overlay Layer (absolute positioned)

All drawers must render here.

Drawer rules:
- anchored bottom: 0
- width: 100%
- max width: container width
- border radius top: 24px
- never exceed phone bounds
- never shift right
- never overflow screen

When drawer is open:
- lock scroll of background content
- allow scroll inside drawer only
- do NOT allow onboarding page to scroll

--------------------------------------------------
GLOBAL WIDTH + CENTERING FIX
--------------------------------------------------

Create ONE shared inner layout wrapper used by ALL screens:

- width: 100%
- max width: 100%
- padding-left: 16–20px
- padding-right: 16–20px
- box-sizing: border-box

Rules:
- no child can exceed this width
- no fixed widths larger than parent
- no translateX or offset hacks
- no negative margins

Everything must align centrally with equal spacing.

--------------------------------------------------
INTERACTION RULES
--------------------------------------------------

Inside the phone:

- buttons = local actions only
- cards = open drawers only
- tabs = scroll or switch sections inside container
- inputs = stay in place, no jumping

No interaction should:
- move the onboarding page
- reset scroll
- jump to top
- break containment

--------------------------------------------------
SCROLL BEHAVIOUR (REQUIRED)
--------------------------------------------------

- scrolling only happens inside Mobile App Container
- parent page must remain static
- scroll position must persist after interactions
- opening/closing drawer must NOT reset scroll

--------------------------------------------------
DEBUG STEP (MANDATORY)
--------------------------------------------------

Temporarily add:

- outline around Mobile App Container
- outline around inner content wrapper
- outline around overlay layer

Verify:
- nothing spills outside phone
- no horizontal overflow
- no right-shift
- all drawers contained

Remove outlines after validation.

--------------------------------------------------
SUCCESS CRITERIA
--------------------------------------------------

✔ Phone preview behaves like a real app  
✔ No jumping to top EVER  
✔ No interaction affects onboarding page  
✔ All screens contained inside phone  
✔ All drawers fully visible and scrollable  
✔ No right alignment issues  
✔ Perfect left/right spacing  
✔ Fully testable without losing position  