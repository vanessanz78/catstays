# Modern SaaS Dashboard - Documentation

## Overview
Clean, modern SaaS dashboard designed specifically for cattery owners to manage their business professionally.

**Route:** `/admin/modern-dashboard`

**Goal:** User feels: "I'm running a real business system"

---

## Design Philosophy

### User Experience Goals
✅ **Powerful** - Shows key metrics at a glance  
✅ **Organized** - Clear information hierarchy  
✅ **Not technical** - Business-focused, not developer-focused  
✅ **Professional** - Feels like enterprise software  
✅ **Friendly** - Approachable with helpful empty states  

### What We AVOID
❌ Cluttered interfaces  
❌ Overwhelming data tables  
❌ Technical jargon  
❌ Generic admin themes  
❌ Information overload  

---

## Layout Structure

```
┌─────────────────────────────────────────┐
│            HEADER (sticky)              │
│  Dashboard    [Notifications] [+ New]   │
│  Date                                   │
├─────────────────────────────────────────┤
│                                         │
│        TOP METRICS (4 cards)            │
│  [Bookings] [Occupancy] [Revenue] [New] │
│                                         │
├──────────────────┬──────────────────────┤
│                  │                      │
│  RECENT          │  UPCOMING            │
│  ACTIVITY        │  BOOKINGS            │
│                  │                      │
│  [Feed items]    │  [Booking cards]     │
│                  │                      │
├──────────────────┴──────────────────────┤
│                                         │
│           YOUR DATA SECTION             │
│                                         │
│  [Customers] [Pets] [Bookings]          │
│  [Import] [Export]                      │
│                                         │
├─────────────────────────────────────────┤
│         QUICK ACTIONS BANNER            │
│   Ready to grow? [View Insights]        │
└─────────────────────────────────────────┘
```

---

## Header Section

### Layout
**Position:** Sticky top-0, z-40  
**Background:** White with bottom border  
**Container:** Max-width 7xl, centered  

### Components

**Left Side:**
1. **Title**
   - Text: "Dashboard"
   - Font: Playfair Display, 2xl, bold
   - Color: Navy (#0A1128)

2. **Date Subtitle**
   - Format: "Wednesday, March 17, 2026"
   - Size: sm
   - Color: Gray-600
   - Dynamic: Uses `format(new Date(), 'EEEE, MMMM d, yyyy')`

**Right Side:**
1. **Notifications Button**
   - Icon: Bell
   - Variant: Outline
   - Text: "Notifications" (hidden on mobile)
   - Size: sm

2. **New Booking Button**
   - Icon: Plus
   - Background: Terracotta (#C46A3A)
   - Text: "New Booking"
   - Size: sm
   - Link: `/admin/bookings?new=true`

**Responsive:**
- Desktop: Full text on buttons
- Mobile: Icons only (text hidden with `sm:inline`)

---

## Top Metrics Section

### Layout
**Grid:** 4 columns (responsive: 1→2→4)  
**Gap:** 6 (24px)  
**Card Style:** Rounded, soft shadow, hover:shadow-lg  

### 4 Metric Cards

#### 1. Upcoming Bookings 📅
**Value:** 12  
**Change:** "+3 from last week"  
**Icon:** Calendar  
**Colors:** Blue-50 bg, blue-600 icon  

#### 2. Occupancy Rate 📈
**Value:** 87%  
**Change:** "+12% from last month"  
**Icon:** TrendingUp  
**Colors:** Green-50 bg, green-600 icon  

#### 3. Revenue This Month 💰
**Value:** $12,450  
**Change:** "+18% from last month"  
**Icon:** DollarSign  
**Colors:** Purple-50 bg, purple-600 icon  

#### 4. New Customers 👥
**Value:** 24  
**Change:** "+6 from last month"  
**Icon:** UserPlus  
**Colors:** Orange-50 bg, orange-600 icon  

### Card Anatomy
```
┌─────────────────────┐
│  [Icon]             │
│                     │
│  12                 │  ← 3xl, bold, navy
│  Upcoming Bookings  │  ← sm, gray-600
│  +3 from last week  │  ← xs, green-600
└─────────────────────┘
```

**Icon Container:**
- Size: p-3
- Border radius: xl
- Background: Color-specific (e.g., blue-50)
- Icon size: w-6 h-6
- Icon color: Color-specific (e.g., blue-600)

**Value:**
- Size: 3xl
- Weight: Bold
- Color: Navy
- Margin bottom: 1

**Label:**
- Size: sm
- Color: Gray-600
- Margin bottom: 2

**Change Indicator:**
- Size: xs
- Color: Green-600 (positive change)
- Weight: Medium
- Shows comparison period

**Hover Effect:**
- Shadow increases to lg
- Smooth transition

---

## Middle Section: Activity + Bookings

### Layout
**Grid:** 2 columns on lg+ (stacks on mobile)  
**Gap:** 6  

---

### Left: Recent Activity Feed

#### Header
**Title:** "Recent Activity" (Playfair Display, xl, bold)  
**Action:** "View All" button with ArrowRight  
**Link:** `/admin/bookings`  

#### Activity Items (4 sample)

**Structure:**
```
┌──────────────────────────────────┐
│ [Icon] New booking from Sarah    │
│        Fluffy • Mar 25-30 • ...  │
│        5 minutes ago             │
├──────────────────────────────────┤
│ [Icon] Payment received          │
│        $245.00 from Mike Chen    │
│        1 hour ago                │
└──────────────────────────────────┘
```

**Activity Item Anatomy:**
1. **Icon Container**
   - Size: p-2, rounded-lg
   - Background: Color-specific (blue-100, green-100, purple-100)
   - Icon size: w-4 h-4
   - Color: Matches background (blue-600, etc.)

2. **Content**
   - Title: sm, semibold, gray-900
   - Description: sm, gray-600
   - Time: xs, gray-500, mt-1

3. **Hover Effect**
   - Background: gray-50
   - Padding: p-3
   - Rounded: lg
   - Transition: colors

**Activity Types:**

1. **Booking** (Blue)
   - Icon: Calendar
   - Example: "New booking from Sarah Johnson"
   - Detail: "Fluffy • Mar 25-30 • Deluxe Suite"

2. **Payment** (Green)
   - Icon: CreditCard
   - Example: "Payment received"
   - Detail: "$245.00 from Mike Chen"

3. **Customer** (Purple)
   - Icon: UserPlus
   - Example: "New customer registered"
   - Detail: "Emma Davis joined"

4. **Confirmation** (Blue)
   - Icon: CheckCircle
   - Example: "Booking confirmed"
   - Detail: "Shadow • Apr 1-5 • Standard Room"

#### Empty State
```
┌──────────────────────────┐
│      [Sparkles Icon]     │
│   No activity yet        │
│   Your recent updates    │
│   will appear here       │
└──────────────────────────┘
```

**Components:**
- Icon: w-16 h-16, gray-100 bg, gray-400 icon
- Heading: gray-600
- Subtext: sm, gray-500

---

### Right: Upcoming Bookings

#### Header
**Title:** "Upcoming Bookings" (Playfair Display, xl, bold)  
**Action:** "Calendar" button with ArrowRight  
**Link:** `/admin/calendar`  

#### Booking Cards (3 sample)

**Structure:**
```
┌─────────────────────────────────┐
│ Sarah Johnson      [Confirmed]  │
│ Fluffy • Deluxe Suite          │
│ 📅 Mar 25-30                   │
└─────────────────────────────────┘
```

**Card Anatomy:**
1. **Container**
   - Padding: p-4
   - Border: gray-200
   - Rounded: lg
   - Hover: Border terracotta/50, shadow-sm

2. **Top Row**
   - Customer name: semibold, gray-900, sm
   - Status badge: Right-aligned

3. **Middle Row**
   - Pet name • Room type
   - Size: sm, gray-600

4. **Bottom Row**
   - Calendar icon + dates
   - Size: xs, gray-500

**Status Badges:**
- **Confirmed:** Blue-100 bg, blue-700 text
- **Pending:** Yellow-100 bg, yellow-700 text
- **Checked In:** Green-100 bg, green-700 text

**Sample Data:**
1. Sarah Johnson | Fluffy | Mar 25-30 | Deluxe Suite | Confirmed
2. Mike Chen | Whiskers | Mar 28-Apr 2 | Standard Room | Checked In
3. Emma Davis | Shadow | Apr 1-5 | Premium Villa | Pending

#### Empty State
```
┌──────────────────────────┐
│    [Calendar Icon]       │
│   No bookings yet —      │
│   your first one is      │
│   coming 🐾              │
│   [+ Create Booking]     │
└──────────────────────────┘
```

**Components:**
- Icon: w-16 h-16, gray-100 bg, gray-400 icon
- Message: gray-600 with paw emoji
- CTA: Terracotta button with Plus icon
- Link: `/admin/bookings?new=true`

---

## Data Centre Section

### Header

**Layout:** Flex, justify-between  

**Left Side:**
1. **Title:** "Your Data" (Playfair Display, 2xl, bold, navy)
2. **Subtitle:** "Manage and organize your cattery information" (sm, gray-600)

**Right Side:**
1. **Import Data Button**
   - Icon: Upload
   - Variant: Outline
   - Size: sm
   - Link: `/admin/smart-data-import`

2. **Export Data Button**
   - Icon: Download
   - Variant: Outline
   - Size: sm

### Data Cards Grid

**Layout:** 3 columns (responsive: 1→3)  
**Gap:** 6  

---

### 3 Data Cards

#### 1. Customers Card 👥

**Icon:** Users (blue)  
**Count:** 124  
**Title:** "Customers"  
**Description:** "Manage your client list"  
**Link:** `/admin/customers`  

**Colors:**
- Icon bg: blue-50
- Icon: blue-600
- Hover: blue-100

---

#### 2. Pets Card 🐾

**Icon:** PawPrint (purple)  
**Count:** 87  
**Title:** "Pets"  
**Description:** "All animals in your care"  
**Link:** `/admin/customers`  

**Colors:**
- Icon bg: purple-50
- Icon: purple-600
- Hover: purple-100

---

#### 3. Bookings Card 📅

**Icon:** CalendarDays (green)  
**Count:** 312  
**Title:** "Bookings"  
**Description:** "Full booking history"  
**Link:** `/admin/bookings`  

**Colors:**
- Icon bg: green-50
- Icon: green-600
- Hover: green-100

---

### Card Anatomy

```
┌─────────────────────────┐
│  [Icon]           124   │  ← Icon (lg) + Count (3xl)
│                         │
│  Customers              │  ← Title (lg, bold)
│  Manage your client list│  ← Description (sm)
│                         │
│  View Details →         │  ← CTA (terracotta)
└─────────────────────────┘
```

**Structure:**
1. **Top Row (flex, justify-between)**
   - Icon container: p-4, rounded-xl, color bg
   - Icon: w-8 h-8
   - Count: 3xl, bold, navy (right-aligned)

2. **Content**
   - Title: lg, bold, navy, Playfair Display
   - Description: sm, gray-600

3. **CTA**
   - Text: "View Details"
   - Icon: ArrowRight
   - Color: Terracotta
   - Size: sm
   - Font weight: Medium
   - Hover: Arrow translates right, gap increases

**Hover Effects:**
- Shadow: lg → xl
- Icon background: Color-50 → Color-100
- Arrow slides right 4px
- Cursor: Pointer
- Smooth transitions

**Link Wrapper:**
- Entire card is clickable
- Group hover for coordinated animations

---

## Quick Actions Banner

### Layout
**Background:** Gradient from navy to lighter navy  
**Text Color:** White  
**Padding:** p-8  

### Content

```
┌────────────────────────────────────────────┐
│  Ready to grow your business?              │
│  Explore advanced features like...         │
│                                            │
│  [View Insights] [Upgrade Features]        │
└────────────────────────────────────────────┘
```

**Left Side:**
- **Headline:** "Ready to grow your business?" (2xl, bold, Playfair Display)
- **Description:** "Explore advanced features like automated messaging, photo updates, and analytics" (gray-300)

**Right Side (Flex, gap-3):**

1. **View Insights Button**
   - Variant: Outline
   - Background: white/10
   - Border: white/20
   - Text: White
   - Hover: white/20
   - Link: `/admin/insights`

2. **Upgrade Features Button**
   - Icon: Sparkles
   - Background: Terracotta
   - Hover: Darker terracotta
   - Text: White
   - Link: `/upsell`

**Responsive:**
- Desktop: Horizontal flex
- Mobile: Stacks vertically (flex-col)

---

## Empty States

### Philosophy
Friendly, encouraging messages with emojis to reduce anxiety

### Examples

#### No Activity
```
[✨ Icon]
No activity yet
Your recent updates will appear here
```

#### No Bookings
```
[📅 Icon]
No bookings yet — your first one is coming 🐾
[+ Create Booking]
```

**Characteristics:**
- Friendly tone
- Emoji for warmth (🐾, ✨)
- Actionable CTA when relevant
- Not intimidating or technical
- Positive framing ("coming" not "missing")

---

## Color System

### Primary Colors
- **Navy:** #0A1128 (headings, values)
- **Terracotta:** #C46A3A (CTAs, links)
- **Cream:** #F8F7F5 (page background)

### Semantic Colors

**Blue (Bookings/Calendar):**
- 50: bg-blue-50
- 100: bg-blue-100
- 600: text-blue-600
- 700: text-blue-700

**Green (Revenue/Success):**
- 50: bg-green-50
- 100: bg-green-100
- 600: text-green-600
- 700: text-green-700

**Purple (Customers):**
- 50: bg-purple-50
- 100: bg-purple-100
- 600: text-purple-600
- 700: text-purple-700

**Orange (New Items):**
- 50: bg-orange-50
- 100: bg-orange-100
- 600: text-orange-600
- 700: text-orange-700

**Yellow (Pending):**
- 100: bg-yellow-100
- 700: text-yellow-700

**Grays:**
- 50, 100, 200, 300, 400, 500, 600, 900

---

## Typography

### Fonts

**Headings:**
- Family: Playfair Display
- Sizes: 2xl, xl
- Weight: Bold
- Usage: Page title, section titles, card titles

**Body:**
- Family: Inter
- Sizes: base, sm, xs
- Weight: Regular, medium, semibold
- Usage: Descriptions, labels, data

### Hierarchy

**Level 1 (Page Title):**
- Font: Playfair Display
- Size: 2xl
- Weight: Bold
- Color: Navy

**Level 2 (Section Titles):**
- Font: Playfair Display
- Size: xl
- Weight: Bold
- Color: Navy

**Level 3 (Card Titles):**
- Font: Playfair Display
- Size: lg
- Weight: Bold
- Color: Navy

**Body Text:**
- Font: Inter
- Size: sm
- Weight: Regular
- Color: Gray-600

**Labels:**
- Font: Inter
- Size: xs-sm
- Weight: Medium/Semibold
- Color: Gray-500/600

**Values:**
- Font: Inter
- Size: 3xl (large metrics)
- Weight: Bold
- Color: Navy

---

## Spacing System

### Container
- **Max width:** 7xl (1280px)
- **Horizontal padding:** px-6
- **Vertical padding:** py-8
- **Section gaps:** space-y-8

### Cards
- **Padding:** p-6
- **Gaps:** gap-6 (grid), gap-3/4 (internal)
- **Border radius:** rounded-lg, rounded-xl
- **Shadows:** shadow (default), shadow-lg (hover), shadow-xl (data cards)

### Grid Gaps
- **Main grid:** gap-6 (24px)
- **Internal elements:** gap-3, gap-4

---

## Responsive Behavior

### Breakpoints

**Mobile (< sm):**
- Metrics: 1 column
- Activity + Bookings: Stack vertically
- Data cards: 1 column
- Button text: Hidden, icons only
- Quick actions: Vertical stack

**Tablet (sm to lg):**
- Metrics: 2 columns
- Activity + Bookings: Stack vertically
- Data cards: 2-3 columns
- Button text: Visible
- Quick actions: Horizontal

**Desktop (lg+):**
- Metrics: 4 columns
- Activity + Bookings: Side by side
- Data cards: 3 columns
- Full layout
- Quick actions: Horizontal

---

## Interactions & Micro-animations

### Hover States

**Metric Cards:**
- Shadow: default → lg
- Transition: 300ms

**Activity Items:**
- Background: transparent → gray-50
- Padding: Consistent
- Border radius: lg

**Booking Cards:**
- Border: gray-200 → terracotta/50
- Shadow: none → sm

**Data Cards:**
- Shadow: lg → xl
- Icon bg: Color-50 → Color-100
- Arrow: translate-x-0 → translate-x-1
- Gap: Increases slightly

**Buttons:**
- Background: Darkens
- Shadow: Increases
- Scale: Subtle lift

### Transitions
- **Duration:** 200-300ms
- **Easing:** Default (ease-in-out)
- **Properties:** background, shadow, transform, border

### Cursor
- **Clickable items:** cursor-pointer
- **Interactive cards:** Full card clickable
- **Buttons:** Default cursor

---

## State Management

### Component State

```typescript
const [hasData, setHasData] = useState(true);
```

**Purpose:** Toggle between populated and empty states for demo

**Data Structures:**

```typescript
interface ActivityItem {
  id: number;
  type: 'booking' | 'payment' | 'customer';
  title: string;
  description: string;
  time: string;
  icon: LucideIcon;
  color: string;
}

interface Booking {
  id: number;
  customer: string;
  pet: string;
  dates: string;
  room: string;
  status: 'confirmed' | 'pending' | 'checked-in';
}
```

### Sample Data

**Metrics:** Static (could be from API)  
**Activity:** 4 recent items  
**Bookings:** 3 upcoming  
**Data Cards:** Static counts  

---

## Accessibility

### Keyboard Navigation
- Tab through all interactive elements
- Enter/Space to activate buttons/links
- Focus visible on all controls
- Logical tab order

### Screen Readers
- Semantic HTML (header, main, nav, section)
- Descriptive link text
- Icon labels where needed
- Status announcements

### Color Contrast
- All text meets WCAG AA
- Icons have sufficient contrast
- Interactive elements clearly distinguished

### Focus States
- Visible focus rings
- No focus traps
- Skip links (future)

---

## Performance Optimizations

### Rendering
- Conditional rendering for empty states
- Map over data arrays efficiently
- No unnecessary re-renders

### Assets
- Icons: Lucide React (tree-shakeable)
- No images (icon-only design)
- Minimal dependencies

### Layout
- Fixed header (sticky, no reflow)
- Grid CSS (no JS calculations)
- CSS transforms for animations (GPU)

---

## Future Enhancements

### Phase 2
- [ ] Real-time data updates (WebSocket)
- [ ] Customizable metrics
- [ ] Filter activity by type
- [ ] Booking calendar widget
- [ ] Quick actions menu

### Phase 3
- [ ] Drag & drop dashboard customization
- [ ] Widget marketplace
- [ ] Data export to CSV/PDF
- [ ] Scheduled reports
- [ ] Mobile app deep links

### Phase 4
- [ ] AI insights ("Your occupancy is trending up")
- [ ] Predictive analytics
- [ ] Automated recommendations
- [ ] Custom reporting builder
- [ ] Multi-location support

---

## Integration Points

### Links to Other Pages

**From Header:**
- Notifications → `/admin/notifications` (future)
- New Booking → `/admin/bookings?new=true`

**From Activity:**
- View All → `/admin/bookings`

**From Bookings:**
- Calendar → `/admin/calendar`
- Create Booking → `/admin/bookings?new=true`

**From Data Cards:**
- Customers → `/admin/customers`
- Pets → `/admin/customers`
- Bookings → `/admin/bookings`

**From Data Centre:**
- Import Data → `/admin/smart-data-import`
- Export Data → Download action (future)

**From Quick Actions:**
- View Insights → `/admin/insights`
- Upgrade Features → `/upsell`

---

## User Journey

### First-Time User (Empty State)
1. Lands on dashboard
2. Sees metrics all at zero or low
3. Empty activity feed with friendly message
4. Empty bookings with CTA
5. Data cards show 0 counts
6. Click "Create Booking" or "Import Data"
7. Feels guided, not lost

### Active User (Populated)
1. Lands on dashboard
2. Scans top metrics (quick health check)
3. Reviews recent activity (catch up)
4. Checks upcoming bookings (prepare)
5. Clicks data card to dive deeper
6. Feels in control, organized

---

## Business Value

### For Cattery Owners
- ✅ See business health at a glance
- ✅ Never miss important updates
- ✅ Quick access to key data
- ✅ Professional appearance
- ✅ Confidence in their system

### For CatStays Platform
- ✅ Drives engagement (daily logins)
- ✅ Upsell opportunities (quick actions)
- ✅ Data quality (import/export)
- ✅ Professional brand perception
- ✅ User retention

---

## Success Metrics

### User Engagement
- **Daily active users:** % who visit dashboard daily
- **Time on page:** Average session duration
- **Click-through rate:** % who click into sub-pages
- **Action completion:** % who create booking from dashboard

### User Satisfaction
- **NPS score:** Net Promoter Score
- **Feedback:** Qualitative comments
- **Support tickets:** Reduction in confusion
- **Churn rate:** % who cancel subscription

---

## Design Principles Summary

### 1. Clarity Over Complexity
Show what matters, hide what doesn't

### 2. Scannable Information
User should understand status in 3 seconds

### 3. Actionable Insights
Every metric suggests a next step

### 4. Friendly Professionalism
Enterprise-grade but approachable

### 5. Consistent Language
Business terms, not technical jargon

---

**Status:** ✅ Fully Implemented  
**Route:** `/admin/modern-dashboard`  
**Created:** March 17, 2026

---

## Quick Reference

**Access:** `/admin/modern-dashboard`

**Sections:**
1. Top Metrics (4 cards)
2. Activity Feed (left)
3. Upcoming Bookings (right)
4. Data Centre (3 cards)
5. Quick Actions (banner)

**Colors:**
- Navy: #0A1128
- Terracotta: #C46A3A
- Cream: #F8F7F5

**Fonts:**
- Headings: Playfair Display
- Body: Inter

**Feeling:**
"I'm running a real business system"
