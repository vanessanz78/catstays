Design a modern SaaS landing page for **CatStays**, a boutique platform built specifically for **small premium catteries**.

The website must clearly communicate that CatStays provides:

• A **website builder for boutique catteries**
• A **booking and reservation system for cat boarding**
• A **mobile-friendly dashboard to manage cats, rooms, and payments**

The design style should feel **warm, calm, boutique, and premium**, not corporate or generic pet software.

The product should be positioned as **software designed specifically for cat boarding businesses**, not general pet boarding.

---

BRAND IDENTITY

Use a warm boutique color palette.

Primary Navy
#1F2A44

Terracotta Accent
#C86B3C

Soft Cream Background
#F7F4EF

Light Neutral
#EFE9E2

Body Text
#2E2E2E

Terracotta should be used mainly for **buttons and highlights**.

---

TYPOGRAPHY

Headings
Fraunces

Body
Inter

Use rounded buttons, soft shadows, generous spacing, and calm modern layouts.

---

NAVIGATION BAR

Sticky navigation at the top.

Left side:
CatStays logo (two cats sitting under a house icon)

Right side links:

Features
How It Works
Pricing
Demo
Sign In

Primary CTA button:

Start Free Trial

Use terracotta for the CTA.

---

HERO SECTION

Two column layout.

LEFT SIDE

Headline:

Beautiful Websites & Booking Software for Boutique Catteries

Subtext:

CatStays helps small catteries create a stunning website, accept online bookings, and manage their guests from a simple mobile dashboard.

Buttons:

Start Free Trial
Watch Demo

Small trust line underneath:

Built specifically for boutique catteries.

---

RIGHT SIDE

Instead of a random cat image, display **a realistic mockup of a cattery website built with CatStays**.

The website preview should include:

• hero image of a cattery
• room listings
• availability calendar
• booking button
• photos of cat rooms

This should visually show what customers will get.

---

SECTION: WHAT CATSTAYS DOES

Title:

Everything Your Cattery Needs in One Platform

Create three feature cards.

---

CARD 1

Title:
Beautiful Booking Website

Image:
Mockup of a cattery website homepage showing:

• hero image
• room gallery
• availability calendar
• booking button

Description:
Create a stunning website in minutes. Cat owners can check availability and book instantly.

---

CARD 2

Title:
Daily Cat Updates

Image:
Mobile screen showing:

• cat photo
• update message
• timeline of daily updates

Description:
Send owners daily photos and updates that build trust and keep them connected.

---

CARD 3

Title:
Mobile Cattery Dashboard

Image:
Admin dashboard screen showing:

• arrivals today
•
