Design and implement a fully integrated booking system for CatStays that is:

- visible on every template homepage
- fully functional in preview mode
- fully connected to backend booking system after publish

---

CORE PRINCIPLE:

The booking system is NOT a static UI element.

It must behave like a REAL product feature:
- interactive
- state-driven
- connected to real data

---

PART 1: HOMEPAGE BOOKING BAR (ALL TEMPLATES)

Include a booking bar on EVERY template homepage.

Position:
- directly below hero OR
- overlaid on hero (floating card)

---

BOOKING BAR UI:

Fields:

1. Check-in date
2. Check-out date
3. Number of cats (dropdown)
4. CTA button: “Check Availability”

---

STYLE:

- Rounded container
- Soft shadow
- Brand color CTA
- Clean spacing
- Mobile responsive (stacked layout)

---

PART 2: BUILDER PREVIEW (CRITICAL)

In the website builder preview (right-hand side):

The booking bar MUST be:

- fully visible above the fold
- clickable
- interactive

---

INTERACTIONS IN PREVIEW MODE:

User can:

- select dates
- select number of cats
- click “Check Availability”

---

WHEN CLICKED (PREVIEW MODE):

Simulate real flow:

→ Show loading state
→ Transition to “Available Rooms” screen (mock data if needed)

---

IMPORTANT:

Preview must feel REAL, not static.

---

PART 3: AVAILABILITY FLOW (FRONTEND UX)

After clicking “Check Availability”:

Show:

---

SCREEN: AVAILABLE ROOMS

For selected dates + cat count:

Display:

Room cards:

- Room name
- Capacity
- Price (calculated)
- Features
- Image
- CTA: “Book Now”

---

LOGIC:

Only show rooms that:
- have availability
- match cat capacity

---

PART 4: BOOKING FLOW

When user clicks “Book Now”:

Open booking flow:

STEP 1:
Customer details
- Name
- Email
- Phone

STEP 2:
Pet details
- Cat name(s)
- Notes

STEP 3:
Review booking
- Dates
- Room
- Total price
- Tax breakdown

STEP 4:
Payment (future-ready or optional)

STEP 5:
Confirmation screen

---

PART 5: BACKEND INTEGRATION (POST-PUBLISH)

Once website is published:

Booking bar must connect to:

→ theirname.catstays.app/admin

---

DATA FLOW:

Booking request:

→ checks room availability
→ locks room temporarily
→ creates booking entry
→ sends confirmation email

---

BACKEND UPDATES:

- booking appears in calendar
- room availability updates
- revenue tracked

---

PART 6: BUILDER SETTINGS (LEFT PANEL)

Add new section:

“Booking Settings”

Controls:

- Default check-in time
- Default check-out time
- Min stay rules
- Max cats allowed
- Booking lead time

---

PRICING LINK:

Pull pricing from:
→ Rooms & Pricing section

---

PART 7: LIVE VS PREVIEW MODE

PREVIEW MODE:
- simulated data
- full UX flow

LIVE MODE:
- real availability
- real bookings
- real data persistence

---

PART 8: MICRO INTERACTIONS

- Date picker smooth animation
- Loading spinner on availability
- Subtle success states
- Inline validation

---

PART 9: MOBILE UX

- Stack fields vertically
- Sticky CTA button
- Easy date picker

---

PART 10: GOAL UX

User (cattery owner) feels:
“This is a real booking system, not just a website”

Customer (end user) feels:
“This is easy, fast, and trustworthy”

---

AVOID:

- static booking forms
- redirecting off-site
- fake interactions in preview
- disconnected backend logic

---

SUCCESS CRITERIA:

The booking bar:
- works inside the builder
- works on the live site
- feeds directly into the backend system

This is a core product feature, not a UI element.