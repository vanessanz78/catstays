Enhance the Booking Details drawer to support editable dates and a proper payment recording system for staff.

This drawer must evolve from a static view into a functional editing interface while maintaining a clean, premium UX.

---

## PART 1: CHECK-IN / CHECK-OUT DATE PICKERS

Replace static date display with interactive date selection.

For both:

* Check-in
* Check-out

Behaviour:

* Dates should appear as clickable fields
* On click → open a calendar date picker (modal or inline)

Date Picker Requirements:

* Clean, minimal calendar UI
* Month navigation
* Highlight selected date
* Disable past dates if required
* Confirm selection on tap

After selection:

* Update the displayed date immediately

---

## TIME INPUT

Keep time simple and flexible:

* Display as editable text input
* Placeholder format: “e.g. 9:15am”
* No strict validation required
* User can type freely

---

## PART 2: PAYMENT STATUS UPGRADE

Replace basic “Payment Status” dropdown with a structured payment system.

---

PAYMENT STATUS FIELD

Keep dropdown with options:

* Unpaid
* Deposit
* Paid

---

## WHEN “DEPOSIT” OR “PAID” IS SELECTED:

Reveal additional fields:

1. Amount Paid

* Numeric input
* Currency format (e.g. $100.00)

2. Payment Method (required)

* Select options:

  * Credit Card
  * Bank Transfer
  * Cash

3. Optional Notes

* Small text input (e.g. “Paid at drop-off”)

---

## OUTSTANDING BALANCE CALCULATION

Display a calculated field:

* “Total Booking Cost” (read-only)
* “Amount Paid”
* “Outstanding Balance”

Logic:

Outstanding Balance = Total - Amount Paid

Rules:

* Never show negative values
* If fully paid → show “$0.00 remaining”
* If deposit → show remaining clearly

Display format:

Total: $XXX
Paid: $XXX
Remaining: $XXX

---

## UX BEHAVIOUR

* Fields appear dynamically when relevant (Deposit or Paid selected)
* Keep layout clean and not overwhelming
* Use subtle dividers between sections

---

## VISUAL DESIGN

* Maintain same card style as existing drawer
* Keep spacing consistent (16–20px padding)
* Align labels and inputs cleanly
* Use soft borders and rounded inputs

---

## BOTTOM ACTION BAR

Keep:

* Cancel (secondary)
* Save Changes (primary)

Behaviour:

* Save stores all updates:

  * Dates
  * Time
  * Payment info

---

## SUCCESS CRITERIA

✔ Dates are clickable and open a calendar picker
✔ Time is editable as free text
✔ Payment status triggers additional fields
✔ Staff can record:

* amount paid
* payment method
  ✔ Outstanding balance is calculated correctly
  ✔ No negative values ever displayed
  ✔ Layout remains clean and premium
  ✔ Drawer feels like a real operational tool, not just display
