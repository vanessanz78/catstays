Make all notification items fully interactive and implement a fast, mobile-first interaction using a bottom sheet (drawer) for quick actions.

The goal is speed, clarity, and minimal navigation.

---

## CORE BEHAVIOUR

When a user taps a notification:

→ Open a bottom drawer (not a new page)
→ Show relevant details immediately
→ Allow quick action without leaving the screen

DO NOT:

* Navigate away instantly
* Open a new page as the primary action

---

## NOTIFICATION TYPES + ACTIONS

1. NEW BOOKING
   Tap opens drawer with:

* Customer name
* Pet name(s)
* Booking dates
* Room
* Payment status

Primary actions:

* “View Booking”
* “Accept / Confirm” (if pending)

---

2. PAYMENT RECEIVED
   Tap opens drawer with:

* Amount received
* Customer name
* Payment method
* Date/time

Primary actions:

* “View Booking”
* “View Payment Details”

---

3. NEW MESSAGE
   Tap opens drawer with:

* Message preview
* Sender name
* Timestamp

Primary actions:

* “Reply”
* “Open Full Conversation”

---

## DRAWER DESIGN

* Slides up from bottom
* Covers ~70–80% of screen height
* Background dim overlay (20–30%)

Header:

* Title based on notification type
* Close (X)
* Optional “Mark as read”

Body:

* Clean card-style layout
* Clear hierarchy of info

Footer:

* Primary action button
* Secondary action (optional)

---

## INTERACTION RULES

* Tapping a notification:
  → Opens drawer instantly (no delay)

* Mark notification as read when opened

* Allow dismiss by:

  * swipe down
  * tapping outside
  * tapping X

---

## OPTIONAL DEEP NAVIGATION

Inside drawer:

Include secondary navigation:

* “View full booking”
* “Go to messages”

Only navigate away if user explicitly chooses to

---

## VISUAL + UX REQUIREMENTS

* Maintain consistent padding (16–20px)
* No clipped text or icons
* Smooth animation (slide up)
* Keep it lightweight and fast

---

## DO NOT IMPLEMENT

* Full page redirect on tap
* Dead/static notification list
* Multiple clicks required to take action

---

## SUCCESS CRITERIA

✔ All notifications are clickable
✔ Tap opens bottom drawer instantly
✔ Relevant info shown per notification type
✔ User can take action immediately
✔ No forced navigation away
✔ Drawer is smooth and mobile-native
✔ Notifications marked as read on open
✔ UX feels fast and effortless
