Fix the Booking Details / Edit Booking drawer so it is fully centered, scrollable, and behaves correctly for all inputs (date picker, payment fields, etc.).

This is a STRUCTURAL + INTERACTION fix, not just visual tweaks.

---

## CRITICAL ISSUE 1: DRAWER NOT CENTERED / OVERFLOWING

Problem:

* Drawer is pushed to the right
* Right edge is cut off (X button + rounded corner not visible)
* Drawer width exceeds mobile screen
* Layout is not respecting parent frame

Fix:

* Ensure drawer is attached to the ROOT mobile screen frame (not nested inside any content)

* Set positioning:

  * Left: 0
  * Right: 0
  * Bottom: 0
  * Width: Fill container

* Remove:

  * Any translateX
  * Any fixed width larger than screen
  * Any negative margins

* Ensure equal left/right alignment within phone frame

* Apply internal padding:

  * 16–20px left/right

---

## CRITICAL ISSUE 2: CONTENT NOT SCROLLING (BOTTOM CUT OFF)

Problem:

* Cannot scroll to see “Call Owner” / “Edit”
* Drawer content is clipped

Fix:

* Set drawer container:

  * Max height: 80–85% of screen

* Inside drawer:

  * Create scrollable content area

Structure:

Drawer

* Header (fixed)

* Scrollable content section (flex / auto layout vertical, scroll enabled)

* Bottom action bar (fixed)

* Ensure:

  * Content scrolls independently
  * Bottom buttons always visible

---

## CRITICAL ISSUE 3: INPUTS JUMPING TO TOP

Problem:

* Clicking date or payment field scrolls drawer to top
* Breaks user context

Fix:

* Prevent any “scroll to top” behaviour on input focus

* Inputs must:

  * Open locally (inline or anchored)
  * NOT reposition the entire drawer
  * NOT reset scroll position

* Maintain current scroll position when interacting with fields

---

## CRITICAL ISSUE 4: DATE PICKER (CALENDAR) BEHAVIOUR

Problem:

* Calendar opens too large
* Overflows screen
* Requires horizontal scrolling
* Appears disconnected from input

Fix:

* Replace with compact mobile date picker

Behaviour:

* Opens as:
  → small modal OR anchored popover within drawer

* Width:
  → max 90% of drawer width

* Centered horizontally

* Height:
  → compact (no full-screen calendar)

* Must NOT:

  * overflow screen
  * require horizontal scroll

* Position:
  → appears near the selected date field (not at top of screen)

---

## CRITICAL ISSUE 5: PAYMENT INPUT POSITIONING

Problem:

* Entering payment info jumps screen to top

Fix:

* Payment inputs must:

  * Stay inline within drawer
  * Expand locally if needed
  * NOT trigger layout shift

* Maintain scroll position during input

---

## FINAL ALIGNMENT FIX (GLOBAL)

Ensure ENTIRE screen is centered:

* Main mobile frame:

  * All content must fit within bounds
  * No overflow left or right

* Apply consistent layout:

  * Single parent container with 16–20px padding
  * All components use width: 100%

---

## DO NOT DO

* Do NOT nudge elements manually
* Do NOT apply visual-only fixes
* Do NOT allow any element to exceed screen width
* Do NOT use full-width desktop-style calendar

---

## SUCCESS CRITERIA

✔ Drawer is perfectly centered within phone frame
✔ No content cut off on left or right
✔ Drawer opens from true bottom of screen
✔ Content scrolls smoothly inside drawer
✔ Bottom buttons always accessible
✔ Inputs do NOT jump to top
✔ Calendar is compact and fully visible
✔ No horizontal scrolling anywhere
✔ Entire UI fits cleanly within mobile viewport
✔ Feels like a native mobile app interaction
