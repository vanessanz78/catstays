Redesign the CatStays website builder to support 6 REAL templates with true layout differences, full interactivity, and a structured high-converting website system.

---

CORE GOAL:

Keep the existing 6 template options, but transform them into:

- TRUE layout variations (not just color changes)
- FULLY functional previews
- Connected to a live website builder

---

PART 1: TEMPLATE SYSTEM (KEEP 6 — MAKE THEM REAL)

Maintain 6 templates, but each must have UNIQUE STRUCTURE:

---

TEMPLATE 1: Boutique Luxury
- Large hero image
- Centered typography
- Elegant spacing
- Serif headings
- Minimal sections per screen

---

TEMPLATE 2: Clean Modern
- Left-aligned layout
- Grid-based sections
- Card UI for rooms/services
- Balanced spacing

---

TEMPLATE 3: Playful Friendly
- Rounded elements
- Softer spacing
- Friendly typography
- Slight asymmetry

---

TEMPLATE 4: Image Focused
- Large full-width imagery
- Minimal text
- Gallery-heavy layout
- Visual storytelling

---

TEMPLATE 5: Split Layout
- Alternating sections (image left / text right)
- Structured flow
- More editorial feel

---

TEMPLATE 6: Classic Service
- Traditional stacked layout
- Simple sections
- Familiar service-business structure

---

IMPORTANT:

When user clicks a template:
→ Load FULL layout (not just colors)
→ Transition into builder

---

PART 2: CORE WEBSITE STRUCTURE (APPLIES TO ALL TEMPLATES)

All templates MUST include these sections:

1. HERO (image, business name, CTA)
2. TRUST / WHY CHOOSE US (icons)
3. FACILITIES
4. ROOMS (pricing, cards, CTA)
5. CTA BANNER
6. ADDITIONAL SERVICES
7. GALLERY
8. TESTIMONIALS
9. FAQ
10. ABOUT
11. COMMITMENT / VALUES
12. LOCATION (map + directions)
13. CONTACT
14. FOOTER

---

PART 3: FUNCTIONAL BUILDER (CRITICAL)

RIGHT SIDE:
- Fully rendered website
- Scrollable
- Looks real (no placeholders only)

USER CAN:
- Click text → edit inline
- Click images → replace
- Click sections → edit settings
- Click buttons → edit links

---

LEFT PANEL (SHOPIFY-STYLE):

Collapsible sections:

1. Branding
- Logo upload
- Colors (6 preset palettes + custom)
- Fonts
- Button styles

2. Layout
- Template selector (switch anytime)
- Spacing controls
- Section order

3. Content
- Edit text
- Edit headings
- Edit CTAs

4. Rooms & Pricing
- Room types
- Capacity
- Pricing tiers
- Multi-cat logic
- Tax logic

5. Services
- Add-ons
- Pricing

6. Booking
- External link OR embedded widget (future-ready)

---

PART 4: TEMPLATE SWITCHING

Add:
“Change Template” button in builder

When switching:
- KEEP all user data
- ONLY change layout structure

---

PART 5: LIVE PREVIEW QUALITY

Replace:
- emoji placeholders

With:
- real cat imagery
- realistic layouts
- proper spacing + typography hierarchy

---

PART 6: INTERACTIVITY REQUIREMENT

Preview must NOT be static.

Must behave like:
- a real website
- clickable navigation
- editable sections

---

PART 7: IMPORT FLOW (IF USED)

If user imported website:

- auto-fill content into structure
- apply default template
- allow switching templates instantly

---

PART 8: GOAL UX

User should feel:

“I already have a professional website”
“I can just tweak it”
“This is mine”

---

AVOID:

- identical layouts across templates
- color-only differences
- non-clickable previews
- empty states

---

SUCCESS CRITERIA:

Each template should feel like:
a completely different website — not a theme variation.