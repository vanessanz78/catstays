Fix ALL drawers (Booking Details, Edit Booking, New Booking, Notifications, etc.) so they behave as true mobile bottom sheet overlays with correct scroll locking, positioning, and interaction.

This must be a GLOBAL system fix applied to every drawer component.

---

## GLOBAL OVERLAY SYSTEM (CRITICAL)

All drawers must be implemented as a top-level overlay layer, NOT inside page content.

Correct structure:

Mobile Screen Frame

* Page Content (scrollable)
* Overlay Layer (fixed)

  * Dim Background
  * Drawer (bottom sheet)

Drawers must NEVER be nested inside:

* cards
* sections
* lists
* page scroll containers

---

## SCROLL LOCK (MAIN ISSUE)

When drawer is open:

* Background page MUST NOT scroll

* Disable scrolling on main page content

* Only the drawer content should scroll

Fix:

* Lock body/page scroll when drawer opens
* Enable scroll ONLY inside drawer content container

---

## DRAWER SCROLL BEHAVIOUR

Inside drawer:

Structure:

* Header (fixed)
* Scrollable content area
* Bottom action bar (fixed)

Rules:

* Content scrolls inside drawer only
* Bottom buttons (Call Owner / Edit / Save) always visible
* No content cut off

---

## PREVENT SCROLL BLEED

Fix these issues:

* Scrolling inside drawer should NOT move background

* Scrolling outside drawer should NOT bypass drawer

* Drawer must capture all scroll interaction while open

---

## DRAWER POSITIONING (FIX RIGHT SHIFT)

Fix ALL drawers:

* Position: absolute within screen
* Left: 0
* Right: 0
* Bottom: 0
* Width: 100%

Remove:

* translateX
* overflow widths
* incorrect parent constraints

Ensure:

* perfectly centered
* equal left/right margins
* rounded corners fully visible

---

## HEIGHT CONTROL

* Drawer max height: 80–85% of screen
* Do NOT allow full-screen overflow unless intentional

---

## NEW BOOKING DRAWER FIX

Apply same rules:

* Must NOT scroll entire page
* Must NOT reveal content behind while scrolling
* Form scrolls inside drawer only

---

## BOOKING DETAILS / EDIT DRAWER FIX

* Fix bottom buttons visibility
* Ensure full scroll access to all fields
* Prevent content clipping

---

## OCCUPANCY LIST INTERACTION

Update occupancy section:

* Show ONLY:
  → Room number
  → Cat name

* Each row/card must be clickable

On click:
→ Open Booking Details drawer (same reusable component)

---

## CARD INTERACTIONS (GLOBAL)

Make ALL cards interactive:

* Arrival cards → open booking drawer
* Departure cards → open booking drawer
* Occupancy cards → open booking drawer

Use ONE shared drawer component for consistency

---

## INTERACTION PRIORITY

* Tap → open drawer instantly
* No delay
* No page navigation

---

## DO NOT

* Do NOT allow page scroll while drawer open
* Do NOT allow drawer to be inside page content
* Do NOT create multiple drawer systems
* Do NOT allow horizontal overflow
* Do NOT clip bottom actions

---

## SUCCESS CRITERIA

✔ Drawer scroll is isolated (no background scroll)
✔ Bottom buttons always visible
✔ No content cut off
✔ Drawer fully centered (no right shift)
✔ All drawers behave consistently
✔ Occupancy list simplified and clickable
✔ All cards open drawer correctly
✔ No scroll bleed anywhere
✔ Feels like a native mobile app
