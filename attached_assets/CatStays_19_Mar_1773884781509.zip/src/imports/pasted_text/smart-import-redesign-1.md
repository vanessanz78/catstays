Redesign the Smart Import screen to align with the existing dashboard design system and implement full functionality for all import actions.

This includes both visual consistency and working interactions.

---

## PART 1 — REMOVE PURPLE / FIX DESIGN SYSTEM

PROBLEM:

* Current purple AI card does not match brand
* Feels disconnected from the rest of the app
* Breaks visual consistency

---

GOAL:
Make AI feel native, subtle, and premium within the existing design system.

---

## DESIGN UPDATE (AI IMPORT CARD)

Replace purple gradient card with:

Option A (Recommended):

* White card background
* Subtle border (light grey or brand outline)
* Small icon (sparkle or AI indicator)
* Title: "Smart Import"
* Subtitle: "Automatically detect and map your data"

Option B (Alternative):

* Very soft brand-tinted background (light beige / soft neutral)
* No harsh gradients

---

## BUTTON STYLE

Primary CTA:

* "Upload File"
* Use EXISTING primary button style (same as dashboard buttons)
* No gradient
* No neon colours

---

## CONSISTENCY RULE

All elements must match:

* existing card radius
* existing spacing system
* existing typography
* existing button styles

AI should feel like a feature, not a separate product.

---

## PART 2 — MAKE IMPORT OPTIONS FUNCTIONAL

Currently non-functional:

* Upload File (Excel, CSV, PDF)
* Import from Spreadsheet
* Import Customers

All must trigger real flows.

---

## OPTION 1 — UPLOAD FILE

Clicking:

"Upload File"

Opens drawer:

Title:
"Upload Data"

Content:

* File upload area (drag & drop or select file)
* Supported formats: CSV, Excel

After upload:

* Show preview of detected data
* Auto-map fields:

  * Name
  * Email
  * Phone
  * Cat Name
  * Dates

---

ACTIONS:

* Cancel
* Import Data

---

## OPTION 2 — IMPORT FROM SPREADSHEET

Clicking:

"Import from Spreadsheet"

Opens drawer:

Options:

* Paste Google Sheets link
* Connect source (simulated)

Show:

* Preview table
* Mapping step (columns → fields)

---

## OPTION 3 — IMPORT CUSTOMERS

Clicking:

"Import Customers"

Opens drawer:

Focused on:

* Customer data only
* Same structure as upload
* Simpler mapping

---

## PART 3 — DRAWER BEHAVIOUR (CRITICAL)

All drawers must:

* open from bottom
* stay inside mobile viewport
* be fully scrollable internally
* NOT affect background scroll
* NOT jump to top
* NOT exceed screen width

---

## PART 4 — IMPORT RESULTS

After successful import:

* Show confirmation:
  "28 customers imported"

* Update:

  * Customers list
  * Bookings (if included)

---

## PART 5 — ERROR STATES

Handle:

* invalid file
* missing fields
* duplicate data

Show clear messages.

---

## PART 6 — UX POLISH

* Add loading state during import
* Add progress indicator (optional)
* Keep interactions smooth

---

## SUCCESS CRITERIA

✔ No purple / off-brand elements
✔ AI fits naturally into dashboard design
✔ Upload button opens working flow
✔ Spreadsheet import works
✔ Customer import works
✔ Drawers behave correctly
✔ Data preview and mapping visible
✔ Import updates system
✔ Feels clean, simple, and powerful
