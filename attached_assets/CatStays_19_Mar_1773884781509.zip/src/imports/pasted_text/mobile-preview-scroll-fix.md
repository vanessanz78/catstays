Fix the issue where interacting with elements inside the mobile preview causes the screen to jump to the top of the onboarding page.

---

## PROBLEM

* Clicking ANY element inside the mobile preview causes scroll reset
* The page jumps back to the top ("Dashboard Preview" header)
* User loses position and must manually scroll back down
* This breaks usability and flow

---

## ROOT CAUSE

This is caused by one or more of the following:

* Automatic scroll-to-top behavior on re-render
* Route/navigation triggering full page scroll reset
* Focus being applied to a parent container
* Anchor links (#) or buttons behaving like page navigation
* Missing scroll containment inside the mobile preview container

---

## GLOBAL FIX (APPLY EVERYWHERE)

1. DISABLE SCROLL RESET

* Remove any:
  window.scrollTo(0, 0)
  scrollToTop()
  or equivalent logic

* Ensure interactions DO NOT trigger page-level scrolling

---

2. CONTAIN SCROLL WITHIN MOBILE PREVIEW

The mobile preview container MUST handle its own scroll.

Apply to mobile container:

* height: fixed (e.g. 100% of device frame)
* overflow-y: auto
* overflow-x: hidden
* position: relative

IMPORTANT:

* The PAGE behind it must NOT scroll when interacting inside mobile

---

3. PREVENT EVENT BUBBLING

Clicks inside mobile preview should NOT affect parent page.

Apply:

* Stop propagation on interactive elements where needed
* Ensure no parent click handlers are triggering layout reset

---

4. REMOVE ANCHOR / LINK JUMPS

Check all buttons:

* Replace <a href="#"> with button elements
* Remove anchor links that cause scroll jump
* Prevent default behavior where necessary

---

5. FIX FOCUS BEHAVIOUR

Inputs and buttons should NOT shift viewport.

Ensure:

* No autoFocus on elements
* No forced focus() on interaction
* Avoid scrollIntoView()

---

6. KEEP SCROLL POSITION ON STATE CHANGE

When UI updates (opening drawer, clicking tab, etc):

* Preserve current scroll position
* Do NOT reset container scroll

---

7. OPTIONAL (BEST PRACTICE)

Wrap mobile preview in isolated container:

* pointer-events: auto
* isolate interactions from parent layout

---

## SUCCESS CRITERIA

✔ Clicking inside mobile does NOT scroll page to top
✔ User stays exactly where they are
✔ Mobile preview behaves like a real app
✔ Background onboarding page remains static
✔ Smooth, uninterrupted interaction flow
