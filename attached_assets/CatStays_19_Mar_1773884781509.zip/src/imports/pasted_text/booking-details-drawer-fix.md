Fix the Booking Details drawer by correcting the PARENT CONTAINER, LAYER HIERARCHY, and OVERLAY BEHAVIOUR — not just the drawer styling.

The previous attempt only adjusted padding, width, and border radius, but the real issue is that the drawer is still attached to the wrong parent container.

--------------------------------------------------
ACTUAL PROBLEM TO FIX
--------------------------------------------------

The Booking Details drawer is currently being rendered inside or relative to the “Departures Today” section/card/frame.

Because of that:
- it appears horizontally misaligned
- it is anchored too high on the screen
- it does not slide up from the true bottom of the phone viewport
- it behaves like a nested card instead of a full-screen bottom sheet overlay

This must be fixed at the structure level.

--------------------------------------------------
REQUIRED STRUCTURE CHANGE
--------------------------------------------------

Move the Booking Details drawer OUT of the Departures Today frame/card/list item entirely.

The drawer must instead live at the top level of the mobile screen frame as a sibling of the page content, not as a child of the departures section.

Correct hierarchy should be:

Mobile Screen Frame
- Main page content
- Dim background overlay
- Booking Details bottom sheet drawer

NOT:

Mobile Screen Frame
- Main page content
  - Departures Today section
    - Departure card
      - Booking Details drawer

The drawer must be attached to the full phone viewport, not to any card, section, list, auto layout stack, or content frame.

--------------------------------------------------
DRAWER POSITIONING
--------------------------------------------------

Set the drawer to behave as a true bottom sheet:

- Positioned absolute within the full phone screen frame
- Left aligned to the phone frame
- Right aligned to the phone frame
- Bottom aligned to the phone frame
- Width fills the parent viewport
- Height hugs content or uses a max height around 80–85% of the screen

Important:
- The drawer must open from the bottom edge of the device screen
- It must NOT be vertically positioned relative to the “Departures Today” heading, card, or list

--------------------------------------------------
HORIZONTAL ALIGNMENT
--------------------------------------------------

Fix the horizontal spacing so the drawer is visually centered and symmetrical.

Requirements:
- Equal left and right outer margins
- Top-left and top-right rounded corners align evenly
- Close button sits comfortably inside the header padding
- No extra inset on the left
- No flush edge on the right

Use a consistent internal padding grid:
- 20px left padding
- 20px right padding

--------------------------------------------------
BOTTOM SHEET BEHAVIOUR
--------------------------------------------------

This drawer should behave like a native mobile bottom sheet:

- Tap departure card → open drawer
- Drawer slides up from bottom of screen
- Background page stays behind it
- Add dim overlay behind drawer
- Overlay covers the full phone viewport
- Drawer sits above overlay

Animation intent:
- slide up from bottom
- smooth and native-feeling
- not a fade-in card
- not an inline expansion

--------------------------------------------------
SCROLL BEHAVIOUR
--------------------------------------------------

The drawer content should scroll independently if content becomes taller than the available height.

Keep bottom action bar fixed inside the drawer:
- Call Owner
- Edit

Bottom action bar should stay pinned to the bottom of the sheet, not scroll away with content.

--------------------------------------------------
HEADER + SAFE SPACING
--------------------------------------------------

At top of drawer:
- centered drag handle
- Booking Details title aligned neatly
- close X button inside safe right padding
- no clipping against frame edge

Use proper top spacing so the header does not feel cramped.

--------------------------------------------------
DO NOT JUST RESTYLE THE EXISTING DRAWER
--------------------------------------------------

Do not only:
- change width
- change border radius
- change padding
- change opacity
- tweak the X button

Those are not enough on their own.

You must:
- detach the drawer from the Departures Today section
- re-parent it to the root mobile screen frame
- rebuild it as a true overlay component

--------------------------------------------------
SUCCESS CRITERIA
--------------------------------------------------

The fix is correct only if all of these are true:

- The drawer is no longer nested inside the Departures Today section
- The drawer opens from the true bottom of the phone screen
- The drawer has equal left and right margins
- The rounded top corners are symmetrical
- The X button is properly padded from the right edge
- The background overlay fills the full phone viewport
- The page content remains behind the drawer
- The drawer feels like a native iPhone / Android bottom sheet
- The drawer is fully interactive and visually centered