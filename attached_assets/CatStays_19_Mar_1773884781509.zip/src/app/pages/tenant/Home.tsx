import { Link } from 'react-router';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';
import { Star, MapPin, Phone, Mail, Calendar, Home, Camera, Heart, Shield, Settings, Clock } from 'lucide-react';
import { ImageWithFallback } from '../../components/figma/ImageWithFallback';
import { PreviewBanner } from '../../components/PreviewBanner';
import { ChatWidget } from '../../components/ChatWidget';

export function TenantHome() {
  // Set to true to show preview mode banner
  const isPreviewMode = false;

  // Smooth scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Preview Mode Banner */}
      {isPreviewMode && <PreviewBanner />}

      {/* Warm Navigation - Sticky with Anchor Links */}
      <nav className="bg-white/95 backdrop-blur-sm border-b border-sage/10 sticky top-0 z-50" style={{ marginTop: isPreviewMode ? '60px' : '0' }}>
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button onClick={() => scrollToSection('hero')} className="flex items-center gap-2 cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sage to-sage-light flex items-center justify-center">
                <span className="text-2xl">🐱</span>
              </div>
              <div>
                <h1 className="text-xl font-serif font-semibold text-forest">Deloraine Cattery</h1>
                <p className="text-xs text-forest/60">Whangārei, New Zealand</p>
              </div>
            </button>
            <div className="hidden md:flex items-center gap-6">
              <button onClick={() => scrollToSection('hero')} className="text-forest/70 hover:text-forest transition-colors">Home</button>
              <button onClick={() => scrollToSection('about')} className="text-forest/70 hover:text-forest transition-colors">About</button>
              <button onClick={() => scrollToSection('rooms')} className="text-forest/70 hover:text-forest transition-colors">Rooms</button>
              <button onClick={() => scrollToSection('contact')} className="text-forest/70 hover:text-forest transition-colors">Contact</button>
              <div className="h-4 w-px bg-sage/20"></div>
              <Link to="/admin">
                <Button variant="ghost" size="sm" className="text-sage hover:bg-sage/5 gap-2">
                  <Settings className="w-4 h-4" />
                  <span className="hidden lg:inline">Staff Portal</span>
                </Button>
              </Link>
              <Link to="/site/login">
                <Button variant="outline" size="sm" className="border-sage text-sage hover:bg-sage/5 rounded-xl">
                  Guest Login
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section with Warm Imagery */}
      <section id="hero" className="relative">
        <div className="h-[500px] relative overflow-hidden">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1763644097584-c2876d5d5a1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjB3aW5kb3clMjBzdW5saWdodCUyMHBlYWNlZnVsfGVufDF8fHx8MTc3MzYzOTIxM3ww&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Peaceful cat by window"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-forest/60 via-forest/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-12 text-white">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center gap-2 mb-4">
                <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30">
                  Premium Cat Boarding
                </Badge>
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map((i) => (
                    <Star key={i} className="w-4 h-4 fill-rose text-rose" />
                  ))}
                  <span className="ml-2 text-sm">5.0 from 87 reviews</span>
                </div>
              </div>
              <h1 className="text-4xl md:text-6xl font-serif font-semibold mb-4">
                A Peaceful Retreat for Your Cat
              </h1>
              <p className="text-xl md:text-2xl mb-6 max-w-3xl opacity-95">
                Luxury cat boarding in beautiful Whangārei. Your cat's comfort, safety, and happiness is our priority.
              </p>
              <div className="flex items-center gap-3 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>15 Maunu Road, Whangārei</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>09 438 1234</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Availability Check - Soft Card */}
      <section className="relative -mt-16 pb-16">
        <div className="max-w-5xl mx-auto px-4">
          <Card className="shadow-2xl border-sage/10 rounded-3xl overflow-hidden">
            <CardContent className="p-8">
              <h3 className="text-2xl font-serif font-semibold text-forest mb-6">Check Availability</h3>
              <div className="grid md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium text-forest/70 mb-2 block">Check-in</label>
                  <Input type="date" className="rounded-xl border-sage/20" />
                </div>
                <div>
                  <label className="text-sm font-medium text-forest/70 mb-2 block">Check-out</label>
                  <Input type="date" className="rounded-xl border-sage/20" />
                </div>
                <div>
                  <label className="text-sm font-medium text-forest/70 mb-2 block">Cats</label>
                  <select className="w-full rounded-xl border border-sage/20 p-2 bg-white">
                    <option>1 cat</option>
                    <option>2 cats</option>
                    <option>3 cats</option>
                  </select>
                </div>
                <div className="flex items-end">
                  <Link to="/site/booking-flow" className="w-full">
                    <Button className="w-full bg-sage hover:bg-sage-dark text-white rounded-xl shadow-md">
                      Check Availability
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Room Types */}
      <section id="rooms" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-serif font-semibold text-forest mb-4">Comfortable Accommodations</h2>
            <p className="text-lg text-forest/70">Choose the perfect space for your cat's stay</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-sage/10 shadow-lg rounded-3xl hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-sage-light/30 to-sage/20 flex items-center justify-center">
                <Home className="w-16 h-16 text-sage" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-serif text-forest">Private Rooms</CardTitle>
                <CardDescription>17 exclusive spaces with outdoor access</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-forest/70 mb-4">
                  Perfect for cats from the same household who love sunshine and fresh air
                </p>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-semibold text-sage">$20</p>
                  <p className="text-sm text-forest/60">per day + GST</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-sage/10 shadow-lg rounded-3xl hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-rose-light/30 to-rose/20 flex items-center justify-center">
                <Home className="w-16 h-16 text-rose" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-serif text-forest">Indoor Rooms</CardTitle>
                <CardDescription>8 cozy climate-controlled spaces</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-forest/70 mb-4">
                  Temperature-controlled comfort for cats who prefer a quieter environment
                </p>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-semibold text-sage">$20</p>
                  <p className="text-sm text-forest/60">per day + GST</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-sage/10 shadow-lg rounded-3xl hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-cream-dark to-cream flex items-center justify-center">
                <Heart className="w-16 h-16 text-sage-dark" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-serif text-forest">Communal Area</CardTitle>
                <CardDescription>Spacious social area for 25 cats</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-forest/70 mb-4">
                  A friendly space for social cats who enjoy feline company
                </p>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-semibold text-sage">$20</p>
                  <p className="text-sm text-forest/60">per day + GST</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-20 bg-gradient-to-b from-cream to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-serif font-semibold text-forest mb-4">Included in Every Stay</h2>
            <p className="text-lg text-forest/70">Premium care and peace of mind</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-sage/10 flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-sage" />
              </div>
              <h4 className="font-semibold text-forest mb-2">Daily Photo Updates</h4>
              <p className="text-sm text-forest/70">See your cat happy and relaxed</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-rose/10 flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-rose" />
              </div>
              <h4 className="font-semibold text-forest mb-2">Personalized Care</h4>
              <p className="text-sm text-forest/70">Individual attention for every cat</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-sage-light/20 flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-sage-dark" />
              </div>
              <h4 className="font-semibold text-forest mb-2">Safe & Secure</h4>
              <p className="text-sm text-forest/70">Your cat's safety is our priority</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-rose-light/30 flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-rose" />
              </div>
              <h4 className="font-semibold text-forest mb-2">Stay Connected</h4>
              <p className="text-sm text-forest/70">Regular updates via SMS or email</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-serif font-semibold text-forest mb-6">About Deloraine Cattery</h2>
              <div className="space-y-4 text-forest/70">
                <p className="text-lg">
                  For over 15 years, we've been providing exceptional care for cats in beautiful Whangārei. 
                  Our purpose-built cattery offers a safe, comfortable, and stress-free environment where 
                  your cat can relax while you're away.
                </p>
                <p className="text-lg">
                  We understand that every cat is unique. That's why we take the time to get to know each 
                  guest personally, ensuring they receive the individual care and attention they deserve. 
                  From daily photo updates to specialized dietary requirements, we go above and beyond.
                </p>
                <p className="text-lg">
                  Our team of experienced cat lovers is dedicated to making every stay a positive experience. 
                  With 25 comfortable rooms and a focus on cleanliness, safety, and enrichment, your cat 
                  will enjoy a peaceful retreat in our care.
                </p>
              </div>
              <div className="flex items-center gap-4 mt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-sage">15+</div>
                  <div className="text-sm text-forest/60">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-sage">25</div>
                  <div className="text-sm text-forest/60">Rooms</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-sage">5.0</div>
                  <div className="text-sm text-forest/60">Average Rating</div>
                </div>
              </div>
            </div>
            <div className="relative h-96 rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Happy cat at cattery"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-serif font-semibold text-forest mb-4">What Cat Owners Say</h2>
            <p className="text-lg text-forest/70">Trusted by families across Whangārei</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Emma Wilson", quote: "My cat Milo absolutely loves it here! The daily photos were such a comfort while we were away. Highly recommend!", stars: 5 },
              { name: "David Chen", quote: "Exceptional care and beautiful facilities. You can tell they genuinely love cats. We'll definitely be back!", stars: 5 },
              { name: "Sarah Mitchell", quote: "The best cattery in Whangārei! Clean, professional, and they treated my cats like family. Thank you!", stars: 5 }
            ].map((testimonial, i) => (
              <Card key={i} className="border-sage/10 shadow-md rounded-3xl p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.stars)].map((_, idx) => (
                    <Star key={idx} className="w-5 h-5 fill-rose text-rose" />
                  ))}
                </div>
                <p className="text-forest/80 mb-6 leading-relaxed italic">
                  "{testimonial.quote}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-sage-light/20 flex items-center justify-center">
                    <span className="text-2xl">😊</span>
                  </div>
                  <div>
                    <p className="font-semibold text-forest">{testimonial.name}</p>
                    <p className="text-sm text-forest/60">Verified Guest</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-b from-cream to-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-serif font-semibold text-forest mb-4">Get in Touch</h2>
            <p className="text-lg text-forest/70">We'd love to hear from you and answer any questions</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <Card className="border-sage/10 shadow-md rounded-3xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-sage/10 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-sage" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-forest mb-2">Visit Us</h4>
                    <p className="text-forest/70">15 Maunu Road, Whangārei 0110</p>
                    <p className="text-sm text-forest/60 mt-1">New Zealand</p>
                  </div>
                </div>
              </Card>

              <Card className="border-sage/10 shadow-md rounded-3xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-sage/10 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-sage" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-forest mb-2">Call Us</h4>
                    <p className="text-forest/70">09 438 1234</p>
                    <p className="text-sm text-forest/60 mt-1">Mon-Sun: 8am - 6pm</p>
                  </div>
                </div>
              </Card>

              <Card className="border-sage/10 shadow-md rounded-3xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-sage/10 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-sage" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-forest mb-2">Email Us</h4>
                    <p className="text-forest/70">hello@delorainecattery.nz</p>
                    <p className="text-sm text-forest/60 mt-1">We'll respond within 24 hours</p>
                  </div>
                </div>
              </Card>

              <Card className="border-sage/10 shadow-md rounded-3xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-sage/10 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-sage" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-forest mb-2">Drop-off & Pick-up Hours</h4>
                    <div className="text-forest/70 space-y-1">
                      <p>Drop-off: 8:00am - 10:00am</p>
                      <p>Pick-up: 4:00pm - 6:00pm</p>
                      <p className="text-sm text-forest/60 mt-2">Open 7 days a week</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Contact Form */}
            <Card className="border-sage/10 shadow-xl rounded-3xl overflow-hidden">
              <CardContent className="p-8">
                <h3 className="text-2xl font-serif font-semibold text-forest mb-6">Send us a Message</h3>
                <form className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-forest/70 mb-2 block">Your Name</label>
                    <Input type="text" placeholder="John Smith" className="rounded-xl border-sage/20" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-forest/70 mb-2 block">Email</label>
                    <Input type="email" placeholder="john@example.com" className="rounded-xl border-sage/20" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-forest/70 mb-2 block">Phone</label>
                    <Input type="tel" placeholder="021 123 4567" className="rounded-xl border-sage/20" />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-forest/70 mb-2 block">Message</label>
                    <textarea 
                      placeholder="Tell us about your cat and when you'd like to book..."
                      className="w-full rounded-xl border border-sage/20 p-3 min-h-32 resize-none"
                    />
                  </div>
                  <Button className="w-full bg-sage hover:bg-sage-dark text-white rounded-xl shadow-md py-6 text-lg">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-forest text-cream py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-full bg-sage flex items-center justify-center">
                  <span className="text-xl">🐱</span>
                </div>
                <span className="text-xl font-serif font-semibold">Deloraine Cattery</span>
              </div>
              <p className="text-cream/70 text-sm">
                Premium cat boarding in beautiful Whangārei
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-cream/70">
                <li><Link to="/site/about" className="hover:text-cream">About Us</Link></li>
                <li><Link to="/site/rooms" className="hover:text-cream">Accommodations</Link></li>
                <li><Link to="/site/booking-flow" className="hover:text-cream">Book Now</Link></li>
                <li><Link to="/site/contact" className="hover:text-cream">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-cream/70">
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>15 Maunu Road, Whangārei</span>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>09 438 1234</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>hello@delorainecattery.nz</span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hours</h4>
              <ul className="space-y-2 text-sm text-cream/70">
                <li>Drop-off: 8am - 10am</li>
                <li>Pick-up: 4pm - 6pm</li>
                <li>7 days a week</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-cream/10 pt-8 text-center text-sm text-cream/60">
            <p>© 2026 Deloraine Cattery. Powered by <Link to="/" className="text-sage-light hover:underline">CatStays</Link></p>
          </div>
        </div>
      </footer>

      {/* Chat Widget */}
      <ChatWidget businessName="Deloraine Cattery" />
    </div>
  );
}