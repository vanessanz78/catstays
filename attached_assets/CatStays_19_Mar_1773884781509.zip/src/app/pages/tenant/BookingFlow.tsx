import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Calendar, CreditCard, Check, Upload } from 'lucide-react';
import { differenceInDays, parseISO } from 'date-fns';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Progress } from '../../components/ui/progress';

// Supabase info for API calls
const projectId = "cbugfbennhujvuiyymyo";
const publicAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNidWdmYmVubmh1anZ1aXl5bXlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE4NzM2MzcsImV4cCI6MjA4NzQ0OTYzN30.IAZ7oAul4xA5itPq8bCoZKuydEDBVRzWBRZSdYYHVRo";

export function BookingFlow() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    arrivalDate: '',
    departureDate: '',
    numberOfCats: 1,
    roomType: 'any',
    catNames: [''],
    ownerName: '',
    mobile: '',
    email: '',
    address: '',
    emergencyContact: '',
    specialRequirements: '',
    paymentMethod: 'stripe'
  });

  // Pricing logic
  const calculatePrice = () => {
    if (!formData.arrivalDate || !formData.departureDate) return { subtotal: 0, gst: 0, total: 0, nights: 0 };
    
    const arrival = parseISO(formData.arrivalDate);
    const departure = parseISO(formData.departureDate);
    const nights = differenceInDays(departure, arrival);
    
    if (nights <= 0) return { subtotal: 0, gst: 0, total: 0, nights: 0 };

    let dailyRate = 20; // 1 cat
    if (formData.numberOfCats === 2) dailyRate = 36;
    if (formData.numberOfCats === 3) dailyRate = 54;

    let subtotal = dailyRate * nights;

    // Long stay discounts
    if (nights >= 60) subtotal *= 0.85; // 15% off
    else if (nights >= 30) subtotal *= 0.90; // 10% off
    else if (nights >= 15) subtotal *= 0.95; // 5% off

    const gst = subtotal * 0.15;
    const deposit = 50;
    const total = subtotal + gst;
    
    return { 
      subtotal, 
      gst, 
      total, 
      nights, 
      dailyRate, 
      deposit,
      discount: nights >= 15 ? (nights >= 60 ? 15 : nights >= 30 ? 10 : 5) : 0
    };
  };

  const pricing = calculatePrice();

  const handleNext = async () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      // Complete booking and send confirmation email
      setIsSubmitting(true);
      
      try {
        // Send booking confirmation email with Petcover insurance
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-4cdbd524/bookings/confirm`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`,
            },
            body: JSON.stringify({
              customerName: formData.ownerName,
              customerEmail: formData.email || formData.ownerName.toLowerCase().replace(/\s+/g, '.') + '@example.com',
              catName: formData.catNames.filter(n => n).join(' & ') || 'Your cat',
              checkIn: formData.arrivalDate,
              checkOut: formData.departureDate,
              roomType: formData.roomType === 'any' ? 'Standard Room' : formData.roomType.charAt(0).toUpperCase() + formData.roomType.slice(1) + ' Room',
              totalPrice: pricing.total,
              catteryName: 'Deloraine Cattery',
            }),
          }
        );

        const data = await response.json();
        
        if (data.success) {
          console.log('Booking confirmation email sent:', data);
        } else {
          console.error('Failed to send confirmation email:', data.error);
        }
      } catch (error) {
        console.error('Error sending confirmation email:', error);
      } finally {
        setIsSubmitting(false);
        // Navigate to customer dashboard
        navigate('/customer');
      }
    }
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const updateCatNames = (index: number, value: string) => {
    const newNames = [...formData.catNames];
    newNames[index] = value;
    setFormData({ ...formData, catNames: newNames });
  };

  const handleCatsChange = (num: number) => {
    const newNames = Array(num).fill('').map((_, i) => formData.catNames[i] || '');
    setFormData({ ...formData, numberOfCats: num, catNames: newNames });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Book Your Cat's Stay</h1>
          <p className="text-gray-600">Deloraine Cattery • Whangārei</p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Step {step} of 4</span>
            <span className="text-sm text-gray-600">{step === 1 ? 'Dates & Cats' : step === 2 ? 'Your Details' : step === 3 ? 'Cat Information' : 'Payment'}</span>
          </div>
          <Progress value={(step / 4) * 100} className="h-2" />
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Main Form */}
          <div className="md:col-span-2">
            <Card>
              {step === 1 && (
                <>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-6 h-6 text-purple-500" />
                      <CardTitle>Dates & Accommodation</CardTitle>
                    </div>
                    <CardDescription>When will your cat be staying?</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="arrival">Arrival Date</Label>
                        <Input
                          id="arrival"
                          type="date"
                          value={formData.arrivalDate}
                          onChange={(e) => setFormData({ ...formData, arrivalDate: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="departure">Departure Date</Label>
                        <Input
                          id="departure"
                          type="date"
                          value={formData.departureDate}
                          onChange={(e) => setFormData({ ...formData, departureDate: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    {pricing.nights > 0 && (
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p className="font-medium text-blue-900">
                          {pricing.nights} night{pricing.nights !== 1 ? 's' : ''}
                        </p>
                        {pricing.discount > 0 && (
                          <p className="text-sm text-blue-700 mt-1">
                            🎉 {pricing.discount}% long stay discount applied!
                          </p>
                        )}
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="cats">Number of Cats</Label>
                      <select
                        id="cats"
                        className="w-full border rounded-md p-2"
                        value={formData.numberOfCats}
                        onChange={(e) => handleCatsChange(parseInt(e.target.value))}
                      >
                        <option value="1">1 cat</option>
                        <option value="2">2 cats (sharing room)</option>
                        <option value="3">3 cats (sharing room)</option>
                      </select>
                      <p className="text-xs text-gray-600">
                        ${formData.numberOfCats === 1 ? 20 : formData.numberOfCats === 2 ? 36 : 54}/day + GST
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="roomType">Room Type (Optional)</Label>
                      <select
                        id="roomType"
                        className="w-full border rounded-md p-2"
                        value={formData.roomType}
                        onChange={(e) => setFormData({ ...formData, roomType: e.target.value })}
                      >
                        <option value="any">Any available room</option>
                        <option value="private">Private Room (outdoor access)</option>
                        <option value="indoor">Indoor Room (climate controlled)</option>
                        <option value="communal">Communal Area (social cats)</option>
                      </select>
                    </div>

                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-green-700">
                        <Check className="w-5 h-5" />
                        <span className="font-medium">Availability confirmed!</span>
                      </div>
                      <p className="text-sm text-green-600 mt-1">
                        We have rooms available for your selected dates
                      </p>
                    </div>
                  </CardContent>
                </>
              )}

              {step === 2 && (
                <>
                  <CardHeader>
                    <CardTitle>Your Details</CardTitle>
                    <CardDescription>Contact information for this booking</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="ownerName">Your Name *</Label>
                      <Input
                        id="ownerName"
                        placeholder="Sarah Johnson"
                        value={formData.ownerName}
                        onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mobile">Mobile Number *</Label>
                      <Input
                        id="mobile"
                        placeholder="021 123 4567"
                        value={formData.mobile}
                        onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                        required
                      />
                      <p className="text-xs text-gray-600">
                        We'll send booking confirmations and updates via SMS
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email (Optional)</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">Address *</Label>
                      <Textarea
                        id="address"
                        placeholder="123 Main Street, Whangārei"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        rows={2}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency">Emergency Contact</Label>
                      <Input
                        id="emergency"
                        placeholder="Name and phone number"
                        value={formData.emergencyContact}
                        onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                      />
                    </div>
                  </CardContent>
                </>
              )}

              {step === 3 && (
                <>
                  <CardHeader>
                    <CardTitle>Cat Information</CardTitle>
                    <CardDescription>Tell us about your cat{formData.numberOfCats > 1 ? 's' : ''}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {Array.from({ length: formData.numberOfCats }).map((_, index) => (
                      <div key={index} className="border rounded-lg p-4 space-y-4">
                        <h3 className="font-semibold">Cat {index + 1}</h3>
                        
                        <div className="space-y-2">
                          <Label htmlFor={`catName${index}`}>Name *</Label>
                          <Input
                            id={`catName${index}`}
                            placeholder="Whiskers"
                            value={formData.catNames[index]}
                            onChange={(e) => updateCatNames(index, e.target.value)}
                            required
                          />
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Age</Label>
                            <Input placeholder="3 years" />
                          </div>
                          <div className="space-y-2">
                            <Label>Breed</Label>
                            <Input placeholder="Domestic Short Hair" />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>Vaccination Record *</Label>
                          <div className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50">
                            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-600">Click to upload or drag and drop</p>
                            <p className="text-xs text-gray-500 mt-1">PDF, JPG or PNG (max 5MB)</p>
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="space-y-2">
                      <Label htmlFor="special">Special Requirements or Medical Notes</Label>
                      <Textarea
                        id="special"
                        placeholder="Dietary requirements, medications, behavioral notes..."
                        value={formData.specialRequirements}
                        onChange={(e) => setFormData({ ...formData, specialRequirements: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                          <span className="text-white text-xl">🛡️</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-purple-900 mb-1">
                            Free Petcover Insurance
                          </h4>
                          <p className="text-sm text-purple-700 mb-2">
                            Get 4 weeks complimentary pet insurance when you book
                          </p>
                          <label className="flex items-center gap-2 text-sm">
                            <input type="checkbox" className="rounded" defaultChecked />
                            <span>Yes, activate my free Petcover insurance</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </>
              )}

              {step === 4 && (
                <>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-6 h-6 text-green-500" />
                      <CardTitle>Payment</CardTitle>
                    </div>
                    <CardDescription>Secure payment to confirm your booking</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-900 mb-2">Booking Summary</h4>
                      <div className="space-y-1 text-sm text-blue-800">
                        <div className="flex justify-between">
                          <span>{formData.catNames.filter(n => n).join(', ') || 'Your cat(s)'}</span>
                          <span>{pricing.nights} nights</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Check-in</span>
                          <span>{formData.arrivalDate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Check-out</span>
                          <span>{formData.departureDate}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Payment Method</Label>
                      <div className="space-y-2">
                        <label className="flex items-center gap-3 border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="payment"
                            value="stripe"
                            checked={formData.paymentMethod === 'stripe'}
                            onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                          />
                          <div className="flex-1">
                            <div className="font-medium">Credit or Debit Card</div>
                            <div className="text-xs text-gray-600">Secure payment via Stripe</div>
                          </div>
                          <div className="flex gap-1">
                            <div className="w-8 h-6 bg-blue-600 rounded text-white text-xs flex items-center justify-center">VISA</div>
                            <div className="w-8 h-6 bg-red-600 rounded text-white text-xs flex items-center justify-center">MC</div>
                          </div>
                        </label>

                        <label className="flex items-center gap-3 border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                          <input
                            type="radio"
                            name="payment"
                            value="bank"
                            checked={formData.paymentMethod === 'bank'}
                            onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                          />
                          <div className="flex-1">
                            <div className="font-medium">Bank Transfer</div>
                            <div className="text-xs text-gray-600">Pay within 24 hours to confirm</div>
                          </div>
                        </label>
                      </div>
                    </div>

                    {formData.paymentMethod === 'stripe' && (
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label>Card Number</Label>
                          <Input placeholder="4242 4242 4242 4242" />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label>Expiry</Label>
                            <Input placeholder="MM/YY" />
                          </div>
                          <div className="space-y-2">
                            <Label>CVC</Label>
                            <Input placeholder="123" />
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-sm text-green-800">
                      <div className="flex items-center gap-2 mb-1">
                        <Check className="w-4 h-4" />
                        <span className="font-medium">Secure Payment</span>
                      </div>
                      <p className="text-xs text-green-700">
                        Your payment information is encrypted and secure
                      </p>
                    </div>
                  </CardContent>
                </>
              )}

              <CardContent className="pt-6 border-t">
                <div className="flex gap-3">
                  {step > 1 && (
                    <Button variant="outline" onClick={handleBack}>
                      Back
                    </Button>
                  )}
                  <Button className="flex-1" onClick={handleNext}>
                    {step === 4 ? `Pay Deposit $${pricing.deposit}` : 'Continue'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Price Summary Sidebar */}
          <div className="md:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-lg">Price Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {pricing.nights > 0 ? (
                  <>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">
                          ${pricing.dailyRate} × {pricing.nights} nights
                        </span>
                        <span>${(pricing.dailyRate * pricing.nights).toFixed(2)}</span>
                      </div>
                      
                      {pricing.discount > 0 && (
                        <div className="flex justify-between text-green-600">
                          <span>Long stay discount ({pricing.discount}%)</span>
                          <span>-${(pricing.dailyRate * pricing.nights * (pricing.discount / 100)).toFixed(2)}</span>
                        </div>
                      )}

                      <div className="flex justify-between">
                        <span className="text-gray-600">Subtotal</span>
                        <span>${pricing.subtotal.toFixed(2)}</span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-gray-600">GST (15%)</span>
                        <span>${pricing.gst.toFixed(2)}</span>
                      </div>

                      <div className="border-t pt-2 flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span>${pricing.total.toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm">
                      <p className="font-medium text-yellow-900 mb-1">
                        Deposit: ${pricing.deposit}
                      </p>
                      <p className="text-xs text-yellow-700">
                        Balance of ${(pricing.total - pricing.deposit).toFixed(2)} due at check-out
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-green-500" />
                        <span>Free cancellation (48hrs)</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-green-500" />
                        <span>Daily photo updates</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-green-500" />
                        <span>Stay Story timeline</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-green-500" />
                        <span>4 weeks free insurance</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-gray-500 text-center">
                    Select dates to see pricing
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="text-center mt-8">
          <Link to="/site" className="text-purple-600 hover:underline">
            ← Back to website
          </Link>
        </div>
      </div>
    </div>
  );
}