import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Heart, ArrowRight, X, Eye, EyeOff } from 'lucide-react';

import logoIcon from 'figma:asset/b463d12091f20e48be52186dedd2a0f6707d0b66.png';
import logoText from 'figma:asset/9900b394e20a5e059447324d58daad1b1bf43ed6.png';

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if user has completed onboarding
    const onboardingProgress = localStorage.getItem('onboarding_progress');
    const onboardingData = onboardingProgress ? JSON.parse(onboardingProgress) : null;
    
    // Check if website has been published
    const isPublished = onboardingData?.published || false;
    const lastStep = onboardingData?.currentStep || 1;
    
    if (!isPublished) {
      // Resume onboarding at last saved step
      navigate(`/onboarding?step=${lastStep}`);
    } else {
      // Get their subdomain from onboarding data
      const businessName = onboardingData?.businessName || 'demo';
      const subdomain = businessName.toLowerCase().replace(/\s+/g, '');
      
      // Redirect to their admin dashboard
      // In production: window.location.href = `https://${subdomain}.catstays.app/admin`;
      // For demo: navigate to admin
      navigate('/admin');
    }
  };

  const handleClose = () => {
    navigate('/');
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={handleBackdropClick}
    >
      <Card className="w-full max-w-md border-[#0A1128]/10 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <CardHeader className="text-center pb-6 pt-8">
          {/* CatStays Logo - Stacked Vertically */}
          <div className="flex flex-col items-center gap-3 mb-6">
            <img src={logoIcon} alt="CatStays" className="h-16 w-16" />
            <img src={logoText} alt="CatStays" className="h-12" />
          </div>

          <CardTitle className="text-3xl font-serif text-[#0A1128] mb-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
            Account Setup
          </CardTitle>
          <CardDescription className="text-base text-[#0A1128]/70">
            Continue setting up your cattery
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#0A1128]">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-[#0A1128]/20 focus:border-[#C46A3A] h-11"
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-[#0A1128]">Password</Label>
                <button
                  type="button"
                  className="text-xs text-[#C46A3A] hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-[#0A1128]/20 focus:border-[#C46A3A] h-11 pr-10"
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-[#C46A3A] hover:bg-[#A85A30] text-white h-11 text-base" 
              size="lg"
            >
              Continue Setup
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>

          {/* Microcopy */}
          <p className="mt-4 text-center text-sm text-[#0A1128]/60 italic">
            Pick up right where you left off
          </p>

          <div className="mt-6 pt-6 border-t border-[#0A1128]/10 text-center text-sm text-[#0A1128]/70">
            Don't have an account?{' '}
            <Link to="/signup" className="text-[#C46A3A] hover:underline font-medium">
              Start free trial
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}