import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';

import logoIcon from 'figma:asset/b463d12091f20e48be52186dedd2a0f6707d0b66.png';
import logoText from 'figma:asset/9900b394e20a5e059447324d58daad1b1bf43ed6.png';

export function Signup() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    businessName: '',
    ownerName: '',
    email: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Clear any existing cached data - fresh start for free trial
    localStorage.removeItem('catstays_signup_data');
    // Navigate to onboarding
    navigate('/onboarding');
  };

  return (
    <div className="min-h-screen bg-[#F8F7F5] flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-[#0A1128]/10">
        <CardHeader className="text-center">
          {/* CatStays Logo - Stacked Vertically */}
          <Link to="/" className="flex flex-col items-center gap-3 mb-4">
            <img src={logoIcon} alt="CatStays" className="h-14 w-14" />
            <img src={logoText} alt="CatStays" className="h-10" />
          </Link>
          <CardTitle className="text-2xl font-serif text-[#0A1128]" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
            Start your free trial
          </CardTitle>
          <CardDescription className="text-[#0A1128]/60">
            No credit card required • 14 days free
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="businessName">Business Name</Label>
              <Input
                id="businessName"
                placeholder="Deloraine Cattery"
                value={formData.businessName}
                onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ownerName">Your Name</Label>
              <Input
                id="ownerName"
                placeholder="Vanessa Smith"
                value={formData.ownerName}
                onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-[#C46A3A] hover:bg-[#A85A30] text-white" size="lg">
              Continue to Setup
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-[#0A1128]/70">
            Already have an account?{' '}
            <Link to="/login" className="text-[#C46A3A] hover:underline font-medium">
              Login
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}