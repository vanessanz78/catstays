import { useState } from 'react';
import { Link } from 'react-router';
import { Button } from '../../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Badge } from '../../components/ui/badge';
import { Search, Phone, Mail, ArrowLeft, Cat } from 'lucide-react';

export function AdminCustomers() {
  const [searchQuery, setSearchQuery] = useState('');

  const customers = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah.j@email.com',
      phone: '027 123 4567',
      cats: [{ name: 'Whiskers', breed: 'Tabby' }],
      totalBookings: 8,
      status: 'active'
    },
    {
      id: 2,
      name: 'Mike Chen',
      email: 'mike.chen@email.com',
      phone: '021 987 6543',
      cats: [{ name: 'Luna', breed: 'Siamese' }, { name: 'Shadow', breed: 'Black Cat' }],
      totalBookings: 5,
      status: 'active'
    },
    {
      id: 3,
      name: 'Emma Wilson',
      email: 'emma.w@email.com',
      phone: '022 456 7890',
      cats: [{ name: 'Mittens', breed: 'Persian' }],
      totalBookings: 3,
      status: 'active'
    },
    {
      id: 4,
      name: 'John Smith',
      email: 'john.smith@email.com',
      phone: '027 234 5678',
      cats: [{ name: 'Tiger', breed: 'Bengal' }],
      totalBookings: 12,
      status: 'vip'
    },
    {
      id: 5,
      name: 'Lisa Brown',
      email: 'lisa.b@email.com',
      phone: '021 345 6789',
      cats: [{ name: 'Fluffy', breed: 'Maine Coon' }],
      totalBookings: 6,
      status: 'active'
    },
    {
      id: 6,
      name: 'James Taylor',
      email: 'james.t@email.com',
      phone: '022 567 8901',
      cats: [{ name: 'Oliver', breed: 'British Shorthair' }],
      totalBookings: 10,
      status: 'vip'
    },
    {
      id: 7,
      name: 'Anna Lee',
      email: 'anna.lee@email.com',
      phone: '027 678 9012',
      cats: [{ name: 'Bella', breed: 'Ragdoll' }],
      totalBookings: 7,
      status: 'active'
    },
    {
      id: 8,
      name: 'Tom Davis',
      email: 'tom.d@email.com',
      phone: '021 789 0123',
      cats: [{ name: 'Charlie', breed: 'Scottish Fold' }],
      totalBookings: 4,
      status: 'active'
    },
    {
      id: 9,
      name: 'Rachel Green',
      email: 'rachel.g@email.com',
      phone: '022 890 1234',
      cats: [{ name: 'Coco', breed: 'Burmese' }, { name: 'Milo', breed: 'Birman' }],
      totalBookings: 9,
      status: 'vip'
    },
    {
      id: 10,
      name: 'David White',
      email: 'david.w@email.com',
      phone: '027 901 2345',
      cats: [{ name: 'Simba', breed: 'Ginger' }],
      totalBookings: 5,
      status: 'active'
    }
  ];

  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.cats.some(cat => cat.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: '#F6F4EF' }}>
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Link to="/admin">
              <Button variant="ghost" size="icon" className="rounded-full">
                <ArrowLeft className="w-5 h-5" style={{ color: '#7DAF7B' }} />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-serif font-semibold" style={{ color: '#2d3e2f' }}>
                Customers
              </h1>
              <p className="text-sm" style={{ color: '#6b7a6d' }}>{customers.length} total customers</p>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="border-t border-sage/10 px-4 py-3">
          <div className="max-w-lg mx-auto relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#6b7a6d' }} />
            <Input
              type="text"
              placeholder="Search by name, email, or cat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-xl border-[#7DAF7B]/20"
              style={{ backgroundColor: '#FFFFFF' }}
            />
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-3">
        {filteredCustomers.map((customer) => (
          <Card 
            key={customer.id}
            className="border-[#7DAF7B]/20 shadow-md hover:shadow-lg transition-shadow" 
            style={{ borderRadius: '16px', backgroundColor: '#FFFFFF' }}
          >
            <CardContent className="p-5">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-lg font-semibold" style={{ color: '#2d3e2f' }}>
                      {customer.name}
                    </h3>
                    {customer.status === 'vip' && (
                      <Badge className="bg-[#E9C46A] hover:bg-[#E9C46A] text-[#2d3e2f] text-xs">
                        VIP
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm" style={{ color: '#6b7a6d' }}>
                    <Mail className="w-4 h-4" />
                    {customer.email}
                  </div>
                  <div className="flex items-center gap-2 text-sm mt-1" style={{ color: '#6b7a6d' }}>
                    <Phone className="w-4 h-4" />
                    {customer.phone}
                  </div>
                </div>
              </div>

              {/* Cats */}
              <div className="border-t border-sage/10 pt-3 mb-3">
                <div className="flex items-center gap-2 mb-2">
                  <Cat className="w-4 h-4" style={{ color: '#7DAF7B' }} />
                  <span className="text-sm font-medium" style={{ color: '#2d3e2f' }}>
                    {customer.cats.length} cat{customer.cats.length > 1 ? 's' : ''}
                  </span>
                </div>
                <div className="space-y-1">
                  {customer.cats.map((cat, index) => (
                    <div key={index} className="text-sm" style={{ color: '#6b7a6d' }}>
                      <span className="font-medium" style={{ color: '#2d3e2f' }}>{cat.name}</span>
                      <span className="mx-2">•</span>
                      {cat.breed}
                    </div>
                  ))}
                </div>
              </div>

              {/* Stats & Actions */}
              <div className="flex items-center justify-between pt-3 border-t border-sage/10">
                <div className="text-sm" style={{ color: '#6b7a6d' }}>
                  <span className="font-semibold" style={{ color: '#7DAF7B' }}>
                    {customer.totalBookings}
                  </span> bookings
                </div>
                <div className="flex gap-2">
                  <a href={`tel:${customer.phone}`}>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="border-[#7DAF7B] text-[#7DAF7B] hover:bg-[#7DAF7B]/5 rounded-xl"
                    >
                      <Phone className="w-4 h-4" />
                    </Button>
                  </a>
                  <a href={`mailto:${customer.email}`}>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="border-[#7DAF7B] text-[#7DAF7B] hover:bg-[#7DAF7B]/5 rounded-xl"
                    >
                      <Mail className="w-4 h-4" />
                    </Button>
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredCustomers.length === 0 && (
          <Card className="border-[#7DAF7B]/20 shadow-sm" style={{ borderRadius: '16px', backgroundColor: '#FFFFFF' }}>
            <CardContent className="py-12 text-center" style={{ color: '#6b7a6d' }}>
              <p>No customers found matching "{searchQuery}"</p>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Removed BottomNav component */}
    </div>
  );
}