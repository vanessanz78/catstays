import { useState } from 'react';
import { RightMenu } from '../../components/RightMenu';
import { NotificationBell } from '../../components/NotificationBell';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, 
  Crown,
  CheckCircle,
  Calendar,
  CreditCard,
  Download,
  AlertCircle,
  Sparkles,
  TrendingUp,
  Lock,
  Zap
} from 'lucide-react';
import { Link, useNavigate } from 'react-router';
import { format } from 'date-fns';

export function Subscription() {
  const navigate = useNavigate();
  
  // Mock subscription data - would come from API
  const [subscriptionData] = useState({
    tier: 'Professional', // 'Basic', 'Professional', 'Premium'
    status: 'active', // 'active', 'cancelled', 'past_due'
    billingCycle: 'monthly', // 'monthly', 'annual'
    price: 49,
    nextBillingDate: new Date('2026-04-18'),
    cardLast4: '4242',
    cardBrand: 'Visa'
  });

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const tiers = [
    {
      name: 'Basic',
      price: 29,
      priceAnnual: 290,
      description: 'Perfect for small catteries just getting started',
      features: [
        'Up to 15 rooms',
        'Basic booking calendar',
        'Customer management',
        'Email support',
        'Mobile dashboard',
        'Photo updates'
      ],
      color: '#6b7a6d'
    },
    {
      name: 'Professional',
      price: 49,
      priceAnnual: 490,
      description: 'Most popular for growing catteries',
      features: [
        'Unlimited rooms',
        'Advanced booking system',
        'Grooming module',
        'Automated messaging',
        'Marketing tools',
        'Priority support',
        'Custom branding',
        'Analytics & insights'
      ],
      color: '#7DAF7B',
      popular: true
    },
    {
      name: 'Premium',
      price: 99,
      priceAnnual: 990,
      description: 'Everything you need to scale your business',
      features: [
        'Everything in Professional',
        'Multi-location support',
        'Advanced analytics',
        'API access',
        'Dedicated account manager',
        'White-label options',
        'Custom integrations',
        'SLA guarantee'
      ],
      color: '#C46A3A'
    }
  ];

  const handleCancelSubscription = () => {
    alert('Subscription cancellation would be processed here');
    setShowCancelModal(false);
  };

  const handleChangeBillingCycle = () => {
    alert('Billing cycle change would be processed here');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F6F4EF' }}>
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/admin" className="p-2 hover:bg-[#F6F4EF] rounded-lg transition-colors">
              <ArrowLeft className="w-5 h-5" style={{ color: '#2d3e2f' }} />
            </Link>
            <div>
              <h1 className="text-xl font-serif font-semibold" style={{ color: '#2d3e2f' }}>
                Subscription Management
              </h1>
              <p className="text-sm" style={{ color: '#6b7a6d' }}>
                Manage your CatStays subscription
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <RightMenu />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto p-4 md:p-6 pb-24 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 80px)' }}>
        {/* Current Subscription */}
        <Card className="mb-6 border-2" style={{ borderColor: '#7DAF7B' }}>
          <CardHeader className="bg-gradient-to-br from-white to-cream">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <CardTitle className="text-2xl font-serif text-forest">
                    Current Plan: {subscriptionData.tier}
                  </CardTitle>
                  <Badge className="bg-[#7DAF7B] hover:bg-[#7DAF7B]">
                    Active
                  </Badge>
                </div>
                <p className="text-sm text-forest/70">
                  Billed {subscriptionData.billingCycle === 'monthly' ? 'monthly' : 'annually'}
                </p>
              </div>
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#7DAF7B] to-[#7DAF7B]/70 flex items-center justify-center">
                <Crown className="w-8 h-8 text-white" />
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div>
                <p className="text-sm text-forest/70 mb-1">Monthly Price</p>
                <p className="text-2xl font-bold text-forest">${subscriptionData.price}/mo</p>
              </div>
              <div>
                <p className="text-sm text-forest/70 mb-1 flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Next Billing Date
                </p>
                <p className="text-lg font-semibold text-forest">
                  {format(subscriptionData.nextBillingDate, 'MMMM d, yyyy')}
                </p>
              </div>
              <div>
                <p className="text-sm text-forest/70 mb-1 flex items-center gap-1">
                  <CreditCard className="w-4 h-4" />
                  Payment Method
                </p>
                <p className="text-lg font-semibold text-forest">
                  {subscriptionData.cardBrand} •••• {subscriptionData.cardLast4}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => navigate('/dashboard/payment')}
                variant="outline"
                className="flex-1 min-w-[200px]"
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Update Payment Method
              </Button>
              <Button
                onClick={handleChangeBillingCycle}
                variant="outline"
                className="flex-1 min-w-[200px]"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Switch to {subscriptionData.billingCycle === 'monthly' ? 'Annual' : 'Monthly'}
              </Button>
              <Button
                onClick={() => setShowUpgradeModal(true)}
                className="flex-1 min-w-[200px] bg-[#C46A3A] hover:bg-[#A85A30] text-white"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Upgrade Plan
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Available Plans */}
        <div className="mb-6">
          <h2 className="text-2xl font-serif font-bold text-forest mb-4">
            Available Plans
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {tiers.map((tier) => (
              <Card 
                key={tier.name} 
                className={`relative ${tier.popular ? 'border-2 shadow-xl' : 'border'}`}
                style={tier.popular ? { borderColor: tier.color } : {}}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-[#C46A3A] hover:bg-[#C46A3A] text-white">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="bg-gradient-to-br from-white to-cream">
                  <CardTitle className="text-xl font-serif text-forest">
                    {tier.name}
                  </CardTitle>
                  <p className="text-sm text-forest/70">{tier.description}</p>
                  <div className="mt-4">
                    <span className="text-4xl font-bold" style={{ color: tier.color }}>
                      ${tier.price}
                    </span>
                    <span className="text-sm text-forest/70">/month</span>
                  </div>
                  <p className="text-xs text-forest/50">
                    or ${tier.priceAnnual}/year (save ${(tier.price * 12) - tier.priceAnnual})
                  </p>
                </CardHeader>
                
                <CardContent className="p-6">
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: tier.color }} />
                        <span className="text-forest/80">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={() => tier.name !== subscriptionData.tier && setShowUpgradeModal(true)}
                    className="w-full"
                    variant={tier.name === subscriptionData.tier ? 'outline' : 'default'}
                    style={tier.name !== subscriptionData.tier ? { 
                      backgroundColor: tier.color,
                      color: 'white'
                    } : {}}
                    disabled={tier.name === subscriptionData.tier}
                  >
                    {tier.name === subscriptionData.tier ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Current Plan
                      </>
                    ) : tier.name === 'Premium' && subscriptionData.tier === 'Professional' ? (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Upgrade
                      </>
                    ) : tier.name === 'Basic' ? (
                      <>
                        <Lock className="w-4 h-4 mr-2" />
                        Downgrade
                      </>
                    ) : (
                      <>
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Choose Plan
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Billing History */}
        <Card className="mb-6">
          <CardHeader className="bg-gradient-to-br from-white to-cream">
            <CardTitle className="text-xl font-serif text-forest">
              Billing History
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-3">
              {[
                { date: new Date('2026-03-18'), amount: 49, status: 'Paid', invoice: 'INV-2026-03' },
                { date: new Date('2026-02-18'), amount: 49, status: 'Paid', invoice: 'INV-2026-02' },
                { date: new Date('2026-01-18'), amount: 49, status: 'Paid', invoice: 'INV-2026-01' }
              ].map((bill, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-[#F8F7F5] rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#7DAF7B]/10 flex items-center justify-center">
                      <CreditCard className="w-5 h-5" style={{ color: '#7DAF7B' }} />
                    </div>
                    <div>
                      <p className="font-semibold text-forest">{format(bill.date, 'MMMM d, yyyy')}</p>
                      <p className="text-sm text-forest/70">{bill.invoice}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-bold text-forest">${bill.amount}.00</p>
                      <Badge className="bg-[#7DAF7B] hover:bg-[#7DAF7B] text-xs">
                        {bill.status}
                      </Badge>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-red-200">
          <CardHeader className="bg-red-50">
            <CardTitle className="text-lg font-serif text-red-900 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Danger Zone
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <p className="text-sm text-red-900/70 mb-4">
              Once you cancel your subscription, you'll lose access to all premium features at the end of your billing period.
            </p>
            <Button
              onClick={() => setShowCancelModal(true)}
              variant="outline"
              className="border-red-300 text-red-700 hover:bg-red-50"
            >
              Cancel Subscription
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Cancel Modal */}
      {showCancelModal && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowCancelModal(false)}
        >
          <Card 
            className="max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader className="bg-red-50">
              <CardTitle className="text-xl text-red-900">Cancel Subscription?</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-forest/70 mb-6">
                Are you sure you want to cancel your subscription? You'll lose access to all premium features, including the grooming module, automated messaging, and analytics.
              </p>
              <div className="flex gap-3">
                <Button
                  onClick={handleCancelSubscription}
                  variant="outline"
                  className="flex-1 border-red-300 text-red-700 hover:bg-red-50"
                >
                  Yes, Cancel
                </Button>
                <Button
                  onClick={() => setShowCancelModal(false)}
                  className="flex-1 bg-[#7DAF7B] hover:bg-[#6a9e6a] text-white"
                >
                  Keep Subscription
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Upgrade Modal */}
      {showUpgradeModal && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setShowUpgradeModal(false)}
        >
          <Card 
            className="max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader className="bg-gradient-to-br from-white to-cream">
              <CardTitle className="text-xl font-serif text-forest">Upgrade Your Plan</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <p className="text-sm text-forest/70 mb-6">
                Contact our team to upgrade your plan and unlock more features for your cattery.
              </p>
              <div className="flex gap-3">
                <Button
                  onClick={() => alert('Upgrade would be processed here')}
                  className="flex-1 bg-[#C46A3A] hover:bg-[#A85A30] text-white"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Upgrade Now
                </Button>
                <Button
                  onClick={() => setShowUpgradeModal(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
