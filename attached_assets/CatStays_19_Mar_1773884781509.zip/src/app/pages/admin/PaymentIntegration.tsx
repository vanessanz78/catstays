import { useState } from 'react';
import { RightMenu } from '../../components/RightMenu';
import { NotificationBell } from '../../components/NotificationBell';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, 
  CreditCard,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Copy,
  Eye,
  EyeOff,
  RefreshCw,
  DollarSign,
  Zap,
  Lock,
  Shield
} from 'lucide-react';
import { Link } from 'react-router';

export function PaymentIntegration() {
  const [stripeConnected, setStripeConnected] = useState(true);
  const [showSecretKey, setShowSecretKey] = useState(false);
  const [showPublishableKey, setShowPublishableKey] = useState(false);
  const [testMode, setTestMode] = useState(true);

  // Mock Stripe data
  const [stripeData] = useState({
    accountId: 'acct_1234567890abcdef',
    publishableKey: 'pk_test_51O...xyz',
    secretKey: 'sk_test_51O...xyz',
    webhookSecret: 'whsec_...abc',
    isActive: true,
    balance: 4580.50,
    pendingBalance: 1250.00,
    lastPayout: new Date('2026-03-15'),
    nextPayout: new Date('2026-03-22')
  });

  const handleConnectStripe = () => {
    alert('Stripe OAuth connection would be initiated here');
  };

  const handleDisconnectStripe = () => {
    if (confirm('Are you sure you want to disconnect Stripe? You will no longer be able to accept payments.')) {
      setStripeConnected(false);
    }
  };

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    alert('API key copied to clipboard!');
  };

  const handleTestWebhook = () => {
    alert('Webhook test event sent successfully!');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F6F4EF' }}>
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link to="/admin" className="p-2 hover:bg-[#F6F4EF] rounded-lg transition-colors">
              <ArrowLeft className="w-5 h-5" style={{ color: '#2d3e2f' }} />
            </Link>
            <div>
              <h1 className="text-xl font-serif font-semibold" style={{ color: '#2d3e2f' }}>
                Payment Integration
              </h1>
              <p className="text-sm" style={{ color: '#6b7a6d' }}>
                Connect Stripe to accept payments
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <RightMenu />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-4 md:p-6 pb-24 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 80px)' }}>
        
        {!stripeConnected ? (
          /* Not Connected State */
          <Card className="border-2 border-[#C46A3A]/20 shadow-xl">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#635BFF] to-[#0A2540] flex items-center justify-center mx-auto mb-6">
                <CreditCard className="w-10 h-10 text-white" />
              </div>
              
              <h2 className="text-3xl font-serif font-bold text-[#0A1128] mb-3">
                Connect Stripe
              </h2>
              
              <p className="text-lg text-[#0A1128]/70 mb-6 max-w-md mx-auto">
                Accept payments from your customers at the time of booking with secure Stripe integration
              </p>

              <div className="bg-[#F8F7F5] rounded-xl p-6 mb-6 text-left max-w-md mx-auto">
                <h3 className="font-semibold text-[#0A1128] mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-[#C46A3A]" />
                  Features included:
                </h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#7DAF7B] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#0A1128]/80">
                      Accept credit & debit cards
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#7DAF7B] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#0A1128]/80">
                      Collect deposits and full payments
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#7DAF7B] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#0A1128]/80">
                      Automated payment confirmations
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#7DAF7B] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#0A1128]/80">
                      PCI-compliant security
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#7DAF7B] flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#0A1128]/80">
                      Automatic reconciliation
                    </span>
                  </li>
                </ul>
              </div>

              <Button
                onClick={handleConnectStripe}
                className="bg-[#635BFF] hover:bg-[#0A2540] text-white mb-4"
                size="lg"
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Connect with Stripe
              </Button>

              <p className="text-xs text-[#0A1128]/50">
                Secure connection powered by Stripe
              </p>
            </CardContent>
          </Card>
        ) : (
          /* Connected State */
          <div className="space-y-6">
            {/* Connection Status */}
            <Card className="border-2" style={{ borderColor: '#7DAF7B' }}>
              <CardHeader className="bg-gradient-to-br from-white to-cream">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle className="text-2xl font-serif text-forest">
                        Stripe Connected
                      </CardTitle>
                      <Badge className="bg-[#7DAF7B] hover:bg-[#7DAF7B]">
                        Active
                      </Badge>
                    </div>
                    <p className="text-sm text-forest/70">
                      Account ID: {stripeData.accountId}
                    </p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#635BFF] to-[#0A2540] flex items-center justify-center">
                    <CreditCard className="w-8 h-8 text-white" />
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-[#F8F7F5] rounded-xl p-4">
                    <p className="text-sm text-forest/70 mb-1 flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      Available Balance
                    </p>
                    <p className="text-3xl font-bold text-forest">
                      ${stripeData.balance.toFixed(2)}
                    </p>
                  </div>
                  <div className="bg-[#F8F7F5] rounded-xl p-4">
                    <p className="text-sm text-forest/70 mb-1 flex items-center gap-1">
                      <RefreshCw className="w-4 h-4" />
                      Pending
                    </p>
                    <p className="text-3xl font-bold text-forest">
                      ${stripeData.pendingBalance.toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => window.open('https://dashboard.stripe.com', '_blank')}
                    className="flex-1 bg-[#635BFF] hover:bg-[#0A2540] text-white"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open Stripe Dashboard
                  </Button>
                  <Button
                    onClick={handleDisconnectStripe}
                    variant="outline"
                    className="border-red-300 text-red-700 hover:bg-red-50"
                  >
                    Disconnect
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Mode Toggle */}
            <Card>
              <CardHeader className="bg-gradient-to-br from-white to-cream">
                <CardTitle className="text-xl font-serif text-forest">
                  Environment Mode
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="font-semibold text-forest">
                      {testMode ? 'Test Mode' : 'Live Mode'}
                    </p>
                    <p className="text-sm text-forest/70">
                      {testMode ? 'Use test cards for development' : 'Processing real payments'}
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!testMode}
                      onChange={(e) => setTestMode(!e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-14 h-8 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#7DAF7B]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:start-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#7DAF7B]"></div>
                  </label>
                </div>
                
                {testMode && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-semibold text-blue-900 mb-1">Test Mode Active</p>
                        <p className="text-blue-800 mb-2">
                          You're in test mode. Use these test card numbers:
                        </p>
                        <ul className="space-y-1 text-blue-700">
                          <li>• Success: 4242 4242 4242 4242</li>
                          <li>• Declined: 4000 0000 0000 0002</li>
                          <li>• 3D Secure: 4000 0025 0000 3155</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* API Keys */}
            <Card>
              <CardHeader className="bg-gradient-to-br from-white to-cream">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-serif text-forest">
                    API Keys
                  </CardTitle>
                  <Badge className="bg-[#6b7a6d] hover:bg-[#6b7a6d]">
                    <Lock className="w-3 h-3 mr-1" />
                    Secure
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {/* Publishable Key */}
                <div>
                  <Label className="text-sm font-medium text-forest/70 mb-2 block">
                    Publishable Key (Client-side)
                  </Label>
                  <div className="flex gap-2">
                    <div className="flex-1 relative">
                      <Input
                        type={showPublishableKey ? 'text' : 'password'}
                        value={stripeData.publishableKey}
                        readOnly
                        className="pr-10 font-mono text-sm"
                      />
                      <button
                        onClick={() => setShowPublishableKey(!showPublishableKey)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-forest/50 hover:text-forest"
                      >
                        {showPublishableKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <Button
                      onClick={() => handleCopyKey(stripeData.publishableKey)}
                      variant="outline"
                      size="icon"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Secret Key */}
                <div>
                  <Label className="text-sm font-medium text-forest/70 mb-2 block">
                    Secret Key (Server-side)
                  </Label>
                  <div className="flex gap-2">
                    <div className="flex-1 relative">
                      <Input
                        type={showSecretKey ? 'text' : 'password'}
                        value={stripeData.secretKey}
                        readOnly
                        className="pr-10 font-mono text-sm"
                      />
                      <button
                        onClick={() => setShowSecretKey(!showSecretKey)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-forest/50 hover:text-forest"
                      >
                        {showSecretKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <Button
                      onClick={() => handleCopyKey(stripeData.secretKey)}
                      variant="outline"
                      size="icon"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    Never share your secret key publicly
                  </p>
                </div>

                {/* Webhook Secret */}
                <div>
                  <Label className="text-sm font-medium text-forest/70 mb-2 block">
                    Webhook Signing Secret
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      type="password"
                      value={stripeData.webhookSecret}
                      readOnly
                      className="flex-1 font-mono text-sm"
                    />
                    <Button
                      onClick={() => handleCopyKey(stripeData.webhookSecret)}
                      variant="outline"
                      size="icon"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Webhook Configuration */}
            <Card>
              <CardHeader className="bg-gradient-to-br from-white to-cream">
                <CardTitle className="text-xl font-serif text-forest">
                  Webhook Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-4">
                  <Label className="text-sm font-medium text-forest/70 mb-2 block">
                    Webhook Endpoint URL
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      value="https://purrfecthaven.catstays.nz/api/webhooks/stripe"
                      readOnly
                      className="flex-1 font-mono text-sm"
                    />
                    <Button
                      onClick={() => handleCopyKey('https://purrfecthaven.catstays.nz/api/webhooks/stripe')}
                      variant="outline"
                      size="icon"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-forest/50 mt-1">
                    Add this URL to your Stripe webhook settings
                  </p>
                </div>

                <div className="bg-[#F8F7F5] rounded-lg p-4 mb-4">
                  <p className="text-sm font-semibold text-forest mb-2">Listening for events:</p>
                  <div className="flex flex-wrap gap-2">
                    {['payment_intent.succeeded', 'payment_intent.failed', 'charge.refunded', 'customer.subscription.updated'].map((event) => (
                      <Badge key={event} variant="outline" className="text-xs">
                        {event}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleTestWebhook}
                  variant="outline"
                  className="w-full"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Send Test Webhook
                </Button>
              </CardContent>
            </Card>

            {/* Payment Settings */}
            <Card>
              <CardHeader className="bg-gradient-to-br from-white to-cream">
                <CardTitle className="text-xl font-serif text-forest">
                  Payment Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between p-4 bg-[#F8F7F5] rounded-lg">
                  <div>
                    <p className="font-semibold text-forest">Accept card payments at booking</p>
                    <p className="text-sm text-forest/70">Customers can pay deposits or full amount</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={true}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#7DAF7B]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#7DAF7B]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-[#F8F7F5] rounded-lg">
                  <div>
                    <p className="font-semibold text-forest">Automatic payment receipts</p>
                    <p className="text-sm text-forest/70">Send receipts to customers automatically</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={true}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#7DAF7B]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#7DAF7B]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between p-4 bg-[#F8F7F5] rounded-lg">
                  <div>
                    <p className="font-semibold text-forest">Save cards for future bookings</p>
                    <p className="text-sm text-forest/70">Allow customers to save payment methods</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={true}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#7DAF7B]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#7DAF7B]"></div>
                  </label>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
