import { useState, useEffect } from 'react';
import { Plus, Home, DollarSign, Users, TrendingUp, Edit, Trash2, Eye, EyeOff } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Room } from '../../types/room-planner';
import { getRooms, saveRooms, getBookings } from '../../utils/roomPlannerStorage';
import { RoomFormModal } from '../../components/rooms/RoomFormModal';

export function RoomManagement() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [showRoomModal, setShowRoomModal] = useState(false);

  useEffect(() => {
    setRooms(getRooms());
    setBookings(getBookings());
  }, []);

  const handleSaveRoom = (room: Room) => {
    let updatedRooms: Room[];
    
    if (selectedRoom) {
      updatedRooms = rooms.map(r => r.id === room.id ? room : r);
    } else {
      const newRoom = { ...room, id: Date.now().toString() };
      updatedRooms = [...rooms, newRoom];
    }
    
    setRooms(updatedRooms);
    saveRooms(updatedRooms);
    setShowRoomModal(false);
    setSelectedRoom(null);
  };

  const handleDeleteRoom = (roomId: string) => {
    if (confirm('Are you sure you want to delete this room?')) {
      const updatedRooms = rooms.filter(r => r.id !== roomId);
      setRooms(updatedRooms);
      saveRooms(updatedRooms);
    }
  };

  const handleToggleActive = (room: Room) => {
    const updatedRooms = rooms.map(r =>
      r.id === room.id ? { ...r, active: !r.active } : r
    );
    setRooms(updatedRooms);
    saveRooms(updatedRooms);
  };

  const getRoomBookings = (roomId: string) => {
    return bookings.filter(b => b.roomId === roomId && b.status !== 'cancelled');
  };

  const getCurrentGuest = (roomId: string) => {
    const today = new Date().toISOString().split('T')[0];
    return bookings.find(
      b => b.roomId === roomId && 
      b.status === 'checked_in' && 
      b.checkIn <= today && 
      b.checkOut >= today
    );
  };

  const getMonthlyRevenue = (roomId: string) => {
    const thisMonth = new Date().getMonth();
    const thisYear = new Date().getFullYear();
    
    return bookings
      .filter(b => {
        if (b.roomId !== roomId || b.status === 'cancelled') return false;
        const checkIn = new Date(b.checkIn);
        return checkIn.getMonth() === thisMonth && checkIn.getFullYear() === thisYear;
      })
      .reduce((sum, b) => sum + b.finalPrice, 0);
  };

  const getRoomTypeColor = (type: string) => {
    switch (type) {
      case 'premium': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'deluxe': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'standard': return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'occupied': return 'bg-[#FF7F7F] text-white';
      case 'available': return 'bg-[#8FBC8F] text-white';
      case 'cleaning': return 'bg-[#FFD700] text-gray-800';
      case 'maintenance': return 'bg-[#DC143C] text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F5F0] to-[#E8E8E3] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Room Management</h1>
              <p className="text-gray-600">Manage your boarding rooms and occupancy</p>
            </div>
            <Button
              onClick={() => {
                setSelectedRoom(null);
                setShowRoomModal(true);
              }}
              className="bg-[#8FBC8F] hover:bg-[#7AAC7A] text-white rounded-xl px-6 py-3"
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Room
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-4">
            <Card className="rounded-2xl border-2 border-[#8FBC8F]/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Total Rooms</p>
                    <p className="text-3xl font-bold text-gray-800">{rooms.length}</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#8FBC8F]/10 flex items-center justify-center">
                    <Home className="w-6 h-6 text-[#8FBC8F]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-2 border-[#87CEEB]/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Available</p>
                    <p className="text-3xl font-bold text-gray-800">
                      {rooms.filter(r => r.status === 'available').length}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#87CEEB]/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-[#87CEEB]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-2 border-[#FF7F7F]/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Occupied</p>
                    <p className="text-3xl font-bold text-gray-800">
                      {rooms.filter(r => r.status === 'occupied').length}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#FF7F7F]/10 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-[#FF7F7F]" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-2 border-[#E6E6FA]/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Avg. Rate</p>
                    <p className="text-3xl font-bold text-gray-800">
                      ${Math.round(rooms.reduce((sum, r) => sum + r.baseRate, 0) / rooms.length || 0)}
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#E6E6FA]/10 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-[#E6E6FA]" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Room Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map(room => {
            const currentGuest = getCurrentGuest(room.id);
            const upcomingBookings = getRoomBookings(room.id).filter(b => 
              b.status !== 'checked_in' && new Date(b.checkIn) > new Date()
            );
            const monthlyRevenue = getMonthlyRevenue(room.id);

            return (
              <Card key={room.id} className={`rounded-2xl border-2 transition-all hover:shadow-lg ${!room.active ? 'opacity-50' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{room.name}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={`${getRoomTypeColor(room.type)} capitalize`}>
                          {room.type}
                        </Badge>
                        <Badge className={getStatusColor(room.status)}>
                          {room.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleActive(room)}
                        className="h-8 w-8 p-0"
                      >
                        {room.active ? (
                          <Eye className="w-4 h-4 text-gray-600" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-gray-400" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedRoom(room);
                          setShowRoomModal(true);
                        }}
                        className="h-8 w-8 p-0"
                      >
                        <Edit className="w-4 h-4 text-gray-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteRoom(room.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Current Guest */}
                  {currentGuest && (
                    <div className="p-3 bg-[#FF7F7F]/10 rounded-xl border border-[#FF7F7F]/20">
                      <p className="text-xs text-gray-600 mb-1">Current Guest</p>
                      <p className="font-semibold text-gray-800">{currentGuest.catName}</p>
                      <p className="text-sm text-gray-600">{currentGuest.ownerName}</p>
                    </div>
                  )}

                  {/* Room Details */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Base Rate</p>
                      <p className="text-lg font-bold text-gray-800">${room.baseRate}/night</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Size</p>
                      <p className="text-lg font-bold text-gray-800">{room.size} sq ft</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Capacity</p>
                      <p className="text-lg font-bold text-gray-800">{room.maxOccupancy} cat(s)</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-1">This Month</p>
                      <p className="text-lg font-bold text-[#228B22]">${monthlyRevenue}</p>
                    </div>
                  </div>

                  {/* Amenities */}
                  {room.amenities.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-600 mb-2">Amenities</p>
                      <div className="flex flex-wrap gap-1">
                        {room.amenities.slice(0, 3).map((amenity, idx) => (
                          <span key={idx} className="text-xs px-2 py-1 bg-[#E6E6FA]/20 text-gray-700 rounded-lg">
                            {amenity}
                          </span>
                        ))}
                        {room.amenities.length > 3 && (
                          <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-lg">
                            +{room.amenities.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Upcoming Bookings */}
                  <div className="pt-3 border-t">
                    <p className="text-xs text-gray-600">
                      {upcomingBookings.length > 0 
                        ? `${upcomingBookings.length} upcoming booking${upcomingBookings.length > 1 ? 's' : ''}`
                        : 'No upcoming bookings'
                      }
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Room Form Modal */}
      {showRoomModal && (
        <RoomFormModal
          room={selectedRoom}
          onSave={handleSaveRoom}
          onClose={() => {
            setShowRoomModal(false);
            setSelectedRoom(null);
          }}
        />
      )}
    </div>
  );
}
