import { useRef, useEffect } from 'react';
import Autocomplete from 'react-google-autocomplete';
import { Input } from './ui/input';

interface AddressAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  id?: string;
}

// Google Maps API key - in production this should come from environment variables
const GOOGLE_MAPS_API_KEY = 'AIzaSyDGmYm_pEXKXvYVMGvWzYV8Q3aZKqR0-0g'; // Demo key - replace with actual key

export function AddressAutocomplete({ 
  value, 
  onChange, 
  placeholder = 'Start typing your address...', 
  className = '',
  id 
}: AddressAutocompleteProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  // If Google Places API is available, use it with autocomplete
  // Otherwise, fall back to regular input with browser autocomplete
  const isGooglePlacesAvailable = typeof window !== 'undefined' && 'google' in window;

  if (isGooglePlacesAvailable) {
    return (
      <Autocomplete
        apiKey={GOOGLE_MAPS_API_KEY}
        onPlaceSelected={(place) => {
          if (place.formatted_address) {
            onChange(place.formatted_address);
          }
        }}
        options={{
          types: ['address'],
          componentRestrictions: { country: ['nz', 'au', 'gb', 'us', 'ca'] }, // Common countries for catteries
        }}
        defaultValue={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`flex h-12 w-full rounded-xl border border-input bg-white px-3 py-2 text-lg ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
        id={id}
      />
    );
  }

  // Fallback to regular input with browser autocomplete
  return (
    <Input
      ref={inputRef}
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className={className}
      id={id}
      autoComplete="street-address"
    />
  );
}
