import { RouterProvider } from 'react-router';
import { router } from './routes';

// CatStays Multi-tenant SaaS Platform - Main App Entry Point
function App() {
  return <RouterProvider router={router} />;
}

export default App;