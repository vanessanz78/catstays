# Petstays Onboarding Flow

## Overview
The new onboarding experience allows users to **preview their website before subscribing**, following a Shopify/Squarespace-style guided setup.

## 8-Step Onboarding Process

### Step 1: Create Account ✅
- Business name input
- Email and password
- Subdomain selection (e.g., `deloraine.petstays.nz`)
- Shows preview URL: `preview.petstays.nz/deloraine`

### Step 2: Import Existing Website (Optional) ✅
- User can paste their current website URL
- AI extracts:
  - Logo and branding
  - Color scheme
  - Typography
  - Images and photos
  - Page content
- Can skip to use luxury template

### Step 3: Brand Customization ✅
**With Live Preview Panel**
- Color pickers:
  - Primary color (#7DAF7B default)
  - Accent color (#E9C46A default)
- Typography selection:
  - Playfair Display (Elegant serif)
  - Inter (Modern sans)
  - Nunito (Friendly sans)
  - Poppins (Clean sans)
- File uploads:
  - Logo (PNG/SVG)
  - Hero image
  - Room photos
- **Live preview updates in real-time** as user changes colors/fonts

### Step 4: Website Preview Mode ✅
- Generate preview version of website
- Preview URL: `preview.petstays.nz/businessname`
- Shows:
  - Full website with user's branding
  - Sample booking flow
  - Preview banner on all pages
  - "Subscribe to Publish" CTA
- Preview expires in 7 days if not activated

### Step 5: Business Setup ✅
Configure operational details:
- **Rooms:**
  - Private rooms
  - Indoor rooms
  - Communal capacity
- **Pricing:**
  - 1 cat per day
  - 2 cats sharing
  - 3 cats sharing
  - Deposit amount
- **Operating Hours:**
  - Morning session (check-in/out window)
  - Afternoon session
- **Cleaning buffer** (hours between bookings)

### Step 6: Booking System Preview ✅
Interactive previews of:
- **Customer Booking Flow** (clickable demo)
- **Admin Dashboard** (daily operations)
- **Calendar & Room Planner** (visual scheduling)
- All open in new tabs for exploration

### Step 7: Subscribe ✅
**Stripe Checkout Integration**
- Price: **$49/month**
- Features included:
  - Custom website at subdomain
  - Online booking with payments
  - Mobile admin dashboard
  - Calendar & room planner
  - Automated messaging
  - Business analytics
  - Unlimited bookings
- Stripe payment form (card details)
- "Subscribe & Publish" button

### Step 8: Publish Website ✅
**Success & Activation**
- Payment confirmation
- Website goes live at: `businessname.petstays.nz`
- Admin dashboard activated
- Next steps guidance:
  1. Explore admin dashboard
  2. Add room photos
  3. Share booking link

## Key Features

### Preview Mode
- Clear separation between preview and live
- Yellow banner on preview sites
- "Subscribe to Publish" CTA throughout
- 7-day expiration timer

### Live Preview Panel
- Real-time updates during brand customization
- Shows actual website appearance
- Browser chrome UI for context
- Live indicator badge

### Progress Tracking
- Step counter (e.g., "Step 3 of 8")
- Progress bar with percentage
- Back/Continue navigation

### User Experience
- Friendly, guided flow
- Visual feedback throughout
- Mobile-responsive design
- Nature-inspired aesthetics (soft greens, creams, rose)
- Luxury cat boarding brand feel

## Technical Implementation

### Components Created
1. **OnboardingWizard.tsx** - Main 8-step wizard
2. **LivePreview.tsx** - Real-time website preview component
3. **PreviewBanner.tsx** - Yellow preview mode banner

### Integration Points
- Stripe: `@stripe/stripe-js`, `@stripe/react-stripe-js`
- Color pickers: Native HTML5 color input
- File uploads: Mock implementation (ready for real backend)
- Route: `/onboarding`

### State Management
- All form data stored in single state object
- Persists across steps
- Real-time preview updates via props

## Preview vs Live States

| Feature | Preview Mode | Live Mode |
|---------|-------------|-----------|
| URL | `preview.petstays.nz/name` | `name.petstays.nz` |
| Banner | Yellow "Preview Mode" | None |
| Bookings | Demo only | Fully functional |
| Admin | View only | Full access |
| Duration | 7 days | Unlimited (while subscribed) |
| Cost | Free | $49/month |

## Next Steps for Production

1. **Stripe Integration:**
   - Add real Stripe publishable key
   - Implement server-side payment processing
   - Handle webhooks for subscription events

2. **File Uploads:**
   - Connect to Supabase Storage
   - Image optimization pipeline
   - CDN delivery

3. **AI Website Import:**
   - Implement web scraping
   - Extract colors, fonts, images
   - Parse content structure

4. **Preview Expiration:**
   - 7-day timer implementation
   - Email reminders
   - Automatic cleanup

5. **Domain Publishing:**
   - DNS configuration
   - SSL certificate provisioning
   - Subdomain routing

## User Journey Example

```
User starts onboarding
  ↓
Creates account → deloraine.petstays.nz
  ↓
Skips website import (uses template)
  ↓
Customizes brand:
  - Primary: #7DAF7B
  - Accent: #E9C46A
  - Font: Playfair Display
  - Uploads logo & hero image
  ↓
Sees LIVE PREVIEW updating in real-time
  ↓
Views preview at preview.petstays.nz/deloraine
  ↓
Configures business (17 rooms, $30/day pricing)
  ↓
Tests booking flow & admin dashboard
  ↓
Subscribes for $49/month via Stripe
  ↓
Website goes LIVE at deloraine.petstays.nz
  ↓
Accesses admin dashboard to manage bookings
```

## Design Philosophy

Following Shopify/Squarespace principles:
- ✅ Show, don't tell (live previews)
- ✅ Incremental commitment (preview before paying)
- ✅ Clear progress indication
- ✅ Beautiful, calming aesthetics
- ✅ Mobile-first responsive design
- ✅ Guided, friendly tone
- ✅ Quick time-to-value

---

**Status:** ✅ Complete and ready for testing
**Route:** `/onboarding`
**Dependencies:** Stripe, date-fns (already installed)
