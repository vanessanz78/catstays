
  # CatStays 19 Mar

  This is a code bundle for CatStays 19 Mar. The original project is available at https://www.figma.com/design/HVQkrEeefgWtrwOLIArv9a/CatStays-19-Mar.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  