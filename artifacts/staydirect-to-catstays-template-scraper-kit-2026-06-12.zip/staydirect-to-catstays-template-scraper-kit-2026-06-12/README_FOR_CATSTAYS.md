# StayDirect To Catstays Template And Scraper Kit

Prepared: 2026-06-12

This bundle contains the StayDirect preview-template and scraper source files that can be adapted into Catstays for cat accommodation rendering pages.

## What Is Included

The main files are under `staydirect-source/` and keep their original StayDirect paths.

Copy-ready starting points:

- `api-server/src/preview.ts`: lightweight preview API with `/api/health`, `/api/scrape`, and `/api/export-image`.
- `src/pages/GeneratedPreviewPage.tsx`: URL input, importer call, initial one-page preview, and the four-style selector.
- `src/pages/WebsiteOptionsPage.tsx`: full template renderer and preview option pages.
- `src/lib/websiteDesignOptions.ts`: template metadata and colour choices.
- `src/lib/previewSessions.ts`: optional Supabase persistence for preview sessions and layout payloads.
- `src/lib/api.ts`: same-origin API URL helper.

The three redesign templates Vanessa asked for are:

- `modern-showcase`: photo-first, visual showcase layout.
- `conversion-focus`: booking/action-first layout with stronger conversion framing.
- `editorial-guide`: story-led editorial layout.

The original/source template is also present in the source files as `source-match`, but Catstays can omit it if the Catstays flow only needs the three new render styles.

## Scraper/API Summary

`api-server/src/preview.ts` is the important scraper file.

It provides:

- `GET /api/health`: confirms the preview API is reachable.
- `GET /api/scrape?url=...`: server-side public URL importer.
- `GET /api/export-image?url=...`: image proxy/export helper for public image URLs.

The scraper:

- Runs server-side to avoid browser CORS problems.
- Accepts public `http` and `https` URLs only.
- Fetches HTML with a browser-like user agent.
- Reads JSON-LD lodging data where available.
- Reads Open Graph and Twitter metadata.
- Collects useful public images from the HTML.
- Includes Airbnb-specific extraction for Next.js/deferred state, host profile, description, reviews, ratings, and images.
- Returns a normalized property-style payload.

For Catstays, adapt the output language from accommodation/stay/guest to cattery/cat owner/cat where appropriate. Keep date fields and booking concepts if Catstays uses boarding dates.

## Template Data Flow

The core flow is:

1. User pastes a URL.
2. Front end calls `/api/scrape?url=...`.
3. Scraped data is saved in browser storage and optionally Supabase `preview_sessions`.
4. `GeneratedPreviewPage` shows the initial preview and template cards.
5. `WebsiteOptionsPage` renders full template previews.
6. Signup/provisioning carries `selectedTemplate` through to the saved site theme.

The key template functions are in `src/pages/WebsiteOptionsPage.tsx`:

- `contentFromImport`
- `FullTemplateSite`
- `ModernShowcaseSite`
- `ConversionSite`
- `EditorialSite`
- `TemplatePreviewPage`

## Catstays Adaptation Checklist

Before copying into Catstays source:

- Replace `StayDirect` branding with `Catstays`.
- Replace `staydirect_*` storage keys with `catstays_*`.
- Replace Deloraine demo fallback with a Catstays/cattery demo fixture.
- Decide whether Catstays needs `source-match`; if not, keep only the three redesign template IDs.
- Adapt labels:
  - `property` -> `cattery` or `cat stay`
  - `guest` -> `cat owner`
  - `guests` -> `cats`
  - `bedrooms`/`bathrooms` -> Catstays-specific capacity/facility fields
  - `amenities` -> cattery facilities/services
- Keep scraper requests server-side.
- If Catstays uses Supabase preview persistence, create or reuse a `preview_sessions`-style table with `url`, `scraped_data`, `layout_previews`, `selected_template`, `created_at`, and optionally `status`.
- If Catstays is local-only at first, `localStorage`/`sessionStorage` preview data is enough.
- Keep Replit/deployment tests separate from local tests; StayDirect had local scraper success while public production still needed deployment verification.

## Runtime Dependencies

The copied code expects:

- React
- React Router
- lucide-react
- Tailwind-style utility classes
- Node 20 or equivalent server runtime with `fetch` and `AbortSignal.timeout`
- Supabase only if using `previewSessions.ts`

If Catstays has different UI primitives, use the template renderer as reference and swap buttons/nav/chat widgets for Catstays equivalents.

## Heavy Reference File

`api-server/src/app.ts` is included as reference only. It contains much more than preview importing. The relevant sections are the selected-template and provisioning logic around:

- `TEMPLATE_TO_DASHBOARD_THEME`
- `TEMPLATE_ACCENTS`
- `provisionPreviewMatchesBody`
- `selectedProvisionTemplate`
- `previewDataForProvision`
- `handleProvision`

Do not blindly copy the full file into Catstays unless Catstays is intentionally adopting the broader StayDirect API surface.
