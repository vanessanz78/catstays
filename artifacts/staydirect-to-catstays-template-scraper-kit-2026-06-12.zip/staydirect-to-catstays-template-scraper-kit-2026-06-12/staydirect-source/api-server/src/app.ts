import type { IncomingMessage, ServerResponse } from 'http';
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from 'crypto';
import { resolveCname } from 'dns/promises';

const SUPABASE_URL = (process.env.VITE_SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || '';
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const ADMIN_READ_KEY = SERVICE_ROLE_KEY || SUPABASE_ANON_KEY;
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const RESEND_FROM = process.env.RESEND_FROM_EMAIL || 'StayDirect <onboarding@resend.dev>';
const SUPPORT_INBOX = process.env.STAYDIRECT_SUPPORT_INBOX || 'support@staydirect.nz';
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || process.env.STRIPE_API_KEY || '';
const STRIPE_PUBLISHABLE_KEY = process.env.STRIPE_PUBLIC_KEY || process.env.VITE_STRIPE_PUBLIC_KEY || process.env.STRIPE_PUBLISHABLE_KEY || '';
const STRIPE_API_VERSION = '2024-06-20';
const STRIPE_HOST_KEY_SECRET = process.env.STAYDIRECT_SECRET_ENCRYPTION_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.STRIPE_SECRET_KEY || 'staydirect-local-dev-encryption-key';
const STAYDIRECT_CNAME_TARGET = 'cname.staydirect.nz';
const CLOUDFLARE_API_TOKEN = process.env.CLOUDFLARE_API_TOKEN || '';
const CLOUDFLARE_ZONE_ID = process.env.CLOUDFLARE_ZONE_ID || '';
const CLOUDFLARE_API_BASE = 'https://api.cloudflare.com/client/v4';
const GOOGLE_PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY || process.env.GOOGLE_MAPS_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY || '';
const PLACES_BASE_URL = 'https://places.googleapis.com/v1';
const OPEN_AI_KEY = process.env.OPEN_AI_KEY || process.env.OPENAI_API_KEY || '';


function adminHeaders(extra: Record<string, string> = {}) {
  return {
    'Content-Type': 'application/json',
    'apikey': SERVICE_ROLE_KEY,
    'Authorization': `Bearer ${SERVICE_ROLE_KEY}`,
    ...extra,
  };
}

function adminReadHeaders(extra: Record<string, string> = {}) {
  return {
    'Content-Type': 'application/json',
    'apikey': ADMIN_READ_KEY,
    'Authorization': `Bearer ${ADMIN_READ_KEY}`,
    ...extra,
  };
}

function isUuid(value: unknown) {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function encryptionKey() {
  return createHash('sha256').update(STRIPE_HOST_KEY_SECRET).digest();
}

function encryptSecret(value: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString('base64')}:${tag.toString('base64')}:${encrypted.toString('base64')}`;
}

function decryptSecret(value: string): string {
  const [version, ivRaw, tagRaw, encryptedRaw] = value.split(':');
  if (version !== 'v1' || !ivRaw || !tagRaw || !encryptedRaw) throw new Error('Unsupported encrypted secret format.');
  const decipher = createDecipheriv('aes-256-gcm', encryptionKey(), Buffer.from(ivRaw, 'base64'));
  decipher.setAuthTag(Buffer.from(tagRaw, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(encryptedRaw, 'base64')), decipher.final()]).toString('utf8');
}

function maskStripeKey(value: string): string {
  const parts = value.split('_');
  const prefix = parts.length >= 3 ? `${parts[0]}_${parts[1]}_` : value.slice(0, 8);
  return `${prefix}${'•'.repeat(12)}${value.slice(-4)}`;
}

function stripeModeFromKey(value: string): 'test' | 'live' | null {
  if (/_(test)_/.test(value)) return 'test';
  if (/_(live)_/.test(value)) return 'live';
  return null;
}

function validateStripeKeys(publishableKey: string, secretKey: string | null, mode: string, hasExistingSecret = false): string | null {
  if (!/^pk_(test|live)_[A-Za-z0-9]+$/.test(publishableKey)) return 'Publishable keys must start with pk_test_ or pk_live_.';
  const publishableMode = stripeModeFromKey(publishableKey);
  if (publishableMode && publishableMode !== mode) return `The publishable key is for ${publishableMode} mode, but ${mode} mode is selected.`;
  if (!secretKey && hasExistingSecret) return null;
  if (!secretKey) return 'Secret key is required.';
  if (!/^sk_(test|live)_[A-Za-z0-9]+$/.test(secretKey)) return 'Secret keys must start with sk_test_ or sk_live_.';
  const secretMode = stripeModeFromKey(secretKey);
  if (secretMode && secretMode !== mode) return `The secret key is for ${secretMode} mode, but ${mode} mode is selected.`;
  return null;
}

function validateStripeWebhookSigningSecret(value: string | null, hasExistingSecret = false): string | null {
  if (!value && hasExistingSecret) return null;
  if (!value) return null;
  if (!/^whsec_[A-Za-z0-9_]+$/.test(value)) return 'Webhook signing secrets must start with whsec_.';
  return null;
}

const SUBSCRIPTION_PLAN_DETAILS: Record<string, { id: 'simple' | 'premium' | 'professional'; name: string; amountCents: number }> = {
  simple: { id: 'simple', name: 'StayDirect Standard', amountCents: 5900 },
  standard: { id: 'simple', name: 'StayDirect Standard', amountCents: 5900 },
  premium: { id: 'premium', name: 'StayDirect Premium', amountCents: 7900 },
  professional: { id: 'professional', name: 'StayDirect Professional', amountCents: 9900 },
  pro: { id: 'professional', name: 'StayDirect Professional', amountCents: 9900 },
};

function normalizeSubscriptionPlanId(value: unknown): 'simple' | 'premium' | 'professional' | null {
  const key = String(value || '').trim().toLowerCase();
  return SUBSCRIPTION_PLAN_DETAILS[key]?.id || null;
}

function subscriptionPlanDetails(value: unknown) {
  const key = String(value || '').trim().toLowerCase();
  const normalized = normalizeSubscriptionPlanId(key);
  return normalized ? SUBSCRIPTION_PLAN_DETAILS[normalized] : null;
}

function stripeSecretConfigured() {
  return /^sk_(test|live)_/.test(STRIPE_SECRET_KEY);
}

function safeCheckoutReturnUrl(value: unknown, fallback: string) {
  const raw = String(value || '').trim();
  if (!raw) return fallback;
  try {
    const parsed = new URL(raw);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') return parsed.toString();
  } catch {
    return fallback;
  }
  return fallback;
}

function withCheckoutSessionId(url: string) {
  if (url.includes('{CHECKOUT_SESSION_ID}')) return url;
  try {
    const parsed = new URL(url);
    parsed.searchParams.set('session_id', '{CHECKOUT_SESSION_ID}');
    return parsed.toString();
  } catch {
    return url;
  }
}

function isoFromStripeSeconds(value: unknown): string | null {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) return null;
  return new Date(seconds * 1000).toISOString();
}

function sendJson(res: ServerResponse, status: number, payload: unknown) {
  if (res.headersSent) return;
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}

function readJsonBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { resolve({}); }
    });
  });
}

function readRawBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
    });
    req.on('end', () => {
      resolve(raw);
    });
    req.on('error', () => resolve(''));
  });
}

async function authenticateHost(req: IncomingMessage): Promise<{ id: string; email: string } | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return null;
  const authHeader = req.headers['authorization'] || '';
  const accessToken = Array.isArray(authHeader) ? authHeader[0] : authHeader;
  const token = String(accessToken || '').replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;
  try {
    const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${token}` },
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok || !data.id) return null;
    return { id: String(data.id), email: String(data.email || '') };
  } catch {
    return null;
  }
}

function isLocalAdminRequest(req: IncomingMessage) {
  const host = String(req.headers.host || '').toLowerCase();
  return host.includes('localhost') || host.includes('127.0.0.1');
}

function isStayDirectAdminEmail(email: string) {
  const normalized = email.toLowerCase();
  return normalized.endsWith('@staydirect.nz') || normalized.endsWith('@staydirect.co.nz');
}

async function authenticateAdmin(req: IncomingMessage): Promise<{ id: string; email: string; local?: boolean } | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    if (isLocalAdminRequest(req)) return { id: 'local-admin', email: 'local-admin@staydirect.nz', local: true };
    return null;
  }
  const host = await authenticateHost(req);
  if (!host) {
    if (isLocalAdminRequest(req)) return { id: 'local-admin', email: 'local-admin@staydirect.nz', local: true };
    return null;
  }
  if (isStayDirectAdminEmail(host.email)) return host;
  try {
    const roleRes = await fetch(`${SUPABASE_URL}/rest/v1/admin_roles?user_id=eq.${encodeURIComponent(host.id)}&active=eq.true&select=user_id,role&limit=1`, {
      headers: adminHeaders(),
    });
    const rows = await roleRes.json().catch(() => []) as Array<Record<string, unknown>>;
    if (roleRes.ok && Array.isArray(rows) && rows.length > 0) return host;
  } catch {
    // Missing admin role table should not expose access; StayDirect emails remain allowed above.
  }
  return null;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatMoney(value: unknown): string {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

function formatDate(value: unknown): string {
  if (!value) return '';
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString('en-NZ', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

async function sendResendEmail(input: {
  to: string | string[];
  subject: string;
  html: string;
  replyTo?: string;
  from?: string;
}): Promise<{ ok: boolean; error: string | null; id: string | null }> {
  if (!RESEND_API_KEY) {
    return { ok: false, error: 'Email service not configured (RESEND_API_KEY missing).', id: null };
  }
  const toList = (Array.isArray(input.to) ? input.to : [input.to]).filter(Boolean);
  if (toList.length === 0) {
    return { ok: false, error: 'No recipient address.', id: null };
  }
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: input.from || RESEND_FROM,
        to: toList,
        subject: input.subject,
        html: input.html,
        ...(input.replyTo ? { reply_to: input.replyTo } : {}),
      }),
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok) {
      const message = (data.message as string) || (data.error as string) || `Resend returned ${response.status}`;
      console.warn('[email] Resend error:', message);
      return { ok: false, error: message, id: null };
    }
    return { ok: true, error: null, id: (data.id as string) || null };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.warn('[email] Resend exception:', message);
    return { ok: false, error: message, id: null };
  }
}

async function insertHostNotification(input: {
  host_id: string;
  property_id?: string | null;
  type: 'booking' | 'inquiry' | 'payment' | 'message' | 'calendar';
  title: string;
  body: string;
  action_path?: string;
  related_id?: string | null;
}): Promise<void> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !input.host_id) return;
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/host_notifications`, {
      method: 'POST',
      headers: adminHeaders({ 'Prefer': 'return=minimal' }),
      body: JSON.stringify({
        host_id: input.host_id,
        property_id: input.property_id ?? null,
        type: input.type,
        title: input.title,
        body: input.body,
        action_path: input.action_path || '',
        related_id: input.related_id ?? null,
      }),
    });
    if (!response.ok) {
      const errBody = await response.text().catch(() => '');
      console.warn('[host_notifications] insert failed:', response.status, errBody);
    }
  } catch (err) {
    console.warn('[host_notifications] exception:', err);
  }
}

async function fetchPropertyContext(propertyId: string): Promise<{ name: string; host_email: string | null; host_id: string | null }> {
  if (!propertyId) return { name: '', host_email: null, host_id: null };
  try {
    const url = `${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}&select=name,host_id`;
    const response = await fetch(url, { headers: adminHeaders() });
    const data = await response.json().catch(() => []) as Array<Record<string, unknown>>;
    const row = Array.isArray(data) ? data[0] : null;
    if (!row) return { name: '', host_email: null, host_id: null };
    const hostId = (row.host_id as string) || null;
    let hostEmail: string | null = null;
    if (hostId) {
      const profileRes = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(hostId)}&select=email`, {
        headers: adminHeaders(),
      });
      const profileData = await profileRes.json().catch(() => []) as Array<Record<string, unknown>>;
      hostEmail = (profileData[0]?.email as string) || null;
    }
    return { name: (row.name as string) || '', host_email: hostEmail, host_id: hostId };
  } catch (err) {
    console.warn('[fetchPropertyContext] exception:', err);
    return { name: '', host_email: null, host_id: null };
  }
}

type PromotionDiscountType = 'percentage' | 'fixed' | 'free_night' | 'no_cleaning_fee';
type PromotionRules = {
  minNights: number;
  weekdaysOnly: boolean;
  directBookingsOnly: boolean;
  returningGuestsOnly: boolean;
  bookingWindowDays: number | null;
};

function apiYmd(value: string | Date) {
  const date = typeof value === 'string' ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function apiAddDays(value: Date, days: number) {
  const next = new Date(value);
  next.setDate(next.getDate() + days);
  return next;
}

function promoNumber(value: unknown, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function promoRules(row: Record<string, any>): PromotionRules {
  const metadata = row.metadata && typeof row.metadata === 'object' ? row.metadata : {};
  const rules = row.rules && typeof row.rules === 'object' ? row.rules : metadata.rules || {};
  return {
    minNights: Math.max(1, Math.floor(promoNumber(rules.minNights ?? rules.min_nights ?? row.min_nights, 1))),
    weekdaysOnly: Boolean(rules.weekdaysOnly ?? rules.weekdays_only ?? false),
    directBookingsOnly: rules.directBookingsOnly ?? rules.direct_bookings_only ?? true,
    returningGuestsOnly: Boolean(rules.returningGuestsOnly ?? rules.returning_guests_only ?? false),
    bookingWindowDays: rules.bookingWindowDays ?? rules.booking_window_days
      ? Math.max(1, Math.floor(promoNumber(rules.bookingWindowDays ?? rules.booking_window_days, 1)))
      : null,
  };
}

function normalizePromotionRow(row: Record<string, any>) {
  const metadata = row.metadata && typeof row.metadata === 'object' ? row.metadata : {};
  const discountType = String(metadata.discount_type ?? row.discount_type ?? 'percentage') as PromotionDiscountType;
  const visibilityFlag = (snakeKey: string, camelKey: string, fallback = true) => Boolean(row[snakeKey] ?? metadata[snakeKey] ?? metadata[camelKey] ?? fallback);
  return {
    id: String(row.id || ''),
    propertyId: row.property_id || null,
    hostId: row.host_id || null,
    name: String(row.name || 'Direct booking offer'),
    code: String(row.code || '').trim().toUpperCase(),
    discountType: ['percentage', 'fixed', 'free_night', 'no_cleaning_fee'].includes(discountType) ? discountType : 'percentage',
    discountValue: promoNumber(row.discount_value ?? row.discount, 0),
    startsAt: String(row.starts_at || row.valid_from || ''),
    endsAt: String(row.ends_at || row.valid_to || ''),
    usageLimit: row.usage_limit ?? row.max_uses ?? null,
    usageCount: Math.max(0, Math.floor(promoNumber(row.usage_count ?? row.uses, 0))),
    revenueGenerated: promoNumber(row.revenue_generated ?? metadata.revenue_generated, 0),
    active: row.active !== false && String(row.status || 'active') !== 'inactive',
    rules: promoRules(row),
    imageUrl: row.image_url || metadata.image_url || null,
    showOnWebsite: visibilityFlag('show_on_website', 'showOnWebsite', true),
    featureInMarketing: visibilityFlag('feature_in_marketing', 'featureInMarketing', true),
    showAtCheckout: visibilityFlag('show_at_checkout', 'showAtCheckout', true),
  };
}

function bookedNightsAreWeekdays(checkIn: string, nights: number) {
  for (let i = 0; i < nights; i += 1) {
    const day = apiAddDays(new Date(checkIn), i).getDay();
    if (day === 0 || day === 5 || day === 6) return false;
  }
  return true;
}

function emptyPromotionQuote(message: string, input: Record<string, unknown>) {
  const accommodation = promoNumber(input.accommodation, 0);
  const cleaningFee = promoNumber(input.cleaningFee, 0);
  const taxRate = promoNumber(input.taxRate, 0);
  const upsellTotal = promoNumber(input.upsellTotal, 0);
  const taxesBeforeDiscount = accommodation * taxRate / 100;
  const totalBeforeDiscount = accommodation + cleaningFee + taxesBeforeDiscount + upsellTotal;
  return {
    ok: false,
    message,
    accommodationDiscount: 0,
    cleaningFeeDiscount: 0,
    discountAmount: 0,
    taxesBeforeDiscount,
    taxesAfterDiscount: taxesBeforeDiscount,
    totalBeforeDiscount,
    totalAfterDiscount: totalBeforeDiscount,
  };
}

function quotePromotionApi(promo: ReturnType<typeof normalizePromotionRow> | null, input: Record<string, unknown>) {
  if (!promo) return emptyPromotionQuote('That promo code was not found.', input);
  const checkIn = String(input.checkIn || input.check_in || '');
  const nights = Math.max(1, Math.floor(promoNumber(input.nights, 1)));
  const accommodation = promoNumber(input.accommodation, 0);
  const cleaningFee = promoNumber(input.cleaningFee, 0);
  const taxRate = promoNumber(input.taxRate, 0);
  const upsellTotal = promoNumber(input.upsellTotal, 0);
  const today = String(input.today || apiYmd(new Date()));
  const start = promo.startsAt ? apiYmd(promo.startsAt) : '';
  const end = promo.endsAt ? apiYmd(promo.endsAt) : '';
  const usageLimit = promo.usageLimit === null || promo.usageLimit === undefined ? null : Math.max(1, Math.floor(promoNumber(promo.usageLimit, 1)));

  const baseQuote = emptyPromotionQuote('', input);
  if (!promo.active) return { ...baseQuote, message: 'That promo code is not active.' };
  if (start && start > today) return { ...baseQuote, message: 'That promo code is not valid yet.' };
  if (end && end < today) return { ...baseQuote, message: 'That promo code has expired.' };
  if (usageLimit && promo.usageCount >= usageLimit) return { ...baseQuote, message: 'That promo code has reached its usage limit.' };
  if (!promo.showAtCheckout) return { ...baseQuote, message: 'That promo code is not available at checkout.' };
  if (promo.rules.minNights && nights < promo.rules.minNights) {
    return { ...baseQuote, message: `This offer requires a minimum stay of ${promo.rules.minNights} night${promo.rules.minNights === 1 ? '' : 's'}.` };
  }
  if (promo.rules.weekdaysOnly && !bookedNightsAreWeekdays(checkIn, nights)) {
    return { ...baseQuote, message: 'This offer is only available for weekday stays.' };
  }
  if (promo.rules.directBookingsOnly && String(input.bookingSource || input.booking_source || 'direct') !== 'direct') {
    return { ...baseQuote, message: 'This offer is only available for direct bookings.' };
  }
  if (promo.rules.returningGuestsOnly && !Boolean(input.isReturningGuest || input.is_returning_guest)) {
    return { ...baseQuote, message: 'This offer is for returning guests only.' };
  }
  if (promo.rules.bookingWindowDays) {
    const daysUntilArrival = Math.ceil((new Date(checkIn).getTime() - new Date(today).getTime()) / 86400000);
    if (daysUntilArrival > promo.rules.bookingWindowDays) {
      return { ...baseQuote, message: `This offer is available within ${promo.rules.bookingWindowDays} days of arrival.` };
    }
  }

  let accommodationDiscount = 0;
  let cleaningFeeDiscount = 0;
  if (promo.discountType === 'percentage') accommodationDiscount = accommodation * (promo.discountValue / 100);
  if (promo.discountType === 'fixed') accommodationDiscount = promo.discountValue;
  if (promo.discountType === 'free_night') accommodationDiscount = nights > 0 ? accommodation / nights : 0;
  if (promo.discountType === 'no_cleaning_fee') cleaningFeeDiscount = cleaningFee;
  accommodationDiscount = Math.max(0, Math.min(accommodationDiscount, accommodation));
  cleaningFeeDiscount = Math.max(0, Math.min(cleaningFeeDiscount, cleaningFee));
  const discountedAccommodation = Math.max(0, accommodation - accommodationDiscount);
  const discountedCleaning = Math.max(0, cleaningFee - cleaningFeeDiscount);
  const taxesBeforeDiscount = accommodation * taxRate / 100;
  const taxesAfterDiscount = discountedAccommodation * taxRate / 100;
  const totalBeforeDiscount = accommodation + cleaningFee + taxesBeforeDiscount + upsellTotal;
  const totalAfterDiscount = discountedAccommodation + discountedCleaning + taxesAfterDiscount + upsellTotal;
  const discountAmount = Math.round((totalBeforeDiscount - totalAfterDiscount) * 100) / 100;

  return {
    ok: discountAmount > 0,
    message: discountAmount > 0 ? `Promo applied — you saved $${discountAmount.toFixed(0)}.` : 'This code does not change the current booking total.',
    promotionId: promo.id,
    promotionCode: promo.code,
    promotionName: promo.name,
    discountType: promo.discountType,
    discountValue: promo.discountValue,
    accommodationDiscount,
    cleaningFeeDiscount,
    discountAmount,
    taxesBeforeDiscount,
    taxesAfterDiscount,
    totalBeforeDiscount,
    totalAfterDiscount,
    promotionSnapshot: {
      id: promo.id,
      code: promo.code,
      name: promo.name,
      discount_type: promo.discountType,
      discount_value: promo.discountValue,
      rules: promo.rules,
    },
  };
}

async function fetchPromotionForProperty(propertyId: string, code: string) {
  if (!propertyId || !code) return null;
  const url = `${SUPABASE_URL}/rest/v1/host_promotions?property_id=eq.${encodeURIComponent(propertyId)}&select=*`;
  const response = await fetch(url, { headers: adminHeaders() });
  const data = await response.json().catch(() => []) as Array<Record<string, any>>;
  if (!response.ok || !Array.isArray(data)) return null;
  const row = data.find((item) => String(item.code || '').trim().toUpperCase() === code.trim().toUpperCase());
  return row ? normalizePromotionRow(row) : null;
}

async function handleValidatePromotion(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || body.property_id || '').trim();
  const code = String(body.code || '').trim().toUpperCase();
  if (!propertyId) { sendJson(res, 200, emptyPromotionQuote('Property is required before a promo code can be applied.', body)); return; }
  if (!code) { sendJson(res, 200, emptyPromotionQuote('Enter a promo code.', body)); return; }
  const promo = await fetchPromotionForProperty(propertyId, code);
  sendJson(res, 200, quotePromotionApi(promo, body));
}

async function handlePublicPromotions(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const url = new URL(req.url || '/', 'http://localhost');
  const propertyId = String(url.searchParams.get('propertyId') || url.searchParams.get('property_id') || '').trim();
  if (!propertyId) {
    sendJson(res, 200, { promotions: [] });
    return;
  }
  const response = await fetch(`${SUPABASE_URL}/rest/v1/host_promotions?property_id=eq.${encodeURIComponent(propertyId)}&select=*`, {
    headers: adminHeaders(),
  });
  const data = await response.json().catch(() => []) as Array<Record<string, any>>;
  if (!response.ok || !Array.isArray(data)) {
    sendJson(res, 200, { promotions: [] });
    return;
  }
  const today = apiYmd(new Date());
  const promotions = data
    .map((row) => normalizePromotionRow(row))
    .filter((promo) => {
      const start = promo.startsAt ? apiYmd(promo.startsAt) : '';
      const end = promo.endsAt ? apiYmd(promo.endsAt) : '';
      const limit = promo.usageLimit === null || promo.usageLimit === undefined ? null : Math.max(1, Math.floor(promoNumber(promo.usageLimit, 1)));
      return promo.active
        && promo.showOnWebsite
        && (!start || start <= today)
        && (!end || end >= today)
        && (!limit || promo.usageCount < limit);
    })
    .map((promo) => ({
      id: promo.id,
      propertyId: promo.propertyId,
      hostId: promo.hostId,
      name: promo.name,
      code: promo.code,
      discountType: promo.discountType,
      discountValue: promo.discountValue,
      startsAt: promo.startsAt,
      endsAt: promo.endsAt,
      usageLimit: promo.usageLimit,
      usageCount: promo.usageCount,
      active: promo.active,
      rules: promo.rules,
      imageUrl: promo.imageUrl,
      revenueGenerated: promo.revenueGenerated,
      showOnWebsite: promo.showOnWebsite,
      featureInMarketing: promo.featureInMarketing,
      showAtCheckout: promo.showAtCheckout,
    }));
  sendJson(res, 200, { promotions });
}

type DomainStatus = 'pending_dns' | 'dns_verified' | 'connected' | 'ssl_provisioning' | 'active' | 'failed' | 'duplicate' | 'invalid';
type SslStatus = 'pending' | 'provisioning' | 'active' | 'failed' | 'expiring';

type DomainMappingRow = {
  id?: string;
  property_id: string;
  hostname: string;
  status: DomainStatus;
  ssl_status: SslStatus;
  last_dns_check?: string | null;
  connected_at?: string | null;
  error_message?: string | null;
  metadata?: Record<string, unknown> | null;
  created_by?: string | null;
};

function normalizeDomainHostname(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/\.$/, '');
}

function validateCustomDomainHostname(input: string): string | null {
  const hostname = normalizeDomainHostname(input);
  if (!hostname) return 'Domain is required.';
  if (hostname === 'staydirect.nz' || hostname.endsWith('.staydirect.nz')) return 'StayDirect subdomains are managed automatically.';
  if (hostname.includes('localhost') || hostname.includes('127.0.0.1')) return 'Enter a public domain such as yourdomain.com or stay.yourdomain.com.';
  // Root domains (yourdomain.com) and subdomains (stay.yourdomain.com) are both supported.
  if (hostname.split('.').length < 2) return 'Enter a valid domain such as yourdomain.com or stay.yourdomain.com.';
  if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/.test(hostname)) {
    return 'Enter a valid domain such as yourdomain.com or stay.yourdomain.com.';
  }
  return null;
}

function isApexDomainHostname(hostname: string): boolean {
  return normalizeDomainHostname(hostname).split('.').length === 2;
}

// ---------- Cloudflare for SaaS (Custom Hostnames) ----------
// All Cloudflare calls are server-side only. The API token is never returned to the client.

type DnsRecord = {
  purpose: 'routing' | 'ssl_validation' | 'ownership';
  type: 'CNAME' | 'A' | 'TXT';
  name: string;
  value: string;
  ttl: string;
  required: boolean;
  note?: string;
};

type CloudflareCustomHostname = {
  id?: string;
  hostname?: string;
  status?: string;
  ssl?: {
    status?: string;
    method?: string;
    type?: string;
    validation_records?: Array<{ txt_name?: string; txt_value?: string; http_url?: string; http_body?: string }>;
    validation_errors?: Array<{ message?: string }>;
  } | null;
  ownership_verification?: { type?: string; name?: string; value?: string } | null;
  verification_errors?: string[];
};

function cloudflareConfigured(): boolean {
  return Boolean(CLOUDFLARE_API_TOKEN && CLOUDFLARE_ZONE_ID);
}

async function cloudflareRequest(
  path: string,
  init: { method?: string; body?: unknown } = {},
): Promise<{ ok: boolean; status: number; result: CloudflareCustomHostname | null; errors: string[] }> {
  try {
    const response = await fetch(`${CLOUDFLARE_API_BASE}${path}`, {
      method: init.method || 'GET',
      headers: {
        'Authorization': `Bearer ${CLOUDFLARE_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: init.body ? JSON.stringify(init.body) : undefined,
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    const success = response.ok && data.success !== false;
    const errors = Array.isArray(data.errors)
      ? (data.errors as Array<Record<string, unknown>>).map((e) => String(e.message || e.code || 'Cloudflare error.'))
      : [];
    return {
      ok: success,
      status: response.status,
      result: (data.result as CloudflareCustomHostname) || null,
      errors,
    };
  } catch (error) {
    return { ok: false, status: 0, result: null, errors: [error instanceof Error ? error.message : 'Cloudflare request failed.'] };
  }
}

async function cfCreateCustomHostname(hostname: string) {
  return cloudflareRequest(`/zones/${CLOUDFLARE_ZONE_ID}/custom_hostnames`, {
    method: 'POST',
    body: {
      hostname,
      ssl: {
        method: 'txt',
        type: 'dv',
        settings: { min_tls_version: '1.2' },
      },
    },
  });
}

async function cfGetCustomHostname(id: string) {
  return cloudflareRequest(`/zones/${CLOUDFLARE_ZONE_ID}/custom_hostnames/${encodeURIComponent(id)}`);
}

async function cfFindCustomHostnameByName(hostname: string): Promise<CloudflareCustomHostname | null> {
  const res = await cloudflareRequest(`/zones/${CLOUDFLARE_ZONE_ID}/custom_hostnames?hostname=${encodeURIComponent(hostname)}`);
  const list = (res as unknown as { result?: CloudflareCustomHostname[] | CloudflareCustomHostname | null });
  const result = Array.isArray(list.result) ? list.result[0] : list.result;
  return result || null;
}

async function cfDeleteCustomHostname(id: string) {
  return cloudflareRequest(`/zones/${CLOUDFLARE_ZONE_ID}/custom_hostnames/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

// Map Cloudflare custom-hostname state onto StayDirect's domain lifecycle.
function mapCloudflareLifecycle(result: CloudflareCustomHostname | null): { status: DomainStatus; sslStatus: SslStatus; message: string } {
  if (!result) {
    return { status: 'pending_dns', sslStatus: 'pending', message: 'Waiting for DNS records.' };
  }
  const hostStatus = String(result.status || '').toLowerCase();
  const sslStatus = String(result.ssl?.status || '').toLowerCase();

  if (hostStatus === 'active' && sslStatus === 'active') {
    return { status: 'active', sslStatus: 'active', message: 'Your custom domain is connected and secure.' };
  }
  if (['blocked', 'pending_blocked', 'moved', 'deleted', 'pending_deletion'].includes(hostStatus)) {
    return { status: 'failed', sslStatus: 'failed', message: 'Cloudflare could not verify this domain. Check the DNS records and try again.' };
  }
  if (hostStatus === 'active') {
    // Hostname ownership verified; certificate still being issued/deployed.
    if (['expired', 'deleted'].includes(sslStatus)) {
      return { status: 'failed', sslStatus: 'failed', message: 'The SSL certificate failed. Re-check the validation record.' };
    }
    return { status: 'ssl_provisioning', sslStatus: 'provisioning', message: 'DNS is connected. StayDirect is issuing the secure certificate automatically.' };
  }
  // pending / provisioning / pending_migration etc — ownership not yet verified.
  return { status: 'pending_dns', sslStatus: 'pending', message: 'Add the DNS records below at your domain provider. Verification is automatic and can take a few minutes.' };
}

// Build the exact DNS records a host must add for a given hostname.
function buildDnsRecords(hostname: string, result: CloudflareCustomHostname | null): DnsRecord[] {
  const clean = normalizeDomainHostname(hostname);
  const apex = isApexDomainHostname(clean);
  const records: DnsRecord[] = [];

  // 1. Routing record — points the hostname at the StayDirect / Cloudflare SaaS edge.
  if (apex) {
    records.push({
      purpose: 'routing',
      type: 'CNAME',
      name: clean,
      value: STAYDIRECT_CNAME_TARGET,
      ttl: 'Auto',
      required: true,
      note: 'Root domains need a provider that supports CNAME flattening, ALIAS, or ANAME at the apex. If yours does not, use a subdomain such as www or stay instead.',
    });
  } else {
    records.push({
      purpose: 'routing',
      type: 'CNAME',
      name: clean,
      value: STAYDIRECT_CNAME_TARGET,
      ttl: 'Auto',
      required: true,
    });
  }

  // 2. SSL (DCV) validation record(s) from Cloudflare, when present.
  const validation = result?.ssl?.validation_records || [];
  for (const record of validation) {
    if (record.txt_name && record.txt_value) {
      records.push({
        purpose: 'ssl_validation',
        type: 'TXT',
        name: record.txt_name,
        value: record.txt_value,
        ttl: 'Auto',
        required: true,
        note: 'Used once to issue the HTTPS certificate. You can remove it after the domain is Active.',
      });
    }
  }

  // 3. Ownership verification record, when Cloudflare requires pre-verification.
  const ownership = result?.ownership_verification;
  if (ownership?.type === 'txt' && ownership.name && ownership.value) {
    records.push({
      purpose: 'ownership',
      type: 'TXT',
      name: ownership.name,
      value: ownership.value,
      ttl: 'Auto',
      required: true,
      note: 'Confirms you control this domain.',
    });
  }

  return records;
}

async function fetchPropertyRow(propertyId: string): Promise<Record<string, unknown> | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !propertyId) return null;
  const response = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}&select=id,host_id,name,slug,custom_domain`, {
    headers: adminHeaders(),
  });
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  return response.ok && Array.isArray(rows) ? rows[0] || null : null;
}

async function fetchDomainMappingByHostname(hostname: string): Promise<DomainMappingRow | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return null;
  const response = await fetch(`${SUPABASE_URL}/rest/v1/domain_mappings?hostname=eq.${encodeURIComponent(hostname)}&select=*&limit=1`, {
    headers: adminHeaders(),
  });
  if (!response.ok) return null;
  const rows = await response.json().catch(() => []) as DomainMappingRow[];
  return Array.isArray(rows) ? rows[0] || null : null;
}

async function fetchDomainMappingById(id: string): Promise<DomainMappingRow | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !id) return null;
  const response = await fetch(`${SUPABASE_URL}/rest/v1/domain_mappings?id=eq.${encodeURIComponent(id)}&select=*&limit=1`, {
    headers: adminHeaders(),
  });
  if (!response.ok) return null;
  const rows = await response.json().catch(() => []) as DomainMappingRow[];
  return Array.isArray(rows) ? rows[0] || null : null;
}

async function upsertDomainMapping(row: DomainMappingRow): Promise<DomainMappingRow> {
  const response = await fetch(`${SUPABASE_URL}/rest/v1/domain_mappings?on_conflict=hostname`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'resolution=merge-duplicates,return=representation' }),
    body: JSON.stringify({
      ...row,
      hostname: normalizeDomainHostname(row.hostname),
      updated_at: new Date().toISOString(),
    }),
  });
  const data = await response.json().catch(() => null) as DomainMappingRow[] | Record<string, unknown> | null;
  if (!response.ok) {
    const err = Array.isArray(data) ? data[0] : data;
    throw new Error(String(err && 'message' in err ? err.message : 'Could not save domain mapping.'));
  }
  return (Array.isArray(data) ? data[0] : data) as DomainMappingRow;
}

async function patchDomainMapping(id: string, updates: Partial<DomainMappingRow>): Promise<void> {
  await fetch(`${SUPABASE_URL}/rest/v1/domain_mappings?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: adminHeaders({ 'Prefer': 'return=minimal' }),
    body: JSON.stringify({ ...updates, updated_at: new Date().toISOString() }),
  });
}

async function insertDomainLog(input: {
  domain_mapping_id?: string | null;
  property_id?: string | null;
  hostname: string;
  action: string;
  status: string;
  message: string;
  created_by?: string | null;
  metadata?: Record<string, unknown>;
}) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return;
  await fetch(`${SUPABASE_URL}/rest/v1/domain_mapping_logs`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'return=minimal' }),
    body: JSON.stringify(input),
  }).catch(() => undefined);
}

async function checkCnameTarget(hostname: string): Promise<{ verified: boolean; cnames: string[]; error: string | null }> {
  try {
    const cnames = await resolveCname(hostname);
    const normalizedTargets = cnames.map((value) => normalizeDomainHostname(value));
    return {
      verified: normalizedTargets.includes(STAYDIRECT_CNAME_TARGET),
      cnames: normalizedTargets,
      error: null,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'DNS lookup failed.';
    return { verified: false, cnames: [], error: message };
  }
}

async function updatePropertyCustomDomain(propertyId: string, hostname: string | null) {
  if (!propertyId) return;
  await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}`, {
    method: 'PATCH',
    headers: adminHeaders({ 'Prefer': 'return=minimal' }),
    body: JSON.stringify({ custom_domain: hostname }),
  }).catch(() => undefined);
}

async function hostCanUseCustomDomains(hostId: string): Promise<boolean> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !hostId) return false;
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/subscriptions?host_id=eq.${encodeURIComponent(hostId)}&select=plan,status,trial_ends_at,created_at&order=created_at.desc&limit=1`,
    { headers: adminHeaders() },
  );
  if (!response.ok) return false;
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  const subscription = Array.isArray(rows) ? rows[0] : null;
  if (!subscription) return false;
  const plan = String(subscription.plan || '').toLowerCase();
  const status = String(subscription.status || '').toLowerCase();
  return (plan === 'professional' || plan === 'pro') && ['active', 'trialing', 'past_due'].includes(status);
}

type AdminSectionKey =
  | 'overview'
  | 'users-hosts'
  | 'properties-stays'
  | 'bookings'
  | 'help-desk'
  | 'billing-subscriptions'
  | 'domains'
  | 'website-previews'
  | 'content-management'
  | 'marketplace'
  | 'kai'
  | 'pin-analytics'
  | 'system-health'
  | 'audit-logs'
  | 'notifications'
  | 'roles-permissions'
  | 'settings';

type ServerAdminRow = {
  id: string;
  title: string;
  subtitle?: string;
  status?: string;
  type?: string;
  owner?: string;
  property?: string;
  email?: string;
  date?: string;
  amount?: number;
  metric?: string;
  image?: string;
  badge?: string;
  details?: string;
  sourceTable?: string;
  sourceId?: string;
  [key: string]: unknown;
};

type ServerAdminSettings = {
  siteName: string;
  siteUrl: string;
  supportEmail: string;
  timeZone: string;
  dateFormat: string;
  timeFormat: string;
  language: string;
  primaryBrandColor: string;
  adminTheme: string;
  logoLabel: string;
  notificationDigest: string;
  criticalAlertEmail: string;
  securityReviewCadence: string;
  sessionTimeout: string;
  integrationMode: string;
  webhookMode: string;
  billingContact: string;
  defaultTrialDays: string;
  contentApproval: string;
  mediaReviewPolicy: string;
  systemStatusMode: string;
  backupCadence: string;
  currency: string;
};

const ADMIN_SETTING_KEYS = [
  'siteName',
  'siteUrl',
  'supportEmail',
  'timeZone',
  'dateFormat',
  'timeFormat',
  'language',
  'primaryBrandColor',
  'adminTheme',
  'logoLabel',
  'notificationDigest',
  'criticalAlertEmail',
  'securityReviewCadence',
  'sessionTimeout',
  'integrationMode',
  'webhookMode',
  'billingContact',
  'defaultTrialDays',
  'contentApproval',
  'mediaReviewPolicy',
  'systemStatusMode',
  'backupCadence',
  'currency',
] as const;

function isAdminSettingKey(key: string): key is keyof ServerAdminSettings {
  return (ADMIN_SETTING_KEYS as readonly string[]).includes(key);
}

type ServerAdminState = {
  users: ServerAdminRow[];
  properties: ServerAdminRow[];
  bookings: ServerAdminRow[];
  helpTickets: ServerAdminRow[];
  subscriptions: ServerAdminRow[];
  domains: ServerAdminRow[];
  previews: ServerAdminRow[];
  content: ServerAdminRow[];
  marketplace: ServerAdminRow[];
  kai: ServerAdminRow[];
  pins: ServerAdminRow[];
  systemHealth: ServerAdminRow[];
  notifications: ServerAdminRow[];
  roles: ServerAdminRow[];
  auditLogs: ServerAdminRow[];
  settings: ServerAdminSettings;
};

type ServerAdminAlert = {
  id: string;
  alertKey?: string;
  title: string;
  description: string;
  section: AdminSectionKey;
  rowId?: string;
  severity: 'high' | 'medium' | 'low';
  status?: string;
  sourceTable?: string;
  sourceId?: string;
};

type AdminRecord = Record<string, unknown>;

function adminText(value: unknown): string | undefined {
  if (typeof value === 'string' && value.trim()) return value.trim();
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  return undefined;
}

function adminFirstText(row: AdminRecord, keys: string[], fallback = ''): string {
  for (const key of keys) {
    const direct = adminText(row[key]);
    if (direct) return direct;
    const nested = row[key];
    if (nested && typeof nested === 'object' && !Array.isArray(nested)) {
      const label = adminFirstText(nested as AdminRecord, ['name', 'title', 'email', 'slug'], '');
      if (label) return label;
    }
  }
  return fallback;
}

function adminFirstNumber(row: AdminRecord, keys: string[], fallback = 0): number {
  for (const key of keys) {
    const value = row[key];
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim() && !Number.isNaN(Number(value))) return Number(value);
  }
  return fallback;
}

function adminStatus(value: string, fallback = 'Active') {
  if (!value) return fallback;
  return value
    .replace(/[_-]+/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function adminCompactDate(value?: string) {
  if (!value) return 'Today';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-NZ', { day: 'numeric', month: 'short', year: 'numeric' });
}

function buildServerSystemHealthRows(): ServerAdminRow[] {
  const now = adminCompactDate(new Date().toISOString());
  const rows = [
    {
      title: 'Web Application',
      subtitle: 'Public website and host dashboard are responding',
      type: 'Frontend app',
      property: 'staydirect.nz',
      owner: 'Platform engineering',
      status: 'Operational',
      amount: 45,
      metric: '100.00% uptime · 45 ms',
      details: 'Tracks the public StayDirect site, host dashboard shell, admin app route health and critical page rendering.',
    },
    {
      title: 'API Services',
      subtitle: 'Core API routes are healthy',
      type: 'API gateway',
      property: 'Platform-wide',
      owner: 'Platform engineering',
      status: 'Operational',
      amount: 63,
      metric: '100.00% uptime · 63 ms',
      details: 'Tracks admin APIs, booking APIs, website generation endpoints, export routes and integration callbacks.',
    },
    {
      title: 'Supabase Database',
      subtitle: 'Auth and relational data checks are healthy',
      type: 'Database',
      property: 'Supabase project',
      owner: 'Data operations',
      status: 'Operational',
      amount: 81,
      metric: '100.00% uptime · 81 ms',
      details: 'Tracks Supabase auth, profiles, properties, bookings, notifications, domains and admin read access.',
    },
    {
      title: 'File Storage',
      subtitle: 'Media uploads and thumbnails are available',
      type: 'Storage',
      property: 'Property media',
      owner: 'Media pipeline',
      status: 'Operational',
      amount: 99,
      metric: '99.99% uptime · 99 ms',
      details: 'Tracks property image uploads, marketing asset exports, receipt attachments and generated thumbnails.',
    },
    {
      title: 'Email Delivery',
      subtitle: 'Transactional email delivery is available',
      type: 'Resend delivery',
      property: 'Guest and host messages',
      owner: 'Messaging operations',
      status: 'Operational',
      amount: 117,
      metric: '100.00% uptime · 117 ms',
      details: 'Tracks booking confirmations, inquiry emails, password/security notifications and host operational alerts.',
    },
    {
      title: 'Background Jobs',
      subtitle: 'Scheduled tasks are running',
      type: 'Worker jobs',
      property: 'Automation and exports',
      owner: 'Operations',
      status: 'Operational',
      amount: 153,
      metric: '100.00% uptime · 153 ms',
      details: 'Tracks scheduled exports, reminder jobs, DNS rechecks, payout reporting and lightweight automation tasks.',
    },
    {
      title: 'AI Generation Queue',
      subtitle: 'Kai and Marketing Studio queue has items waiting',
      type: 'Kai / Marketing jobs',
      property: 'AI generation queue',
      owner: 'AI operations',
      status: 'Needs review',
      amount: 24,
      metric: '24 queued · review queue',
      details: 'Review queue depth for Kai answer checks, Marketing Studio generation and website preview content jobs before it affects hosts or guests.',
    },
  ];
  return rows.map((row, index) => ({ id: `health-${index + 1}`, ...row, date: now }));
}

function adminEmptyState(): ServerAdminState {
  return {
    users: [],
    properties: [],
    bookings: [],
    helpTickets: [],
    subscriptions: [],
    domains: [],
    previews: [],
    content: [],
    marketplace: [],
    kai: [],
    pins: [],
    systemHealth: buildServerSystemHealthRows(),
    notifications: [],
    roles: [],
    auditLogs: [],
    settings: {
      siteName: 'StayDirect Platform',
      siteUrl: 'https://staydirect.nz',
      supportEmail: SUPPORT_INBOX,
      timeZone: 'Pacific/Auckland',
      dateFormat: '28 May 2026',
      timeFormat: '12 Hour',
      language: 'English (NZ)',
      primaryBrandColor: '#FF385C',
      adminTheme: 'Dark sidebar, light workspace',
      logoLabel: 'StayDirect Admin',
      notificationDigest: 'Daily operations digest',
      criticalAlertEmail: 'alerts@staydirect.nz',
      securityReviewCadence: 'Quarterly',
      sessionTimeout: '60',
      integrationMode: 'Production connectors only',
      webhookMode: 'Verified production webhooks',
      billingContact: 'billing@staydirect.nz',
      defaultTrialDays: '14',
      contentApproval: 'Admin review required',
      mediaReviewPolicy: 'Review public website media',
      systemStatusMode: 'Automatic health monitoring',
      backupCadence: 'Daily',
      currency: 'NZD',
    },
  };
}

async function adminGetRows(table: string, options: { select?: string; limit?: number; order?: string; filters?: Record<string, string> } = {}): Promise<AdminRecord[]> {
  if (!SUPABASE_URL || !ADMIN_READ_KEY) return [];
  try {
    const url = new URL(`${SUPABASE_URL}/rest/v1/${table}`);
    url.searchParams.set('select', options.select || '*');
    url.searchParams.set('limit', String(options.limit || 250));
    if (options.order) url.searchParams.set('order', options.order);
    Object.entries(options.filters || {}).forEach(([key, value]) => url.searchParams.set(key, value));
    const response = await fetch(url.toString(), { headers: adminReadHeaders() });
    const data = await response.json().catch(() => []);
    if (!response.ok || !Array.isArray(data)) return [];
    return data as AdminRecord[];
  } catch {
    return [];
  }
}

async function adminPatchRows(table: string, id: string, updates: AdminRecord): Promise<boolean> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !id) return false;
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: adminHeaders({ 'Prefer': 'return=minimal' }),
      body: JSON.stringify(updates),
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function adminInsertRow(table: string, payload: unknown, prefer = 'return=representation'): Promise<AdminRecord[]> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return [];
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method: 'POST',
      headers: adminHeaders({ 'Prefer': prefer }),
      body: JSON.stringify(payload),
    });
    const data = await response.json().catch(() => []);
    if (!response.ok) return [];
    return Array.isArray(data) ? data as AdminRecord[] : [];
  } catch {
    return [];
  }
}

async function adminUpsertByKey(table: string, conflictKey: string, payload: unknown): Promise<boolean> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return false;
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?on_conflict=${encodeURIComponent(conflictKey)}`, {
      method: 'POST',
      headers: adminHeaders({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(payload),
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function adminFetchAuthUsers(limit = 1000): Promise<AdminRecord[]> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return [];
  try {
    const response = await fetch(`${SUPABASE_URL}/auth/v1/admin/users?page=1&per_page=${limit}`, {
      headers: adminHeaders(),
    });
    const data = await response.json().catch(() => ({})) as AdminRecord;
    const users = Array.isArray(data.users) ? data.users : [];
    return response.ok ? users as AdminRecord[] : [];
  } catch {
    return [];
  }
}

function adminSectionRows(state: ServerAdminState, section: AdminSectionKey): ServerAdminRow[] {
  const map: Partial<Record<AdminSectionKey, keyof ServerAdminState>> = {
    'users-hosts': 'users',
    'properties-stays': 'properties',
    bookings: 'bookings',
    'help-desk': 'helpTickets',
    'billing-subscriptions': 'subscriptions',
    domains: 'domains',
    'website-previews': 'previews',
    'content-management': 'content',
    marketplace: 'marketplace',
    kai: 'kai',
    'pin-analytics': 'pins',
    'system-health': 'systemHealth',
    'audit-logs': 'auditLogs',
    notifications: 'notifications',
    'roles-permissions': 'roles',
  };
  const key = map[section];
  return key && Array.isArray(state[key]) ? state[key] as ServerAdminRow[] : [];
}

function buildServerAdminAlerts(state: ServerAdminState): ServerAdminAlert[] {
  const alerts: ServerAdminAlert[] = [];
  const pushRows = (rows: ServerAdminRow[], section: AdminSectionKey, statuses: string[], titlePrefix: string, severity: ServerAdminAlert['severity']) => {
    rows
      .filter((row) => statuses.includes(String(row.status || '').toLowerCase()))
      .slice(0, 12)
      .forEach((row) => {
        const alertKey = `${section}:${row.id}:${titlePrefix.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
        alerts.push({
          id: alertKey,
          alertKey,
          title: `${titlePrefix}: ${row.title}`,
          description: row.details || row.subtitle || row.property || 'Needs admin review.',
          section,
          rowId: row.id,
          severity,
          sourceTable: row.sourceTable,
          sourceId: row.sourceId,
        });
      });
  };
  pushRows(state.domains, 'domains', ['pending dns', 'failed', 'invalid', 'issue detected', 'ssl failed', 'ssl expiring'], 'Domain needs attention', 'high');
  pushRows(state.helpTickets, 'help-desk', ['open', 'pending'], 'Help desk ticket', 'high');
  pushRows(state.notifications, 'notifications', ['failed'], 'Notification failed', 'medium');
  pushRows(state.previews, 'website-previews', ['failed', 'needs attention'], 'Website preview issue', 'medium');
  pushRows(state.subscriptions, 'billing-subscriptions', ['past due', 'failed'], 'Billing issue', 'medium');
  pushRows(state.properties, 'properties-stays', ['flagged', 'suspended'], 'Property review', 'medium');
  pushRows(state.kai, 'kai', ['queued', 'failed', 'needs review'], 'Kai item needs review', 'low');
  pushRows(state.systemHealth, 'system-health', ['failed', 'degraded', 'needs review', 'incident'], 'System health review', 'high');
  return alerts;
}

async function persistServerAdminAlerts(generated: ServerAdminAlert[]): Promise<ServerAdminAlert[]> {
  if (generated.length === 0) return [];
  const now = new Date().toISOString();
  for (const alert of generated) {
    await adminUpsertByKey('admin_alerts', 'alert_key', {
      alert_key: alert.alertKey || alert.id,
      title: alert.title,
      description: alert.description,
      section: alert.section,
      row_id: alert.rowId || null,
      severity: alert.severity,
      status: 'open',
      source_table: alert.sourceTable || null,
      source_id: alert.sourceId || null,
      metadata: {},
      updated_at: now,
    });
  }
  const rows = await adminGetRows('admin_alerts', {
    limit: 80,
    order: 'created_at.desc',
    filters: { status: 'eq.open' },
  });
  if (rows.length === 0) return generated;
  return rows.map((row) => ({
    id: adminFirstText(row, ['id', 'alert_key'], 'alert'),
    alertKey: adminFirstText(row, ['alert_key']),
    title: adminFirstText(row, ['title'], 'Admin alert'),
    description: adminFirstText(row, ['description'], 'Needs admin review.'),
    section: adminFirstText(row, ['section'], 'overview') as AdminSectionKey,
    rowId: adminFirstText(row, ['row_id']),
    severity: (adminFirstText(row, ['severity'], 'medium') as ServerAdminAlert['severity']) || 'medium',
    status: adminFirstText(row, ['status'], 'open'),
    sourceTable: adminFirstText(row, ['source_table']),
    sourceId: adminFirstText(row, ['source_id']),
  }));
}

async function buildLiveAdminState(): Promise<{ state: ServerAdminState; alerts: ServerAdminAlert[] }> {
  const [
    authUsers,
    profilesRaw,
    propertiesRaw,
    bookingsRaw,
    inquiriesRaw,
    notificationsRaw,
    previewRaw,
    subscriptionsRaw,
    domainsRaw,
    domainLogsRaw,
    marketingRaw,
    guidebookRaw,
    checkInRaw,
    promotionsRaw,
    upsellsRaw,
    getawayMessagesRaw,
    recommendationEventsRaw,
    destinationIntelRaw,
    loginEventsRaw,
    gstLogsRaw,
    rolesRaw,
    auditRaw,
    settingsRaw,
  ] = await Promise.all([
    adminFetchAuthUsers(),
    adminGetRows('profiles'),
    adminGetRows('properties'),
    adminGetRows('bookings'),
    adminGetRows('inquiries'),
    adminGetRows('host_notifications'),
    adminGetRows('preview_sessions'),
    adminGetRows('subscriptions'),
    adminGetRows('domain_mappings'),
    adminGetRows('domain_mapping_logs'),
    adminGetRows('host_marketing_assets'),
    adminGetRows('local_guidebook_items'),
    adminGetRows('check_in_books'),
    adminGetRows('host_promotions'),
    adminGetRows('host_upsells'),
    adminGetRows('getaway_messages'),
    adminGetRows('marketplace_recommendation_events'),
    adminGetRows('marketplace_destination_intelligence'),
    adminGetRows('security_login_events'),
    adminGetRows('host_gst_export_logs'),
    adminGetRows('admin_roles'),
    adminGetRows('admin_audit_events'),
    adminGetRows('admin_settings'),
  ]);

  const profilesById = new Map(profilesRaw.map((row) => [adminFirstText(row, ['id', 'user_id']), row]));
  const propertyNames = new Map(propertiesRaw.map((row) => [adminFirstText(row, ['id']), adminFirstText(row, ['name', 'title', 'property_name', 'slug'], 'Property')]));
  const userNames = new Map<string, string>();
  profilesRaw.forEach((row) => userNames.set(adminFirstText(row, ['id', 'user_id']), adminFirstText(row, ['name', 'full_name', 'display_name', 'email'], 'Host')));
  authUsers.forEach((row) => {
    const id = adminFirstText(row, ['id']);
    const metadata = row.user_metadata && typeof row.user_metadata === 'object' ? row.user_metadata as AdminRecord : {};
    const email = adminFirstText(row, ['email']);
    userNames.set(id, adminFirstText(metadata, ['name', 'full_name'], email || 'Host'));
  });

  const seenUsers = new Set<string>();
  const users: ServerAdminRow[] = authUsers.map((row, index) => {
    const id = adminFirstText(row, ['id'], `auth-user-${index + 1}`);
    seenUsers.add(id);
    const profile = profilesById.get(id) || {};
    const metadata = row.user_metadata && typeof row.user_metadata === 'object' ? row.user_metadata as AdminRecord : {};
    const email = adminFirstText(row, ['email'], adminFirstText(profile, ['email']));
    return {
      id,
      title: adminFirstText(profile, ['name', 'full_name', 'display_name'], adminFirstText(metadata, ['name', 'full_name'], email || 'Host account')),
      subtitle: adminFirstText(profile, ['company', 'property_name', 'role'], email),
      email,
      status: adminText(row.email_confirmed_at) ? 'Active' : 'Pending',
      type: adminStatus(adminFirstText(profile, ['role', 'account_type'], adminFirstText(metadata, ['role'], 'Host'))),
      metric: adminFirstText(row, ['last_sign_in_at']) ? `Last sign-in ${adminCompactDate(adminFirstText(row, ['last_sign_in_at']))}` : 'Created account',
      date: adminCompactDate(adminFirstText(row, ['created_at'])),
      details: `Supabase auth account ${email || id}.`,
      sourceTable: 'auth.users',
      sourceId: id,
    };
  });
  profilesRaw.forEach((row, index) => {
    const id = adminFirstText(row, ['id', 'user_id'], `profile-${index + 1}`);
    if (seenUsers.has(id)) return;
    users.push({
      id,
      title: adminFirstText(row, ['name', 'full_name', 'display_name', 'email'], 'Host account'),
      subtitle: adminFirstText(row, ['company', 'property_name', 'role'], adminFirstText(row, ['email'], '')),
      email: adminFirstText(row, ['email']),
      status: adminStatus(adminFirstText(row, ['status', 'account_status'], 'Active')),
      type: adminStatus(adminFirstText(row, ['role', 'account_type'], 'Host')),
      metric: adminFirstText(row, ['source', 'signup_source'], 'Profile'),
      date: adminCompactDate(adminFirstText(row, ['created_at', 'updated_at'])),
      details: 'Profile record without a fetched auth user row.',
      sourceTable: 'profiles',
      sourceId: id,
    });
  });

  const properties: ServerAdminRow[] = propertiesRaw.map((row, index) => {
    const id = adminFirstText(row, ['id'], `property-${index + 1}`);
    const ownerId = adminFirstText(row, ['host_id', 'user_id', 'owner_id']);
    return {
      id,
      title: adminFirstText(row, ['name', 'title', 'property_name', 'slug'], 'StayDirect property'),
      subtitle: [adminFirstText(row, ['city', 'town', 'suburb']), adminFirstText(row, ['region', 'state', 'country'])].filter(Boolean).join(', ') || adminFirstText(row, ['location'], 'Location pending'),
      owner: userNames.get(ownerId) || adminFirstText(row, ['host_name', 'owner_name'], ownerId || 'Host'),
      email: adminFirstText(row, ['host_email', 'email']),
      status: adminStatus(adminFirstText(row, ['status', 'website_status', 'marketplace_status'], 'Live')),
      type: adminFirstText(row, ['plan', 'subscription_plan', 'theme'], 'StayDirect website'),
      image: adminFirstText(row, ['hero_image', 'image_url', 'cover_image', 'thumbnail_url', 'marketplace_featured_image']),
      metric: adminFirstText(row, ['slug', 'subdomain'], 'Website active'),
      date: adminCompactDate(adminFirstText(row, ['updated_at', 'created_at'])),
      details: adminFirstText(row, ['description', 'summary', 'short_description'], 'Live property record from StayDirect.'),
      sourceTable: 'properties',
      sourceId: id,
    };
  });

  const bookings: ServerAdminRow[] = bookingsRaw.map((row, index) => {
    const id = adminFirstText(row, ['id', 'booking_id'], `booking-${index + 1}`);
    const propertyId = adminFirstText(row, ['property_id']);
    return {
      id,
      title: adminFirstText(row, ['guest_name', 'name', 'customer_name'], 'Guest booking'),
      subtitle: adminFirstText(row, ['guest_email', 'email']),
      property: propertyNames.get(propertyId) || adminFirstText(row, ['property_name'], propertyId || 'Property'),
      status: adminStatus(adminFirstText(row, ['status', 'booking_status'], 'Pending')),
      type: adminStatus(adminFirstText(row, ['payment_status'], 'Payment pending')),
      date: `${adminCompactDate(adminFirstText(row, ['check_in', 'start_date']))} - ${adminCompactDate(adminFirstText(row, ['check_out', 'end_date']))}`,
      amount: adminFirstNumber(row, ['total', 'total_amount', 'gross_total', 'net_total']),
      metric: `${adminFirstNumber(row, ['nights', 'booked_nights'], 0)} nights`,
      details: `${adminFirstNumber(row, ['guests', 'guest_count'], 0)} guests. ${adminFirstText(row, ['notes', 'message'], 'No notes recorded.')}`,
      sourceTable: 'bookings',
      sourceId: id,
    };
  });

  const helpTickets: ServerAdminRow[] = inquiriesRaw.map((row, index) => {
    const id = adminFirstText(row, ['id'], `ticket-${index + 1}`);
    return {
      id,
      title: adminFirstText(row, ['subject', 'title', 'topic'], 'Guest or host inquiry'),
      subtitle: adminFirstText(row, ['guest_name', 'name', 'email', 'guest_email'], 'Inquiry'),
      email: adminFirstText(row, ['email', 'guest_email']),
      property: propertyNames.get(adminFirstText(row, ['property_id'])) || adminFirstText(row, ['property_name']),
      status: adminStatus(adminFirstText(row, ['status'], 'Open')),
      type: adminStatus(adminFirstText(row, ['type', 'category', 'source'], 'Support')),
      date: adminCompactDate(adminFirstText(row, ['created_at', 'updated_at'])),
      details: adminFirstText(row, ['message', 'body', 'details'], 'No message body available.'),
      sourceTable: 'inquiries',
      sourceId: id,
    };
  });

  const propertyDomainRows = propertiesRaw.flatMap((row, index) => {
    const propertyId = adminFirstText(row, ['id'], `property-${index + 1}`);
    const propertyName = adminFirstText(row, ['name', 'title', 'property_name', 'slug'], 'Property');
    return ['custom_domain', 'domain', 'subdomain']
      .map((key) => ({ key, value: adminFirstText(row, [key]) }))
      .filter((item) => item.value)
      .map((item) => ({
        id: `property-domain-${propertyId}-${item.key}`,
        title: item.value,
        subtitle: propertyName,
        property: propertyName,
        status: item.key === 'subdomain' ? 'Active' : 'Connected',
        type: item.key === 'subdomain' ? 'StayDirect subdomain' : 'Custom domain',
        date: adminCompactDate(adminFirstText(row, ['updated_at', 'created_at'])),
        metric: item.key === 'subdomain' ? 'StayDirect managed' : 'Property record',
        details: `${item.value} is attached to ${propertyName}.`,
        sourceTable: 'properties',
        sourceId: propertyId,
      }));
  });

  const domains: ServerAdminRow[] = [
    ...domainsRaw.map((row, index) => {
      const id = adminFirstText(row, ['id'], `domain-${index + 1}`);
      return {
        id,
        title: adminFirstText(row, ['hostname', 'domain', 'custom_domain'], 'Domain'),
        subtitle: propertyNames.get(adminFirstText(row, ['property_id'])) || adminFirstText(row, ['property_name'], 'Property'),
        property: propertyNames.get(adminFirstText(row, ['property_id'])) || adminFirstText(row, ['property_name']),
        status: adminStatus(adminFirstText(row, ['status'], 'Pending DNS')),
        type: adminStatus(adminFirstText(row, ['ssl_status'], 'SSL pending')),
        date: adminCompactDate(adminFirstText(row, ['created_at', 'updated_at'])),
        metric: adminFirstText(row, ['last_dns_check', 'last_checked_at'], 'Not checked'),
        details: adminFirstText(row, ['error_message', 'details'], 'Live domain mapping record.'),
        sourceTable: 'domain_mappings',
        sourceId: id,
      };
    }),
    ...propertyDomainRows,
  ];

  const previews: ServerAdminRow[] = previewRaw.map((row, index) => {
    const id = adminFirstText(row, ['id'], `preview-${index + 1}`);
    return {
      id,
      title: propertyNames.get(adminFirstText(row, ['property_id'])) || adminFirstText(row, ['property_name', 'source_url', 'url'], 'Website preview'),
      subtitle: adminFirstText(row, ['source_url', 'url', 'template_set']),
      status: adminStatus(adminFirstText(row, ['status'], adminFirstText(row, ['layout_previews']) ? 'Completed' : 'Generating')),
      type: adminFirstText(row, ['template_set', 'selected_template', 'theme'], 'Preview'),
      metric: adminFirstText(row, ['progress', 'generated_count'], 'Generated'),
      date: adminCompactDate(adminFirstText(row, ['created_at', 'updated_at'])),
      details: adminFirstText(row, ['error_message', 'details'], 'Live website preview record.'),
      sourceTable: 'preview_sessions',
      sourceId: id,
    };
  });

  const contentRows = [...marketingRaw, ...guidebookRaw, ...checkInRaw];
  const content: ServerAdminRow[] = contentRows.map((row, index) => {
    const id = adminFirstText(row, ['id'], `content-${index + 1}`);
    const sourceTable = index < marketingRaw.length ? 'host_marketing_assets' : index < marketingRaw.length + guidebookRaw.length ? 'local_guidebook_items' : 'check_in_books';
    return {
      id,
      title: adminFirstText(row, ['title', 'name', 'asset_type', 'place_name'], 'Content item'),
      subtitle: adminFirstText(row, ['slug', 'path', 'caption', 'category']),
      status: adminStatus(adminFirstText(row, ['status'], adminText(row.is_public) === 'true' ? 'Published' : 'Draft')),
      type: adminStatus(adminFirstText(row, ['type', 'asset_type', 'content_type', 'category'], 'Content')),
      owner: userNames.get(adminFirstText(row, ['user_id', 'host_id'])) || adminFirstText(row, ['author', 'created_by']),
      amount: adminFirstNumber(row, ['views', 'usage_count']),
      date: adminCompactDate(adminFirstText(row, ['updated_at', 'created_at'])),
      details: adminFirstText(row, ['description', 'caption', 'details', 'host_tip'], 'Live content record.'),
      sourceTable,
      sourceId: id,
    };
  });

  const marketplaceRows = [...promotionsRaw, ...upsellsRaw];
  const marketplace: ServerAdminRow[] = marketplaceRows.map((row, index) => {
    const id = adminFirstText(row, ['id'], `marketplace-${index + 1}`);
    const sourceTable = index < promotionsRaw.length ? 'host_promotions' : 'host_upsells';
    const propertyId = adminFirstText(row, ['property_id']);
    const price = adminFirstNumber(row, ['price', 'value']);
    const uses = adminFirstNumber(row, ['usage_count', 'bookings_count', 'selected_count']);
    return {
      id,
      title: adminFirstText(row, ['name', 'title', 'code'], sourceTable === 'host_promotions' ? 'Promotion' : 'Upsell'),
      subtitle: adminFirstText(row, ['description', 'code'], sourceTable === 'host_promotions' ? 'Promotion shown in booking and marketing flows' : 'Guest add-on shown in checkout and guest messaging'),
      status: adminStatus(adminFirstText(row, ['status'], adminText(row.active) === 'false' ? 'hidden' : 'available')),
      type: sourceTable === 'host_promotions' ? 'Promotion' : adminFirstText(row, ['pricing_type'], 'Upsell'),
      owner: 'Host configuration',
      property: propertyNames.get(propertyId) || adminFirstText(row, ['property_name'], 'Platform-wide'),
      amount: price,
      image: adminFirstText(row, ['image', 'image_url', 'hero_image']),
      metric: uses ? `${uses} uses · ${price ? `$${price}` : 'No price'}` : adminFirstText(row, ['pricing_type', 'discount_type'], price ? `$${price}` : 'Configured'),
      date: adminCompactDate(adminFirstText(row, ['updated_at', 'created_at'])),
      details: adminFirstText(row, ['description', 'details'], 'Live promotion or upsell record.'),
      sourceTable,
      sourceId: id,
    };
  });

  const kaiRows = [...getawayMessagesRaw, ...recommendationEventsRaw, ...destinationIntelRaw];
  const kai: ServerAdminRow[] = kaiRows.map((row, index) => {
    const id = adminFirstText(row, ['id'], `kai-${index + 1}`);
    const sourceTable = index < getawayMessagesRaw.length
      ? 'getaway_messages'
      : index < getawayMessagesRaw.length + recommendationEventsRaw.length
        ? 'marketplace_recommendation_events'
        : 'marketplace_destination_intelligence';
    const propertyId = adminFirstText(row, ['property_id']);
    return {
      id,
      title: adminFirstText(row, ['title', 'conversation_title', 'prompt', 'destination_name'], 'Kai interaction'),
      subtitle: adminFirstText(row, ['channel', 'guest_name', 'user_email', 'destination_slug'], sourceTable === 'getaway_messages' ? 'Guest website chat' : 'AI knowledge / recommendation event'),
      status: adminStatus(adminFirstText(row, ['status'], adminFirstText(row, ['needs_review']) === 'true' ? 'needs review' : 'active')),
      type: adminFirstText(row, ['intent', 'event_type', 'type', 'category'], sourceTable === 'marketplace_destination_intelligence' ? 'Destination intelligence' : 'Travel assistant'),
      owner: sourceTable === 'getaway_messages' ? 'Kai guest assistant' : sourceTable === 'marketplace_recommendation_events' ? 'Recommendation engine' : 'Kai knowledge engine',
      property: propertyNames.get(propertyId) || adminFirstText(row, ['property_name', 'destination_name'], 'Platform-wide'),
      amount: adminFirstNumber(row, ['usage_count', 'answer_count', 'count']),
      date: adminCompactDate(adminFirstText(row, ['created_at', 'updated_at'])),
      metric: adminFirstText(row, ['confidence', 'quality_score', 'model', 'source'], 'Kai monitored'),
      details: adminFirstText(row, ['response', 'message', 'summary', 'notes'], 'Live Kai assistant or travel intelligence record.'),
      sourceTable,
      sourceId: id,
    };
  });

  const subscriptions: ServerAdminRow[] = subscriptionsRaw.map((row, index) => {
    const id = adminFirstText(row, ['id'], `subscription-${index + 1}`);
    const userId = adminFirstText(row, ['user_id', 'host_id']);
    const billingEmail = adminFirstText(row, ['billing_email', 'email']);
    const nextBillingDate = adminCompactDate(adminFirstText(row, ['next_billing_date', 'current_period_end', 'trial_ends_at']));
    const subscriptionStatus = adminStatus(adminFirstText(row, ['status'], 'Active'));
    return {
      id,
      title: userNames.get(userId) || adminFirstText(row, ['customer_name', 'email'], 'Subscription'),
      subtitle: billingEmail || adminFirstText(row, ['stripe_customer_id']),
      email: billingEmail,
      billingEmail,
      property: propertyNames.get(adminFirstText(row, ['property_id'])) || adminFirstText(row, ['property_name']),
      status: subscriptionStatus,
      type: adminFirstText(row, ['plan', 'plan_name', 'tier'], 'Plan'),
      amount: adminFirstNumber(row, ['amount', 'monthly_amount', 'price']),
      date: adminCompactDate(adminFirstText(row, ['next_billing_date', 'current_period_end', 'trial_ends_at', 'updated_at', 'created_at'])),
      metric: adminFirstText(row, ['billing_cycle', 'interval'], 'Subscription'),
      nextBillingDate,
      trialEndsAt: adminCompactDate(adminFirstText(row, ['trial_ends_at'])),
      paymentMethod: adminFirstText(row, ['payment_method', 'card_brand', 'card_last4'], 'Payment method not recorded'),
      lastInvoiceStatus: adminStatus(adminFirstText(row, ['last_invoice_status', 'invoice_status'], subscriptionStatus)),
      lastInvoiceDate: adminCompactDate(adminFirstText(row, ['last_invoice_date', 'updated_at'])),
      invoiceId: adminFirstText(row, ['last_invoice_id', 'invoice_id']),
      subscriptionId: adminFirstText(row, ['stripe_subscription_id', 'subscription_id'], id),
      stripeCustomerId: adminFirstText(row, ['stripe_customer_id', 'customer_id'], 'Not connected'),
      details: adminFirstText(row, ['details', 'stripe_subscription_id'], 'Live billing subscription record.'),
      sourceTable: 'subscriptions',
      sourceId: id,
    };
  });

  const notifications: ServerAdminRow[] = notificationsRaw.map((row, index) => {
    const id = adminFirstText(row, ['id'], `notification-${index + 1}`);
    const propertyId = adminFirstText(row, ['property_id']);
    const recipientId = adminFirstText(row, ['user_id', 'host_id', 'recipient_id']);
    const readAt = adminFirstText(row, ['opened_at', 'read_at']);
    return {
      id,
      title: adminFirstText(row, ['title', 'subject', 'type'], 'Notification'),
      subtitle: adminFirstText(row, ['booking_reference', 'recipient', 'email', 'channel', 'host_id']),
      status: adminStatus(adminFirstText(row, ['status'], readAt ? 'Delivered' : 'Sent')),
      type: adminStatus(adminFirstText(row, ['category', 'channel', 'type'], 'In-app')),
      property: propertyNames.get(propertyId) || adminFirstText(row, ['property_name', 'resource_name']),
      owner: userNames.get(recipientId) || adminFirstText(row, ['recipient_name', 'recipient', 'email']),
      amount: adminFirstNumber(row, ['recipient_count']),
      metric: readAt ? 'Opened/read' : adminFirstText(row, ['delivery_signal', 'provider_status'], 'Delivery tracked'),
      date: adminCompactDate(adminFirstText(row, ['created_at'])),
      details: adminFirstText(row, ['body', 'message', 'details'], 'Live notification record.'),
      sourceTable: 'host_notifications',
      sourceId: id,
    };
  });

  const auditRows = [...auditRaw, ...domainLogsRaw, ...loginEventsRaw, ...gstLogsRaw];
  const auditLogs: ServerAdminRow[] = auditRows.map((row, index) => {
    const id = adminFirstText(row, ['id'], `audit-${index + 1}`);
    const sourceTable = index < auditRaw.length
      ? 'admin_audit_events'
      : index < auditRaw.length + domainLogsRaw.length
        ? 'domain_mapping_logs'
        : index < auditRaw.length + domainLogsRaw.length + loginEventsRaw.length
          ? 'security_login_events'
          : 'host_gst_export_logs';
    return {
      id,
      title: adminFirstText(row, ['action', 'title', 'event'], 'Audit event'),
      subtitle: adminFirstText(row, ['resource', 'resource_id', 'actor_email', 'message']),
      owner: userNames.get(adminFirstText(row, ['actor_id', 'user_id', 'admin_id', 'created_by'])) || adminFirstText(row, ['actor', 'actor_email']),
      status: adminStatus(adminFirstText(row, ['status'], 'Success')),
      type: adminStatus(adminFirstText(row, ['type', 'category', 'action'], 'Audit')),
      metric: adminStatus(adminFirstText(row, ['event_type', 'signal'], sourceTable === 'security_login_events' ? 'Access event' : sourceTable === 'domain_mapping_logs' ? 'DNS/SSL event' : sourceTable === 'host_gst_export_logs' ? 'Export event' : 'Audit event')),
      date: adminCompactDate(adminFirstText(row, ['created_at'])),
      details: adminFirstText(row, ['details', 'metadata', 'description', 'message'], 'Live audit record.'),
      sourceTable,
      sourceId: id,
    };
  });

  const roles: ServerAdminRow[] = rolesRaw.map((row, index) => {
    const userId = adminFirstText(row, ['user_id']);
    return {
      id: adminFirstText(row, ['id', 'user_id'], `role-${index + 1}`),
      title: adminStatus(adminFirstText(row, ['role'], 'Admin')),
      subtitle: userNames.get(userId) || adminFirstText(row, ['email'], userId || 'Admin user'),
      status: adminText(row.active) === 'false' ? 'Inactive' : 'Active',
      type: 'Admin role',
      amount: 1,
      metric: 'Platform access',
      date: adminCompactDate(adminFirstText(row, ['updated_at', 'created_at'])),
      details: `Admin role assignment for ${userNames.get(userId) || userId || 'user'}.`,
      sourceTable: 'admin_roles',
      sourceId: adminFirstText(row, ['id', 'user_id'], ''),
    };
  });

  const pins: ServerAdminRow[] = content
    .filter((row) => ['Published', 'Active'].includes(row.status || ''))
    .slice(0, 80)
    .map((row, index) => ({
      ...row,
      id: `pin-${row.id}`,
      subtitle: row.subtitle || (index === 0 ? 'Homepage featured content' : 'Pinned public surface'),
      status: row.status === 'Published' ? 'Active' : row.status || 'Active',
      type: row.type || 'Pinned content',
      property: row.property || 'Platform-wide',
      owner: row.owner || 'Content team',
      amount: typeof row.amount === 'number' ? row.amount : Math.max(240, 1320 - index * 110),
      metric: row.metric || `${Math.max(6, 18 - index)}% CTR · ${Math.max(0, 5 - index)} bookings`,
      details: row.details || `${row.title} is pinned on a public StayDirect surface. Review placement, performance and relevance before keeping it promoted.`,
    }));

  const settings = adminEmptyState().settings;
  settingsRaw.forEach((row) => {
    const key = adminFirstText(row, ['key']);
    const value = row.value;
    if (!key || value == null) return;
    const text = typeof value === 'string' ? value : typeof value === 'object' ? adminFirstText(value as AdminRecord, ['label', 'value'], '') : String(value);
    if (isAdminSettingKey(key)) settings[key] = text || settings[key];
  });

  const state: ServerAdminState = {
    ...adminEmptyState(),
    users,
    properties,
    bookings,
    helpTickets,
    subscriptions,
    domains,
    previews,
    content,
    marketplace,
    kai,
    pins,
    systemHealth: buildServerSystemHealthRows(),
    notifications,
    roles,
    auditLogs,
    settings,
  };
  const alerts = await persistServerAdminAlerts(buildServerAdminAlerts(state));
  return { state, alerts };
}

async function insertAdminAuditEvent(admin: { id: string; email: string; local?: boolean }, input: {
  action: string;
  section?: string;
  target_table?: string;
  target_id?: string;
  status?: string;
  message?: string;
  metadata?: Record<string, unknown>;
}) {
  await adminInsertRow('admin_audit_events', {
    admin_id: admin.local || !isUuid(admin.id) ? null : admin.id,
    admin_email: admin.email,
    action: input.action,
    section: input.section || null,
    target_table: input.target_table || null,
    target_id: input.target_id || null,
    status: input.status || 'success',
    message: input.message || '',
    metadata: input.metadata || {},
  }, 'return=minimal');
}

async function handleAdminData(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  const payload = await buildLiveAdminState();
  sendJson(res, 200, payload);
}

async function handleAdminAction(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  if (!SERVICE_ROLE_KEY) {
    const payload = await buildLiveAdminState();
    sendJson(res, 503, {
      ...payload,
      message: 'Admin write access requires the server-side Supabase service role key to be configured.',
    });
    return;
  }
  const body = await readJsonBody(req);
  const section = String(body.section || '') as AdminSectionKey;
  const action = String(body.action || 'primary');
  const rowId = String(body.rowId || '');
  const adminMessage = String(body.message || '').trim();
  let sourceTable = String(body.sourceTable || '');
  let sourceId = String(body.sourceId || rowId);
  const before = await buildLiveAdminState();
  const target = adminSectionRows(before.state, section).find((row) => row.id === rowId || row.sourceId === rowId);
  if (target) {
    sourceTable = sourceTable || String(target.sourceTable || '');
    sourceId = sourceId || String(target.sourceId || target.id);
  }

  let ok = true;
  let message = 'Admin action recorded';
  if (action === 'create') {
    message = 'Admin note created. Use the relevant product workflow to create live records.';
  } else if (action === 'note') {
    message = adminMessage ? 'Admin note saved' : 'Admin note saved with no message body';
  } else if (action === 'delete') {
    const now = new Date().toISOString();
    if (section === 'domains' && sourceTable === 'domain_mappings') {
      ok = await adminPatchRows('domain_mappings', sourceId, {
        status: 'failed',
        ssl_status: 'failed',
        error_message: 'Disconnected by StayDirect admin.',
        updated_at: now,
      });
      message = ok ? 'Domain disconnected' : 'Domain could not be disconnected';
    } else if (section === 'bookings' && sourceTable === 'bookings') {
      ok = await adminPatchRows('bookings', sourceId, { status: 'cancelled', updated_at: now });
      message = ok ? 'Booking cancelled' : 'Booking could not be cancelled';
    } else if (section === 'help-desk' && sourceTable === 'inquiries') {
      ok = await adminPatchRows('inquiries', sourceId, { status: 'closed', updated_at: now });
      message = ok ? 'Ticket closed' : 'Ticket could not be closed';
    } else if (section === 'billing-subscriptions' && sourceTable === 'subscriptions') {
      ok = await adminPatchRows('subscriptions', sourceId, { status: 'cancelled' });
      message = ok ? 'Subscription cancelled' : 'Subscription could not be cancelled';
    } else if (section === 'website-previews' && sourceTable === 'preview_sessions') {
      ok = await adminPatchRows('preview_sessions', sourceId, { status: 'cancelled' });
      message = ok ? 'Preview job deleted' : 'Preview job could not be deleted';
    } else if (section === 'properties-stays' && sourceTable === 'properties') {
      ok = await adminPatchRows('properties', sourceId, { status: 'archived', updated_at: now });
      message = ok ? 'Property archived' : 'Property could not be archived';
    } else if (section === 'content-management' && sourceTable === 'host_marketing_assets') {
      ok = await adminPatchRows('host_marketing_assets', sourceId, { status: 'archived', updated_at: now });
      message = ok ? 'Content archived' : 'Content could not be archived';
    } else if (section === 'pin-analytics' && sourceTable === 'host_marketing_assets') {
      ok = await adminPatchRows('host_marketing_assets', sourceId, { status: 'archived', updated_at: now });
      message = ok ? 'Pin removed' : 'Pin could not be removed';
    } else if (section === 'pin-analytics' && sourceTable === 'local_guidebook_items') {
      ok = await adminPatchRows('local_guidebook_items', sourceId, { is_public: false, updated_at: now });
      message = ok ? 'Pin removed' : 'Pin could not be removed';
    } else if (section === 'marketplace' && (sourceTable === 'host_promotions' || sourceTable === 'host_upsells')) {
      ok = await adminPatchRows(sourceTable, sourceId, { status: 'inactive', active: false, updated_at: now });
      message = ok ? 'Marketplace listing hidden' : 'Marketplace listing could not be hidden';
    } else if (section === 'kai') {
      message = 'Kai archive request recorded';
    } else if (section === 'system-health') {
      message = 'Service monitor archive request recorded';
    } else if (section === 'audit-logs') {
      message = 'Audit logs are immutable. Follow-up note request recorded.';
    } else if (section === 'roles-permissions' && sourceTable === 'admin_roles') {
      ok = await adminPatchRows('admin_roles', sourceId, { active: false, updated_at: now });
      message = ok ? 'Role deactivated' : 'Role could not be deactivated';
    } else {
      message = 'Removal request recorded';
    }
  } else if (section === 'domains' && sourceTable === 'domain_mappings') {
    if (action === 'primary') {
      const mapping = await fetchDomainMappingById(sourceId);
      if (mapping?.id) {
        const dns = await checkCnameTarget(mapping.hostname);
        const status: DomainStatus = dns.verified ? (mapping.ssl_status === 'active' ? 'active' : 'ssl_provisioning') : 'pending_dns';
        const sslStatus: SslStatus = dns.verified ? (mapping.ssl_status === 'active' ? 'active' : 'provisioning') : 'pending';
        await patchDomainMapping(mapping.id, {
          status,
          ssl_status: sslStatus,
          last_dns_check: new Date().toISOString(),
          error_message: dns.verified ? null : dns.error || 'CNAME does not resolve to StayDirect.',
          metadata: { cnames: dns.cnames, expected: STAYDIRECT_CNAME_TARGET },
        });
        await insertDomainLog({
          domain_mapping_id: mapping.id,
          property_id: mapping.property_id,
          hostname: mapping.hostname,
          action: 'admin_dns_recheck',
          status,
          message: dns.verified ? 'DNS verified by admin check.' : 'DNS check failed.',
          created_by: admin.local || !isUuid(admin.id) ? null : admin.id,
          metadata: { cnames: dns.cnames, expected: STAYDIRECT_CNAME_TARGET },
        });
        message = 'DNS check completed';
      } else {
        ok = false;
      }
    } else {
      ok = await adminPatchRows('domain_mappings', sourceId, {
        status: 'failed',
        ssl_status: 'failed',
        error_message: 'Disconnected or marked failed by StayDirect admin.',
        updated_at: new Date().toISOString(),
      });
      message = ok ? 'Domain marked for review' : 'Domain could not be updated';
    }
  } else if (section === 'help-desk' && sourceTable === 'inquiries') {
    const nextStatus = target?.status === 'Open' ? 'pending' : target?.status === 'Pending' ? 'open' : 'open';
    ok = await adminPatchRows('inquiries', sourceId, { status: nextStatus, updated_at: new Date().toISOString() });
    message = 'Help desk ticket updated';
  } else if (section === 'bookings' && sourceTable === 'bookings') {
    ok = await adminPatchRows('bookings', sourceId, { status: 'confirmed', payment_status: 'paid' });
    message = 'Booking marked confirmed and paid';
  } else if (section === 'notifications' && sourceTable === 'host_notifications') {
    ok = await adminPatchRows('host_notifications', sourceId, { read_at: new Date().toISOString() });
    message = 'Notification marked reviewed';
  } else if (section === 'billing-subscriptions' && sourceTable === 'subscriptions') {
    if (action === 'more') {
      message = 'Invoice follow-up logged';
    } else {
      ok = await adminPatchRows('subscriptions', sourceId, { status: 'active' });
      message = 'Payment marked resolved';
    }
  } else if (section === 'properties-stays' && sourceTable === 'properties') {
    ok = await adminPatchRows('properties', sourceId, { status: 'live', updated_at: new Date().toISOString() });
    message = 'Property marked live';
  } else if (section === 'content-management' && sourceTable === 'host_marketing_assets') {
    ok = await adminPatchRows('host_marketing_assets', sourceId, { status: action === 'more' ? 'archived' : 'published', updated_at: new Date().toISOString() });
    message = 'Content status updated';
  } else if (section === 'pin-analytics') {
    const now = new Date().toISOString();
    if (sourceTable === 'host_marketing_assets') {
      ok = await adminPatchRows('host_marketing_assets', sourceId, { status: action === 'more' ? 'archived' : 'published', updated_at: now });
    } else if (sourceTable === 'local_guidebook_items') {
      ok = await adminPatchRows('local_guidebook_items', sourceId, { is_public: action !== 'more', updated_at: now });
    }
    message = action === 'more' ? 'Pin paused' : 'Pin analytics refreshed';
  } else if (section === 'marketplace' && (sourceTable === 'host_promotions' || sourceTable === 'host_upsells')) {
    ok = await adminPatchRows(sourceTable, sourceId, { status: action === 'more' ? 'inactive' : 'active', active: action !== 'more', updated_at: new Date().toISOString() });
    message = action === 'more' ? 'Marketplace listing hidden' : 'Marketplace listing reviewed';
  } else if (section === 'kai') {
    message = action === 'more' ? 'Kai workflow pause note recorded' : 'Kai quality review recorded';
  } else if (section === 'system-health') {
    message = action === 'more' ? 'System alert suppression recorded' : 'System health check recorded';
  } else if (section === 'audit-logs') {
    message = action === 'more' ? 'Audit evidence export recorded' : 'Audit event review recorded';
  } else if (section === 'roles-permissions' && sourceTable === 'admin_roles') {
    ok = await adminPatchRows('admin_roles', sourceId, { active: action !== 'more', updated_at: new Date().toISOString() });
    message = 'Role assignment updated';
  }

  await insertAdminAuditEvent(admin, {
    action: `admin_${action}`,
    section,
    target_table: sourceTable,
    target_id: sourceId,
    status: ok ? 'success' : 'failed',
    message,
    metadata: { rowId, note: action === 'note' ? adminMessage : undefined },
  });
  const payload = await buildLiveAdminState();
  sendJson(res, ok ? 200 : 422, { ...payload, message });
}

async function handleAdminSendNotification(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  if (!SERVICE_ROLE_KEY) {
    const payload = await buildLiveAdminState();
    sendJson(res, 503, {
      ...payload,
      message: 'Admin notification writes require the server-side Supabase service role key to be configured.',
    });
    return;
  }
  const body = await readJsonBody(req);
  const title = String(body.title || 'Important StayDirect update').trim();
  const messageBody = String(body.body || 'We have made a platform improvement that may affect your dashboard.').trim();
  const profiles = await adminGetRows('profiles', { select: 'id,email,name', limit: 1000 });
  const hostIds = profiles.map((row) => adminFirstText(row, ['id', 'user_id'])).filter(Boolean);
  const rows = hostIds.map((hostId) => ({
    host_id: hostId,
    type: 'system',
    title,
    body: messageBody,
    action_path: '/dashboard',
    related_id: null,
  }));
  if (rows.length > 0) await adminInsertRow('host_notifications', rows, 'return=minimal');
  await insertAdminAuditEvent(admin, {
    action: 'send_notification',
    section: 'notifications',
    target_table: 'host_notifications',
    status: 'success',
    message: `Admin notification queued for ${rows.length} hosts.`,
  });
  const payload = await buildLiveAdminState();
  sendJson(res, 200, { ...payload, inserted: rows.length });
}

async function handleAdminSaveSettings(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  if (!SERVICE_ROLE_KEY) {
    const payload = await buildLiveAdminState();
    sendJson(res, 503, {
      ...payload,
      message: 'Admin settings writes require the server-side Supabase service role key to be configured.',
    });
    return;
  }
  const body = await readJsonBody(req);
  const settings = body.settings && typeof body.settings === 'object' ? body.settings as AdminRecord : {};
  const now = new Date().toISOString();
  const rows = Object.entries(settings)
    .filter(([key]) => isAdminSettingKey(key))
    .map(([key, value]) => ({
      key,
      value: typeof value === 'string' ? value : String(value || ''),
      updated_by: admin.local || !isUuid(admin.id) ? null : admin.id,
      updated_at: now,
    }));
  for (const row of rows) await adminUpsertByKey('admin_settings', 'key', row);
  await insertAdminAuditEvent(admin, {
    action: 'save_settings',
    section: 'settings',
    target_table: 'admin_settings',
    status: 'success',
    message: 'Platform settings saved.',
  });
  const payload = await buildLiveAdminState();
  sendJson(res, 200, payload);
}

async function handleAdminAcknowledgeAlert(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  if (!SERVICE_ROLE_KEY) {
    const payload = await buildLiveAdminState();
    sendJson(res, 503, {
      ...payload,
      message: 'Admin alert persistence requires the server-side Supabase service role key to be configured.',
    });
    return;
  }
  const body = await readJsonBody(req);
  const id = String(body.id || '');
  const alertKey = String(body.alertKey || '');
  if (id) {
    await adminPatchRows('admin_alerts', id, {
      acknowledged_at: new Date().toISOString(),
      acknowledged_by: admin.local || !isUuid(admin.id) ? null : admin.id,
      status: 'acknowledged',
      updated_at: new Date().toISOString(),
    });
  } else if (alertKey) {
    const rows = await adminGetRows('admin_alerts', { select: 'id', filters: { alert_key: `eq.${alertKey}` }, limit: 1 });
    const rowId = adminFirstText(rows[0] || {}, ['id']);
    if (rowId) await adminPatchRows('admin_alerts', rowId, {
      acknowledged_at: new Date().toISOString(),
      acknowledged_by: admin.local || !isUuid(admin.id) ? null : admin.id,
      status: 'acknowledged',
      updated_at: new Date().toISOString(),
    });
  }
  const payload = await buildLiveAdminState();
  sendJson(res, 200, { alerts: payload.alerts });
}

type HostStripeRow = {
  id?: string;
  host_id: string;
  property_id: string;
  mode: 'test' | 'live';
  account_email?: string | null;
  publishable_key?: string | null;
  publishable_key_last4?: string | null;
  secret_key_encrypted?: string | null;
  secret_key_last4?: string | null;
  webhook_url?: string | null;
  webhook_configured?: boolean | null;
  webhook_signing_secret_encrypted?: string | null;
  webhook_signing_secret_last4?: string | null;
  stripe_account_id?: string | null;
  charges_enabled?: boolean | null;
  payouts_enabled?: boolean | null;
  details_submitted?: boolean | null;
  connection_status?: string | null;
  test_connection_at?: string | null;
  last_test_booking_at?: string | null;
  last_error?: string | null;
  deposits_enabled?: boolean | null;
  balance_payments_enabled?: boolean | null;
  refunds_enabled?: boolean | null;
};

function stripePublicStatus(row: HostStripeRow | null) {
  if (!row) return null;
  const status = row.connection_status || 'setup';
  return {
    status: status === 'connected' ? 'connected' : status === 'error' ? 'error' : status === 'disconnected' ? 'disconnected' : 'setup',
    mode: 'direct-booking-payments',
    stripeMode: row.mode || 'test',
    accountEmail: row.account_email || '',
    publishableKey: row.publishable_key || '',
    publishableKeyMasked: row.publishable_key ? maskStripeKey(row.publishable_key) : row.publishable_key_last4 ? `pk_${row.mode || 'test'}_••••••••••••${row.publishable_key_last4}` : '',
    secretKeyMasked: row.secret_key_last4 ? `sk_${row.mode || 'test'}_••••••••••••${row.secret_key_last4}` : '',
    webhookUrl: row.webhook_url || '',
    webhookConfigured: Boolean(row.webhook_configured),
    webhookSigningSecretMasked: row.webhook_signing_secret_last4 ? `whsec_••••••••••••${row.webhook_signing_secret_last4}` : '',
    stripeAccountId: row.stripe_account_id || '',
    chargesEnabled: Boolean(row.charges_enabled),
    payoutsEnabled: Boolean(row.payouts_enabled),
    detailsSubmitted: Boolean(row.details_submitted),
    testConnectionAt: row.test_connection_at || undefined,
    testBookingAt: row.last_test_booking_at || undefined,
    lastStripeError: row.last_error || undefined,
    depositsEnabled: row.deposits_enabled !== false,
    balancePaymentsEnabled: row.balance_payments_enabled !== false,
    refundsEnabled: row.refunds_enabled !== false,
  };
}

async function getHostStripeConnection(hostId: string, propertyId: string, mode?: string): Promise<HostStripeRow | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !hostId || !propertyId) return null;
  const params = new URLSearchParams({
    host_id: `eq.${hostId}`,
    property_id: `eq.${propertyId}`,
    select: '*',
    limit: '1',
  });
  if (mode) params.set('mode', `eq.${mode}`);
  const response = await fetch(`${SUPABASE_URL}/rest/v1/host_stripe_connections?${params.toString()}`, {
    headers: adminHeaders(),
  });
  if (!response.ok) return null;
  const rows = await response.json().catch(() => []) as HostStripeRow[];
  return Array.isArray(rows) ? rows[0] || null : null;
}

async function getHostStripeConnectionByProperty(propertyId: string): Promise<HostStripeRow | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !propertyId) return null;
  const response = await fetch(`${SUPABASE_URL}/rest/v1/host_stripe_connections?property_id=eq.${encodeURIComponent(propertyId)}&connection_status=eq.connected&select=*&order=updated_at.desc&limit=1`, {
    headers: adminHeaders(),
  });
  if (!response.ok) return null;
  const rows = await response.json().catch(() => []) as HostStripeRow[];
  return Array.isArray(rows) ? rows[0] || null : null;
}

async function validateStripeSecret(secretKey: string): Promise<{
  accountId: string;
  chargesEnabled: boolean;
  payoutsEnabled: boolean;
  detailsSubmitted: boolean;
  country: string;
}> {
  const response = await fetch('https://api.stripe.com/v1/account', {
    headers: {
      'Authorization': `Bearer ${secretKey}`,
      'Stripe-Version': '2024-06-20',
    },
  });
  const data = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const stripeErr = (data.error as Record<string, unknown> | null) || {};
    throw new Error(String(stripeErr.message || data.message || `Stripe returned ${response.status}`));
  }
  return {
    accountId: String(data.id || ''),
    chargesEnabled: Boolean(data.charges_enabled),
    payoutsEnabled: Boolean(data.payouts_enabled),
    detailsSubmitted: Boolean(data.details_submitted),
    country: String(data.country || ''),
  };
}

async function upsertHostStripeConnection(input: HostStripeRow & { secretKey?: string | null; webhookSigningSecret?: string | null }) {
  const now = new Date().toISOString();
  const existing = await getHostStripeConnection(input.host_id, input.property_id, input.mode);
  const secret = input.secretKey ? {
    secret_key_encrypted: encryptSecret(input.secretKey),
    secret_key_last4: input.secretKey.slice(-4),
  } : existing?.secret_key_encrypted ? {
    secret_key_encrypted: existing.secret_key_encrypted,
    secret_key_last4: existing.secret_key_last4,
  } : {};
  const webhookSigningSecret = input.webhookSigningSecret ? {
    webhook_signing_secret_encrypted: encryptSecret(input.webhookSigningSecret),
    webhook_signing_secret_last4: input.webhookSigningSecret.slice(-4),
  } : existing?.webhook_signing_secret_encrypted ? {
    webhook_signing_secret_encrypted: existing.webhook_signing_secret_encrypted,
    webhook_signing_secret_last4: existing.webhook_signing_secret_last4,
  } : {};
  const row = {
    host_id: input.host_id,
    property_id: input.property_id,
    mode: input.mode,
    account_email: input.account_email || '',
    publishable_key: input.publishable_key || '',
    publishable_key_last4: input.publishable_key?.slice(-4) || existing?.publishable_key_last4 || '',
    webhook_url: input.webhook_url || '',
    webhook_configured: Boolean(input.webhook_configured),
    stripe_account_id: input.stripe_account_id || existing?.stripe_account_id || '',
    charges_enabled: Boolean(input.charges_enabled),
    payouts_enabled: Boolean(input.payouts_enabled),
    details_submitted: Boolean(input.details_submitted),
    connection_status: input.connection_status || 'setup',
    test_connection_at: input.test_connection_at || existing?.test_connection_at || null,
    last_test_booking_at: input.last_test_booking_at || existing?.last_test_booking_at || null,
    last_error: input.last_error || null,
    deposits_enabled: input.deposits_enabled !== false,
    balance_payments_enabled: input.balance_payments_enabled !== false,
    refunds_enabled: input.refunds_enabled !== false,
    updated_at: now,
    ...secret,
    ...webhookSigningSecret,
  };
  const response = await fetch(`${SUPABASE_URL}/rest/v1/host_stripe_connections?on_conflict=host_id,property_id,mode`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'resolution=merge-duplicates,return=representation' }),
    body: JSON.stringify(row),
  });
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const err = Array.isArray(data) ? data[0] : data;
    throw new Error((err?.message as string) || 'Could not save Stripe connection.');
  }
  return (Array.isArray(data) ? data[0] : data) as HostStripeRow;
}

async function updatePropertyPublishableKey(propertyId: string, publishableKey: string | null) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !propertyId) return;
  await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}`, {
    method: 'PATCH',
    headers: adminHeaders({ 'Prefer': 'return=minimal' }),
    body: JSON.stringify({ stripe_publishable_key: publishableKey }),
  }).catch(() => undefined);
}

async function resolveStripeSecretForProperty(propertyId: string): Promise<string | null> {
  const row = await getHostStripeConnectionByProperty(propertyId);
  if (row?.secret_key_encrypted) {
    try {
      return decryptSecret(row.secret_key_encrypted);
    } catch (error) {
      console.warn('[stripe] could not decrypt host secret:', error);
    }
  }
  return null;
}

function verifyStripeWebhookSignature(rawBody: string, signatureHeader: string, signingSecret: string): boolean {
  const signatureParts = Object.fromEntries(signatureHeader.split(',').map((part) => {
    const [key, ...rest] = part.split('=');
    return [key, rest.join('=')];
  }));
  const timestamp = signatureParts.t;
  const signature = signatureParts.v1;
  if (!timestamp || !signature) return false;
  const expected = createHmac('sha256', signingSecret).update(`${timestamp}.${rawBody}`, 'utf8').digest('hex');
  const expectedBuffer = Buffer.from(expected, 'hex');
  const actualBuffer = Buffer.from(signature, 'hex');
  if (expectedBuffer.length !== actualBuffer.length) return false;
  return timingSafeEqual(expectedBuffer, actualBuffer);
}

function classifySignupError(message: string, details: string, errorCode: string): string {
  const combined = `${message} ${details} ${errorCode}`.toLowerCase();
  if (/hook|auth.*hook|signup.*blocked|blocked.*signup/i.test(combined)) {
    return 'Signup is temporarily unavailable. Please try again in a moment.';
  }
  if (/constraint|violates|duplicate|unique/i.test(combined)) {
    return 'A database constraint failed during signup. Please contact support if this continues.';
  }
  if (/password.*too short|password.*length|weak password/i.test(combined)) {
    return 'Password is too short. Please use at least 8 characters.';
  }
  if (/invalid.*email|email.*invalid/i.test(combined)) {
    return 'That email address does not appear to be valid.';
  }
  if (/rate.?limit|too many/i.test(combined)) {
    return 'Too many signup attempts. Please wait a moment and try again.';
  }
  if (/database error/i.test(combined)) {
    return 'A database error occurred during signup. Please try again, or contact support if it persists.';
  }
  return message || 'Could not create account. Please try again.';
}

type ProvisionContext = {
  previewId?: unknown;
  selectedTemplate?: unknown;
  selectedDashboardTheme?: unknown;
  selectedColours?: unknown;
  importUrl?: unknown;
  signupDraft?: unknown;
  previewData?: unknown;
  conversionIntent?: unknown;
};

const TEMPLATE_TO_DASHBOARD_THEME: Record<string, string> = {
  'source-match': 'onepage',
  'modern-showcase': 'modern',
  'conversion-focus': 'minimal',
  'editorial-guide': 'classic',
  onepage: 'onepage',
  modern: 'modern',
  minimal: 'minimal',
  classic: 'classic',
};

const TEMPLATE_ACCENTS: Record<string, string> = {
  'source-match': '#AA7942',
  'modern-showcase': '#4A684F',
  'conversion-focus': '#C89A4B',
  'editorial-guide': '#4A5A44',
  onepage: '#FF5A5F',
  modern: '#00A699',
  minimal: '#C89A4B',
  classic: '#4A5A44',
};

const PROVISION_AMENITY_MATCHERS: Array<[string, RegExp]> = [
  ['wifi', /wi[-\s]?fi|wireless|internet|broadband/i],
  ['parking', /parking|garage|car\s?park/i],
  ['pool', /pool|swimming/i],
  ['kitchen', /kitchen|self[-\s]?contained|cooking|cooktop|oven|microwave|fridge/i],
  ['ac', /air\s?conditioning|a\/c|cooling/i],
  ['tv', /\btv\b|television|satellite/i],
  ['washer', /washer|washing machine|laundry/i],
  ['dryer', /dryer|clothes dryer/i],
  ['dishwasher', /dishwasher/i],
  ['workspace', /workspace|desk|office/i],
  ['gym', /gym|fitness/i],
  ['bbq', /bbq|barbecue|barbeque/i],
  ['fireplace', /fireplace|fire pit|wood burner|woodburner/i],
  ['hottub', /hot\s?tub|spa|jacuzzi/i],
  ['heating', /heating|heater|heat pump/i],
];

function recordValue(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function textValue(...values: unknown[]): string {
  for (const value of values) {
    if (typeof value !== 'string') continue;
    const trimmed = value.trim();
    if (trimmed) return trimmed;
  }
  return '';
}

function numberValue(...values: unknown[]): number | null {
  for (const value of values) {
    if (value === null || value === undefined || value === '') continue;
    const parsed = typeof value === 'string' ? Number(value.replace(/[^0-9.-]/g, '')) : Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return null;
}

function boolValue(value: unknown, fallback = false): boolean {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') return /^(true|yes|1)$/i.test(value);
  return fallback;
}

function stringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => typeof item === 'string' ? item.trim() : '').filter(Boolean);
}

function normaliseProvisionAmenities(...sources: unknown[]): string[] {
  const result = new Set<string>();
  sources.flatMap(stringArray).forEach((value) => {
    const compact = value.toLowerCase().replace(/[^a-z0-9]+/g, '');
    const exact = PROVISION_AMENITY_MATCHERS.find(([key]) => key === compact);
    if (exact) {
      result.add(exact[0]);
      return;
    }
    const match = PROVISION_AMENITY_MATCHERS.find(([, pattern]) => pattern.test(value));
    result.add(match?.[0] || compact || value);
  });
  return Array.from(result);
}

function slugifyProvision(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function comparableProvisionUrl(value: string): string {
  if (!value) return '';
  try {
    const url = new URL(value);
    return `${url.hostname.replace(/^www\./i, '').toLowerCase()}${url.pathname.replace(/\/$/, '')}`;
  } catch {
    return value.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '').toLowerCase();
  }
}

function provisionPreviewMatchesBody(previewRow: Record<string, unknown> | null, body: ProvisionContext, bodyPreview: Record<string, unknown>, rowPreview: Record<string, unknown>): boolean {
  if (!previewRow) return false;
  const bodyUrl = comparableProvisionUrl(textValue(body.importUrl, bodyPreview.sourceUrl, bodyPreview.url));
  const rowUrl = comparableProvisionUrl(textValue(previewRow.url, rowPreview.sourceUrl, rowPreview.url));
  if (!bodyUrl || !rowUrl) return true;
  return bodyUrl === rowUrl;
}

function hasFreshConversionIntent(body: ProvisionContext, userEmail: string): boolean {
  const intent = recordValue(body.conversionIntent);
  const draft = recordValue(body.signupDraft);
  const createdAt = Date.parse(textValue(intent.createdAt));
  const ageMs = Number.isFinite(createdAt) ? Date.now() - createdAt : Number.POSITIVE_INFINITY;
  const emailMatches = !textValue(intent.email) || textValue(intent.email).toLowerCase() === userEmail.trim().toLowerCase();
  return (
    ageMs >= 0 &&
    ageMs <= 2 * 60 * 60 * 1000 &&
    emailMatches &&
    Boolean(textValue(draft.propertyName, intent.propertyName)) &&
    Boolean(textValue(body.previewId, body.importUrl) || Object.keys(recordValue(body.previewData)).length)
  );
}

function isHexColour(value: string) {
  return /^#[0-9a-f]{6}$/i.test(value);
}

function selectedProvisionTemplate(body: ProvisionContext, previewRow: Record<string, unknown> | null): string {
  return textValue(
    body.selectedTemplate,
    previewRow?.selected_template,
    body.selectedDashboardTheme,
    'source-match',
  );
}

function selectedProvisionTheme(templateId: string, dashboardTheme?: unknown) {
  const explicit = textValue(dashboardTheme);
  if (explicit && TEMPLATE_TO_DASHBOARD_THEME[explicit]) return TEMPLATE_TO_DASHBOARD_THEME[explicit];
  return TEMPLATE_TO_DASHBOARD_THEME[templateId] || 'onepage';
}

function selectedProvisionAccent(body: ProvisionContext, templateId: string, imported: Record<string, unknown>): string {
  const colours = recordValue(body.selectedColours);
  const accent = textValue(colours.accentColor, imported.brandColor);
  if (isHexColour(accent)) return accent;
  return TEMPLATE_ACCENTS[templateId] || '#FF5A5F';
}

function unsupportedColumnFromPayload(payload: unknown): string | null {
  const text = typeof payload === 'string' ? payload : JSON.stringify(payload || {});
  return (
    text.match(/Could not find the '([^']+)' column/i)?.[1] ||
    text.match(/column "([^"]+)" of relation "[^"]+" does not exist/i)?.[1] ||
    text.match(/Could not find column '([^']+)'/i)?.[1] ||
    null
  );
}

async function adminInsertReturning(table: string, payload: Record<string, unknown>, select = 'id') {
  const next = { ...payload };
  const removedColumns = new Set<string>();

  for (let attempt = 0; attempt < 20; attempt += 1) {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=${select}`, {
      method: 'POST',
      headers: adminHeaders({ 'Prefer': 'return=representation' }),
      body: JSON.stringify(next),
    });
    const data = await response.json().catch(() => null);
    if (response.ok) {
      const row = Array.isArray(data) ? data[0] : data;
      return { row: recordValue(row), removedColumns };
    }

    const column = unsupportedColumnFromPayload(data);
    if (column && column in next) {
      delete next[column];
      removedColumns.add(column);
      continue;
    }

    throw new Error(String(recordValue(data).message || recordValue(data).error || `${table} insert failed with ${response.status}`));
  }

  throw new Error(`Could not insert ${table}; too many unsupported columns.`);
}

async function adminPatchWithFallback(table: string, filter: string, payload: Record<string, unknown>) {
  const next = { ...payload };
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}`, {
      method: 'PATCH',
      headers: adminHeaders(),
      body: JSON.stringify(next),
    });
    const data = await response.json().catch(() => null);
    if (response.ok) return true;
    const column = unsupportedColumnFromPayload(data);
    if (column && column in next) {
      delete next[column];
      continue;
    }
    return false;
  }
  return false;
}

type ProvisionGuidebookCategory =
  | 'beach'
  | 'walk'
  | 'free_thing'
  | 'rainy_day'
  | 'family_friendly'
  | 'hidden_gem'
  | 'host_recommendation';

type ProvisionGuidebookPlace = {
  id: string;
  name: string;
  formattedAddress: string;
  latitude: number | null;
  longitude: number | null;
  types: string[];
  rating: number | null;
  userRatingsTotal: number | null;
  googleMapsUri: string;
  websiteUri: string;
  locality: string;
  photoName: string | null;
  photoAttribution: string | null;
};

const PROVISION_GUIDEBOOK_TARGET = 6;
const PROVISION_GUIDEBOOK_MAX_DISTANCE_KM = 35;
const PROVISION_GUIDEBOOK_SEARCHES: Array<{ query: string; category: ProvisionGuidebookCategory; radius: number }> = [
  { query: 'top tourist attractions', category: 'host_recommendation', radius: 35000 },
  { query: 'nature walks hiking tracks', category: 'walk', radius: 35000 },
  { query: 'beaches coastal attractions', category: 'beach', radius: 40000 },
  { query: 'museum art gallery cultural attraction', category: 'rainy_day', radius: 35000 },
  { query: 'scenic lookout viewpoint', category: 'walk', radius: 35000 },
  { query: 'parks gardens reserves', category: 'free_thing', radius: 30000 },
  { query: 'waterfall caves natural attraction', category: 'walk', radius: 40000 },
  { query: 'family friendly attractions', category: 'family_friendly', radius: 35000 },
];

const PROVISION_GUIDEBOOK_BLOCKED_TYPES = new Set([
  'cafe',
  'restaurant',
  'meal_takeaway',
  'meal_delivery',
  'bar',
  'bakery',
  'food',
  'grocery_or_supermarket',
  'supermarket',
  'liquor_store',
  'store',
  'shopping_mall',
  'lodging',
  'real_estate_agency',
  'car_dealer',
  'car_repair',
  'gas_station',
  'bank',
  'atm',
  'pharmacy',
  'doctor',
  'dentist',
  'hospital',
  'veterinary_care',
  'school',
  'university',
]);

const PROVISION_GUIDEBOOK_BLOCKED_NAME_PATTERNS = [
  /\bcafe\b/i,
  /\bcoffee\b/i,
  /\brestaurant\b/i,
  /\bbar\b/i,
  /\btavern\b/i,
  /\bgrill\b/i,
  /\bsupermarket\b/i,
  /\bgrocery\b/i,
  /\bpharmacy\b/i,
  /\bpetrol\b/i,
  /\bgas\s+station\b/i,
  /\bhotel\b/i,
  /\bmotel\b/i,
  /\blodge\b/i,
];

function uniqueTextValues(values: string[]) {
  return Array.from(new Set(values.map((value) => value.trim()).filter(Boolean)));
}

function guidebookMapsSearchUrl(place: ProvisionGuidebookPlace) {
  const query = Number.isFinite(Number(place.latitude)) && Number.isFinite(Number(place.longitude))
    ? `${place.latitude},${place.longitude}`
    : [place.name, place.formattedAddress].filter(Boolean).join(' ');
  const params = new URLSearchParams({ api: '1', query });
  if (place.id) params.set('query_place_id', place.id);
  return `https://www.google.com/maps/search/?${params.toString()}`;
}

function guidebookDistanceKm(property: Record<string, unknown>, place: ProvisionGuidebookPlace) {
  const aLat = numberValue(property.latitude);
  const aLng = numberValue(property.longitude);
  const bLat = numberValue(place.latitude);
  const bLng = numberValue(place.longitude);
  if ([aLat, aLng, bLat, bLng].some((value) => typeof value !== 'number')) return null;
  const radius = 6371;
  const dLat = ((bLat! - aLat!) * Math.PI) / 180;
  const dLng = ((bLng! - aLng!) * Math.PI) / 180;
  const lat1 = (aLat! * Math.PI) / 180;
  const lat2 = (bLat! * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return radius * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function guidebookTravelLabel(distanceKm: number | null) {
  if (!distanceKm) return '';
  const driveMinutes = Math.max(3, Math.round((distanceKm / 45) * 60));
  if (driveMinutes < 20) return `${driveMinutes} minutes away`;
  if (driveMinutes < 60) return `${driveMinutes} min drive`;
  const hours = Math.floor(driveMinutes / 60);
  const minutes = driveMinutes % 60;
  return `${hours} hr${hours > 1 ? 's' : ''}${minutes ? ` ${minutes} min` : ''} drive`;
}

function provisionGuidebookCategory(types: string[], name: string, hint: ProvisionGuidebookCategory): ProvisionGuidebookCategory {
  const merged = `${types.join(' ')} ${name}`.toLowerCase();
  if (/(beach|bay|cove|coast|waterfront)/.test(merged)) return 'beach';
  if (/(museum|gallery|art|heritage|theatre|center|centre)/.test(merged)) return 'rainy_day';
  if (/(playground|zoo|aquarium|family|children|kids)/.test(merged)) return 'family_friendly';
  if (/(waterfall|falls|cave|track|trail|walk|hike|lookout|viewpoint|summit|mount|park|garden|reserve)/.test(merged)) return 'walk';
  if (/(hidden|secret|local)/.test(merged)) return 'hidden_gem';
  return hint;
}

function provisionGuidebookDescription(name: string, category: ProvisionGuidebookCategory, area: string, types: string[]) {
  const nearby = area ? ` near ${area}` : '';
  const merged = `${name} ${types.join(' ')}`.toLowerCase();
  if (/cave/.test(merged)) return `Explore a memorable cave and nature stop${nearby}, ideal for guests who want an easy local adventure.`;
  if (/waterfall|falls/.test(merged)) return `A refreshing nature stop with water, greenery, and a simple reason to slow down.`;
  if (category === 'beach') return `A beautiful coastal stop${nearby} for fresh air, photos, and a slower beach moment.`;
  if (category === 'rainy_day') return `A useful culture or rainy-day idea${nearby} when guests want something memorable without depending on the weather.`;
  if (category === 'family_friendly') return `A simple, guest-friendly attraction${nearby} that works well for families and mixed-age groups.`;
  if (category === 'walk') return `Take a scenic local wander with enough nature and breathing room to make the day feel special.`;
  if (category === 'hidden_gem') return `A quieter local favourite that feels a little more tucked-away than the obvious visitor stops.`;
  return `A well-defined local attraction${nearby} that helps guests shape an easier, more memorable day out.`;
}

function provisionGuidebookTags(category: ProvisionGuidebookCategory, types: string[], text: string) {
  const tags = new Set<string>(['things-to-do']);
  const vibes = new Set<string>();
  const merged = `${category} ${types.join(' ')} ${text}`.toLowerCase();
  if (category === 'beach') tags.add('beach');
  if (category === 'walk') tags.add('walking');
  if (category === 'rainy_day') tags.add('rainy-day');
  if (category === 'family_friendly') tags.add('family-friendly');
  if (category === 'hidden_gem') tags.add('hidden-gem');
  if (/free|park|walk|beach|waterfall|lookout|cave|reserve|garden/.test(merged)) tags.add('free');
  if (/scenic|view|lookout|coast|waterfall|garden/.test(merged)) tags.add('scenic');
  if (/art|museum|gallery|heritage|culture/.test(merged)) tags.add('culture');
  if (/adventure|cave|track|hike|trail/.test(merged)) vibes.add('adventure');
  if (/family|playground|easy|kids|children/.test(merged)) vibes.add('family');
  if (/hidden|quiet|local|reserve/.test(merged)) vibes.add('hidden-gem');
  if (/scenic|view|garden|beach|waterfall/.test(merged)) vibes.add('slow-getaway');
  if (/museum|gallery|art|heritage/.test(merged)) vibes.add('culture');
  return { tags: Array.from(tags), vibeTags: Array.from(vibes) };
}

function provisionGuidebookDuration(category: ProvisionGuidebookCategory, types: string[], name: string) {
  const merged = `${category} ${types.join(' ')} ${name}`.toLowerCase();
  if (/cave|waterfall|track|trail|walk|hike|park|tourist_attraction/.test(merged)) return '1-2 hours';
  if (/beach|bay|lookout|view/.test(merged)) return '45-90 min';
  if (/museum|gallery|art|heritage/.test(merged)) return '1-2 hours';
  return '45-90 min';
}

function provisionGuidebookFallbackImage(category: ProvisionGuidebookCategory) {
  if (category === 'beach') return 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1400&q=80';
  if (category === 'rainy_day') return 'https://images.unsplash.com/photo-1564399580075-5dfe19c205f3?auto=format&fit=crop&w=1400&q=80';
  return 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=80';
}

function isProvisionGuidebookCandidate(place: ProvisionGuidebookPlace) {
  const types = place.types || [];
  if (types.some((type) => PROVISION_GUIDEBOOK_BLOCKED_TYPES.has(type))) return false;
  if (PROVISION_GUIDEBOOK_BLOCKED_NAME_PATTERNS.some((pattern) => pattern.test(place.name))) return false;
  const merged = `${place.name} ${place.formattedAddress} ${types.join(' ')}`.toLowerCase();
  return /(tourist_attraction|park|museum|art_gallery|natural_feature|beach|bay|cave|walk|track|trail|waterfall|falls|lookout|viewpoint|garden|reserve|heritage|zoo|aquarium|landmark|scenic)/.test(merged);
}

async function googlePlacesTextSearch(textQuery: string, property: Record<string, unknown>, radius = 35000, maxResultCount = 8): Promise<ProvisionGuidebookPlace[]> {
  if (!GOOGLE_PLACES_API_KEY) return [];
  const latitude = numberValue(property.latitude);
  const longitude = numberValue(property.longitude);
  const requestBody: Record<string, unknown> = {
    textQuery,
    languageCode: 'en',
    regionCode: 'NZ',
    maxResultCount,
  };
  if (typeof latitude === 'number' && typeof longitude === 'number') {
    requestBody.locationBias = {
      circle: {
        center: { latitude, longitude },
        radius,
      },
    };
  }
  const response = await fetch(`${PLACES_BASE_URL}/places:searchText`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
      'X-Goog-FieldMask': [
        'places.id',
        'places.displayName',
        'places.formattedAddress',
        'places.location',
        'places.types',
        'places.primaryType',
        'places.rating',
        'places.userRatingCount',
        'places.googleMapsUri',
        'places.websiteUri',
        'places.photos',
        'places.addressComponents',
      ].join(','),
    },
    body: JSON.stringify(requestBody),
  });
  const payload: any = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error?.message || 'Google Places text search failed');
  return (payload.places || []).map((place: any) => {
    const photo = (place.photos || [])[0] || null;
    const locality = (place.addressComponents || []).find((component: any) => component.types?.includes('locality'))?.longText
      || (place.addressComponents || []).find((component: any) => component.types?.includes('sublocality'))?.longText
      || '';
    return {
      id: place.id || '',
      name: place.displayName?.text || '',
      formattedAddress: place.formattedAddress || '',
      latitude: place.location?.latitude ?? null,
      longitude: place.location?.longitude ?? null,
      types: uniqueTextValues([...(place.types || []), place.primaryType || '']),
      rating: place.rating ?? null,
      userRatingsTotal: place.userRatingCount ?? null,
      googleMapsUri: place.googleMapsUri || '',
      websiteUri: place.websiteUri || '',
      locality,
      photoName: photo?.name || null,
      photoAttribution: photo?.authorAttributions?.[0]?.displayName || null,
    };
  }).filter((place: ProvisionGuidebookPlace) => place.id && place.name);
}

async function googlePlacesPhotoUri(photoName: string | null) {
  if (!photoName || !GOOGLE_PLACES_API_KEY) return '';
  try {
    const response = await fetch(`${PLACES_BASE_URL}/${photoName}/media?${new URLSearchParams({
      key: GOOGLE_PLACES_API_KEY,
      maxWidthPx: '1600',
      skipHttpRedirect: 'true',
    }).toString()}`);
    const payload: any = await response.json().catch(() => ({}));
    return payload.photoUri || (response.ok ? response.url : '');
  } catch {
    return '';
  }
}

async function hydrateProvisionPropertyLocation(property: Record<string, unknown>) {
  const latitude = numberValue(property.latitude);
  const longitude = numberValue(property.longitude);
  if (typeof latitude === 'number' && typeof longitude === 'number') return property;

  const placeId = textValue(property.google_place_id);
  const addressQuery = textValue(
    property.address,
    [property.name, property.city, property.country].map((value) => textValue(value)).filter(Boolean).join(', '),
  );
  let places: ProvisionGuidebookPlace[] = [];
  if (placeId) {
    const response = await fetch(`${PLACES_BASE_URL}/places/${encodeURIComponent(placeId)}`, {
      headers: {
        'X-Goog-Api-Key': GOOGLE_PLACES_API_KEY,
        'X-Goog-FieldMask': 'id,displayName,formattedAddress,location,types,googleMapsUri,addressComponents',
      },
    });
    const payload: any = await response.json().catch(() => ({}));
    if (response.ok) {
      places = [{
        id: payload.id || placeId,
        name: payload.displayName?.text || textValue(property.name),
        formattedAddress: payload.formattedAddress || addressQuery,
        latitude: payload.location?.latitude ?? null,
        longitude: payload.location?.longitude ?? null,
        types: payload.types || [],
        rating: null,
        userRatingsTotal: null,
        googleMapsUri: payload.googleMapsUri || '',
        websiteUri: '',
        locality: '',
        photoName: null,
        photoAttribution: null,
      }];
    }
  }

  if (!places.length && addressQuery) {
    places = await googlePlacesTextSearch(addressQuery, {}, 50000, 1).catch(() => []);
  }

  const match = places.find((place) => typeof place.latitude === 'number' && typeof place.longitude === 'number');
  if (!match) return property;
  const updates = {
    latitude: match.latitude,
    longitude: match.longitude,
    google_place_id: match.id || null,
    address: textValue(property.address, match.formattedAddress),
    updated_at: new Date().toISOString(),
  };
  await adminPatchWithFallback('properties', `id=eq.${encodeURIComponent(textValue(property.id))}`, updates);
  return { ...property, ...updates };
}

async function loadProvisionGuidebookProperty(propertyId: string, hostId: string) {
  const selects = [
    'id,host_id,name,address,city,country,latitude,longitude,google_place_id',
    'id,host_id,name,address,city,country,latitude,longitude',
  ];

  for (const select of selects) {
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}&host_id=eq.${encodeURIComponent(hostId)}&select=${select}&limit=1`,
      { headers: adminHeaders() },
    );
    const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
    if (response.ok && Array.isArray(rows) && rows[0]) return recordValue(rows[0]);
  }

  return {};
}

async function buildProvisionGuidebookItem(
  place: ProvisionGuidebookPlace,
  property: Record<string, unknown>,
  hostId: string,
  categoryHint: ProvisionGuidebookCategory,
  sortOrder: number,
) {
  const distanceKm = guidebookDistanceKm(property, place);
  if (distanceKm !== null && distanceKm > PROVISION_GUIDEBOOK_MAX_DISTANCE_KM) return null;
  const category = provisionGuidebookCategory(place.types, `${place.name} ${place.formattedAddress}`, categoryHint);
  const area = place.locality || textValue(property.city);
  const photoUri = await googlePlacesPhotoUri(place.photoName);
  const duration = provisionGuidebookDuration(category, place.types, place.name);
  const { tags, vibeTags } = provisionGuidebookTags(category, place.types, `${place.name} ${place.formattedAddress}`);

  return {
    property_id: textValue(property.id),
    host_id: hostId,
    title: place.name,
    category,
    description: provisionGuidebookDescription(place.name, category, area, place.types),
    address: place.formattedAddress,
    distance_from_property: guidebookTravelLabel(distanceKm),
    google_maps_link: place.googleMapsUri || guidebookMapsSearchUrl(place),
    google_place_id: place.id,
    image_url: photoUri || provisionGuidebookFallbackImage(category),
    host_note: '',
    recommended: true,
    is_public: true,
    sort_order: sortOrder,
    latitude: place.latitude,
    longitude: place.longitude,
    google_place_types: place.types,
    google_rating: place.rating,
    google_user_ratings_total: place.userRatingsTotal,
    nearby_area: area,
    travel_time_minutes: distanceKm ? Math.max(3, Math.round((distanceKm / 45) * 60)) : null,
    travel_distance_km: distanceKm ? Number(distanceKm.toFixed(1)) : null,
    tags,
    vibe_tags: vibeTags,
    hidden_gem: tags.includes('hidden-gem') || category === 'hidden_gem',
    image_source: photoUri ? 'google_places' : 'starter_fallback',
    image_cache_status: photoUri ? 'external_reference' : 'not_cached',
    google_photo_reference: place.photoName,
    photo_attribution: place.photoAttribution,
    source_metadata: {
      provider: 'google_places_api',
      starter_recommendation: true,
      starter_context: 'preview_to_live_conversion',
      generated_at: new Date().toISOString(),
      place_types: place.types,
      google_place_id: place.id,
      google_maps_url: place.googleMapsUri,
      google_website: place.websiteUri,
      estimated_duration: duration,
    },
    estimated_duration: duration,
    kai_ready: true,
    last_enriched_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

async function seedStarterGuidebookForProperty(propertyId: string, hostId: string) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !GOOGLE_PLACES_API_KEY || !propertyId || !hostId) {
    return { seeded: 0, skipped: 'not_configured' };
  }

  const existingRes = await fetch(
    `${SUPABASE_URL}/rest/v1/local_guidebook_items?property_id=eq.${encodeURIComponent(propertyId)}&select=id,title,google_place_id&limit=20`,
    { headers: adminHeaders() },
  );
  const existingRows = await existingRes.json().catch(() => []) as Array<Record<string, unknown>>;
  const existing = existingRes.ok && Array.isArray(existingRows) ? existingRows : [];
  if (existing.length >= PROVISION_GUIDEBOOK_TARGET) return { seeded: 0, skipped: 'already_has_guidebook' };

  let property = await loadProvisionGuidebookProperty(propertyId, hostId);
  if (!property.id) return { seeded: 0, skipped: 'property_not_found' };
  property = await hydrateProvisionPropertyLocation(property);

  const latitude = numberValue(property.latitude);
  const longitude = numberValue(property.longitude);
  if (typeof latitude !== 'number' || typeof longitude !== 'number') return { seeded: 0, skipped: 'missing_location' };

  const seenPlaceIds = new Set(existing.map((item) => textValue(item.google_place_id).toLowerCase()).filter(Boolean));
  const seenTitles = new Set(existing.map((item) => textValue(item.title).toLowerCase()).filter(Boolean));
  const needed = PROVISION_GUIDEBOOK_TARGET - existing.length;
  const items: Array<Record<string, unknown>> = [];

  for (const search of PROVISION_GUIDEBOOK_SEARCHES) {
    if (items.length >= needed) break;
    let places: ProvisionGuidebookPlace[] = [];
    try {
      places = await googlePlacesTextSearch(search.query, property, search.radius, 6);
    } catch (error) {
      console.warn('[guidebook seed] Google Places search failed', search.query, error);
      continue;
    }
    for (const place of places) {
      const placeKey = place.id.toLowerCase();
      const titleKey = place.name.toLowerCase();
      if (seenPlaceIds.has(placeKey) || seenTitles.has(titleKey)) continue;
      if (!isProvisionGuidebookCandidate(place)) continue;
      const item = await buildProvisionGuidebookItem(place, property, hostId, search.category, existing.length + items.length);
      if (!item) continue;
      seenPlaceIds.add(placeKey);
      seenTitles.add(titleKey);
      items.push(item);
      break;
    }
  }

  let seeded = 0;
  for (const item of items.slice(0, needed)) {
    try {
      await adminInsertReturning('local_guidebook_items', item, 'id,title');
      seeded += 1;
    } catch (error) {
      console.warn('[guidebook seed] Could not insert starter guidebook item', textValue(item.title), error);
    }
  }

  return { seeded, skipped: seeded ? null : 'no_attractions_found' };
}

const KAI_DESTINATION_GUIDEBOOK_TARGET = 8;
const KAI_GUIDEBOOK_SELECT = [
  'id',
  'property_id',
  'title',
  'category',
  'description',
  'address',
  'distance_from_property',
  'google_maps_link',
  'google_place_id',
  'image_url',
  'host_note',
  'recommended',
  'is_public',
  'latitude',
  'longitude',
  'nearby_area',
  'travel_time_minutes',
  'travel_distance_km',
  'tags',
  'vibe_tags',
  'hidden_gem',
  'google_rating',
  'google_user_ratings_total',
  'source_metadata',
].join(',');

type KaiGuidebookLookupRow = Record<string, unknown>;

function kaiGuidebookLimit(value: unknown) {
  const parsed = Number(value);
  return Math.max(3, Math.min(Number.isFinite(parsed) ? parsed : KAI_DESTINATION_GUIDEBOOK_TARGET, 24));
}

function kaiDestinationSlug(destination: string) {
  return slugifyProvision(destination || 'new-zealand') || 'new-zealand';
}

function kaiDestinationSearchText(destination: string) {
  return destination.replace(/[(),]/g, ' ').replace(/\s+/g, ' ').trim();
}

function kaiServerRowScore(row: KaiGuidebookLookupRow) {
  let score = 50;
  if (boolValue(row.recommended)) score += 18;
  if (textValue(row.host_note)) score += 8;
  if (boolValue(row.hidden_gem)) score += 8;
  const rating = numberValue(row.google_rating);
  if (rating) score += Math.min(10, rating * 2);
  const totalRatings = numberValue(row.google_user_ratings_total);
  if (totalRatings) score += Math.min(8, Math.log10(totalRatings + 1) * 3);
  const distance = numberValue(row.travel_distance_km);
  if (distance !== null) score += Math.max(0, 12 - distance);
  const minutes = numberValue(row.travel_time_minutes);
  if (minutes !== null) score += Math.max(0, 10 - minutes / 8);
  return score;
}

function dedupeKaiGuidebookRows(rows: KaiGuidebookLookupRow[], limit: number) {
  const seen = new Set<string>();
  const deduped: KaiGuidebookLookupRow[] = [];
  rows
    .filter((row) => textValue(row.title))
    .sort((a, b) => kaiServerRowScore(b) - kaiServerRowScore(a))
    .forEach((row) => {
      const placeId = textValue(row.google_place_id);
      const fallbackKey = [
        textValue(row.title).toLowerCase(),
        textValue(row.address).toLowerCase(),
        textValue(row.nearby_area).toLowerCase(),
      ].filter(Boolean).join('|');
      const key = placeId ? `place:${placeId}` : fallbackKey;
      if (!key || seen.has(key)) return;
      seen.add(key);
      deduped.push(row);
    });
  return deduped.slice(0, limit);
}

async function fetchKaiGuidebookRows(input: {
  propertyId?: string;
  destination?: string;
  limit: number;
}) {
  if (!SUPABASE_URL || !ADMIN_READ_KEY) return [];
  const url = new URL(`${SUPABASE_URL}/rest/v1/local_guidebook_items`);
  url.searchParams.set('select', KAI_GUIDEBOOK_SELECT);
  url.searchParams.set('is_public', 'eq.true');
  url.searchParams.set('kai_ready', 'eq.true');
  url.searchParams.set('order', 'created_at.desc');
  url.searchParams.set('limit', String(Math.max(24, input.limit * 4)));
  if (input.propertyId) {
    url.searchParams.set('property_id', `eq.${input.propertyId}`);
  } else if (input.destination) {
    const search = kaiDestinationSearchText(input.destination);
    if (search.length >= 3) {
      const match = `*${search}*`;
      url.searchParams.set('or', `(nearby_area.ilike.${match},address.ilike.${match},title.ilike.${match},description.ilike.${match})`);
    }
  }

  const response = await fetch(url, { headers: adminReadHeaders() });
  const rows = await response.json().catch(() => []) as KaiGuidebookLookupRow[];
  if (!response.ok || !Array.isArray(rows)) return [];
  return rows;
}

function parseDestinationGuidebookCache(value: unknown) {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

function destinationCacheRowToGuidebookRows(row: KaiGuidebookLookupRow, limit: number) {
  const destinationSlug = textValue(row.destination_slug);
  const destinationName = textValue(row.destination_name, destinationSlug.replace(/-/g, ' '));
  return parseDestinationGuidebookCache(row.guidebook_recommendations)
    .map((raw, index) => {
      const item = recordValue(raw);
      const title = textValue(item.title, item.name);
      if (!title) return null;
      const sourceMetadata = {
        ...recordValue(item.source_metadata),
        provider: textValue(recordValue(item.source_metadata).provider, 'marketplace_destination_intelligence'),
        destination_slug: destinationSlug,
        destination_name: destinationName,
        cache_source: 'marketplace_destination_intelligence',
      };
      return {
        id: textValue(item.id, `destination-${destinationSlug}-${slugifyProvision(title) || index}`),
        property_id: textValue(item.property_id) || null,
        title,
        category: textValue(item.category, 'host_recommendation'),
        description: textValue(item.description, item.summary) || null,
        address: textValue(item.address) || null,
        distance_from_property: textValue(item.distance_from_property, item.distance) || null,
        google_maps_link: textValue(item.google_maps_link, item.googleMapsUri, item.sourceUrl) || null,
        google_place_id: textValue(item.google_place_id, item.placeId) || null,
        image_url: textValue(item.image_url, item.imageUrl) || null,
        host_note: textValue(item.host_note, item.hostNote) || null,
        recommended: item.recommended !== false,
        is_public: true,
        latitude: numberValue(item.latitude),
        longitude: numberValue(item.longitude),
        nearby_area: textValue(item.nearby_area, item.locality, destinationName) || null,
        travel_time_minutes: numberValue(item.travel_time_minutes),
        travel_distance_km: numberValue(item.travel_distance_km),
        tags: stringArray(item.tags),
        vibe_tags: stringArray(item.vibe_tags),
        hidden_gem: boolValue(item.hidden_gem),
        google_rating: numberValue(item.google_rating, item.rating),
        google_user_ratings_total: numberValue(item.google_user_ratings_total, item.userRatingsTotal),
        source_metadata: sourceMetadata,
      };
    })
    .filter((item): item is KaiGuidebookLookupRow => Boolean(item))
    .slice(0, limit);
}

async function fetchKaiDestinationIntelligence(destination: string) {
  if (!SUPABASE_URL || !ADMIN_READ_KEY || !destination) return null;
  const slug = kaiDestinationSlug(destination);
  const selectWithCache = 'id,destination_slug,destination_name,guidebook_recommendations,guidebook_generated_at,guidebook_source,guidebook_cache_status,seasonal_highlights,local_travel_notes,updated_at';
  const selectFallback = 'id,destination_slug,destination_name,seasonal_highlights,local_travel_notes,updated_at';
  for (const select of [selectWithCache, selectFallback]) {
    const url = new URL(`${SUPABASE_URL}/rest/v1/marketplace_destination_intelligence`);
    url.searchParams.set('select', select);
    url.searchParams.set('destination_slug', `eq.${slug}`);
    url.searchParams.set('limit', '1');
    const response = await fetch(url, { headers: adminReadHeaders() });
    const rows = await response.json().catch(() => []) as KaiGuidebookLookupRow[];
    if (response.ok && Array.isArray(rows) && rows[0]) return rows[0];
  }
  return null;
}

async function findKaiDestinationAnchor(destination: string, latitude: number | null, longitude: number | null) {
  if (typeof latitude === 'number' && typeof longitude === 'number') {
    return {
      id: `destination-${kaiDestinationSlug(destination)}`,
      name: destination,
      city: destination,
      latitude,
      longitude,
    };
  }
  const places = await googlePlacesTextSearch(`${destination} New Zealand`, {}, 50000, 1).catch(() => []);
  const match = places.find((place) => typeof place.latitude === 'number' && typeof place.longitude === 'number');
  if (!match) return null;
  return {
    id: match.id,
    name: match.name || destination,
    city: match.locality || destination,
    latitude: match.latitude,
    longitude: match.longitude,
  };
}

async function buildKaiDestinationGuidebookRow(
  place: ProvisionGuidebookPlace,
  anchor: Record<string, unknown>,
  categoryHint: ProvisionGuidebookCategory,
  destination: string,
  sortOrder: number,
) {
  const distanceKm = guidebookDistanceKm(anchor, place);
  const category = provisionGuidebookCategory(place.types, `${place.name} ${place.formattedAddress}`, categoryHint);
  const area = place.locality || textValue(anchor.city, destination);
  const photoUri = await googlePlacesPhotoUri(place.photoName);
  const duration = provisionGuidebookDuration(category, place.types, place.name);
  const { tags, vibeTags } = provisionGuidebookTags(category, place.types, `${place.name} ${place.formattedAddress}`);
  const destinationSlug = kaiDestinationSlug(destination);

  return {
    id: `destination-${destinationSlug}-${place.id || slugifyProvision(place.name) || sortOrder}`,
    property_id: null,
    title: place.name,
    category,
    description: provisionGuidebookDescription(place.name, category, area, place.types),
    address: place.formattedAddress,
    distance_from_property: guidebookTravelLabel(distanceKm),
    google_maps_link: place.googleMapsUri || guidebookMapsSearchUrl(place),
    google_place_id: place.id,
    image_url: photoUri || '',
    host_note: '',
    recommended: true,
    is_public: true,
    latitude: place.latitude,
    longitude: place.longitude,
    google_place_types: place.types,
    google_rating: place.rating,
    google_user_ratings_total: place.userRatingsTotal,
    nearby_area: area,
    travel_time_minutes: distanceKm ? Math.max(3, Math.round((distanceKm / 45) * 60)) : null,
    travel_distance_km: distanceKm ? Number(distanceKm.toFixed(1)) : null,
    tags,
    vibe_tags: vibeTags,
    hidden_gem: tags.includes('hidden-gem') || category === 'hidden_gem',
    image_source: photoUri ? 'google_places' : 'none',
    image_cache_status: photoUri ? 'external_reference' : 'not_cached',
    google_photo_reference: place.photoName,
    photo_attribution: place.photoAttribution,
    source_metadata: {
      provider: 'google_places_api',
      destination_slug: destinationSlug,
      destination_name: destination,
      cache_source: 'google_places_destination_fallback',
      generated_at: new Date().toISOString(),
      place_types: place.types,
      google_place_id: place.id,
      google_maps_url: place.googleMapsUri,
      google_website: place.websiteUri,
      estimated_duration: duration,
    },
  };
}

async function discoverKaiDestinationGuidebookRows(input: {
  destination: string;
  latitude: number | null;
  longitude: number | null;
  limit: number;
}) {
  if (!GOOGLE_PLACES_API_KEY || !input.destination) return [];
  const anchor = await findKaiDestinationAnchor(input.destination, input.latitude, input.longitude);
  if (!anchor) return [];
  const seenPlaceIds = new Set<string>();
  const seenTitles = new Set<string>();
  const rows: KaiGuidebookLookupRow[] = [];

  for (const search of PROVISION_GUIDEBOOK_SEARCHES) {
    if (rows.length >= input.limit) break;
    const query = `${search.query} near ${input.destination}`;
    let places: ProvisionGuidebookPlace[] = [];
    try {
      places = await googlePlacesTextSearch(query, anchor, search.radius, 6);
    } catch (error) {
      console.warn('[kai guidebook] Google Places destination search failed', query, error);
      continue;
    }
    for (const place of places) {
      const placeKey = place.id.toLowerCase();
      const titleKey = place.name.toLowerCase();
      if (seenPlaceIds.has(placeKey) || seenTitles.has(titleKey)) continue;
      if (!isProvisionGuidebookCandidate(place)) continue;
      const row = await buildKaiDestinationGuidebookRow(place, anchor, search.category, input.destination, rows.length);
      seenPlaceIds.add(placeKey);
      seenTitles.add(titleKey);
      rows.push(row);
      break;
    }
  }

  return rows;
}

async function saveKaiDestinationGuidebookCache(destination: string, rows: KaiGuidebookLookupRow[], source: string) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !destination || rows.length === 0) return false;
  const destinationSlug = kaiDestinationSlug(destination);
  const now = new Date().toISOString();
  const payload = {
    destination_slug: destinationSlug,
    destination_name: destination,
    guidebook_recommendations: rows,
    guidebook_generated_at: now,
    guidebook_source: source,
    guidebook_cache_status: rows.length >= KAI_DESTINATION_GUIDEBOOK_TARGET ? 'ready' : 'partial',
    local_travel_notes: `Kai destination guidebook cache last refreshed for ${destination}.`,
    updated_at: now,
  };

  const existing = await fetchKaiDestinationIntelligence(destination);
  if (existing?.id) {
    return adminPatchWithFallback(
      'marketplace_destination_intelligence',
      `destination_slug=eq.${encodeURIComponent(destinationSlug)}`,
      payload,
    );
  }

  try {
    await adminInsertReturning('marketplace_destination_intelligence', { ...payload, created_at: now }, 'id,destination_slug');
    return true;
  } catch (error) {
    console.warn('[kai guidebook] Could not save destination guidebook cache', error);
    return false;
  }
}

async function handleKaiGuidebookRecommendations(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const destination = textValue(body.destination, body.region);
  const propertyId = textValue(body.propertyId, body.property_id);
  const limit = kaiGuidebookLimit(body.limit);
  const allowGoogleFallback = body.allowGoogleFallback !== false;
  const latitude = numberValue(body.latitude);
  const longitude = numberValue(body.longitude);
  const notes: string[] = [];
  let source = 'none';

  if (propertyId && !isUuid(propertyId)) {
    sendJson(res, 400, { error: 'Valid propertyId is required when supplied.' });
    return;
  }

  const rows: KaiGuidebookLookupRow[] = [];
  if (propertyId || destination) {
    const localRows = await fetchKaiGuidebookRows({ propertyId: propertyId || undefined, destination, limit });
    if (localRows.length) {
      rows.push(...localRows);
      source = propertyId ? 'property_guidebook' : 'local_guidebook_items';
      notes.push(propertyId ? 'Property guidebook cache hit.' : 'Public host guidebooks matched the destination.');
    }
  }

  if (destination && rows.length < Math.min(KAI_DESTINATION_GUIDEBOOK_TARGET, limit)) {
    const intelligence = await fetchKaiDestinationIntelligence(destination);
    const cachedRows = intelligence ? destinationCacheRowToGuidebookRows(intelligence, limit) : [];
    if (cachedRows.length) {
      rows.push(...cachedRows);
      source = source === 'none' ? 'destination_intelligence' : `${source}+destination_intelligence`;
      notes.push('Destination intelligence cache hit.');
    }
  }

  let recommendations = dedupeKaiGuidebookRows(rows, limit);
  if (recommendations.length >= Math.min(KAI_DESTINATION_GUIDEBOOK_TARGET, limit)) {
    sendJson(res, 200, {
      ok: true,
      cacheHit: true,
      source,
      recommendations,
      generatedAt: new Date().toISOString(),
      notes,
    });
    return;
  }

  if (destination && allowGoogleFallback) {
    const ip = getClientIp(req);
    const rateLimit = checkGooglePlacesRateLimit(ip);
    if (!rateLimit.allowed) {
      notes.push('Google Places fallback skipped because the rate limit was reached.');
    } else {
      const googleRows = await discoverKaiDestinationGuidebookRows({
        destination,
        latitude,
        longitude,
        limit,
      });
      if (googleRows.length) {
        rows.push(...googleRows);
        source = source === 'none' ? 'google_places' : `${source}+google_places`;
        notes.push('Google Places fallback discovered new destination recommendations.');
        await saveKaiDestinationGuidebookCache(destination, googleRows, 'google_places');
      }
    }
  }

  recommendations = dedupeKaiGuidebookRows(rows, limit);
  sendJson(res, 200, {
    ok: true,
    cacheHit: recommendations.length > 0 && !source.includes('google_places'),
    source,
    recommendations,
    generatedAt: new Date().toISOString(),
    notes,
  });
}

async function loadProvisionPreviewRow(previewId: string): Promise<Record<string, unknown> | null> {
  if (!previewId) return null;
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/preview_sessions?id=eq.${encodeURIComponent(previewId)}&select=id,url,scraped_data,layout_previews,selected_template,status,converted_property_id,created_at&limit=1`,
    { headers: adminHeaders() },
  );
  const rows = await response.json().catch(() => []) as unknown[];
  if (!response.ok || !Array.isArray(rows) || !rows[0]) return null;
  return recordValue(rows[0]);
}

function previewDataForProvision(row: Record<string, unknown> | null, templateId: string): Record<string, unknown> {
  const layouts = recordValue(row?.layout_previews);
  const layout = recordValue(layouts[templateId]);
  const layoutData = recordValue(layout.scraped_data);
  return Object.keys(layoutData).length ? layoutData : recordValue(row?.scraped_data);
}

async function provisionSlugExists(slug: string): Promise<boolean> {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/properties?slug=eq.${encodeURIComponent(slug)}&select=id,host_id&limit=1`,
    { headers: adminHeaders() },
  );
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  if (!response.ok || !Array.isArray(rows) || rows.length === 0) return false;
  return Boolean(rows[0].id);
}

async function uniqueProvisionSlug(base: string, hostId: string): Promise<string> {
  const clean = slugifyProvision(base) || `stay-${hostId.slice(0, 8)}`;
  for (let index = 0; index < 25; index += 1) {
    const candidate = index === 0 ? clean : `${clean}-${index + 1}`;
    if (!(await provisionSlugExists(candidate))) return candidate;
  }
  return `${clean}-${Date.now().toString(36)}`;
}

function normaliseProvisionReviews(imported: Record<string, unknown>) {
  const rawReviews = Array.isArray(imported.reviews) ? imported.reviews : [];
  return rawReviews
    .map(recordValue)
    .map((review) => ({
      author: textValue(review.author, review.name, review.guestName, review.reviewerName) || null,
      date: textValue(review.date, review.createdAt, review.localizedDate) || null,
      text: textValue(review.text, review.body, review.comment, review.review) || null,
      rating: numberValue(review.rating, review.score),
      source: textValue(review.source, imported.reviewSource) || null,
    }))
    .filter((review) => review.text)
    .slice(0, 6);
}

function buildProvisionWebsiteContent(imported: Record<string, unknown>, sourceUrl: string) {
  const reviewSummary = recordValue(imported.reviewSummary);
  const host = recordValue(imported.host);
  const owner = recordValue(imported.owner);
  const profile = recordValue(imported.profile);
  const profiles = recordValue(imported.profiles);
  const hostProfile = recordValue(imported.hostProfile);
  const isAirbnbSource = /airbnb\./i.test(sourceUrl) || /airbnb/i.test(textValue(imported.source));
  const hostName = textValue(
    imported.hostName,
    imported.host_name,
    imported.ownerName,
    imported.owner_name,
    imported.hostDisplayName,
    imported.host_display_name,
    host.name,
    host.fullName,
    host.displayName,
    host.firstName,
    owner.name,
    owner.fullName,
    owner.displayName,
    profile.name,
    profiles.name,
    hostProfile.name,
  );
  const hostPhoto = textValue(
    imported.hostPhoto,
    imported.hostImage,
    imported.hostAvatar,
    imported.host_photo,
    imported.host_image,
    imported.ownerPhoto,
    imported.ownerImage,
    imported.profileImage,
    imported.avatar_url,
    host.photo,
    host.image,
    host.picture,
    host.avatar,
    host.pictureUrl,
    host.profilePictureUrl,
    owner.photo,
    owner.image,
    owner.avatar,
    profile.avatar_url,
    profile.image,
    profile.photo,
    profiles.avatar_url,
    hostProfile.pictureUrl,
    hostProfile.profilePictureUrl,
  );
  const hostBio = textValue(
    imported.hostBio,
    imported.hostAbout,
    imported.hostDescription,
    imported.host_bio,
    imported.host_about,
    imported.host_description,
    host.bio,
    host.about,
    host.description,
    owner.bio,
    owner.about,
    profile.bio,
    profiles.bio,
    hostProfile.bio,
    hostProfile.about,
    hostProfile.description,
  );
  const reviewRating = numberValue(reviewSummary.rating, imported.ratingAverage, imported.overallRating, imported.reviewRating, imported.rating);
  const reviewCount = numberValue(reviewSummary.count, imported.ratingCount, imported.overallCount, imported.reviewCount, imported.reviewsCount);
  const reviewSource = textValue(reviewSummary.source, imported.reviewSource, isAirbnbSource ? 'Airbnb' : '');
  const reviewUrl = textValue(reviewSummary.externalUrl, imported.reviewUrl, imported.reviewsUrl, isAirbnbSource ? sourceUrl : '');
  const reviews = normaliseProvisionReviews(imported);
  return {
    source_url: sourceUrl || null,
    logo_image: textValue(imported.logoImage) || null,
    virtual_tour_url: textValue(imported.googleTourUrl) || null,
    host: hostName || hostPhoto || hostBio ? {
      name: hostName || null,
      image: hostPhoto || null,
      bio: hostBio || null,
    } : null,
    review: reviewRating || reviewCount || reviewSource || reviewUrl ? {
      rating: reviewRating,
      count: reviewCount,
      source: reviewSource || null,
      externalUrl: reviewUrl || null,
    } : null,
    reviews: reviews.length ? reviews : null,
  };
}

async function buildProvisionPropertyPayload(input: {
  hostId: string;
  userEmail: string;
  metadata: Record<string, unknown>;
  body: ProvisionContext;
  previewRow: Record<string, unknown> | null;
}): Promise<Record<string, unknown>> {
  const templateId = selectedProvisionTemplate(input.body, input.previewRow);
  const bodyPreview = recordValue(input.body.previewData);
  const rowPreview = previewDataForProvision(input.previewRow, templateId);
  const usePreviewRow = provisionPreviewMatchesBody(input.previewRow, input.body, bodyPreview, rowPreview);
  if (input.previewRow && !usePreviewRow) {
    console.warn('[provision] ignored stale preview row for conversion', {
      previewId: textValue(input.previewRow.id),
      bodyUrl: textValue(input.body.importUrl, bodyPreview.sourceUrl, bodyPreview.url),
      rowUrl: textValue(input.previewRow.url, rowPreview.sourceUrl, rowPreview.url),
    });
  }
  const imported = {
    ...bodyPreview,
    ...(usePreviewRow ? rowPreview : {}),
  };
  const draft = recordValue(input.body.signupDraft);
  const name = textValue(draft.propertyName, imported.name, input.metadata.property_name, 'Your Property');
  const slug = await uniqueProvisionSlug(textValue(draft.subdomain, draft.slug, name), input.hostId);
  const sourceUrl = textValue(imported.sourceUrl, imported.url, input.previewRow?.url, input.body.importUrl);
  const contactEmail = textValue(imported.contactEmail, imported.email, input.userEmail);
  const contactPhone = textValue(imported.contactPhone, imported.phone);
  const shortDescription = textValue(imported.shortDescription, imported.summary, imported.description, `${name} is ready for direct bookings.`);
  const fullDescription = textValue(imported.fullDescription, imported.description, shortDescription);
  const images = stringArray(imported.images);
  const city = textValue(imported.city);
  const country = textValue(imported.country, 'New Zealand');
  const address = textValue(imported.address);
  const amenities = normaliseProvisionAmenities(imported.amenities, imported.amenityDetails);
  const maxGuests = numberValue(imported.maxGuests, imported.max_guests, 2) || 2;
  const basePrice = numberValue(imported.basePrice, imported.base_price, imported.nightlyPrice, 0) || 0;
  const theme = selectedProvisionTheme(templateId, input.body.selectedDashboardTheme);
  const accent = selectedProvisionAccent(input.body, templateId, imported);
  const now = new Date().toISOString();

  return {
    host_id: input.hostId,
    name,
    type: textValue(imported.type, 'guest accommodation'),
    address,
    suburb: textValue(imported.suburb),
    city,
    country,
    latitude: numberValue(imported.latitude),
    longitude: numberValue(imported.longitude),
    google_place_id: textValue(imported.google_place_id, imported.googlePlaceId, imported.placeId) || null,
    bedrooms: numberValue(imported.bedrooms, 1) || 1,
    bathrooms: numberValue(imported.bathrooms, 1) || 1,
    max_guests: maxGuests,
    occupancy: maxGuests,
    base_price: basePrice,
    nightly_price: basePrice,
    cleaning_fee: numberValue(imported.cleaningFee, imported.cleaning_fee, 0) || 0,
    tax_rate: numberValue(imported.taxRate, imported.tax_rate, 15) || 15,
    min_nights: numberValue(imported.minNights, imported.min_nights, 1) || 1,
    short_description: shortDescription,
    full_description: fullDescription,
    amenities,
    images,
    check_in_time: textValue(imported.checkInTime, imported.check_in_time, '15:00'),
    check_out_time: textValue(imported.checkOutTime, imported.check_out_time, '10:00'),
    pets_allowed: boolValue(imported.petsAllowed, /\bpet|dog/i.test([...amenities, fullDescription].join(' '))),
    smoking_allowed: boolValue(imported.smokingAllowed, false),
    events_allowed: boolValue(imported.eventsAllowed, false),
    accent_color: accent,
    theme,
    slug,
    custom_domain: null,
    stripe_publishable_key: null,
    contact_email: contactEmail || null,
    contact_phone: contactPhone || null,
    contact_email_visible: Boolean(contactEmail),
    contact_phone_visible: Boolean(contactPhone),
    contact_preference: contactPhone ? 'either' : 'email',
    staydirect_email_alias: `${slug.replace(/-/g, '').slice(0, 32)}@staydirect.nz`,
    website_content: buildProvisionWebsiteContent(imported, sourceUrl),
    status: 'live',
    marketplace_enabled: true,
    marketplace_status: 'published',
    marketplace_headline: name,
    marketplace_short_description: shortDescription,
    marketplace_featured_image: images[0] || null,
    marketplace_booking_mode: 'host_site',
    marketplace_destination: slugifyProvision(city || country || 'new-zealand'),
    marketplace_tags: [],
    marketplace_search_priority: 0,
    marketplace_featured: false,
    marketplace_quality_score: images.length ? 70 : 45,
    marketplace_conversion_score: 0,
    instant_booking: false,
    created_at: now,
    updated_at: now,
  };
}

async function fetchProvisionPropertyForHost(propertyId: string, hostId: string): Promise<Record<string, unknown> | null> {
  if (!propertyId || !hostId) return null;
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}&host_id=eq.${encodeURIComponent(hostId)}&select=id,slug&limit=1`,
    { headers: adminHeaders() },
  );
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  if (!response.ok || !Array.isArray(rows) || !rows[0]?.id) return null;
  return rows[0];
}

async function fetchLatestProvisionPropertyForHost(hostId: string): Promise<Record<string, unknown> | null> {
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/properties?host_id=eq.${encodeURIComponent(hostId)}&select=id,slug&order=created_at.desc&limit=1`,
    { headers: adminHeaders() },
  );
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  if (!response.ok || !Array.isArray(rows) || !rows[0]?.id) return null;
  return rows[0];
}

async function ensureProvisionedProperty(userId: string, userEmail: string, metadata: Record<string, unknown>, body: ProvisionContext) {
  const previewId = textValue(body.previewId);
  const previewRow = await loadProvisionPreviewRow(previewId);
  const templateId = selectedProvisionTemplate(body, previewRow);
  const bodyPreview = recordValue(body.previewData);
  const rowPreview = previewDataForProvision(previewRow, templateId);
  const usePreviewRow = provisionPreviewMatchesBody(previewRow, body, bodyPreview, rowPreview);
  const effectivePreviewRow = usePreviewRow ? previewRow : null;
  const conversionIntent = hasFreshConversionIntent(body, userEmail);

  if (previewRow && !usePreviewRow) {
    console.warn('[provision] preview id did not match current signup payload; using browser preview data instead', {
      previewId: textValue(previewRow.id),
      bodyUrl: textValue(body.importUrl, bodyPreview.sourceUrl, bodyPreview.url),
      rowUrl: textValue(previewRow.url, rowPreview.sourceUrl, rowPreview.url),
    });
  }

  const convertedPropertyId = effectivePreviewRow ? textValue(effectivePreviewRow.converted_property_id) : '';
  if (conversionIntent && convertedPropertyId) {
    const converted = await fetchProvisionPropertyForHost(convertedPropertyId, userId);
    if (converted?.id) {
      try {
        const seedResult = await seedStarterGuidebookForProperty(String(converted.id), userId);
        console.log('[provision] starter guidebook checked for converted property', seedResult);
      } catch (error) {
        console.warn('[provision] starter guidebook check failed', error);
      }
      return converted;
    }
  }

  const existing = await fetchLatestProvisionPropertyForHost(userId);
  if (!conversionIntent && existing?.id) {
    try {
      const seedResult = await seedStarterGuidebookForProperty(String(existing.id), userId);
      console.log('[provision] starter guidebook checked for existing property', seedResult);
    } catch (error) {
      console.warn('[provision] starter guidebook check failed', error);
    }
    return existing;
  }

  const payload = await buildProvisionPropertyPayload({
    hostId: userId,
    userEmail,
    metadata,
    body,
    previewRow: effectivePreviewRow,
  });
  const { row, removedColumns } = await adminInsertReturning('properties', payload, 'id,slug');

  if (removedColumns.size > 0) {
    console.warn('[provision] created property without unsupported columns', Array.from(removedColumns));
  }

  if (previewId && effectivePreviewRow && row.id) {
    await adminPatchWithFallback(
      'preview_sessions',
      `id=eq.${encodeURIComponent(previewId)}`,
      {
        status: 'converted',
        selected_template: textValue(body.selectedTemplate) || textValue(effectivePreviewRow.selected_template) || null,
        converted_at: new Date().toISOString(),
        converted_property_id: row.id,
      },
    );
  }

  if (row.id) {
    try {
      const seedResult = await seedStarterGuidebookForProperty(String(row.id), userId);
      console.log('[provision] starter guidebook seeded', seedResult);
    } catch (error) {
      console.warn('[provision] starter guidebook seed failed', error);
    }
  }

  console.log('[provision] created live property from signup', {
    userId,
    propertyId: row.id,
    slug: row.slug,
    conversionIntent,
    previewId: previewId || null,
  });
  return row;
}

// ---------- /api/auth/signup ----------
async function handleSignup(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured. Missing Supabase credentials.' });
    return;
  }
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const name = String(body.name || '');
  const propertyName = String(body.propertyName || '');
  if (!email || !password) {
    sendJson(res, 400, { error: 'Email and password are required.' });
    return;
  }
  const response = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
    method: 'POST',
    headers: adminHeaders(),
    body: JSON.stringify({
      email, password, email_confirm: true,
      user_metadata: { name, property_name: propertyName },
    }),
  });
  const data = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const errorCode = String(data.error_code || data.code || '');
    const rawMessage = (data.msg as string) || (data.message as string) || (data.error as string) || (data.error_description as string) || '';
    const details = String(data.details || data.detail || '');
    const hint = String(data.hint || '');
    const internalCode = String(data.internal_error_code || data.internal_code || data.code || '');
    const errorId = String(data.error_id || '');
    console.error('[signup] Supabase admin user creation failed', {
      httpStatus: response.status,
      errorCode,
      message: rawMessage,
      details: details || undefined,
      hint: hint || undefined,
      internalCode: internalCode || undefined,
      errorId: errorId || undefined,
      email,
    });
    if (errorCode === 'email_exists' || /already (been )?registered|already exists|user already/i.test(rawMessage)) {
      sendJson(res, 409, { error: 'An account already exists with this email address. Please log in or reset your password.' });
      return;
    }
    if (errorCode === 'unexpected_failure' && /database error/i.test(rawMessage)) {
      console.error('[signup] LIKELY CAUSE: auth.users trigger (handle_new_user) is failing. ' +
        'Apply supabase/migrations/202606060002_fix_auth_trigger.sql via Supabase Dashboard > SQL Editor. ' +
        (errorId ? 'Supabase error_id for Dashboard logs: ' + errorId : ''));
    }
    // Translate common Supabase database-level errors into user-readable messages
    const userMessage = classifySignupError(rawMessage, details, errorCode);
    sendJson(res, response.status, { error: userMessage });
    return;
  }
  sendJson(res, 200, { ok: true });
}

// ---------- /api/auth/provision ----------
async function handleProvision(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const authHeader = req.headers['authorization'] || '';
  const accessToken = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!accessToken) {
    sendJson(res, 401, { error: 'Missing access token.' });
    return;
  }
  const body = await readJsonBody(req) as ProvisionContext;
  const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${accessToken}` },
  });
  const userData = await userRes.json().catch(() => ({})) as Record<string, unknown>;
  if (!userRes.ok || !userData.id) {
    sendJson(res, 401, { error: 'Invalid or expired session.' });
    return;
  }
  const userId = userData.id as string;
  const userEmail = (userData.email as string) || '';
  const metadata = (userData.user_metadata as Record<string, unknown>) || {};
  const name = String(metadata.name || userEmail.split('@')[0] || '');
  const restHeaders = adminHeaders({ 'Prefer': 'resolution=ignore-duplicates' });
  await fetch(`${SUPABASE_URL}/rest/v1/profiles`, {
    method: 'POST', headers: restHeaders,
    body: JSON.stringify({ id: userId, name, email: userEmail }),
  });
  const subRes = await fetch(`${SUPABASE_URL}/rest/v1/subscriptions?host_id=eq.${userId}&select=id`, {
    headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${SERVICE_ROLE_KEY}` },
  });
  const existing = await subRes.json().catch(() => []) as unknown[];
  const isNewAccount = !Array.isArray(existing) || existing.length === 0;
  if (isNewAccount) {
    const trialEndsAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
    await fetch(`${SUPABASE_URL}/rest/v1/subscriptions`, {
      method: 'POST', headers: restHeaders,
      body: JSON.stringify({ host_id: userId, plan: 'simple', status: 'trialing', trial_ends_at: trialEndsAt }),
    });
    // Send welcome email for new accounts (fire-and-forget — never blocks sign-in)
    if (userEmail && RESEND_API_KEY) {
      const propertyName = String(metadata.property_name || '').trim();
      const dashboardUrl = 'https://staydirect.nz/dashboard';
      const welcomeHtml = `<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:0 auto;padding:32px 24px;color:#222">
  <h2 style="margin:0 0 16px;color:#FF5A5F">Welcome to StayDirect${name ? `, ${escapeHtml(name)}` : ''}!</h2>
  ${propertyName
    ? `<p style="font-size:15px;line-height:1.6;margin:0 0 16px">You're setting up <strong>${escapeHtml(propertyName)}</strong> — your 14&#8209;day free trial has started.</p>`
    : '<p style="font-size:15px;line-height:1.6;margin:0 0 16px">Your 14&#8209;day free trial has started. Head to your dashboard to begin setting up your property.</p>'}
  <div style="background:#FFF1F3;border-radius:12px;padding:20px;margin:16px 0">
    <p style="margin:0 0 10px;font-weight:600;color:#484848">Your host dashboard</p>
    <p style="margin:0"><a href="${escapeHtml(dashboardUrl)}" style="color:#FF5A5F">${escapeHtml(dashboardUrl)}</a></p>
  </div>
  <p style="font-size:15px;font-weight:600;margin:20px 0 8px;color:#484848">Get started in 3 steps</p>
  <ol style="font-size:14px;line-height:2;margin:0;padding-left:20px;color:#484848">
    <li>Import your listing or fill in your property details</li>
    <li>Set your pricing, availability, and house rules</li>
    <li>Go live — share your direct booking link with guests</li>
  </ol>
  <p style="margin-top:28px"><a href="${escapeHtml(dashboardUrl)}" style="display:inline-block;background:#FF5A5F;color:#fff;padding:12px 22px;border-radius:10px;text-decoration:none;font-weight:600;font-size:15px">Complete Your Setup →</a></p>
  <p style="font-size:13px;color:#ababab;margin-top:24px">14&#8209;day free trial — no credit card required to get started.</p>
  <p style="font-size:13px;color:#ababab;margin-top:4px">StayDirect — direct bookings, zero commission</p>
</div>`;
      void sendResendEmail({
        to: userEmail,
        subject: 'Welcome to StayDirect — your account is ready',
        html: welcomeHtml,
      }).then((result) => {
        if (!result.ok) console.warn('[provision] welcome email failed:', result.error);
        else console.log('[provision] welcome email sent to:', userEmail);
      });
    }
  }

  // Ensure Deloraine property exists for the real owner
  let propertyRow: Record<string, unknown> | null = null;
  try {
    if (userEmail.trim().toLowerCase() === 'hello@delorainecottage.com') {
      await ensureDeloraineProperty(userId);
    } else {
      propertyRow = await ensureProvisionedProperty(userId, userEmail, metadata, body);
    }
  } catch (error) {
    console.error('[provision] property conversion failed', error);
    sendJson(res, 500, { error: 'Account created, but the live property could not be created from the selected preview. Please contact StayDirect support before trying again.' });
    return;
  }

  sendJson(res, 200, { ok: true, property: propertyRow });
}

async function ensureDeloraineProperty(userId: string) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) return;
  const DELORAINE_ID = '70905e83-f782-4501-9f40-12114153ff73';
  const DELORAINE_SLUG = 'delorainecottage';
  const DELORAINE_DOMAIN = 'delorainecottage.com';

  // 0. If the property already exists, only ensure the owner is linked. Never
  // overwrite host-edited content (custom_domain, pricing, copy, images, etc.)
  // on subsequent logins — that would clobber the redirect domain and any edits.
  const existingByIdRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${DELORAINE_ID}&select=id`, {
    headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${SERVICE_ROLE_KEY}` },
  });
  if (existingByIdRes.ok) {
    const rows = await existingByIdRes.json().catch(() => []) as unknown[];
    if (Array.isArray(rows) && rows.length > 0) {
      const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${DELORAINE_ID}`, {
        method: 'PATCH',
        headers: adminHeaders(),
        body: JSON.stringify({ host_id: userId }),
      });
      if (patchRes.ok) {
        console.log('[Deloraine Provision] Linked existing property to owner', userId);
      } else {
        console.warn('[Deloraine Provision] host_id link failed:', patchRes.status);
      }
      return;
    }
  }

  // 1. No row by canonical ID yet — seed full content (runs once, on creation).
  const upsertRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${DELORAINE_ID}`, {
    method: 'POST',
    headers: adminHeaders({
      'Prefer': 'resolution=merge-duplicates,return=representation',
      'Content-Type': 'application/json',
    }),
    body: JSON.stringify({
      id: DELORAINE_ID,
      host_id: userId,
      name: 'Deloraine Stone Cottage',
      type: 'cottage',
      address: '50 Konini Street, Whangarei, Northland, New Zealand 0112',
      city: 'Whangarei',
      country: 'New Zealand',
      bedrooms: 3,
      bathrooms: 1,
      max_guests: 6,
      base_price: 220,
      cleaning_fee: 75,
      tax_rate: 15,
      min_nights: 2,
      short_description: 'A peaceful stone cottage set in flowering rural gardens near Whangarei.',
      full_description: 'Deloraine Stone Cottage is set in a beautiful rural landscape amongst flowering gardens. The cottage has three king bedrooms, a fully self-contained kitchen, dining for six, laundry facilities, flat-screen TV, outdoor pool access, fire pit, playground and peaceful garden views.',
      amenities: ['wifi', 'parking', 'pool', 'kitchen', 'ac', 'tv', 'washer', 'dryer', 'dishwasher', 'bbq', 'heating'],
      images: [
        'https://l.icdbcdn.com/oh/834ba443-1e56-46dc-849c-a2d02a313aaf.jpg?w=1200',
        'https://l.icdbcdn.com/oh/0a338506-1f2b-46af-82d0-e3e4b975cd7e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/4f1473c0-fddb-4a8d-b138-b879ab01ccf5.jpg?w=1200',
        'https://l.icdbcdn.com/oh/d02ab761-b9d3-4357-93ab-7abfce458dea.jpg?w=1200',
        'https://l.icdbcdn.com/oh/d7414d8d-fbd3-4117-ba4f-9f77990ead8b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/bb377649-e280-483c-b749-f7e5ea2a7664.jpg?w=1200',
        'https://l.icdbcdn.com/oh/57513ed9-1464-4cdb-993a-cf59aea2f253.jpg?w=1200',
        'https://l.icdbcdn.com/oh/dec277fd-9092-4233-8ae8-6f969438398e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/221d4e68-8dfc-4902-a1e3-0fc764a34ee1.jpg?w=1200',
        'https://l.icdbcdn.com/oh/199763d1-8013-4861-b0a9-c1e44cde987b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/b14ca382-c4c2-4181-ac63-1d900b15bd9c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/97879185-c929-4439-8f7f-7b3669f6827e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/6276ef0f-dc25-4502-ae42-3514dae15743.jpg?w=1200',
        'https://l.icdbcdn.com/oh/3951d2c5-0a95-4adf-9fd0-91dcb1037574.jpg?w=1200',
        'https://l.icdbcdn.com/oh/822ae858-c979-4bf3-bfe8-aedce831b10a.jpg?w=1200',
        'https://l.icdbcdn.com/oh/64127bec-b2b8-43ce-8e50-c45979f87a99.jpg?w=1200',
        'https://l.icdbcdn.com/oh/b17979a6-b354-4725-962c-0de5f38a79bb.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fa780137-3274-4ddb-a9cf-444072334f8d.jpg?w=1200',
        'https://l.icdbcdn.com/oh/75407d66-3598-47f3-aef9-01e33b0be573.jpg?w=1200',
        'https://l.icdbcdn.com/oh/4cf8324f-a31d-45e5-91a6-0bb7f5f154b4.jpg?w=1200',
        'https://l.icdbcdn.com/oh/394b0c5f-4819-41cc-957a-0dee7b1a18c8.jpg?w=1200',
        'https://l.icdbcdn.com/oh/af02677c-f4d3-43e6-9d2d-186aef88edbc.jpg?w=1200',
        'https://l.icdbcdn.com/oh/bd8639df-2ded-4100-9315-1a46b043b6cb.jpg?w=1200',
        'https://l.icdbcdn.com/oh/225fecaf-fa0d-4e54-bf48-2150a928a44c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/409ffef5-b588-4289-afd6-3360907009fd.jpg?w=1200',
        'https://l.icdbcdn.com/oh/af1521ab-c82a-4623-8aed-343d04e98110.jpg?w=1200',
        'https://l.icdbcdn.com/oh/7524bb71-2138-463f-a573-42790528e198.jpg?w=1200',
        'https://l.icdbcdn.com/oh/368c6d27-7875-4e61-84ed-482e7308e762.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8babe40d-57d8-40a4-8072-5d2155fd8f21.jpg?w=1200',
        'https://l.icdbcdn.com/oh/f5483fec-71fd-477f-9b3f-616db6c10f3c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/2acc5193-69ad-4d97-87db-6c55f012e3a6.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8f48e940-7d9a-4ffd-b12e-727a393ba03b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fe187c0a-027d-4a94-b56d-73a630308059.jpg?w=1200',
        'https://l.icdbcdn.com/oh/ede56d76-079a-4bcd-a686-7434d5f593c5.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8962baaa-f2ed-4ef6-b60e-7e163b4e5136.jpg?w=1200',
        'https://l.icdbcdn.com/oh/5f5e223f-2556-43e0-838e-802ffbfceb2d.jpg?w=1200',
        'https://l.icdbcdn.com/oh/e8db56c5-b550-4d18-9c02-8365a8ed3085.jpg?w=1200',
        'https://l.icdbcdn.com/oh/0be46b11-ad95-499d-a711-85d71611dee4.jpg?w=1200',
        'https://l.icdbcdn.com/oh/48faa011-2cc4-497c-8601-955031ecf176.jpg?w=1200',
        'https://l.icdbcdn.com/oh/79796ccd-6aa6-4445-9be8-9cc709f7bca1.jpg?w=1200',
        'https://l.icdbcdn.com/oh/56f0f0a6-e47d-44c3-a25b-a8748c2b4d78.jpg?w=1200',
        'https://l.icdbcdn.com/oh/52807e7f-07db-4f65-bad5-ac397c360813.jpg?w=1200',
        'https://l.icdbcdn.com/oh/002981d5-f401-4c9a-9539-acc3e505c299.jpg?w=1200',
        'https://l.icdbcdn.com/oh/eff292df-d68b-4b5e-bfae-e179a218f50.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fe43af5b-0714-479d-a911-eeab4bc8186b.png?w=1200',
        'https://l.icdbcdn.com/oh/60cd4721-6378-4ebb-95f3-ef3f1a7a05d3.jpg?w=1200',
      ],
      check_in_time: '15:00',
      check_out_time: '10:00',
      pets_allowed: false,
      smoking_allowed: false,
      events_allowed: false,
      accent_color: '#aa7942',
      theme: 'onepage',
      slug: DELORAINE_SLUG,
      custom_domain: DELORAINE_DOMAIN,
      stripe_publishable_key: null,
      contact_email: 'hello@delorainecottage.com',
      contact_phone: '+64 21 920 552',
      updated_at: new Date().toISOString(),
    }),
  });

  if (upsertRes.ok) {
    console.log('[Deloraine Provision] Upserted property for', userId);
    return;
  }

  // 2. If upsert failed (e.g. id conflict resolution unsupported), try by canonical slug
  const propRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?slug=eq.${DELORAINE_SLUG}&select=id`, {
    headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${SERVICE_ROLE_KEY}` },
  });
  if (!propRes.ok) {
    console.warn('[Deloraine Provision] Failed to query by slug:', propRes.status);
    return;
  }
  const existingProps = await propRes.json().catch(() => []) as unknown[];
  if (Array.isArray(existingProps) && existingProps.length > 0) {
    const propId = (existingProps[0] as { id: string }).id;
    const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${propId}`, {
      method: 'PATCH',
      headers: adminHeaders({ 'Prefer': 'resolution=merge-duplicates' }),
      body: JSON.stringify({ host_id: userId }),
    });
    if (patchRes.ok) {
      console.log('[Deloraine Provision] Patched existing property host_id for', userId);
    } else {
      console.warn('[Deloraine Provision] Patch failed:', patchRes.status);
    }
    return;
  }

  // 3. If no property by slug, try by custom domain
  const domainRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?custom_domain=eq.${DELORAINE_DOMAIN}&select=id`, {
    headers: { 'apikey': SERVICE_ROLE_KEY, 'Authorization': `Bearer ${SERVICE_ROLE_KEY}` },
  });
  if (domainRes.ok) {
    const domainProps = await domainRes.json().catch(() => []) as unknown[];
    if (Array.isArray(domainProps) && domainProps.length > 0) {
      const propId = (domainProps[0] as { id: string }).id;
      const patchRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${propId}`, {
        method: 'PATCH',
        headers: adminHeaders({ 'Prefer': 'resolution=merge-duplicates' }),
        body: JSON.stringify({ host_id: userId }),
      });
      if (patchRes.ok) {
        console.log('[Deloraine Provision] Patched property by domain for', userId);
      } else {
        console.warn('[Deloraine Provision] Domain patch failed:', patchRes.status);
      }
      return;
    }
  }

  // 4. Last resort: create the property with the canonical ID
  const createRes = await fetch(`${SUPABASE_URL}/rest/v1/properties`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'return=representation' }),
    body: JSON.stringify({
      id: DELORAINE_ID,
      host_id: userId,
      name: 'Deloraine Stone Cottage',
      type: 'cottage',
      address: '50 Konini Street, Whangarei, Northland, New Zealand 0112',
      city: 'Whangarei',
      country: 'New Zealand',
      bedrooms: 3,
      bathrooms: 1,
      max_guests: 6,
      base_price: 220,
      cleaning_fee: 75,
      tax_rate: 15,
      min_nights: 2,
      short_description: 'A peaceful stone cottage set in flowering rural gardens near Whangarei.',
      full_description: 'Deloraine Stone Cottage is set in a beautiful rural landscape amongst flowering gardens. The cottage has three king bedrooms, a fully self-contained kitchen, dining for six, laundry facilities, flat-screen TV, outdoor pool access, fire pit, playground and peaceful garden views.',
      amenities: ['wifi', 'parking', 'pool', 'kitchen', 'ac', 'tv', 'washer', 'dryer', 'dishwasher', 'bbq', 'heating'],
      images: [
        'https://l.icdbcdn.com/oh/834ba443-1e56-46dc-849c-a2d02a313aaf.jpg?w=1200',
        'https://l.icdbcdn.com/oh/0a338506-1f2b-46af-82d0-e3e4b975cd7e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/4f1473c0-fddb-4a8d-b138-b879ab01ccf5.jpg?w=1200',
        'https://l.icdbcdn.com/oh/d02ab761-b9d3-4357-93ab-7abfce458dea.jpg?w=1200',
        'https://l.icdbcdn.com/oh/d7414d8d-fbd3-4117-ba4f-9f77990ead8b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/bb377649-e280-483c-b749-f7e5ea2a7664.jpg?w=1200',
        'https://l.icdbcdn.com/oh/57513ed9-1464-4cdb-993a-cf59aea2f253.jpg?w=1200',
        'https://l.icdbcdn.com/oh/dec277fd-9092-4233-8ae8-6f969438398e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/221d4e68-8dfc-4902-a1e3-0fc764a34ee1.jpg?w=1200',
        'https://l.icdbcdn.com/oh/199763d1-8013-4861-b0a9-c1e44cde987b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/b14ca382-c4c2-4181-ac63-1d900b15bd9c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/97879185-c929-4439-8f7f-7b3669f6827e.jpg?w=1200',
        'https://l.icdbcdn.com/oh/6276ef0f-dc25-4502-ae42-3514dae15743.jpg?w=1200',
        'https://l.icdbcdn.com/oh/3951d2c5-0a95-4adf-9fd0-91dcb1037574.jpg?w=1200',
        'https://l.icdbcdn.com/oh/822ae858-c979-4bf3-bfe8-aedce831b10a.jpg?w=1200',
        'https://l.icdbcdn.com/oh/64127bec-b2b8-43ce-8e50-c45979f87a99.jpg?w=1200',
        'https://l.icdbcdn.com/oh/b17979a6-b354-4725-962c-0de5f38a79bb.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fa780137-3274-4ddb-a9cf-444072334f8d.jpg?w=1200',
        'https://l.icdbcdn.com/oh/75407d66-3598-47f3-aef9-01e33b0be573.jpg?w=1200',
        'https://l.icdbcdn.com/oh/4cf8324f-a31d-45e5-91a6-0bb7f5f154b4.jpg?w=1200',
        'https://l.icdbcdn.com/oh/394b0c5f-4819-41cc-957a-0dee7b1a18c8.jpg?w=1200',
        'https://l.icdbcdn.com/oh/af02677c-f4d3-43e6-9d2d-186aef88edbc.jpg?w=1200',
        'https://l.icdbcdn.com/oh/bd8639df-2ded-4100-9315-1a46b043b6cb.jpg?w=1200',
        'https://l.icdbcdn.com/oh/225fecaf-fa0d-4e54-bf48-2150a928a44c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/409ffef5-b588-4289-afd6-3360907009fd.jpg?w=1200',
        'https://l.icdbcdn.com/oh/af1521ab-c82a-4623-8aed-343d04e98110.jpg?w=1200',
        'https://l.icdbcdn.com/oh/7524bb71-2138-463f-a573-42790528e198.jpg?w=1200',
        'https://l.icdbcdn.com/oh/368c6d27-7875-4e61-84ed-482e7308e762.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8babe40d-57d8-40a4-8072-5d2155fd8f21.jpg?w=1200',
        'https://l.icdbcdn.com/oh/f5483fec-71fd-477f-9b3f-616db6c10f3c.jpg?w=1200',
        'https://l.icdbcdn.com/oh/2acc5193-69ad-4d97-87db-6c55f012e3a6.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8f48e940-7d9a-4ffd-b12e-727a393ba03b.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fe187c0a-027d-4a94-b56d-73a630308059.jpg?w=1200',
        'https://l.icdbcdn.com/oh/ede56d76-079a-4bcd-a686-7434d5f593c5.jpg?w=1200',
        'https://l.icdbcdn.com/oh/8962baaa-f2ed-4ef6-b60e-7e163b4e5136.jpg?w=1200',
        'https://l.icdbcdn.com/oh/5f5e223f-2556-43e0-838e-802ffbfceb2d.jpg?w=1200',
        'https://l.icdbcdn.com/oh/e8db56c5-b550-4d18-9c02-8365a8ed3085.jpg?w=1200',
        'https://l.icdbcdn.com/oh/0be46b11-ad95-499d-a711-85d71611dee4.jpg?w=1200',
        'https://l.icdbcdn.com/oh/48faa011-2cc4-497c-8601-955031ecf176.jpg?w=1200',
        'https://l.icdbcdn.com/oh/79796ccd-6aa6-4445-9be8-9cc709f7bca1.jpg?w=1200',
        'https://l.icdbcdn.com/oh/56f0f0a6-e47d-44c3-a25b-a8748c2b4d78.jpg?w=1200',
        'https://l.icdbcdn.com/oh/52807e7f-07db-4f65-bad5-ac397c360813.jpg?w=1200',
        'https://l.icdbcdn.com/oh/002981d5-f401-4c9a-9539-acc3e505c299.jpg?w=1200',
        'https://l.icdbcdn.com/oh/eff292df-d68b-4b5e-bfae-e179a218f50.jpg?w=1200',
        'https://l.icdbcdn.com/oh/fe43af5b-0714-479d-a911-eeab4bc8186b.png?w=1200',
        'https://l.icdbcdn.com/oh/60cd4721-6378-4ebb-95f3-ef3f1a7a05d3.jpg?w=1200',
      ],
      check_in_time: '15:00',
      check_out_time: '10:00',
      pets_allowed: false,
      smoking_allowed: false,
      events_allowed: false,
      accent_color: '#aa7942',
      theme: 'onepage',
      slug: DELORAINE_SLUG,
      custom_domain: DELORAINE_DOMAIN,
      stripe_publishable_key: null,
      contact_email: 'hello@delorainecottage.com',
      contact_phone: '+64 21 920 552',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }),
  });

  if (createRes.ok) {
    console.log('[Deloraine Provision] Created property for', userId);
  } else {
    console.warn('[Deloraine Provision] Create failed:', createRes.status);
  }
}

// ---------- /api/bookings ----------
async function handleCreateBooking(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const body = await readJsonBody(req);

  const bookingId = String(body.booking_id || body.id || '').trim();
  const propertyId = String(body.property_id || '').trim();
  const guestName = String(body.guest_name || '').trim();
  const guestEmail = String(body.guest_email || '').trim().toLowerCase();
  const guestPhone = String(body.guest_phone || '').trim();
  const checkIn = String(body.check_in || '').trim();
  const checkOut = String(body.check_out || '').trim();
  const guests = Math.max(1, Math.floor(Number(body.guests) || 1));
  const nights = Math.max(1, Math.floor(Number(body.nights) || 1));
  const total = Number(body.total) || 0;
  const notes = String(body.notes || '');
  const stripePaymentIntentId = String(body.stripe_payment_intent_id || '').trim();
  const requestedStatus = String(body.status || '').trim().toLowerCase();
  const promotionId = String(body.promotion_id || '').trim();
  const promotionCode = String(body.promotion_code || '').trim().toUpperCase();
  const promotionDiscount = Math.max(0, Number(body.promotion_discount) || 0);
  const totalBeforeDiscount = Number(body.total_before_discount) || total;
  const promotionSnapshot = body.promotion_snapshot && typeof body.promotion_snapshot === 'object' ? body.promotion_snapshot : {};
  const upsells = Array.isArray(body.upsells)
    ? body.upsells
      .filter((item: unknown) => item && typeof item === 'object')
      .map((item: any) => {
        const quantity = Math.max(1, Math.floor(Number(item.quantity) || 1));
        const price = Math.max(0, Number(item.price ?? item.calculatedPrice ?? 0) || 0);
        return {
          id: item.id ?? null,
          icon: String(item.icon || '✨'),
          name: String(item.name || 'Stay enhancement'),
          description: String(item.description || ''),
          imageUrl: item.imageUrl || item.image_url || null,
          price,
          priceType: String(item.priceType || item.price_type || 'flat'),
          quantity,
          source: ['checkout', 'manual', 'check_in_email'].includes(item.source) ? item.source : 'checkout',
          addedAt: item.addedAt || item.added_at || new Date().toISOString(),
          paymentState: ['included', 'pending', 'paid', 'refunded'].includes(item.paymentState || item.payment_state)
            ? (item.paymentState || item.payment_state)
            : stripePaymentIntentId ? 'paid' : 'pending',
          addedBy: ['guest', 'host', 'automation'].includes(item.addedBy || item.added_by)
            ? (item.addedBy || item.added_by)
            : 'guest',
          chargeMode: ['pay_now', 'pay_later', 'add_to_balance'].includes(item.chargeMode || item.charge_mode)
            ? (item.chargeMode || item.charge_mode)
            : stripePaymentIntentId ? 'pay_now' : 'add_to_balance',
        };
      })
    : [];
  const declaredUpsellTotal = Number(body.upsell_total ?? body.upsellTotal);
  const upsellTotal = Number.isFinite(declaredUpsellTotal)
    ? Math.max(0, declaredUpsellTotal)
    : upsells.reduce((sum: number, item: any) => sum + Number(item.price || 0) * Number(item.quantity || 1), 0);

  if (!bookingId) { sendJson(res, 400, { error: 'booking_id is required.' }); return; }
  if (!propertyId) { sendJson(res, 400, { error: 'property_id is required.' }); return; }
  if (!guestName) { sendJson(res, 400, { error: 'guest_name is required.' }); return; }
  if (!guestEmail) { sendJson(res, 400, { error: 'guest_email is required.' }); return; }
  if (!checkIn || !checkOut) { sendJson(res, 400, { error: 'check_in and check_out are required.' }); return; }
  if (new Date(checkOut).getTime() <= new Date(checkIn).getTime()) {
    sendJson(res, 400, { error: 'check_out must be after check_in.' });
    return;
  }

  const context = await fetchPropertyContext(propertyId);
  if (!context.host_id) {
    sendJson(res, 404, { error: 'Property not found.' });
    return;
  }
  // Always use the authoritative host from the property record — never trust the caller-supplied host_id.
  const hostId = context.host_id;
  const bookingStatus = stripePaymentIntentId
    ? 'confirmed'
    : requestedStatus === 'confirmed'
      ? 'confirmed'
      : 'pending';
  const isBookingRequest = bookingStatus === 'pending' && !stripePaymentIntentId;

  let validatedPromotion: ReturnType<typeof normalizePromotionRow> | null = null;
  if (promotionCode && !promotionId.startsWith('local-')) {
    validatedPromotion = await fetchPromotionForProperty(propertyId, promotionCode);
    const promoQuote = quotePromotionApi(validatedPromotion, {
      ...body,
      checkIn,
      checkOut,
      nights,
      bookingSource: 'direct',
    });
    if (!promoQuote.ok) {
      sendJson(res, 400, { error: promoQuote.message || 'Promo code could not be applied.' });
      return;
    }
    if (Math.abs(promoQuote.discountAmount - promotionDiscount) > 1) {
      sendJson(res, 400, { error: 'Promo code totals changed. Please review the booking total and try again.' });
      return;
    }
  }

  // Check for overlapping confirmed bookings
  const overlapUrl = `${SUPABASE_URL}/rest/v1/bookings?property_id=eq.${encodeURIComponent(propertyId)}&status=neq.cancelled&select=id,check_in,check_out`;
  const overlapRes = await fetch(overlapUrl, { headers: adminHeaders() });
  const existing = await overlapRes.json().catch(() => []) as Array<Record<string, unknown>>;
  const requestedIn = new Date(checkIn).getTime();
  const requestedOut = new Date(checkOut).getTime();
  const conflict = Array.isArray(existing) && existing.some((b) => {
    const eIn = new Date(String(b.check_in)).getTime();
    const eOut = new Date(String(b.check_out)).getTime();
    return requestedIn < eOut && requestedOut > eIn;
  });
  if (conflict) {
    sendJson(res, 409, { error: 'Those dates are no longer available. Please choose different dates.' });
    return;
  }

  const insertPayload: Record<string, unknown> = {
    id: bookingId,
    property_id: propertyId,
    host_id: hostId,
    guest_name: guestName,
    guest_email: guestEmail,
    guest_phone: guestPhone,
    check_in: checkIn,
    check_out: checkOut,
    guests, nights, total,
    status: bookingStatus,
    payment_status: stripePaymentIntentId ? 'paid' : 'pending',
    notes,
    upsells,
    upsell_total: upsellTotal,
    booking_date: new Date().toISOString(),
  };
  if (promotionCode && promotionDiscount > 0) {
    insertPayload.promotion_id = promotionId && !promotionId.startsWith('local-') ? promotionId : null;
    insertPayload.promotion_code = promotionCode;
    insertPayload.promotion_discount = promotionDiscount;
    insertPayload.promotion_snapshot = promotionSnapshot;
    insertPayload.total_before_discount = totalBeforeDiscount;
  }

  let insertRes = await fetch(`${SUPABASE_URL}/rest/v1/bookings`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'return=representation' }),
    body: JSON.stringify(insertPayload),
  });
  let inserted = await insertRes.json().catch(() => null);
  if (!insertRes.ok && (promotionCode || upsells.length)) {
    const err = Array.isArray(inserted) ? inserted[0] : inserted;
    const errMsg = (err && String((err as Record<string, unknown>).message || '')) || '';
    if (/promotion_|total_before_discount|upsells|upsell_total|column .* does not exist/i.test(errMsg)) {
      delete insertPayload.promotion_id;
      delete insertPayload.promotion_code;
      delete insertPayload.promotion_discount;
      delete insertPayload.promotion_snapshot;
      delete insertPayload.total_before_discount;
      delete insertPayload.upsells;
      delete insertPayload.upsell_total;
      insertRes = await fetch(`${SUPABASE_URL}/rest/v1/bookings`, {
        method: 'POST',
        headers: adminHeaders({ 'Prefer': 'return=representation' }),
        body: JSON.stringify(insertPayload),
      });
      inserted = await insertRes.json().catch(() => null);
    }
  }
  if (!insertRes.ok) {
    const err = Array.isArray(inserted) ? inserted[0] : inserted;
    const errMsg = (err && (err.message as string)) || 'Could not save booking.';
    console.warn('[bookings] insert failed:', insertRes.status, err);
    sendJson(res, 500, { error: errMsg });
    return;
  }

  if (promotionCode && promotionDiscount > 0 && validatedPromotion?.id) {
    const redemptionPayload = {
      promotion_id: validatedPromotion.id,
      property_id: propertyId,
      host_id: hostId,
      booking_id: bookingId,
      guest_email: guestEmail,
      code: promotionCode,
      discount_amount: promotionDiscount,
      booking_total_before_discount: totalBeforeDiscount,
      booking_total_after_discount: total,
      currency: 'NZD',
    };
    const redemptionRes = await fetch(`${SUPABASE_URL}/rest/v1/promotion_redemptions`, {
      method: 'POST',
      headers: adminHeaders({ 'Prefer': 'resolution=ignore-duplicates' }),
      body: JSON.stringify(redemptionPayload),
    });
    if (!redemptionRes.ok) {
      const err = await redemptionRes.text().catch(() => '');
      console.warn('[promotions] redemption insert failed:', redemptionRes.status, err);
    }
    const nextUsage = validatedPromotion.usageCount + 1;
    const nextRevenue = validatedPromotion.revenueGenerated + total;
    const promoPatchRes = await fetch(`${SUPABASE_URL}/rest/v1/host_promotions?id=eq.${encodeURIComponent(validatedPromotion.id)}`, {
      method: 'PATCH',
      headers: adminHeaders(),
      body: JSON.stringify({
        usage_count: nextUsage,
        uses: nextUsage,
        revenue_generated: nextRevenue,
        updated_at: new Date().toISOString(),
      }),
    });
    if (!promoPatchRes.ok) {
      const err = await promoPatchRes.text().catch(() => '');
      console.warn('[promotions] usage update failed:', promoPatchRes.status, err);
    }
  }

  if (upsells.length > 0) {
    const reservationRows = upsells.map((upsell: any) => ({
      property_id: propertyId,
      host_id: hostId,
      booking_id: bookingId,
      upsell_id: isUuid(upsell.id) ? upsell.id : null,
      name: upsell.name,
      description: upsell.description,
      image_url: upsell.imageUrl,
      pricing_type: upsell.priceType,
      unit_price: upsell.price,
      quantity: upsell.quantity,
      total_amount: Math.round(upsell.price * upsell.quantity * 100) / 100,
      payment_state: upsell.paymentState,
      added_by: upsell.addedBy,
      source: upsell.source,
      selected_at: upsell.addedAt,
      metadata: {
        icon: upsell.icon,
        charge_mode: upsell.chargeMode,
      },
    }));
    const upsellRes = await fetch(`${SUPABASE_URL}/rest/v1/reservation_upsells`, {
      method: 'POST',
      headers: adminHeaders(),
      body: JSON.stringify(reservationRows),
    });
    if (!upsellRes.ok) {
      const err = await upsellRes.text().catch(() => '');
      console.warn('[upsells] reservation upsell insert failed:', upsellRes.status, err);
    }
  }

  await insertHostNotification({
    host_id: hostId,
    property_id: propertyId,
    type: 'booking',
    title: `${isBookingRequest ? 'New booking request' : 'New booking'} from ${guestName}`,
    body: `${guests} guest${guests === 1 ? '' : 's'} · ${formatDate(checkIn)} → ${formatDate(checkOut)} · $${formatMoney(total)} NZD`,
    action_path: `/dashboard/bookings?id=${encodeURIComponent(bookingId)}`,
    related_id: bookingId,
  });

  // Fire-and-forget host email
  if (context.host_email) {
    sendResendEmail({
      to: context.host_email,
      subject: `${isBookingRequest ? 'New booking request' : 'New booking'} · ${context.name || 'your property'} · ${formatDate(checkIn)}`,
      replyTo: guestEmail,
      html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
        <h2 style="margin:0 0 12px;color:#FF5A5F">${isBookingRequest ? 'New booking request' : 'New booking confirmed'}</h2>
        <p>${escapeHtml(guestName)} ${isBookingRequest ? 'sent a booking request for' : 'just booked'} <strong>${escapeHtml(context.name || 'your property')}</strong>.</p>
        <table style="border-collapse:collapse;margin:16px 0;font-size:14px">
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-in</td><td>${escapeHtml(formatDate(checkIn))}</td></tr>
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-out</td><td>${escapeHtml(formatDate(checkOut))}</td></tr>
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Guests</td><td>${guests}</td></tr>
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Total</td><td>$${formatMoney(total)} NZD</td></tr>
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Booking ID</td><td>${escapeHtml(bookingId)}</td></tr>
          <tr><td style="padding:4px 16px 4px 0;color:#717171">Guest email</td><td>${escapeHtml(guestEmail)}</td></tr>
          ${guestPhone ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Phone</td><td>${escapeHtml(guestPhone)}</td></tr>` : ''}
        </table>
        ${notes ? `<p style="background:#F7F7F7;padding:12px;border-radius:8px;font-size:13px"><strong>Guest notes:</strong><br>${escapeHtml(notes)}</p>` : ''}
        <p style="font-size:12px;color:#717171;margin-top:24px">Open it in your dashboard at staydirect.nz/dashboard/bookings</p>
      </div>`,
    }).catch(() => undefined);
  }

  sendJson(res, 201, { ok: true, booking: Array.isArray(inserted) ? inserted[0] : inserted });
}

// ---------- /api/inquiries ----------
async function handleCreateInquiry(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const body = await readJsonBody(req);
  const propertyId = String(body.property_id || '').trim();
  const guestName = String(body.guest_name || body.name || '').trim();
  const guestEmail = String(body.guest_email || body.email || '').trim().toLowerCase();
  const guestPhone = String(body.guest_phone || body.phone || '').trim();
  const subject = String(body.subject || '').trim();
  const message = String(body.message || '').trim();
  const source = String(body.source || 'website').trim();
  const checkIn = String(body.check_in || '').trim() || null;
  const checkOut = String(body.check_out || '').trim() || null;
  const guests = body.guests != null ? Math.max(1, Math.floor(Number(body.guests) || 1)) : null;

  if (!guestEmail && !guestPhone) {
    sendJson(res, 400, { error: 'An email or phone number is required so the host can reply.' });
    return;
  }
  if (!message) {
    sendJson(res, 400, { error: 'Message is required.' });
    return;
  }

  let hostId: string | null = null;
  let propertyName = '';
  let hostEmail: string | null = null;
  if (propertyId) {
    const context = await fetchPropertyContext(propertyId);
    hostId = context.host_id;
    propertyName = context.name;
    hostEmail = context.host_email;
  }
  if (!hostId) {
    sendJson(res, 404, { error: 'Property not found.' });
    return;
  }

  const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/inquiries`, {
    method: 'POST',
    headers: adminHeaders({ 'Prefer': 'return=representation' }),
    body: JSON.stringify({
      property_id: propertyId,
      host_id: hostId,
      guest_name: guestName || 'Website visitor',
      guest_email: guestEmail,
      guest_phone: guestPhone,
      subject: subject || 'New inquiry',
      message,
      source,
      status: 'open',
      check_in: checkIn,
      check_out: checkOut,
      guests,
    }),
  });
  const inserted = await insertRes.json().catch(() => null);
  if (!insertRes.ok) {
    const err = Array.isArray(inserted) ? inserted[0] : inserted;
    const errMsg = (err && (err.message as string)) || '';
    // 42P01 = table missing, common before the migration is applied
    if (insertRes.status === 404 || /relation .*inquiries.* does not exist/i.test(errMsg)) {
      sendJson(res, 503, { error: 'Inquiry storage is not yet provisioned. Please apply the 2026-05-18 migration.' });
      return;
    }
    console.warn('[inquiries] insert failed:', insertRes.status, err);
    sendJson(res, 500, { error: errMsg || 'Could not save inquiry.' });
    return;
  }
  const inquiry = Array.isArray(inserted) ? inserted[0] : inserted;
  const inquiryId = (inquiry && (inquiry.id as string)) || '';

  await insertHostNotification({
    host_id: hostId,
    property_id: propertyId,
    type: 'inquiry',
    title: `New inquiry from ${guestName || 'a guest'}`,
    body: message.length > 140 ? `${message.slice(0, 140)}…` : message,
    action_path: `/dashboard/messages?thread=${encodeURIComponent(inquiryId)}`,
    related_id: inquiryId,
  });

  if (hostEmail) {
    sendResendEmail({
      to: hostEmail,
      subject: `New inquiry · ${propertyName || 'your property'}`,
      replyTo: guestEmail || undefined,
      html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
        <h2 style="margin:0 0 12px;color:#FF5A5F">New guest inquiry</h2>
        <p><strong>${escapeHtml(guestName || 'A website visitor')}</strong> sent a message about <strong>${escapeHtml(propertyName || 'your property')}</strong>.</p>
        ${subject ? `<p style="font-size:14px"><strong>Subject:</strong> ${escapeHtml(subject)}</p>` : ''}
        <div style="background:#F7F7F7;padding:14px;border-radius:8px;font-size:14px;white-space:pre-wrap">${escapeHtml(message)}</div>
        <table style="border-collapse:collapse;margin:16px 0;font-size:13px;color:#484848">
          ${guestEmail ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Email</td><td>${escapeHtml(guestEmail)}</td></tr>` : ''}
          ${guestPhone ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Phone</td><td>${escapeHtml(guestPhone)}</td></tr>` : ''}
          ${checkIn ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Dates</td><td>${escapeHtml(formatDate(checkIn))} → ${escapeHtml(formatDate(checkOut))}</td></tr>` : ''}
          ${guests ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Guests</td><td>${guests}</td></tr>` : ''}
        </table>
        <p style="font-size:12px;color:#717171">Reply in your dashboard inbox.</p>
      </div>`,
    }).catch(() => undefined);
  }

  sendJson(res, 201, { ok: true, inquiry });
}

// ---------- /api/email/booking-confirmation ----------
async function handleBookingConfirmationEmail(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const guestEmail = String(body.guestEmail || '').trim();
  const hostEmail = String(body.hostEmail || '').trim();
  const guestName = String(body.guestName || 'Guest');
  const propertyName = String(body.propertyName || 'your stay');
  const bookingId = String(body.bookingId || '');
  const checkIn = formatDate(body.checkIn);
  const checkOut = formatDate(body.checkOut);
  const nights = Number(body.nights) || 0;
  const guests = Number(body.guests) || 1;
  const total = formatMoney(body.total);
  const specialRequests = String(body.specialRequests || '');

  if (!guestEmail) {
    sendJson(res, 400, { error: 'guestEmail is required.' });
    return;
  }

  const guestHtml = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 12px;color:#FF5A5F">Booking confirmed</h2>
    <p>Hi ${escapeHtml(guestName)}, your stay at <strong>${escapeHtml(propertyName)}</strong> is confirmed.</p>
    <table style="border-collapse:collapse;margin:16px 0;font-size:14px">
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Booking ID</td><td>${escapeHtml(bookingId)}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-in</td><td>${escapeHtml(checkIn)}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-out</td><td>${escapeHtml(checkOut)}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Nights</td><td>${nights}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Guests</td><td>${guests}</td></tr>
      <tr><td style="padding:4px 16px 4px 0;color:#717171">Total paid</td><td>$${total} NZD</td></tr>
    </table>
    ${specialRequests ? `<p style="background:#F7F7F7;padding:12px;border-radius:8px;font-size:13px"><strong>Your notes:</strong><br>${escapeHtml(specialRequests)}</p>` : ''}
    <p style="font-size:12px;color:#717171;margin-top:24px">Thanks for booking direct.</p>
  </div>`;

  const guestSend = await sendResendEmail({
    to: guestEmail,
    subject: `Your booking is confirmed · ${propertyName}`,
    html: guestHtml,
    replyTo: hostEmail || undefined,
  });

  let hostSend: { ok: boolean; error: string | null; id: string | null } = { ok: true, error: null, id: null };
  if (hostEmail) {
    const hostHtml = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
      <h2 style="margin:0 0 12px;color:#FF5A5F">New booking received</h2>
      <p><strong>${escapeHtml(guestName)}</strong> just booked <strong>${escapeHtml(propertyName)}</strong>.</p>
      <table style="border-collapse:collapse;margin:16px 0;font-size:14px">
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Booking ID</td><td>${escapeHtml(bookingId)}</td></tr>
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-in</td><td>${escapeHtml(checkIn)}</td></tr>
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Check-out</td><td>${escapeHtml(checkOut)}</td></tr>
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Guests</td><td>${guests}</td></tr>
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Total</td><td>$${total} NZD</td></tr>
        <tr><td style="padding:4px 16px 4px 0;color:#717171">Guest email</td><td>${escapeHtml(guestEmail)}</td></tr>
      </table>
    </div>`;
    hostSend = await sendResendEmail({
      to: hostEmail,
      subject: `New booking · ${propertyName} · ${checkIn}`,
      html: hostHtml,
      replyTo: guestEmail,
    });
  }

  if (!guestSend.ok && !hostSend.ok) {
    sendJson(res, 502, { error: guestSend.error || hostSend.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, {
    ok: true,
    guest: { delivered: guestSend.ok, id: guestSend.id, error: guestSend.error },
    host: { delivered: hostSend.ok, id: hostSend.id, error: hostSend.error },
  });
}

// ---------- /api/email/support-inquiry ----------
async function handleSupportInquiryEmail(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const name = String(body.name || 'Website visitor');
  const email = String(body.email || '').trim();
  const phone = String(body.phone || '').trim();
  const subject = String(body.subject || 'Website inquiry');
  const message = String(body.message || '');
  const ticketNumber = String(body.ticketNumber || body.id || '');
  const category = String(body.category || '');
  const propertyName = String(body.propertyName || '');
  const websiteUrl = String(body.websiteUrl || '');

  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 12px;color:#FF5A5F">New support inquiry</h2>
    ${ticketNumber ? `<p style="font-size:12px;color:#717171">Ticket ${escapeHtml(ticketNumber)}</p>` : ''}
    <p><strong>${escapeHtml(name)}</strong></p>
    <table style="border-collapse:collapse;margin:8px 0;font-size:13px">
      ${email ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Email</td><td>${escapeHtml(email)}</td></tr>` : ''}
      ${phone ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Phone</td><td>${escapeHtml(phone)}</td></tr>` : ''}
      ${category ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Category</td><td>${escapeHtml(category)}</td></tr>` : ''}
      ${propertyName ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">Property</td><td>${escapeHtml(propertyName)}</td></tr>` : ''}
      ${websiteUrl ? `<tr><td style="padding:4px 16px 4px 0;color:#717171">From</td><td>${escapeHtml(websiteUrl)}</td></tr>` : ''}
    </table>
    <p style="font-size:14px"><strong>Subject:</strong> ${escapeHtml(subject)}</p>
    <div style="background:#F7F7F7;padding:14px;border-radius:8px;font-size:14px;white-space:pre-wrap">${escapeHtml(message)}</div>
  </div>`;

  const send = await sendResendEmail({
    to: SUPPORT_INBOX,
    subject: `[Support] ${subject}`,
    html,
    replyTo: email || undefined,
  });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- /api/email/guest-message ----------
async function handleGuestMessageEmail(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const to = String(body.to || body.guestEmail || '').trim();
  const subject = String(body.subject || 'Message from your host');
  const messageBody = String(body.body || body.message || '');
  const fromName = String(body.fromName || body.propertyName || 'Your host');
  const replyTo = String(body.replyTo || body.hostEmail || '').trim();
  if (!to) {
    sendJson(res, 400, { error: 'Recipient email is required.' });
    return;
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <p style="font-size:14px;color:#717171">Message from ${escapeHtml(fromName)}</p>
    <div style="background:#F7F7F7;padding:14px;border-radius:8px;font-size:15px;white-space:pre-wrap">${escapeHtml(messageBody)}</div>
  </div>`;
  const send = await sendResendEmail({ to, subject, html, replyTo: replyTo || undefined });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- /api/email/review-request ----------
async function handleReviewRequestEmail(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const to = String(body.guestEmail || body.to || '').trim();
  const guestName = String(body.guestName || 'there');
  const propertyName = String(body.propertyName || 'your stay');
  const reviewUrl = String(body.reviewUrl || body.url || '').trim();
  const hostEmail = String(body.hostEmail || '').trim();
  if (!to) {
    sendJson(res, 400, { error: 'guestEmail is required.' });
    return;
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 12px;color:#FF5A5F">How was your stay?</h2>
    <p>Hi ${escapeHtml(guestName)}, thanks for staying at <strong>${escapeHtml(propertyName)}</strong>.</p>
    <p>Would you mind sharing a quick review? It really helps future guests.</p>
    ${reviewUrl ? `<p><a href="${escapeHtml(reviewUrl)}" style="display:inline-block;background:#FF5A5F;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:600">Leave a review</a></p>` : ''}
  </div>`;
  const send = await sendResendEmail({
    to, subject: `How was your stay at ${propertyName}?`, html, replyTo: hostEmail || undefined,
  });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- email rate limiting ----------
const emailRateLimitStore = new Map<string, { count: number; resetAt: number }>();
const EMAIL_RATE_LIMIT = 5;
const EMAIL_RATE_WINDOW_MS = 60 * 60 * 1000;

function checkEmailRateLimit(key: string): { ok: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = emailRateLimitStore.get(key);
  if (!entry || now > entry.resetAt) {
    emailRateLimitStore.set(key, { count: 1, resetAt: now + EMAIL_RATE_WINDOW_MS });
    return { ok: true };
  }
  if (entry.count >= EMAIL_RATE_LIMIT) {
    return { ok: false, retryAfter: Math.ceil((entry.resetAt - now) / 1000) };
  }
  entry.count += 1;
  return { ok: true };
}

// ---------- /api/email/host-welcome ----------
async function handleHostWelcomeEmail(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in required.' });
    return;
  }
  const body = await readJsonBody(req);
  const to = String(body.to || body.email || '').trim().toLowerCase();
  const name = String(body.name || body.hostName || '').trim();
  const propertyName = String(body.propertyName || body.property || 'your property').trim();
  const slug = String(body.slug || '').trim();
  const dashboardUrl = String(body.dashboardUrl || '').trim();
  const websiteUrl = String(body.websiteUrl || '').trim();
  if (!to) {
    sendJson(res, 400, { error: 'Recipient email is required.' });
    return;
  }
  const rate = checkEmailRateLimit(`welcome-${host.id}`);
  if (!rate.ok) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: rate.retryAfter });
    return;
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 16px;color:#FF5A5F">Welcome to StayDirect, ${escapeHtml(name || 'Host')}!</h2>
    <p style="font-size:15px;line-height:1.6">Your property <strong>${escapeHtml(propertyName)}</strong> is live. You can manage everything from your host dashboard.</p>
    <div style="background:#FFF1F3;border-radius:12px;padding:16px;margin:16px 0">
      <p style="margin:0 0 8px;font-weight:600">Your dashboard</p>
      ${dashboardUrl ? `<p style="margin:0"><a href="${escapeHtml(dashboardUrl)}" style="color:#FF5A5F">${escapeHtml(dashboardUrl)}</a></p>` : ''}
      ${websiteUrl ? `<p style="margin:8px 0 0"><strong>Your public website:</strong> <a href="${escapeHtml(websiteUrl)}" style="color:#FF5A5F">${escapeHtml(websiteUrl)}</a></p>` : ''}
    </div>
    <p style="font-size:14px;color:#717171">You have 14 days of full access to all features. Explore the dashboard, set up your calendar, and start receiving direct bookings.</p>
    <p style="margin-top:24px"><a href="${escapeHtml(dashboardUrl || 'https://staydirect.nz/dashboard')}" style="display:inline-block;background:#FF5A5F;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:600">Go to Dashboard</a></p>
  </div>`;
  const send = await sendResendEmail({
    to, subject: `Welcome to StayDirect — ${escapeHtml(propertyName)} is live`, html,
  });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- /api/email/save-progress ----------
async function handleSaveProgressEmail(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in required.' });
    return;
  }
  const body = await readJsonBody(req);
  const to = String(body.to || body.email || '').trim().toLowerCase();
  const name = String(body.name || body.hostName || '').trim();
  const propertyName = String(body.propertyName || body.property || 'your property').trim();
  const loginUrl = String(body.loginUrl || 'https://staydirect.nz/sign-in').trim();
  const progress = body.progress || {};
  const progressStep = String(progress.step || body.step || '1').trim();
  if (!to) {
    sendJson(res, 400, { error: 'Recipient email is required.' });
    return;
  }
  const rate = checkEmailRateLimit(`save-progress-${host.id}`);
  if (!rate.ok) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: rate.retryAfter });
    return;
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 16px;color:#FF5A5F">Your progress is saved, ${escapeHtml(name || 'Host')}</h2>
    <p style="font-size:15px;line-height:1.6">We've saved your setup for <strong>${escapeHtml(propertyName)}</strong>. You can pick up right where you left off at any time.</p>
    <div style="background:#FFF1F3;border-radius:12px;padding:16px;margin:16px 0">
      <p style="margin:0;font-weight:600">Current step: ${escapeHtml(progressStep)}</p>
      <p style="margin:8px 0 0;font-size:14px;color:#717171">Click the Sign Up button on the StayDirect homepage, enter the same email and password, and you'll be taken straight back to your setup.</p>
    </div>
    <p style="margin-top:24px"><a href="${escapeHtml(loginUrl)}" style="display:inline-block;background:#FF5A5F;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:600">Continue Setup</a></p>
  </div>`;
  const send = await sendResendEmail({
    to, subject: `Your StayDirect setup is saved — ${escapeHtml(propertyName)}`, html,
  });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- /api/email/abandonment-reminder ----------
async function handleAbandonmentReminderEmail(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in required.' });
    return;
  }
  const body = await readJsonBody(req);
  const to = String(body.to || body.email || '').trim().toLowerCase();
  const name = String(body.name || body.hostName || '').trim();
  const propertyName = String(body.propertyName || body.property || 'your property').trim();
  const loginUrl = String(body.loginUrl || 'https://staydirect.nz/sign-in').trim();
  const progressStep = String(body.step || body.progressStep || '1').trim();
  if (!to) {
    sendJson(res, 400, { error: 'Recipient email is required.' });
    return;
  }
  const rate = checkEmailRateLimit(`abandonment-${host.id}`);
  if (!rate.ok) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: rate.retryAfter });
    return;
  }
  const html = `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
    <h2 style="margin:0 0 16px;color:#FF5A5F">Don't lose your progress, ${escapeHtml(name || 'Host')}</h2>
    <p style="font-size:15px;line-height:1.6">You started setting up <strong>${escapeHtml(propertyName)}</strong> on StayDirect but didn't finish. Your work is saved — you can complete it in just a few minutes.</p>
    <div style="background:#FFF1F3;border-radius:12px;padding:16px;margin:16px 0">
      <p style="margin:0;font-weight:600">Last step completed: ${escapeHtml(progressStep)}</p>
      <p style="margin:8px 0 0;font-size:14px;color:#717171">Click the Sign Up button on the StayDirect homepage, enter the same email and password, and you'll continue right where you left off.</p>
    </div>
    <p style="margin-top:24px"><a href="${escapeHtml(loginUrl)}" style="display:inline-block;background:#FF5A5F;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:600">Continue Setup</a></p>
  </div>`;
  const send = await sendResendEmail({
    to, subject: `Complete your StayDirect setup — ${escapeHtml(propertyName)}`, html,
  });
  if (!send.ok) {
    sendJson(res, 502, { error: send.error || 'Email delivery failed.' });
    return;
  }
  sendJson(res, 200, { ok: true, id: send.id });
}

// ---------- /api/stripe/create-payment-intent ----------
async function handleGetHostStripeSetup(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to view Stripe setup.' });
    return;
  }
  const url = new URL(req.url || '/', 'http://localhost');
  const propertyId = url.searchParams.get('propertyId') || '';
  if (!propertyId) {
    sendJson(res, 400, { error: 'propertyId is required.' });
    return;
  }
  const row = await getHostStripeConnection(host.id, propertyId);
  sendJson(res, 200, stripePublicStatus(row));
}

async function handleSaveHostStripeSetup(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to save Stripe setup.' });
    return;
  }
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }

  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  const mode = String(body.mode || 'test') === 'live' ? 'live' : 'test';
  const publishableKey = String(body.publishableKey || '').trim();
  const secretKey = String(body.secretKey || '').trim() || null;
  const webhookSigningSecret = String(body.webhookSigningSecret || '').trim() || null;
  const existing = propertyId ? await getHostStripeConnection(host.id, propertyId, mode) : null;
  const validationError = validateStripeKeys(publishableKey, secretKey, mode, Boolean(existing?.secret_key_encrypted));
  const webhookSecretError = validateStripeWebhookSigningSecret(webhookSigningSecret, Boolean(existing?.webhook_signing_secret_encrypted));
  if (!propertyId) {
    sendJson(res, 400, { error: 'propertyId is required.' });
    return;
  }
  if (validationError) {
    sendJson(res, 400, { error: validationError });
    return;
  }
  if (webhookSecretError) {
    sendJson(res, 400, { error: webhookSecretError });
    return;
  }

  try {
    const account = secretKey ? await validateStripeSecret(secretKey) : existing?.secret_key_encrypted ? await validateStripeSecret(decryptSecret(existing.secret_key_encrypted)) : null;
    const now = new Date().toISOString();
    const row = await upsertHostStripeConnection({
      host_id: host.id,
      property_id: propertyId,
      mode,
      account_email: String(body.accountEmail || host.email || '').trim(),
      publishable_key: publishableKey,
      secretKey,
      webhookSigningSecret,
      webhook_url: String(body.webhookUrl || '').trim(),
      webhook_configured: Boolean(body.webhookUrl) && Boolean(webhookSigningSecret || existing?.webhook_signing_secret_encrypted),
      stripe_account_id: account?.accountId || '',
      charges_enabled: Boolean(account?.chargesEnabled),
      payouts_enabled: Boolean(account?.payoutsEnabled),
      details_submitted: Boolean(account?.detailsSubmitted),
      connection_status: account?.chargesEnabled ? 'connected' : 'setup',
      test_connection_at: now,
      deposits_enabled: body.depositsEnabled !== false,
      balance_payments_enabled: body.balancePaymentsEnabled !== false,
      refunds_enabled: body.refundsEnabled !== false,
    });
    await updatePropertyPublishableKey(propertyId, publishableKey);
    sendJson(res, 200, stripePublicStatus(row));
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Stripe setup could not be saved.';
    await upsertHostStripeConnection({
      host_id: host.id,
      property_id: propertyId,
      mode,
      account_email: String(body.accountEmail || host.email || '').trim(),
      publishable_key: publishableKey,
      secretKey,
      webhookSigningSecret,
      webhook_url: String(body.webhookUrl || '').trim(),
      webhook_configured: Boolean(body.webhookUrl) && Boolean(webhookSigningSecret || existing?.webhook_signing_secret_encrypted),
      charges_enabled: false,
      payouts_enabled: false,
      details_submitted: false,
      connection_status: 'error',
      last_error: message,
      deposits_enabled: body.depositsEnabled !== false,
      balance_payments_enabled: body.balancePaymentsEnabled !== false,
      refunds_enabled: body.refundsEnabled !== false,
    }).catch(() => undefined);
    sendJson(res, 400, { error: message });
  }
}

async function handleTestHostStripeSetup(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to test Stripe setup.' });
    return;
  }
  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  const mode = String(body.mode || 'test') === 'live' ? 'live' : 'test';
  const publishableKey = String(body.publishableKey || '').trim();
  const secretKey = String(body.secretKey || '').trim() || null;
  const existing = propertyId ? await getHostStripeConnection(host.id, propertyId, mode) : null;
  if (!propertyId) {
    sendJson(res, 400, { error: 'propertyId is required.' });
    return;
  }
  const validationError = validateStripeKeys(publishableKey, secretKey, mode, Boolean(existing?.secret_key_encrypted));
  if (validationError) {
    sendJson(res, 400, { error: validationError });
    return;
  }
  try {
    const key = secretKey || (existing?.secret_key_encrypted ? decryptSecret(existing.secret_key_encrypted) : '');
    const account = await validateStripeSecret(key);
    const row = await upsertHostStripeConnection({
      host_id: host.id,
      property_id: propertyId,
      mode,
      account_email: existing?.account_email || host.email || '',
      publishable_key: publishableKey,
      secretKey,
      webhook_url: existing?.webhook_url || '',
      webhook_configured: Boolean(existing?.webhook_configured),
      stripe_account_id: account.accountId,
      charges_enabled: account.chargesEnabled,
      payouts_enabled: account.payoutsEnabled,
      details_submitted: account.detailsSubmitted,
      connection_status: account.chargesEnabled ? 'connected' : 'setup',
      test_connection_at: new Date().toISOString(),
      deposits_enabled: existing?.deposits_enabled !== false,
      balance_payments_enabled: existing?.balance_payments_enabled !== false,
      refunds_enabled: existing?.refunds_enabled !== false,
    });
    await updatePropertyPublishableKey(propertyId, publishableKey);
    sendJson(res, 200, stripePublicStatus(row));
  } catch (error) {
    sendJson(res, 400, { error: error instanceof Error ? error.message : 'Stripe connection failed.' });
  }
}

async function handleRunHostStripeTestBooking(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to run a test booking.' });
    return;
  }
  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  if (!propertyId) {
    sendJson(res, 400, { error: 'propertyId is required.' });
    return;
  }
  const row = await getHostStripeConnectionByProperty(propertyId);
  if (!row || row.host_id !== host.id || !row.secret_key_encrypted) {
    sendJson(res, 400, { error: 'Save and test Stripe keys before running a test booking.' });
    return;
  }
  if (row.mode !== 'test') {
    sendJson(res, 400, { error: 'Run test bookings with test mode keys only.' });
    return;
  }
  try {
    const secret = decryptSecret(row.secret_key_encrypted);
    const params = new URLSearchParams({
      amount: '100',
      currency: 'nzd',
      capture_method: 'manual',
      'metadata[staydirect_test]': 'true',
      'metadata[property_id]': propertyId,
      'metadata[host_id]': host.id,
    });
    const response = await fetch('https://api.stripe.com/v1/payment_intents', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${secret}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Stripe-Version': '2024-06-20',
      },
      body: params.toString(),
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok) {
      const stripeErr = (data.error as Record<string, unknown> | null) || {};
      throw new Error(String(stripeErr.message || data.message || `Stripe returned ${response.status}`));
    }
    const updated = await upsertHostStripeConnection({
      ...row,
      host_id: host.id,
      property_id: propertyId,
      mode: row.mode,
      connection_status: 'connected',
      last_test_booking_at: new Date().toISOString(),
    });
    const payload = stripePublicStatus(updated) || {};
    sendJson(res, 200, { ...payload, testPaymentIntentId: String(data.id || '') });
  } catch (error) {
    sendJson(res, 400, { error: error instanceof Error ? error.message : 'Test booking could not be run.' });
  }
}

async function handleDisconnectHostStripe(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to disconnect Stripe.' });
    return;
  }
  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  if (!propertyId) {
    sendJson(res, 400, { error: 'propertyId is required.' });
    return;
  }
  await fetch(`${SUPABASE_URL}/rest/v1/host_stripe_connections?host_id=eq.${encodeURIComponent(host.id)}&property_id=eq.${encodeURIComponent(propertyId)}`, {
    method: 'PATCH',
    headers: adminHeaders({ 'Prefer': 'return=minimal' }),
    body: JSON.stringify({
      connection_status: 'disconnected',
      publishable_key: '',
      secret_key_encrypted: null,
      secret_key_last4: '',
      webhook_signing_secret_encrypted: null,
      webhook_signing_secret_last4: '',
      webhook_configured: false,
      charges_enabled: false,
      payouts_enabled: false,
      updated_at: new Date().toISOString(),
    }),
  }).catch(() => undefined);
  await updatePropertyPublishableKey(propertyId, null);
  sendJson(res, 200, { ok: true });
}

async function handleHostStripeWebhook(req: IncomingMessage, res: ServerResponse) {
  const url = new URL(req.url || '/', 'http://localhost');
  const propertyId = url.searchParams.get('propertyId') || '';
  const rawBody = await readRawBody(req);
  if (propertyId) {
    const row = await getHostStripeConnectionByProperty(propertyId);
    if (row?.webhook_signing_secret_encrypted) {
      const signatureHeader = String(req.headers['stripe-signature'] || '');
      let verified = false;
      try {
        verified = verifyStripeWebhookSignature(rawBody, signatureHeader, decryptSecret(row.webhook_signing_secret_encrypted));
      } catch {
        verified = false;
      }
      if (!verified) {
        sendJson(res, 401, { error: 'Invalid Stripe webhook signature.' });
        return;
      }
    }
  }
  let event: Record<string, unknown>;
  try {
    event = JSON.parse(rawBody || '{}') as Record<string, unknown>;
  } catch {
    sendJson(res, 400, { error: 'Invalid Stripe webhook payload.' });
    return;
  }
  const eventType = String(event.type || '');
  const eventData = event.data;
  const dataObject = (eventData && typeof eventData === 'object' && !Array.isArray(eventData) && 'object' in eventData)
    ? (eventData as { object?: Record<string, unknown> }).object || {}
    : {};
  const metadata = (dataObject.metadata && typeof dataObject.metadata === 'object')
    ? dataObject.metadata as Record<string, unknown>
    : {};
  const bookingId = String(metadata.booking_id || metadata.bookingId || '').trim();
  const paymentIntentId = String(dataObject.id || dataObject.payment_intent || '').trim();

  if (!bookingId && !paymentIntentId) {
    sendJson(res, 200, { ok: true, ignored: 'No booking metadata found.' });
    return;
  }

  let paymentStatus: string | null = null;
  let notificationType: 'payment' | 'booking' = 'payment';
  if (eventType === 'payment_intent.succeeded' || eventType === 'payment_intent.amount_capturable_updated') paymentStatus = 'paid';
  if (eventType === 'payment_intent.payment_failed') paymentStatus = 'pending';
  if (eventType === 'charge.refunded' || eventType === 'refund.created') paymentStatus = 'refunded';
  if (eventType === 'charge.dispute.created' || eventType === 'dispute.created') {
    paymentStatus = 'pending';
    notificationType = 'payment';
  }

  if (paymentStatus && SUPABASE_URL && SERVICE_ROLE_KEY) {
    const filters = bookingId
      ? `id=eq.${encodeURIComponent(bookingId)}`
      : `notes=ilike.%${encodeURIComponent(paymentIntentId)}%`;
    await fetch(`${SUPABASE_URL}/rest/v1/bookings?${filters}`, {
      method: 'PATCH',
      headers: adminHeaders({ 'Prefer': 'return=representation' }),
      body: JSON.stringify({ payment_status: paymentStatus }),
    }).then(async (response) => {
      const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
      const booking = rows[0];
      const hostId = String(booking?.host_id || '');
      if (hostId) {
        await insertHostNotification({
          host_id: hostId,
          property_id: propertyId || String(booking?.property_id || '') || null,
          type: notificationType,
          title: `Stripe ${eventType.replace(/_/g, ' ')}`,
          body: bookingId ? `Booking ${bookingId} payment status is now ${paymentStatus}.` : `Payment ${paymentIntentId} status is now ${paymentStatus}.`,
          action_path: bookingId ? `/dashboard/bookings?id=${encodeURIComponent(bookingId)}` : '/dashboard/bookings',
          related_id: bookingId || paymentIntentId || null,
        });
      }
    }).catch((error) => {
      console.warn('[stripe webhook] booking update failed:', error);
    });
  }

  sendJson(res, 200, { ok: true });
}

async function fetchLatestHostSubscription(hostId: string): Promise<Record<string, unknown> | null> {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY || !hostId) return null;
  const response = await fetch(
    `${SUPABASE_URL}/rest/v1/subscriptions?host_id=eq.${encodeURIComponent(hostId)}&select=*&order=created_at.desc&limit=1`,
    { headers: adminHeaders() },
  );
  const rows = await response.json().catch(() => []) as Array<Record<string, unknown>>;
  return response.ok && Array.isArray(rows) ? rows[0] || null : null;
}

async function upsertHostSubscription(hostId: string, patch: Record<string, unknown>) {
  const existing = await fetchLatestHostSubscription(hostId);
  if (existing?.id) {
    const ok = await adminPatchWithFallback('subscriptions', `id=eq.${encodeURIComponent(String(existing.id))}`, patch);
    if (!ok) throw new Error('Could not update subscription.');
    return { ...existing, ...patch };
  }
  const { row } = await adminInsertReturning('subscriptions', { host_id: hostId, ...patch }, 'id');
  return row;
}

async function handleStripeConfig(_req: IncomingMessage, res: ServerResponse) {
  if (!/^pk_(test|live)_/.test(STRIPE_PUBLISHABLE_KEY)) {
    sendJson(res, 503, { error: 'Stripe publishable key is not configured.' });
    return;
  }
  sendJson(res, 200, { publishableKey: STRIPE_PUBLISHABLE_KEY });
}

async function handleCreateSubscriptionCheckout(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to manage your StayDirect plan.' });
    return;
  }
  if (!stripeSecretConfigured()) {
    sendJson(res, 503, { error: 'StayDirect subscription billing is not configured yet. Please contact StayDirect support.' });
    return;
  }

  const body = await readJsonBody(req);
  const plan = subscriptionPlanDetails(body.planId);
  if (!plan) {
    sendJson(res, 400, { error: 'Choose a valid StayDirect plan.' });
    return;
  }

  const existing = await fetchLatestHostSubscription(host.id);
  const successUrl = withCheckoutSessionId(safeCheckoutReturnUrl(
    body.successUrl,
    'https://staydirect.nz/dashboard/billing-settings?success=1',
  ));
  const cancelUrl = safeCheckoutReturnUrl(
    body.cancelUrl,
    'https://staydirect.nz/dashboard/billing-settings?cancelled=1',
  );

  const params = new URLSearchParams({
    mode: 'subscription',
    success_url: successUrl,
    cancel_url: cancelUrl,
    client_reference_id: host.id,
    allow_promotion_codes: 'true',
    'metadata[host_id]': host.id,
    'metadata[plan_id]': plan.id,
    'subscription_data[metadata][host_id]': host.id,
    'subscription_data[metadata][plan_id]': plan.id,
    'line_items[0][quantity]': '1',
    'line_items[0][price_data][currency]': 'nzd',
    'line_items[0][price_data][unit_amount]': String(plan.amountCents),
    'line_items[0][price_data][recurring][interval]': 'month',
    'line_items[0][price_data][product_data][name]': plan.name,
  });

  const existingCustomerId = String(existing?.stripe_customer_id || '').trim();
  if (/^cus_/.test(existingCustomerId)) {
    params.set('customer', existingCustomerId);
  } else if (host.email) {
    params.set('customer_email', host.email);
  } else if (body.hostEmail) {
    params.set('customer_email', String(body.hostEmail));
  }

  try {
    const response = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Stripe-Version': STRIPE_API_VERSION,
      },
      body: params.toString(),
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok) {
      const stripeErr = recordValue(data.error);
      sendJson(res, response.status >= 500 ? 502 : 400, { error: String(stripeErr.message || data.message || 'Stripe could not start checkout.') });
      return;
    }
    sendJson(res, 200, { url: data.url, sessionId: data.id });
  } catch (error) {
    console.error('[stripe subscription] checkout session failed:', error);
    sendJson(res, 502, { error: 'Could not reach Stripe Billing. Please try again.' });
  }
}

async function handleSyncSubscriptionCheckout(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to finish updating your plan.' });
    return;
  }
  if (!stripeSecretConfigured()) {
    sendJson(res, 503, { error: 'StayDirect subscription billing is not configured yet.' });
    return;
  }

  const body = await readJsonBody(req);
  const sessionId = String(body.sessionId || '').trim();
  if (!/^cs_/.test(sessionId)) {
    sendJson(res, 400, { error: 'A valid Stripe Checkout session is required.' });
    return;
  }

  try {
    const response = await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}?expand%5B%5D=subscription`, {
      headers: {
        'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
        'Stripe-Version': STRIPE_API_VERSION,
      },
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok) {
      const stripeErr = recordValue(data.error);
      sendJson(res, response.status >= 500 ? 502 : 400, { error: String(stripeErr.message || data.message || 'Could not verify Stripe checkout.') });
      return;
    }

    const metadata = recordValue(data.metadata);
    if (String(data.client_reference_id || metadata.host_id || '') !== host.id) {
      sendJson(res, 403, { error: 'This checkout session belongs to another host.' });
      return;
    }
    if (String(data.status || '') !== 'complete') {
      sendJson(res, 400, { error: 'Stripe checkout has not completed yet.' });
      return;
    }

    const planId = normalizeSubscriptionPlanId(metadata.plan_id || body.planId) || 'premium';
    const subscription = recordValue(data.subscription);
    const subscriptionId = typeof data.subscription === 'string' ? String(data.subscription) : String(subscription.id || '');
    const stripeStatus = String(subscription.status || 'active').toLowerCase();
    const status = ['active', 'trialing', 'past_due', 'cancelled'].includes(stripeStatus) ? stripeStatus : 'active';
    const customer = typeof data.customer === 'string' ? String(data.customer) : String(recordValue(data.customer).id || '');
    const customerDetails = recordValue(data.customer_details);

    const patch: Record<string, unknown> = {
      plan: planId,
      status,
      stripe_customer_id: customer || null,
      stripe_subscription_id: subscriptionId || null,
      stripe_checkout_session_id: sessionId,
      billing_email: String(customerDetails.email || data.customer_email || host.email || ''),
      current_period_end: isoFromStripeSeconds(subscription.current_period_end),
      updated_at: new Date().toISOString(),
    };
    const trialEndsAt = isoFromStripeSeconds(subscription.trial_end);
    if (trialEndsAt) patch.trial_ends_at = trialEndsAt;

    const row = await upsertHostSubscription(host.id, patch);
    sendJson(res, 200, { ok: true, subscription: row });
  } catch (error) {
    console.error('[stripe subscription] sync failed:', error);
    sendJson(res, 502, { error: 'Could not sync the completed Stripe checkout.' });
  }
}

async function handleCreatePaymentIntent(req: IncomingMessage, res: ServerResponse) {
  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  const hostStripeSecret = propertyId ? await resolveStripeSecretForProperty(propertyId) : null;
  const secretForPayment = hostStripeSecret || STRIPE_SECRET_KEY;
  const keyOk = /^(sk|rk)_(test|live)_/.test(secretForPayment);
  if (!keyOk) {
    console.error('[stripe] STRIPE_SECRET_KEY is missing or invalid format. Set STRIPE_SECRET_KEY in Replit Secrets with a valid sk_test_ or sk_live_ key.');
    sendJson(res, 503, { error: 'Payment service is not configured. Contact the site owner.' });
    return;
  }

  const rawAmount = Number(body.amount);
  const currency = String(body.currency || 'nzd').toLowerCase();
  const guestEmail = String(body.guestEmail || '').trim().toLowerCase();
  const propertyName = String(body.propertyName || '').trim();
  const bookingId = String(body.bookingId || '').trim();

  if (!Number.isFinite(rawAmount) || rawAmount <= 0) {
    sendJson(res, 400, { error: 'amount must be a positive number.' });
    return;
  }
  if (currency !== 'nzd') {
    sendJson(res, 400, { error: 'Only NZD is supported.' });
    return;
  }
  if (!bookingId) {
    sendJson(res, 400, { error: 'bookingId is required.' });
    return;
  }

  // Stripe amounts are in the smallest currency unit (cents for NZD)
  const amountCents = Math.round(rawAmount * 100);
  if (amountCents < 50) {
    sendJson(res, 400, { error: 'Amount is too small. Minimum charge is $0.50 NZD.' });
    return;
  }

  const params = new URLSearchParams({
    amount: String(amountCents),
    currency,
    capture_method: 'manual',
    'metadata[booking_id]': bookingId,
    'metadata[property_id]': propertyId,
    'metadata[property_name]': propertyName,
  });
  if (guestEmail) params.set('receipt_email', guestEmail);

  try {
    const response = await fetch('https://api.stripe.com/v1/payment_intents', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${secretForPayment}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Stripe-Version': STRIPE_API_VERSION,
      },
      body: params.toString(),
    });
    const data = await response.json().catch(() => ({})) as Record<string, unknown>;
    if (!response.ok) {
      const stripeErr = (data.error as Record<string, unknown> | null) || {};
      const message = String(stripeErr.message || data.message || `Stripe returned ${response.status}`);
      console.warn('[stripe] payment intent failed:', response.status, message);
      sendJson(res, response.status >= 500 ? 502 : 400, { error: message });
      return;
    }
    const id = data.id as string;
    const clientSecret = data.client_secret as string;
    if (!clientSecret) {
      sendJson(res, 502, { error: 'Stripe did not return a client secret.' });
      return;
    }
    console.log('[stripe] payment intent created:', id, `amount=${amountCents} NZD cents`);
    sendJson(res, 200, { clientSecret, paymentIntentId: id });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('[stripe] exception creating payment intent:', message);
    sendJson(res, 502, { error: 'Could not reach the payment service. Please try again.' });
  }
}

async function handleAdminDomainRecheck(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  const body = await readJsonBody(req);
  const mapping = String(body.id || '').trim()
    ? await fetchDomainMappingById(String(body.id || '').trim())
    : await fetchDomainMappingByHostname(normalizeDomainHostname(String(body.hostname || '')));
  if (!mapping?.id) {
    sendJson(res, 404, { error: 'Domain mapping not found.' });
    return;
  }
  const meta = (mapping.metadata || {}) as Record<string, unknown>;
  const cfId = meta.cloudflare_id ? String(meta.cloudflare_id) : '';

  // Prefer Cloudflare for SaaS when configured (and this mapping was created through it).
  if (cloudflareConfigured()) {
    let cf: CloudflareCustomHostname | null = null;
    if (cfId) {
      const fetched = await cfGetCustomHostname(cfId);
      cf = fetched.result;
    }
    if (!cf) cf = await cfFindCustomHostnameByName(mapping.hostname);
    const lifecycle = mapCloudflareLifecycle(cf);
    const dnsRecords = buildDnsRecords(mapping.hostname, cf);
    await patchDomainMapping(mapping.id, {
      status: lifecycle.status,
      ssl_status: lifecycle.sslStatus,
      last_dns_check: new Date().toISOString(),
      connected_at: lifecycle.status === 'active' ? mapping.connected_at || new Date().toISOString() : mapping.connected_at,
      error_message: lifecycle.status === 'failed' ? lifecycle.message : null,
      metadata: { ...meta, cloudflare_id: cf?.id || cfId || null, dns_records: dnsRecords, cf_status: cf?.status, cf_ssl_status: cf?.ssl?.status, expected: STAYDIRECT_CNAME_TARGET },
    });
    if (lifecycle.status === 'active' && lifecycle.sslStatus === 'active') {
      await updatePropertyCustomDomain(mapping.property_id, mapping.hostname);
    }
    await insertDomainLog({
      domain_mapping_id: mapping.id,
      property_id: mapping.property_id,
      hostname: mapping.hostname,
      action: 'admin_dns_recheck',
      status: lifecycle.status,
      message: `Cloudflare recheck: ${lifecycle.message}`,
      created_by: admin.local || !isUuid(admin.id) ? null : admin.id,
      metadata: { cloudflare_id: cf?.id || cfId || null },
    });
    sendJson(res, 200, { ok: true, status: lifecycle.status, sslStatus: lifecycle.sslStatus, dnsRecords });
    return;
  }

  // Fallback: legacy CNAME-based check when Cloudflare is not configured.
  const dns = await checkCnameTarget(mapping.hostname);
  const status: DomainStatus = dns.verified ? (mapping.ssl_status === 'active' ? 'active' : 'ssl_provisioning') : 'pending_dns';
  const sslStatus: SslStatus = dns.verified ? (mapping.ssl_status === 'active' ? 'active' : 'provisioning') : 'pending';
  await patchDomainMapping(mapping.id, {
    status,
    ssl_status: sslStatus,
    last_dns_check: new Date().toISOString(),
    error_message: dns.verified ? null : dns.error || 'CNAME does not resolve to StayDirect.',
    metadata: { cnames: dns.cnames, expected: STAYDIRECT_CNAME_TARGET },
  });
  await insertDomainLog({
    domain_mapping_id: mapping.id,
    property_id: mapping.property_id,
    hostname: mapping.hostname,
    action: 'admin_dns_recheck',
    status,
    message: dns.verified ? 'DNS verified by admin check.' : 'DNS check failed.',
    created_by: admin.local || !isUuid(admin.id) ? null : admin.id,
    metadata: { cnames: dns.cnames, expected: STAYDIRECT_CNAME_TARGET },
  });
  sendJson(res, 200, { ok: true, status, sslStatus, cnames: dns.cnames });
}

async function handleAdminDomainRefreshSsl(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  const body = await readJsonBody(req);
  const mapping = await fetchDomainMappingById(String(body.id || '').trim());
  if (!mapping?.id) {
    sendJson(res, 404, { error: 'Domain mapping not found.' });
    return;
  }
  await patchDomainMapping(mapping.id, {
    status: 'active',
    ssl_status: 'active',
    connected_at: mapping.connected_at || new Date().toISOString(),
    error_message: null,
  });
  await updatePropertyCustomDomain(mapping.property_id, mapping.hostname);
  await insertDomainLog({
    domain_mapping_id: mapping.id,
    property_id: mapping.property_id,
    hostname: mapping.hostname,
    action: 'admin_ssl_refresh',
    status: 'active',
    message: 'SSL marked active.',
    created_by: admin.local || !isUuid(admin.id) ? null : admin.id,
  });
  sendJson(res, 200, { ok: true, status: 'active', sslStatus: 'active' });
}

async function handleAdminDomainDisconnect(req: IncomingMessage, res: ServerResponse) {
  const admin = await authenticateAdmin(req);
  if (!admin) {
    sendJson(res, 403, { error: 'Admin access required.' });
    return;
  }
  const body = await readJsonBody(req);
  const mapping = await fetchDomainMappingById(String(body.id || '').trim());
  if (!mapping?.id) {
    sendJson(res, 404, { error: 'Domain mapping not found.' });
    return;
  }
  const meta = (mapping.metadata || {}) as Record<string, unknown>;
  const cfId = meta.cloudflare_id ? String(meta.cloudflare_id) : '';
  if (cloudflareConfigured() && cfId) {
    await cfDeleteCustomHostname(cfId);
  }
  await patchDomainMapping(mapping.id, {
    status: 'failed',
    ssl_status: 'failed',
    error_message: 'Disconnected by StayDirect admin.',
  });
  await updatePropertyCustomDomain(mapping.property_id, null);
  await insertDomainLog({
    domain_mapping_id: mapping.id,
    property_id: mapping.property_id,
    hostname: mapping.hostname,
    action: 'admin_disconnect',
    status: 'failed',
    message: 'Domain disconnected by admin.',
    created_by: admin.local || !isUuid(admin.id) ? null : admin.id,
  });
  sendJson(res, 200, { ok: true, status: 'failed', sslStatus: 'failed' });
}

// ---------- Host self-serve custom domains (Cloudflare for SaaS) ----------

async function authorizeHostProperty(
  host: { id: string },
  propertyId: string,
): Promise<{ ok: boolean; property?: Record<string, unknown> }> {
  if (!propertyId) return { ok: false };
  const property = await fetchPropertyRow(propertyId);
  if (!property || String(property.host_id) !== host.id) return { ok: false };
  return { ok: true, property };
}

async function handleHostDomainConnect(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to connect a custom domain.' });
    return;
  }
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured for custom domains.' });
    return;
  }

  const body = await readJsonBody(req);
  const propertyId = String(body.propertyId || '').trim();
  const hostname = normalizeDomainHostname(String(body.hostname || ''));

  if (!propertyId) {
    sendJson(res, 400, { error: 'A property is required.' });
    return;
  }
  const validationError = validateCustomDomainHostname(hostname);
  if (validationError) {
    sendJson(res, 400, { error: validationError, status: 'invalid', sslStatus: 'pending' });
    return;
  }

  const access = await authorizeHostProperty(host, propertyId);
  if (!access.ok) {
    sendJson(res, 403, { error: 'You can only connect domains for properties you manage.' });
    return;
  }

  const allowed = await hostCanUseCustomDomains(host.id);
  if (!allowed) {
    sendJson(res, 403, { error: 'Custom domains are available on the Professional plan. Upgrade to connect your own domain.' });
    return;
  }
  if (!cloudflareConfigured()) {
    sendJson(res, 503, { error: 'Custom domain automation is not configured on this deployment yet. StayDirect support needs to finish the domain service setup before this can be connected.' });
    return;
  }

  // Prevent the same hostname being claimed by a different property, unless the
  // existing mapping is in a terminal/disconnected state (then it can be reclaimed).
  const existing = await fetchDomainMappingByHostname(hostname);
  const reclaimableStates: DomainStatus[] = ['failed', 'invalid', 'duplicate'];
  if (existing && existing.property_id !== propertyId && !reclaimableStates.includes(existing.status as DomainStatus)) {
    await insertDomainLog({
      domain_mapping_id: existing.id || null,
      property_id: propertyId,
      hostname,
      action: 'host_connect',
      status: 'duplicate',
      message: 'Domain already connected to another property.',
      created_by: host.id,
      metadata: { duplicate_of: existing.property_id },
    });
    sendJson(res, 409, { error: 'This domain is already connected to another StayDirect property.', status: 'duplicate', sslStatus: 'pending' });
    return;
  }

  // Find or create the Cloudflare custom hostname.
  let cf = await cfFindCustomHostnameByName(hostname);
  if (!cf?.id) {
    const created = await cfCreateCustomHostname(hostname);
    if (!created.ok || !created.result?.id) {
      const message = created.errors[0] || 'Cloudflare could not register this domain. Please try again.';
      await insertDomainLog({
        domain_mapping_id: existing?.id,
        property_id: propertyId,
        hostname,
        action: 'cloudflare_create',
        status: 'failed',
        message,
        created_by: host.id,
      });
      sendJson(res, 502, { error: message });
      return;
    }
    cf = created.result;
  }

  const lifecycle = mapCloudflareLifecycle(cf);
  const dnsRecords = buildDnsRecords(hostname, cf);
  const now = new Date().toISOString();
  const row = await upsertDomainMapping({
    id: existing?.id,
    property_id: propertyId,
    hostname,
    status: lifecycle.status,
    ssl_status: lifecycle.sslStatus,
    last_dns_check: now,
    connected_at: lifecycle.status === 'active' ? existing?.connected_at || now : existing?.connected_at || null,
    error_message: lifecycle.status === 'failed' ? lifecycle.message : null,
    created_by: host.id,
    metadata: {
      cloudflare_id: cf.id,
      dns_records: dnsRecords,
      expected: STAYDIRECT_CNAME_TARGET,
      cf_status: cf.status,
      cf_ssl_status: cf.ssl?.status,
    },
  });

  await insertDomainLog({
    domain_mapping_id: row.id,
    property_id: propertyId,
    hostname,
    action: 'host_connect',
    status: lifecycle.status,
    message: lifecycle.message,
    created_by: host.id,
    metadata: { cloudflare_id: cf.id },
  });

  if (lifecycle.status === 'active' && lifecycle.sslStatus === 'active') {
    await updatePropertyCustomDomain(propertyId, hostname);
  }

  sendJson(res, 200, {
    ok: true,
    id: row.id,
    hostname,
    isApex: isApexDomainHostname(hostname),
    status: lifecycle.status,
    sslStatus: lifecycle.sslStatus,
    message: lifecycle.message,
    dnsRecords,
  });
}

async function handleHostDomainStatus(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to check your domain status.' });
    return;
  }
  const body = await readJsonBody(req);
  const id = String(body.id || '').trim();
  const hostname = normalizeDomainHostname(String(body.hostname || ''));
  const mapping = id
    ? await fetchDomainMappingById(id)
    : await fetchDomainMappingByHostname(hostname);
  if (!mapping?.id) {
    sendJson(res, 404, { error: 'Domain mapping not found.' });
    return;
  }

  const access = await authorizeHostProperty(host, mapping.property_id);
  if (!access.ok) {
    sendJson(res, 403, { error: 'You can only check domains for properties you manage.' });
    return;
  }

  const meta = (mapping.metadata || {}) as Record<string, unknown>;
  const cfId = meta.cloudflare_id ? String(meta.cloudflare_id) : '';

  let cf: CloudflareCustomHostname | null = null;
  if (cloudflareConfigured()) {
    if (cfId) {
      const fetched = await cfGetCustomHostname(cfId);
      cf = fetched.result;
    }
    if (!cf) cf = await cfFindCustomHostnameByName(mapping.hostname);
  }

  const lifecycle = mapCloudflareLifecycle(cf);
  const dnsRecords = buildDnsRecords(mapping.hostname, cf);
  const now = new Date().toISOString();

  await patchDomainMapping(mapping.id, {
    status: lifecycle.status,
    ssl_status: lifecycle.sslStatus,
    last_dns_check: now,
    connected_at: lifecycle.status === 'active' ? mapping.connected_at || now : mapping.connected_at,
    error_message: lifecycle.status === 'failed' ? lifecycle.message : null,
    metadata: {
      ...meta,
      cloudflare_id: cf?.id || cfId || null,
      dns_records: dnsRecords,
      cf_status: cf?.status,
      cf_ssl_status: cf?.ssl?.status,
      expected: STAYDIRECT_CNAME_TARGET,
    },
  });

  // Only log meaningful transitions to avoid flooding the audit trail while polling.
  if (lifecycle.status !== mapping.status) {
    await insertDomainLog({
      domain_mapping_id: mapping.id,
      property_id: mapping.property_id,
      hostname: mapping.hostname,
      action: 'host_status_poll',
      status: lifecycle.status,
      message: lifecycle.message,
      created_by: host.id,
    });
  }

  if (lifecycle.status === 'active' && lifecycle.sslStatus === 'active') {
    await updatePropertyCustomDomain(mapping.property_id, mapping.hostname);
  }

  sendJson(res, 200, {
    ok: true,
    id: mapping.id,
    hostname: mapping.hostname,
    isApex: isApexDomainHostname(mapping.hostname),
    status: lifecycle.status,
    sslStatus: lifecycle.sslStatus,
    message: lifecycle.message,
    dnsRecords,
  });
}

async function handleHostDomainDisconnect(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) {
    sendJson(res, 401, { error: 'Sign in to disconnect your domain.' });
    return;
  }
  const body = await readJsonBody(req);
  const id = String(body.id || '').trim();
  const hostname = normalizeDomainHostname(String(body.hostname || ''));
  const mapping = id
    ? await fetchDomainMappingById(id)
    : await fetchDomainMappingByHostname(hostname);
  if (!mapping?.id) {
    sendJson(res, 404, { error: 'Domain mapping not found.' });
    return;
  }

  const access = await authorizeHostProperty(host, mapping.property_id);
  if (!access.ok) {
    sendJson(res, 403, { error: 'You can only disconnect domains for properties you manage.' });
    return;
  }

  const meta = (mapping.metadata || {}) as Record<string, unknown>;
  const cfId = meta.cloudflare_id ? String(meta.cloudflare_id) : '';
  if (cloudflareConfigured() && cfId) {
    await cfDeleteCustomHostname(cfId);
  }

  await patchDomainMapping(mapping.id, {
    status: 'failed',
    ssl_status: 'failed',
    error_message: 'Disconnected by host.',
    metadata: { ...meta, cloudflare_id: null, disconnected_at: new Date().toISOString() },
  });
  await updatePropertyCustomDomain(mapping.property_id, null);
  await insertDomainLog({
    domain_mapping_id: mapping.id,
    property_id: mapping.property_id,
    hostname: mapping.hostname,
    action: 'host_disconnect',
    status: 'failed',
    message: 'Domain disconnected by host.',
    created_by: host.id,
  });

  sendJson(res, 200, { ok: true, status: 'failed', sslStatus: 'failed' });
}

// ---------- /api/auth/send-password-reset ----------
async function handleSendPasswordReset(req: IncomingMessage, res: ServerResponse) {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    sendJson(res, 503, { error: 'Server is not configured.' });
    return;
  }
  const body = await readJsonBody(req);
  const email = String(body.email || '').trim().toLowerCase();
  const redirectBase = String(body.redirectBase || '').trim();
  const propertyName = String(body.propertyName || '').trim();
  const propertySlug = String(body.propertySlug || '').trim();
  const propertyId = String(body.propertyId || '').trim();

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    sendJson(res, 400, { error: 'A valid email address is required.' });
    return;
  }

  // Build the redirect URL for after the user clicks the reset link.
  // Property subdomains (e.g. delorainecottage.staydirect.nz) are typically NOT in
  // Supabase's allowed redirect URL list, so the auth server falls back to the Site URL
  // (staydirect.nz) and drops the path — landing the user on the home page instead of
  // /reset-password. To avoid this, we always redirect to the main site URL which IS
  // in the allowed list.
  const rawRedirect = redirectBase
    ? `${redirectBase.replace(/\/$/, '')}/reset-password`
    : 'https://staydirect.nz/reset-password';
  // Force any *.staydirect.nz redirect to the main domain so Supabase accepts it.
  const redirectTo = /^https:\/\/[^/]+\.staydirect\.nz/.test(rawRedirect)
    ? 'https://staydirect.nz/reset-password'
    : rawRedirect;

  // Use the admin generate_link API to get the reset URL.
  // This avoids relying on Supabase's own SMTP (which is not configured).
  // Resend is already proven working, so we deliver the link ourselves.
  const linkRes = await fetch(`${SUPABASE_URL}/auth/v1/admin/generate_link`, {
    method: 'POST',
    headers: adminHeaders(),
    body: JSON.stringify({ type: 'recovery', email, options: { redirect_to: redirectTo } }),
  });
  const linkData = await linkRes.json().catch(() => ({})) as Record<string, unknown>;

  if (!linkRes.ok) {
    const msg = String(linkData.msg || linkData.message || linkData.error || '');
    // Treat "not found" as success to prevent email enumeration
    if (/not found/i.test(msg)) {
      console.log('[password-reset] email not found (silent success):', email);
      sendJson(res, 200, { ok: true });
      return;
    }
    console.warn('[password-reset] generate_link failed:', linkRes.status, msg);
    sendJson(res, 502, { error: 'Could not send reset email. Please try again.' });
    return;
  }

  const actionLink = String(linkData.action_link || '');
  if (!actionLink) {
    console.error('[password-reset] no action_link in generate_link response');
    sendJson(res, 502, { error: 'Could not generate reset link. Please try again.' });
    return;
  }

  // Extract the raw token from the Supabase action_link so we can build our own direct link.
  // The action_link looks like: https://<project>.supabase.co/auth/v1/verify?token=<TOKEN>&type=recovery&...
  // Email security scanners (Gmail, Outlook, etc.) prefetch Supabase links, consuming the one-time
  // token before the user clicks. Sending our own direct link bypasses this entirely.
  let directLink: string;
  try {
    const actionUrl = new URL(actionLink);
    const rawToken = actionUrl.searchParams.get('token');
    if (!rawToken) {
      throw new Error('no token in action_link');
    }
    // Build a direct link to our own reset page — the page calls exchangeCodeForSession(token)
    const resetBase = redirectTo.replace(/\/reset-password.*$/, '/reset-password');
    const resetUrl = new URL(resetBase);
    resetUrl.searchParams.set('token', rawToken);
    if (propertySlug) {
      resetUrl.searchParams.set('slug', propertySlug);
    }
    if (propertyId) {
      resetUrl.searchParams.set('property', propertyId);
    }
    directLink = resetUrl.toString();
  } catch (e) {
    console.error('[password-reset] failed to extract token from action_link:', e);
    // Fallback to the Supabase link (less safe against prefetchers)
    directLink = actionLink;
  }

  if (!RESEND_API_KEY) {
    console.error('[password-reset] RESEND_API_KEY not set, cannot deliver reset email');
    sendJson(res, 503, { error: 'Email service is not configured.' });
    return;
  }

  const brandedSubject = propertyName
    ? `Reset your password — ${propertyName} on StayDirect.nz`
    : 'Reset your StayDirect.nz password';
  const brandedHeading = propertyName
    ? `Reset your password for ${propertyName}`
    : 'Reset your password';
  const brandedFooter = propertyName
    ? `<p style="color:#ababab;font-size:13px;margin-top:8px;">StayDirect.nz — ${propertyName}</p>`
    : '<p style="color:#ababab;font-size:13px;margin-top:8px;">StayDirect.nz</p>';

  const emailRes = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({
      from: RESEND_FROM,
      to: [email],
      subject: brandedSubject,
      html: `
        <div style="font-family:Inter,Arial,sans-serif;max-width:520px;margin:0 auto;padding:32px 24px;">
          <h1 style="font-size:24px;font-weight:700;color:#484848;margin-bottom:8px;">${brandedHeading}</h1>
          <p style="color:#717171;margin-bottom:24px;">Click the button below to choose a new password. This link expires in 1 hour.</p>
          <a href="${directLink}"
             style="display:inline-block;background:#FF385C;color:#fff;font-weight:700;padding:14px 28px;border-radius:12px;text-decoration:none;font-size:16px;">
            Reset password
          </a>
          <p style="color:#ababab;font-size:13px;margin-top:32px;">If you didn't request a password reset, you can safely ignore this email.</p>
          <p style="color:#ababab;font-size:13px;">Or copy this link: <a href="${directLink}" style="color:#00A699;">${directLink.slice(0, 80)}…</a></p>
          ${brandedFooter}
        </div>
      `,
    }),
  });

  if (!emailRes.ok) {
    const errBody = await emailRes.json().catch(() => ({})) as Record<string, unknown>;
    console.error('[password-reset] Resend failed:', emailRes.status, errBody);
    sendJson(res, 502, { error: 'Could not deliver reset email. Please try again.' });
    return;
  }

  console.log('[password-reset] reset email sent to:', email);
  sendJson(res, 200, { ok: true });
}

// ---------- Google Places API helpers ----------
const googlePlacesRateLimit = new Map<string, { count: number; resetAt: number }>();
const chatbotRateLimit = new Map<string, { count: number; resetAt: number }>();

function getClientIp(req: IncomingMessage): string {
  const remote = String(req.socket.remoteAddress || 'unknown');
  const forwarded = String(req.headers['x-forwarded-for'] || '');
  // Only trust x-forwarded-for from Replit internal proxies (private ranges)
  const isTrustedProxy =
    remote.startsWith('127.') ||
    remote.startsWith('172.24.') ||
    remote.startsWith('10.') ||
    remote.startsWith('192.168.') ||
    remote.startsWith('::') ||
    remote.startsWith('::1') ||
    remote.startsWith('fe80:');
  if (forwarded && isTrustedProxy) {
    return forwarded.split(',')[0].trim();
  }
  return remote;
}

function checkGooglePlacesRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const key = ip;
  const entry = googlePlacesRateLimit.get(key);
  if (!entry || now > entry.resetAt) {
    googlePlacesRateLimit.set(key, { count: 1, resetAt: now + 60000 });
    return { allowed: true };
  }
  if (entry.count >= 20) {
    return { allowed: false, retryAfter: Math.ceil((entry.resetAt - now) / 1000) };
  }
  entry.count += 1;
  return { allowed: true };
}

async function handleGooglePlacesAutocomplete(req: IncomingMessage, res: ServerResponse) {
  const ip = getClientIp(req);
  const limit = checkGooglePlacesRateLimit(ip);
  if (!limit.allowed) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: limit.retryAfter });
    return;
  }
  const key = GOOGLE_PLACES_API_KEY;
  if (!key) {
    sendJson(res, 503, { error: 'Google Places is not configured.' });
    return;
  }
  const body = await readJsonBody(req);
  const input = String(body.input || '').trim();
  if (input.length < 2) {
    sendJson(res, 200, { suggestions: [] });
    return;
  }
  const latitude =
    body.latitude === null || body.latitude === undefined || body.latitude === ''
      ? Number.NaN
      : Number(body.latitude);
  const longitude =
    body.longitude === null || body.longitude === undefined || body.longitude === ''
      ? Number.NaN
      : Number(body.longitude);
  const requestBody: Record<string, unknown> = {
    input,
    includedRegionCodes: ['nz'],
    languageCode: 'en',
  };
  if (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180
  ) {
    requestBody.locationBias = {
      circle: {
        center: { latitude, longitude },
        radius: 50000,
      },
    };
  }
  const response = await fetch(`${PLACES_BASE_URL}/places:autocomplete`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': key,
      'X-Goog-FieldMask': 'suggestions.placePrediction.placeId,suggestions.placePrediction.text,suggestions.placePrediction.structuredFormat,suggestions.placePrediction.types',
    },
    body: JSON.stringify(requestBody),
  });
  const payload: any = await response.json();
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || 'Google Places autocomplete failed', details: payload });
    return;
  }
  sendJson(res, 200, {
    suggestions: (payload.suggestions || [])
      .map((item: any) => item.placePrediction)
      .filter(Boolean)
      .map((prediction: any) => ({
        placeId: prediction.placeId,
        title: prediction.structuredFormat?.mainText?.text || prediction.text?.text || '',
        secondaryText: prediction.structuredFormat?.secondaryText?.text || '',
        description: prediction.text?.text || prediction.structuredFormat?.mainText?.text || '',
        placeTypes: prediction.types || [],
      })),
  });
}

async function handleGooglePlacesDetails(req: IncomingMessage, res: ServerResponse) {
  const ip = getClientIp(req);
  const limit = checkGooglePlacesRateLimit(ip);
  if (!limit.allowed) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: limit.retryAfter });
    return;
  }
  const key = GOOGLE_PLACES_API_KEY;
  if (!key) {
    sendJson(res, 503, { error: 'Google Places is not configured.' });
    return;
  }
  const url = new URL(req.url || '/', 'http://localhost');
  const pathParts = url.pathname.split('/');
  const placeId = pathParts[pathParts.length - 1] || '';
  if (!placeId) {
    sendJson(res, 400, { error: 'Missing placeId' });
    return;
  }
  const fieldMask = [
    'id',
    'displayName',
    'formattedAddress',
    'location',
    'types',
    'rating',
    'userRatingCount',
    'googleMapsUri',
    'websiteUri',
    'photos',
    'addressComponents',
    'nationalPhoneNumber',
  ].join(',');
  const response = await fetch(`${PLACES_BASE_URL}/places/${encodeURIComponent(placeId)}`, {
    headers: {
      'X-Goog-Api-Key': key,
      'X-Goog-FieldMask': fieldMask,
    },
  });
  const payload: any = await response.json();
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || 'Google Place details failed', details: payload });
    return;
  }
  const requestedPhotoIndex = Math.max(0, Number(url.searchParams.get('photoIndex') || 0));
  const photos = payload.photos || [];
  const photoIndex = photos.length ? requestedPhotoIndex % photos.length : 0;
  const primaryPhoto = photos[photoIndex] || null;
  sendJson(res, 200, {
    id: payload.id || placeId,
    name: payload.displayName?.text || '',
    formattedAddress: payload.formattedAddress || '',
    latitude: payload.location?.latitude ?? null,
    longitude: payload.location?.longitude ?? null,
    types: payload.types || [],
    rating: payload.rating ?? null,
    userRatingsTotal: payload.userRatingCount ?? null,
    googleMapsUri: payload.googleMapsUri || '',
    websiteUri: payload.websiteUri || '',
    phone: payload.nationalPhoneNumber || '',
    addressComponents: payload.addressComponents || [],
    photoName: primaryPhoto?.name || null,
    photoAttribution: primaryPhoto?.authorAttributions?.[0]?.displayName || null,
    photos,
    photoIndex,
    photoCount: photos.length,
  });
}

async function handleGooglePlacesPhoto(req: IncomingMessage, res: ServerResponse) {
  const ip = getClientIp(req);
  const limit = checkGooglePlacesRateLimit(ip);
  if (!limit.allowed) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: limit.retryAfter });
    return;
  }
  const key = GOOGLE_PLACES_API_KEY;
  if (!key) {
    sendJson(res, 503, { error: 'Google Places is not configured.' });
    return;
  }
  const url = new URL(req.url || '/', 'http://localhost');
  const name = url.searchParams.get('name') || '';
  const maxWidthPx = Math.min(Math.max(Number(url.searchParams.get('maxWidthPx') || 1200), 100), 4800);
  if (!name) {
    sendJson(res, 400, { error: 'Missing photo resource name' });
    return;
  }
  const response = await fetch(`${PLACES_BASE_URL}/${name}/media?${new URLSearchParams({
    key,
    maxWidthPx: String(maxWidthPx),
    skipHttpRedirect: 'true',
  }).toString()}`);
  const contentType = response.headers.get('content-type') || '';
  if (response.ok && !contentType.includes('application/json')) {
    sendJson(res, 200, { photoUri: response.url || '' });
    return;
  }
  const body = await response.text();
  let payload: any = {};
  try {
    payload = body ? JSON.parse(body) : {};
  } catch {
    if (response.ok) {
      sendJson(res, 200, { photoUri: response.url || '' });
      return;
    }
    sendJson(res, response.status, { error: 'Google Place photo failed', details: body });
    return;
  }
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || 'Google Place photo failed', details: payload });
    return;
  }
  sendJson(res, 200, { photoUri: payload.photoUri || response.url || '' });
}

async function handleGooglePlacesNearby(req: IncomingMessage, res: ServerResponse) {
  const ip = getClientIp(req);
  const limit = checkGooglePlacesRateLimit(ip);
  if (!limit.allowed) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.', retryAfter: limit.retryAfter });
    return;
  }
  const key = GOOGLE_PLACES_API_KEY;
  if (!key) {
    sendJson(res, 503, { error: 'Google Places is not configured.' });
    return;
  }
  const body = await readJsonBody(req);
  const textQuery = String(body.textQuery || '').trim();
  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);
  if (!textQuery) {
    sendJson(res, 400, { error: 'A search query is required.' });
    return;
  }
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    sendJson(res, 400, { error: 'Valid latitude and longitude are required for a nearby search.' });
    return;
  }
  const radius = Math.min(Math.max(Number(body.radius) || 25000, 500), 50000);
  const maxResultCount = Math.min(Math.max(Number(body.maxResultCount) || 8, 1), 20);
  const requestBody: Record<string, unknown> = {
    textQuery,
    languageCode: 'en',
    regionCode: 'NZ',
    maxResultCount,
    locationBias: {
      circle: {
        center: { latitude, longitude },
        radius,
      },
    },
  };
  let response: Response;
  try {
    response = await fetch(`${PLACES_BASE_URL}/places:searchText`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': key,
        'X-Goog-FieldMask': [
          'places.id',
          'places.displayName',
          'places.formattedAddress',
          'places.location',
          'places.types',
          'places.primaryType',
          'places.rating',
          'places.userRatingCount',
          'places.googleMapsUri',
          'places.websiteUri',
          'places.photos',
          'places.addressComponents',
        ].join(','),
      },
      body: JSON.stringify(requestBody),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, 502, { error: 'Google Places nearby search is temporarily unavailable.', details: message });
    return;
  }
  const payload: any = await response.json().catch(() => ({}));
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || 'Google Places nearby search failed', details: payload });
    return;
  }
  const places = (payload.places || []).map((place: any) => {
    const photo = (place.photos || [])[0] || null;
    const locality = (place.addressComponents || []).find((component: any) => component.types?.includes('locality'))?.longText
      || (place.addressComponents || []).find((component: any) => component.types?.includes('sublocality'))?.longText
      || '';
    return {
      id: place.id || '',
      name: place.displayName?.text || '',
      formattedAddress: place.formattedAddress || '',
      latitude: place.location?.latitude ?? null,
      longitude: place.location?.longitude ?? null,
      types: place.types || [],
      primaryType: place.primaryType || '',
      rating: place.rating ?? null,
      userRatingsTotal: place.userRatingCount ?? null,
      googleMapsUri: place.googleMapsUri || '',
      websiteUri: place.websiteUri || '',
      locality,
      photoName: photo?.name || null,
      photoAttribution: photo?.authorAttributions?.[0]?.displayName || null,
    };
  });
  sendJson(res, 200, { places });
}

async function handleGuidebookSeedStarter(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) { sendJson(res, 401, { error: 'Authentication required.' }); return; }
  if (!SERVICE_ROLE_KEY || !SUPABASE_URL) { sendJson(res, 503, { error: 'Supabase is not configured.' }); return; }
  if (!GOOGLE_PLACES_API_KEY) { sendJson(res, 503, { error: 'Google Places is not configured.' }); return; }

  const body = await readJsonBody(req);
  let propertyId = String(body.property_id || '').trim();
  if (propertyId && !isUuid(propertyId)) {
    sendJson(res, 400, { error: 'Valid property_id is required.' });
    return;
  }

  if (!propertyId) {
    const propertyRes = await fetch(
      `${SUPABASE_URL}/rest/v1/properties?host_id=eq.${encodeURIComponent(host.id)}&select=id&order=created_at.desc&limit=1`,
      { headers: adminHeaders() },
    );
    const rows = await propertyRes.json().catch(() => []) as Array<Record<string, unknown>>;
    propertyId = propertyRes.ok && Array.isArray(rows) ? String(rows[0]?.id || '') : '';
  }

  if (!propertyId) {
    sendJson(res, 404, { error: 'Property not found.' });
    return;
  }

  const verifyRes = await fetch(
    `${SUPABASE_URL}/rest/v1/properties?id=eq.${encodeURIComponent(propertyId)}&host_id=eq.${encodeURIComponent(host.id)}&select=id&limit=1`,
    { headers: adminHeaders() },
  );
  const verified = await verifyRes.json().catch(() => []) as Array<Record<string, unknown>>;
  if (!verifyRes.ok || !Array.isArray(verified) || !verified[0]) {
    sendJson(res, 403, { error: 'Property not found or access denied.' });
    return;
  }

  const result = await seedStarterGuidebookForProperty(propertyId, host.id);
  sendJson(res, 200, { ok: true, propertyId, ...result });
}

async function handleGuidebookMigratePhotos(req: IncomingMessage, res: ServerResponse) {
  const host = await authenticateHost(req);
  if (!host) { sendJson(res, 401, { error: 'Authentication required.' }); return; }

  const key = GOOGLE_PLACES_API_KEY;
  if (!key) { sendJson(res, 503, { error: 'Google Places is not configured.' }); return; }
  if (!SERVICE_ROLE_KEY || !SUPABASE_URL) { sendJson(res, 503, { error: 'Supabase is not configured.' }); return; }

  const body = await readJsonBody(req);
  const propertyId = String(body.property_id || '');
  if (!isUuid(propertyId)) { sendJson(res, 400, { error: 'Valid property_id is required.' }); return; }

  const verifyRes = await fetch(`${SUPABASE_URL}/rest/v1/properties?id=eq.${propertyId}&host_id=eq.${host.id}&select=id`, { headers: adminHeaders() });
  const verified: any[] = await verifyRes.json().catch(() => []);
  if (!verified.length) { sendJson(res, 403, { error: 'Property not found or access denied.' }); return; }

  const itemsRes = await fetch(
    `${SUPABASE_URL}/rest/v1/local_guidebook_items?property_id=eq.${propertyId}&host_id=eq.${host.id}&select=id,title,google_place_id,google_photo_reference,image_cache_status,image_source`,
    { headers: adminHeaders() }
  );
  const allItems: any[] = await itemsRes.json().catch(() => []);

  function realPlaceId(id: unknown): boolean {
    const s = String(id || '');
    return s.length > 8 && !s.startsWith('starter-') && !s.startsWith('local-');
  }

  const staleItems = allItems.filter((item) => {
    if (item.image_cache_status === 'cached') return false;
    if (item.image_source === 'host_upload') return false;
    if (!item.google_photo_reference && !realPlaceId(item.google_place_id)) return false;
    return true;
  });

  let migrated = 0;
  let skipped = 0;

  for (const item of staleItems) {
    try {
      let photoUrl = '';
      let photoName: string | null = item.google_photo_reference || null;

      if (!photoName && realPlaceId(item.google_place_id)) {
        const detailsRes = await fetch(`${PLACES_BASE_URL}/places/${encodeURIComponent(item.google_place_id)}`, {
          headers: { 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': 'photos' },
        });
        if (detailsRes.ok) {
          const details: any = await detailsRes.json().catch(() => ({}));
          photoName = (details.photos || [])[0]?.name || null;
        }
      }

      if (!photoName) { skipped++; continue; }

      const mediaRes = await fetch(`${PLACES_BASE_URL}/${photoName}/media?${new URLSearchParams({ key, maxWidthPx: '1600', skipHttpRedirect: 'true' }).toString()}`);
      const mediaParsed: any = await mediaRes.json().catch(() => ({}));
      photoUrl = mediaParsed.photoUri || (mediaRes.ok ? mediaRes.url : '');
      if (!photoUrl) { skipped++; continue; }

      const imgRes = await fetch(photoUrl);
      if (!imgRes.ok) { skipped++; continue; }
      const imgBuffer = await imgRes.arrayBuffer();
      const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
      const ext = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg';

      const slug = String(item.title || 'place').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40);
      const storagePath = `${host.id}/${propertyId}/${Date.now()}-${slug}.${ext}`;
      const uploadRes = await fetch(`${SUPABASE_URL}/storage/v1/object/guidebook-media/${storagePath}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${SERVICE_ROLE_KEY}`,
          'apikey': SERVICE_ROLE_KEY,
          'Content-Type': contentType,
          'x-upsert': 'true',
        },
        body: imgBuffer,
      });
      if (!uploadRes.ok) { skipped++; continue; }

      const publicUrl = `${SUPABASE_URL}/storage/v1/object/public/guidebook-media/${storagePath}`;

      await fetch(`${SUPABASE_URL}/rest/v1/local_guidebook_items?id=eq.${item.id}&host_id=eq.${host.id}`, {
        method: 'PATCH',
        headers: { ...adminHeaders(), 'Content-Type': 'application/json', 'Prefer': 'return=minimal' },
        body: JSON.stringify({
          image_url: publicUrl,
          image_storage_path: storagePath,
          image_source: 'google_places_cached',
          image_cache_status: 'cached',
          google_photo_reference: photoName,
        }),
      });

      migrated++;
      await new Promise((r) => setTimeout(r, 120));
    } catch {
      skipped++;
    }
  }

  sendJson(res, 200, { migrated, skipped, total: staleItems.length });
}

// ---------- AI chatbot ----------
async function handleChatbotMessage(req: IncomingMessage, res: ServerResponse) {
  const ip = getClientIp(req);
  const now = Date.now();
  const rle = chatbotRateLimit.get(ip);
  if (!rle || now > rle.resetAt) {
    chatbotRateLimit.set(ip, { count: 1, resetAt: now + 60000 });
  } else if (rle.count >= 30) {
    sendJson(res, 429, { error: 'Rate limit exceeded. Please try again later.' });
    return;
  } else {
    rle.count += 1;
  }

  if (!OPEN_AI_KEY) {
    sendJson(res, 503, { error: 'AI chatbot not configured.' });
    return;
  }

  const body = await readJsonBody(req);
  const message = String(body.message || '').trim();
  if (!message || message.length > 600) {
    sendJson(res, 400, { error: 'Message is required and must be under 600 characters.' });
    return;
  }

  const ctx = (body.propertyContext || {}) as Record<string, unknown>;
  const guidebookItems = Array.isArray(body.guidebookItems) ? body.guidebookItems : [];
  const history = Array.isArray(body.history) ? body.history : [];

  const propertyName = String(ctx.propertyName || 'this property');
  const lines: string[] = [];

  lines.push(
    `You are a helpful concierge assistant for ${propertyName}. Answer guest questions using the specific property data provided below. Be warm, concise, and accurate. If you don't have the information needed, say so briefly and offer to send a message to the host through StayDirect.`,
    '',
    '## Property',
  );
  if (ctx.propertyType) lines.push(`Type: ${String(ctx.propertyType).replace(/_/g, ' ')}`);
  const locationParts = [ctx.address, ctx.city, ctx.country].filter(Boolean).map(String);
  if (locationParts.length) lines.push(`Location: ${locationParts.join(', ')}`);
  if (ctx.description) lines.push(`Description: ${String(ctx.description).slice(0, 500)}`);

  lines.push('', '## Stay details');
  if (ctx.checkInTime) lines.push(`Check-in: from ${ctx.checkInTime}`);
  if (ctx.checkOutTime) lines.push(`Check-out: by ${ctx.checkOutTime}`);
  if (ctx.maxGuests) lines.push(`Max guests: ${ctx.maxGuests}`);
  if (ctx.bedrooms) lines.push(`Bedrooms: ${ctx.bedrooms}`);
  if (ctx.bathrooms) lines.push(`Bathrooms: ${ctx.bathrooms}`);
  if (ctx.minNights) lines.push(`Minimum stay: ${ctx.minNights} night${Number(ctx.minNights) === 1 ? '' : 's'}`);
  if (ctx.basePrice) lines.push(`Nightly rate from: NZ$${ctx.basePrice}${ctx.cleaningFee ? ` + NZ$${ctx.cleaningFee} cleaning fee` : ''}`);

  const amenities = Array.isArray(ctx.amenities) ? ctx.amenities : [];
  if (amenities.length) {
    lines.push('', '## Amenities');
    lines.push(amenities.map((a: unknown) => String(a).replace(/-/g, ' ')).join(', '));
  }

  lines.push('', '## Policies');
  lines.push(`Pets: ${ctx.petsAllowed ? 'Allowed' : 'Not allowed'}`);
  lines.push(`Smoking: ${ctx.smokingAllowed ? 'Allowed in designated areas' : 'Not allowed'}`);
  lines.push(`Events/parties: ${ctx.eventsAllowed ? 'Allowed by arrangement' : 'Not allowed'}`);
  if (ctx.houseRules) lines.push(`House rules: ${String(ctx.houseRules).slice(0, 400)}`);

  lines.push('', '## Host contact');
  if (ctx.contactEmail) lines.push(`Email: ${ctx.contactEmail}`);
  if (ctx.contactPhone) lines.push(`Phone: ${ctx.contactPhone}`);
  if (!ctx.contactEmail && !ctx.contactPhone) lines.push('Guests can use the contact or booking form on the website.');

  if (guidebookItems.length) {
    lines.push('', '## Nearby places (local guidebook)');
    for (const raw of guidebookItems.slice(0, 20)) {
      const item = raw as Record<string, unknown>;
      const title = String(item.title || '').trim();
      if (!title) continue;
      const cat = String(item.category || '').replace(/_/g, ' ');
      const desc = String(item.description || '').slice(0, 120);
      const dist = item.distanceFromProperty ? ` — ${item.distanceFromProperty}` : '';
      const note = item.hostNote ? ` (Host: "${String(item.hostNote).slice(0, 80)}")` : '';
      lines.push(`- ${title} (${cat})${dist}: ${desc}${note}`);
    }
  }

  const systemPrompt = lines.join('\n');

  type OAIRole = 'system' | 'user' | 'assistant';
  type OAIMsg = { role: OAIRole; content: string };
  const messages: OAIMsg[] = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-8).map((m: any) => ({
      role: (m.author === 'guest' ? 'user' : 'assistant') as OAIRole,
      content: String(m.body || '').slice(0, 400),
    })),
    { role: 'user', content: message },
  ];

  const oaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPEN_AI_KEY}`,
    },
    body: JSON.stringify({ model: 'gpt-4o-mini', messages, max_tokens: 350, temperature: 0.5 }),
  });

  const oaiData: any = await oaiRes.json().catch(() => ({}));
  if (!oaiRes.ok) {
    console.warn('[chatbot] OpenAI error:', oaiData?.error?.message || oaiRes.status);
    sendJson(res, 502, { error: 'AI response unavailable. Try a quick question below or contact the host directly.' });
    return;
  }

  const reply = String(oaiData?.choices?.[0]?.message?.content || '').trim();
  if (!reply) {
    sendJson(res, 502, { error: 'No reply received.' });
    return;
  }
  sendJson(res, 200, { reply });
}

// ---------- middleware entry ----------
export default function middleware(req: IncomingMessage, res: ServerResponse, next: () => void) {
  const url = new URL(req.url || '/', 'http://localhost');
  const route = (path: string, method: string, handler: (r: IncomingMessage, w: ServerResponse) => Promise<void>) => {
    if (url.pathname === path && req.method === method) {
      handler(req, res).catch((err) => {
        console.error(`[${path}]`, err);
        sendJson(res, 500, { error: 'Internal server error.' });
      });
      return true;
    }
    return false;
  };

  if (route('/api/auth/signup', 'POST', handleSignup)) return;
  if (route('/api/auth/provision', 'POST', handleProvision)) return;
  if (route('/api/auth/send-password-reset', 'POST', handleSendPasswordReset)) return;
  if (route('/api/promotions/validate', 'POST', handleValidatePromotion)) return;
  if (route('/api/promotions/public', 'GET', handlePublicPromotions)) return;
  if (route('/api/bookings', 'POST', handleCreateBooking)) return;
  if (route('/api/inquiries', 'POST', handleCreateInquiry)) return;
  if (route('/api/stripe/host-setup', 'GET', handleGetHostStripeSetup)) return;
  if (route('/api/stripe/host-setup', 'POST', handleSaveHostStripeSetup)) return;
  if (route('/api/stripe/host-setup/test', 'POST', handleTestHostStripeSetup)) return;
  if (route('/api/stripe/host-setup/test-booking', 'POST', handleRunHostStripeTestBooking)) return;
  if (route('/api/stripe/host-setup/disconnect', 'POST', handleDisconnectHostStripe)) return;
  if (route('/api/stripe/host-webhook', 'POST', handleHostStripeWebhook)) return;
  if (route('/api/stripe/config', 'GET', handleStripeConfig)) return;
  if (route('/api/stripe/create-subscription-checkout', 'POST', handleCreateSubscriptionCheckout)) return;
  if (route('/api/stripe/sync-subscription-checkout', 'POST', handleSyncSubscriptionCheckout)) return;
  if (route('/api/stripe/create-payment-intent', 'POST', handleCreatePaymentIntent)) return;
  if (route('/api/admin/data', 'GET', handleAdminData)) return;
  if (route('/api/admin/action', 'POST', handleAdminAction)) return;
  if (route('/api/admin/notifications/send', 'POST', handleAdminSendNotification)) return;
  if (route('/api/admin/settings', 'POST', handleAdminSaveSettings)) return;
  if (route('/api/admin/alerts/acknowledge', 'POST', handleAdminAcknowledgeAlert)) return;
  if (route('/api/domains/connect', 'POST', handleHostDomainConnect)) return;
  if (route('/api/domains/status', 'POST', handleHostDomainStatus)) return;
  if (route('/api/domains/disconnect', 'POST', handleHostDomainDisconnect)) return;
  if (route('/api/admin/domains/recheck', 'POST', handleAdminDomainRecheck)) return;
  if (route('/api/admin/domains/ssl-refresh', 'POST', handleAdminDomainRefreshSsl)) return;
  if (route('/api/admin/domains/disconnect', 'POST', handleAdminDomainDisconnect)) return;
  if (route('/api/email/booking-confirmation', 'POST', handleBookingConfirmationEmail)) return;
  if (route('/api/email/support-inquiry', 'POST', handleSupportInquiryEmail)) return;
  if (route('/api/email/guest-message', 'POST', handleGuestMessageEmail)) return;
  if (route('/api/email/review-request', 'POST', handleReviewRequestEmail)) return;
  if (route('/api/email/host-welcome', 'POST', handleHostWelcomeEmail)) return;
  if (route('/api/email/save-progress', 'POST', handleSaveProgressEmail)) return;
  if (route('/api/email/abandonment-reminder', 'POST', handleAbandonmentReminderEmail)) return;
  if (route('/api/google-places/autocomplete', 'POST', handleGooglePlacesAutocomplete)) return;
  if (url.pathname.startsWith('/api/google-places/details/') && req.method === 'GET') {
    (async () => {
      await handleGooglePlacesDetails(req, res);
    })().catch((err) => {
      console.error(`[${url.pathname}]`, err);
      sendJson(res, 500, { error: 'Internal server error.' });
    });
    return;
  }
  if (route('/api/google-places/photo', 'GET', handleGooglePlacesPhoto)) return;
  if (route('/api/google-places/nearby', 'POST', handleGooglePlacesNearby)) return;
  if (route('/api/guidebook/seed-starter', 'POST', handleGuidebookSeedStarter)) return;
  if (route('/api/guidebook/migrate-photos', 'POST', handleGuidebookMigratePhotos)) return;
  if (route('/api/kai/guidebook-recommendations', 'POST', handleKaiGuidebookRecommendations)) return;
  if (route('/api/chatbot', 'POST', handleChatbotMessage)) return;

  next();
}
