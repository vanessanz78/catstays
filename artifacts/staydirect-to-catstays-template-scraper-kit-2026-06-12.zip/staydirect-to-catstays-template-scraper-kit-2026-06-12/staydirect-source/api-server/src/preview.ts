import type { IncomingMessage, ServerResponse } from 'http';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80';

type ScrapedReview = {
  author: string;
  date?: string;
  text: string;
  rating?: number | null;
  source?: string;
};

type ScrapedReviewSummary = {
  rating: number | null;
  count: number | null;
  source: string;
  externalUrl?: string;
};

export function handlePreviewApi(req: IncomingMessage, res: ServerResponse, next: () => void) {
  const url = new URL(req.url || '/', 'http://localhost');

  if (url.pathname === '/api/health') {
    sendJson(res, 200, {
      ok: true,
      service: 'staydirect',
      mode: process.env.NODE_ENV === 'production' ? 'production' : 'preview',
    });
    return;
  }

  if (url.pathname === '/api/scrape' && req.method === 'GET') {
    handlePreviewScrape(url, res).catch((error) => {
      console.error('[api/scrape]', error);
      sendJson(res, 500, { error: 'The preview importer could not run.' });
    });
    return;
  }

  if (url.pathname === '/api/export-image' && req.method === 'GET') {
    handleExportImage(url, res).catch((error) => {
      console.error('[api/export-image]', error);
      sendJson(res, 500, { error: 'The image export helper could not run.' });
    });
    return;
  }

  next();
}

async function handleExportImage(url: URL, res: ServerResponse) {
  const rawUrl = url.searchParams.get('url') || '';
  let target: URL;

  try {
    target = new URL(rawUrl);
  } catch {
    sendJson(res, 400, { error: 'Missing or invalid image URL.' });
    return;
  }

  if (!['http:', 'https:'].includes(target.protocol)) {
    sendJson(res, 400, { error: 'Only public http(s) images can be exported.' });
    return;
  }

  try {
    const response = await fetch(target.toString(), {
      signal: AbortSignal.timeout(15000),
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      },
    });

    if (!response.ok) {
      sendJson(res, response.status >= 400 && response.status < 500 ? 422 : 502, {
        error: `Image returned ${response.status}.`,
      });
      return;
    }

    const contentType = response.headers.get('content-type') || 'image/jpeg';
    if (!contentType.startsWith('image/')) {
      sendJson(res, 422, { error: 'The requested URL is not an image.' });
      return;
    }

    const arrayBuffer = await response.arrayBuffer();
    res.statusCode = 200;
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.end(Buffer.from(arrayBuffer));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, message.toLowerCase().includes('timeout') ? 504 : 502, {
      error: 'The image could not be prepared for export.',
      details: message,
    });
  }
}

async function handlePreviewScrape(url: URL, res: ServerResponse) {
  const rawUrl = url.searchParams.get('url') || '';
  let target: URL;

  try {
    target = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
  } catch {
    sendJson(res, 400, { error: 'Paste a valid accommodation listing or website URL.' });
    return;
  }

  try {
    const response = await fetch(target.toString(), {
      signal: AbortSignal.timeout(15000),
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-NZ,en-GB;q=0.9,en-US;q=0.8,en;q=0.7',
      },
    });

    if (!response.ok) {
      sendJson(res, response.status >= 400 && response.status < 500 ? 422 : 502, {
        error: `That site returned ${response.status}. Try a public property page or paste the StayDirect/Deloraine demo URL.`,
      });
      return;
    }

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('html')) {
      sendJson(res, 422, { error: 'That URL does not look like a public website page.' });
      return;
    }

    const html = await response.text();
    sendJson(res, 200, buildScrapeResult(html, target));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, message.toLowerCase().includes('timeout') ? 504 : 502, {
      error: 'The importer could not read that website. Try the public property website URL, or try again in a moment.',
      details: message,
    });
  }
}

function buildScrapeResult(html: string, target: URL) {
  const jsonLd = extractJsonLd(html);
  const isAirbnbUrl = target.hostname.includes('airbnb.');
  const airbnbStateRecords = isAirbnbUrl ? extractAirbnbStateRecords(html) : [];
  const records = [...jsonLd, ...airbnbStateRecords];
  const lodgingData = findLodgingJsonLd(jsonLd);
  const host = extractHostProfile(html, records, target);
  const pageTitle =
    stringFrom(lodgingData?.name) ||
    extractMeta(html, 'og:title') ||
    extractMeta(html, 'twitter:title') ||
    extractTag(html, 'title') ||
    'Your Property';
  const airbnbFullDesc = isAirbnbUrl ? extractAirbnbDescription(html) : '';
  const descriptionCandidates = [
    airbnbFullDesc,
    stringFrom(lodgingData?.description),
    extractMeta(html, 'description'),
    extractMeta(html, 'og:description'),
    extractMeta(html, 'twitter:description'),
  ]
    .map((value) => cleanText(value))
    .filter((value) => value && value.toLowerCase() !== cleanText(pageTitle).toLowerCase() && value.length > 24);
  const rawDescription =
    descriptionCandidates.sort((a, b) => b.length - a.length)[0] ||
    'A direct booking website preview created from your public accommodation page.';
  const description = isAirbnbUrl ? cleanAirbnbMeta(rawDescription) : rawDescription;
  const tagline = generateDescriptionTagline(description);
  const title = isAirbnbUrl && /^cottage in |^home in |^apartment in |^rental unit in |^guest suite in /i.test(pageTitle) && description.length < 80
    ? description
    : pageTitle;
  const address = addressFromJsonLd(lodgingData?.address);
  const images = curateImageUrls([
    ...arrayFrom(lodgingData?.image),
    extractMeta(html, 'og:image'),
    extractMeta(html, 'twitter:image'),
    ...collectHtmlImages(html, target),
  ], target);
  const amenities = extractAmenities(html);
  const location = locationFromJsonLd(lodgingData?.geo);
  const price = numberFromDeep(lodgingData, ['price', 'lowPrice', 'priceRange']);
  const titleRating = title.match(/(?:star|rating|rated)\s*[:\s]*([0-5](?:\.\d{1,2})?)/i)?.[1];
  const importedReviews = extractImportedReviews(html, records, target, isAirbnbUrl);
  const reviewSummary = importedReviews.reviewSummary || (titleRating
    ? { rating: Number(titleRating), count: null, source: isAirbnbUrl ? 'Airbnb' : target.hostname, externalUrl: isAirbnbUrl ? `${target.toString()}#reviews` : target.toString() }
    : undefined);

  return {
    name: cleanText(title),
    shortDescription: tagline || cleanText(description).slice(0, 120),
    fullDescription: cleanText(description),
    city: cityFromAddress(address) || (target.hostname.includes('airbnb.') ? '' : cityFromHost(target.hostname)),
    country: countryFromAddress(address) || '',
    phone: stringFrom(lodgingData?.telephone),
    hostName: host.hostName,
    hostPhoto: host.hostPhoto,
    hostBio: host.hostBio,
    images: images.length ? images : [FALLBACK_IMAGE],
    amenities,
    amenityDetails: amenities,
    address,
    latitude: location.latitude,
    longitude: location.longitude,
    locationDescription: address || '',
    reviews: importedReviews.reviews,
    reviewSummary,
    brandColor: '#FF5A5F',
    fontFamily: 'Inter, Arial, sans-serif',
    bedrooms: numberFromDeep(lodgingData, ['numberOfBedrooms', 'bedrooms']),
    bathrooms: numberFromDeep(lodgingData, ['numberOfBathrooms', 'bathrooms']),
    maxGuests: numberFromDeep(lodgingData, ['occupancy', 'maximumAttendeeCapacity', 'personCapacity']),
    basePrice: price,
    sourceUrl: target.toString(),
    source: isAirbnbUrl ? 'airbnb' : 'generic',
  };
}

function cleanAirbnbMeta(text: string): string {
  return text
    .replace(/^\d{1,2}\s+\w+\s+\d{4}\s*[.]\s*/i, '')
    .replace(/^[^.]{2,45}[.]\s+/i, '')
    .replace(/\s*\w{0,6}\.{2,}$/, '')
    .trim();
}

function walkForDescription(obj: unknown, depth: number): string {
  if (depth > 8 || !obj || typeof obj !== 'object') return '';
  const record = obj as Record<string, unknown>;
  for (const key of ['htmlDescription', 'listingDescription', 'descriptionItems']) {
    const val = record[key];
    if (typeof val === 'string' && val.length > 80) return val;
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      const inner = walkForDescription(val, depth + 1);
      if (inner.length > 80) return inner;
    }
    if (Array.isArray(val)) {
      const combined = val.map((item) => {
        if (typeof item === 'string') return item;
        if (item && typeof item === 'object') {
          const r = item as Record<string, unknown>;
          return String(r.html ?? r.htmlText ?? r.title ?? r.body ?? '');
        }
        return '';
      }).filter(Boolean).join('\n\n');
      if (combined.length > 80) return combined;
    }
  }
  for (const val of Object.values(record)) {
    if (val && typeof val === 'object' && !Array.isArray(val)) {
      const found = walkForDescription(val, depth + 1);
      if (found.length > 80) return found;
    }
  }
  return '';
}

function extractAirbnbDescription(html: string): string {
  const nextDataMatch = html.match(/<script[^>]*id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
  if (nextDataMatch) {
    try {
      const data = JSON.parse(nextDataMatch[1]);
      const found = walkForDescription(data, 0);
      if (found.length > 80) return cleanText(found.replace(/<[^>]+>/g, ' '));
    } catch {}
  }
  const longDescPattern = /"(?:htmlDescription|listingDescription|description)"\s*:\s*"((?:[^"\\]|\\.){100,})"/g;
  for (const match of html.matchAll(longDescPattern)) {
    try {
      const decoded = JSON.parse(`"${match[1]}"`);
      const cleaned = cleanText(decoded.replace(/<[^>]+>/g, ' '));
      if (cleaned.length > 80 && /[a-z].*[.!?]/i.test(cleaned)) return cleaned;
    } catch {}
  }
  return '';
}

function extractAirbnbStateRecords(html: string): Record<string, unknown>[] {
  const records: Record<string, unknown>[] = [];
  const nextDataMatch = html.match(/<script[^>]*id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
  if (nextDataMatch) {
    try {
      const parsed = JSON.parse(nextDataMatch[1]);
      if (parsed && typeof parsed === 'object') records.push(parsed as Record<string, unknown>);
    } catch {}
  }

  const deferredMatches = html.matchAll(/<script[^>]+data-deferred-state-\d+=["']true["'][^>]*type=["']application\/json["'][^>]*>([\s\S]*?)<\/script>/gi);
  const deferredRoots: unknown[] = [];
  for (const match of deferredMatches) {
    try {
      deferredRoots.push(JSON.parse(match[1]) as unknown);
    } catch {}
  }
  if (deferredRoots.length) records.push({ airbnbDeferredState: deferredRoots });
  return records;
}

function deepFind(obj: unknown, key: string, depth = 0): unknown {
  if (depth > 24 || obj === null || typeof obj !== 'object') return undefined;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = deepFind(item, key, depth + 1);
      if (found !== undefined) return found;
    }
    return undefined;
  }

  const record = obj as Record<string, unknown>;
  if (key in record) return record[key];
  for (const value of Object.values(record)) {
    const found = deepFind(value, key, depth + 1);
    if (found !== undefined) return found;
  }
  return undefined;
}

function deepFindObjects(
  obj: unknown,
  predicate: (record: Record<string, unknown>) => boolean,
  results: Record<string, unknown>[] = [],
  depth = 0,
): Record<string, unknown>[] {
  if (depth > 24 || obj === null || typeof obj !== 'object') return results;
  if (Array.isArray(obj)) {
    for (const item of obj) deepFindObjects(item, predicate, results, depth + 1);
    return results;
  }

  const record = obj as Record<string, unknown>;
  if (predicate(record)) results.push(record);
  for (const value of Object.values(record)) deepFindObjects(value, predicate, results, depth + 1);
  return results;
}

function numberFromValue(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) && value > 0 ? value : null;
  if (typeof value === 'string') {
    const numeric = Number(value.replace(/[^0-9.]/g, ''));
    return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
  }
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    return numberFromValue(record.ratingValue ?? record.value ?? record.count);
  }
  return null;
}

function firstNumber(...values: unknown[]): number | null {
  for (const value of values) {
    const numeric = numberFromValue(value);
    if (numeric !== null) return numeric;
  }
  return null;
}

function rawText(value: unknown): string {
  if (typeof value === 'string') return cleanText(value.replace(/<[^>]+>/g, ' '));
  if (typeof value === 'number') return String(value);
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    return rawText(record.text ?? record.htmlText ?? record.title ?? record.body);
  }
  return '';
}

function firstUsefulText(...values: unknown[]): string {
  for (const value of values) {
    const text = rawText(value);
    if (text.length > 1) return text;
  }
  return '';
}

function reviewTextFromRecord(record: Record<string, unknown>): string {
  return firstUsefulText(
    record.comments,
    record.localizedReview,
    record.reviewText,
    record.reviewBody,
    record.body,
    record.text,
    record.description,
  );
}

function extractImportedReviews(
  html: string,
  records: Record<string, unknown>[],
  target: URL,
  isAirbnbSource: boolean,
): { reviews: ScrapedReview[]; reviewSummary?: ScrapedReviewSummary } {
  const source = isAirbnbSource ? 'Airbnb' : target.hostname.replace(/^www\./, '');
  const aggregateRating = deepFind(records, 'aggregateRating') as Record<string, unknown> | undefined;
  const visibleText = cleanText(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' '));
  const visibleRating = visibleText.match(/(?:★|rated\s*|rating\s*)\s*([0-5](?:\.\d{1,2})?)/i)?.[1];
  const visibleCount = visibleText.match(/([0-9][0-9,]{0,5})\s+(?:guest\s+)?reviews?/i)?.[1];
  const rating = firstNumber(
    deepFind(records, 'overallRating'),
    deepFind(records, 'ratingAverage'),
    deepFind(records, 'reviewRating'),
    aggregateRating?.ratingValue,
    aggregateRating?.value,
    visibleRating,
  );
  const count = firstNumber(
    deepFind(records, 'overallCount'),
    deepFind(records, 'ratingCount'),
    deepFind(records, 'reviewCount'),
    deepFind(records, 'reviewsCount'),
    aggregateRating?.reviewCount,
    aggregateRating?.ratingCount,
    visibleCount,
  );

  const reviewObjects = deepFindObjects(records, (record) => {
    const text = reviewTextFromRecord(record);
    if (!text || text.length < 30) return false;
    const typeName = rawText(record.__typename ?? record['@type'] ?? record.type);
    const hasReviewKey = ['comments', 'localizedReview', 'reviewText', 'reviewBody'].some((key) => typeof record[key] === 'string');
    const hasAuthor = Boolean(record.reviewer || record.author || record.user || record.reviewerName || record.authorName);
    return hasReviewKey || hasAuthor || /review/i.test(typeName) || Boolean(record.reviewRating);
  });

  const reviews: ScrapedReview[] = [];
  for (const review of reviewObjects) {
    const text = reviewTextFromRecord(review);
    if (!text || reviews.some((existing) => existing.text === text)) continue;
    const authorRecord = (review.reviewer ?? review.author ?? review.user) as Record<string, unknown> | undefined;
    const author = firstUsefulText(
      review.reviewerName,
      review.authorName,
      authorRecord?.name,
      authorRecord?.firstName,
    ) || `${source} guest`;
    const date = firstUsefulText(review.localizedDate, review.createdAt, review.date) || undefined;
    reviews.push({
      author,
      date,
      text,
      rating: firstNumber(review.rating, review.reviewRating, review.score),
      source,
    });
    if (reviews.length >= 6) break;
  }

  return {
    reviews,
    reviewSummary: rating || count ? {
      rating,
      count,
      source,
      externalUrl: isAirbnbSource ? `${target.toString()}#reviews` : target.toString(),
    } : undefined,
  };
}

function generateDescriptionTagline(description: string): string {
  if (!description || description.length < 20) return '';
  const firstSentence = description.match(/^(.{20,160}?[.!?])(?:\s|$)/)?.[1];
  if (firstSentence) return firstSentence.trim();
  const short = description.slice(0, 120);
  const lastSpace = short.lastIndexOf(' ');
  return (lastSpace > 40 ? short.slice(0, lastSpace) : short).trim();
}

function extractMeta(html: string, name: string): string {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${escaped}["'][^>]+content=["']([^"']+)["']`, 'i'),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+property=["']${escaped}["']`, 'i'),
    new RegExp(`<meta[^>]+name=["']${escaped}["'][^>]+content=["']([^"']+)["']`, 'i'),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+name=["']${escaped}["']`, 'i'),
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) return decodeEntities(match[1]).trim();
  }
  return '';
}

function extractTag(html: string, tag: string): string {
  const match = html.match(new RegExp(`<${tag}[^>]*>([^<]+)<\\/${tag}>`, 'i'));
  return match?.[1] ? decodeEntities(match[1]).trim() : '';
}

function extractJsonLd(html: string): Record<string, unknown>[] {
  const results: Record<string, unknown>[] = [];
  const matches = html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
  for (const match of matches) {
    try {
      const parsed = JSON.parse(match[1]);
      if (Array.isArray(parsed)) {
        results.push(...parsed.filter((item) => item && typeof item === 'object'));
      } else if (parsed && typeof parsed === 'object') {
        results.push(parsed);
      }
    } catch {}
  }
  return results;
}

function findLodgingJsonLd(records: Record<string, unknown>[]): Record<string, unknown> | null {
  const queue = [...records];
  while (queue.length) {
    const item = queue.shift();
    if (!item) continue;
    const type = arrayFrom(item['@type']).join(' ').toLowerCase();
    if (/lodging|hotel|accommodation|house|apartment|resort|bedandbreakfast|localbusiness/.test(type)) return item;
    for (const value of Object.values(item)) {
      if (Array.isArray(value)) queue.push(...value.filter((child) => child && typeof child === 'object') as Record<string, unknown>[]);
      if (value && typeof value === 'object') queue.push(value as Record<string, unknown>);
    }
  }
  return records[0] || null;
}

function collectHtmlImages(html: string, baseUrl: URL): string[] {
  const images: string[] = [];
  const directUrls = html.matchAll(/https?:\/\/[^"'<>\s\\)]+\.(?:jpe?g|png|webp)(?:\?[^"'<>\s\\)]*)?/gi);
  for (const match of directUrls) images.push(match[0]);

  const imgTags = html.matchAll(/<img\b[^>]*>/gi);
  for (const tagMatch of imgTags) {
    const tag = tagMatch[0];
    const src = tag.match(/\ssrc=["']([^"']+)["']/i)?.[1];
    if (src) images.push(src);
    const srcSet = tag.match(/\ssrcset=["']([^"']+)["']/i)?.[1];
    if (srcSet) {
      for (const candidate of srcSet.split(',')) {
        const [candidateUrl] = candidate.trim().split(/\s+/);
        if (candidateUrl) images.push(candidateUrl);
      }
    }
  }
  return images.map((image) => absoluteImageUrl(image, baseUrl)).filter(Boolean) as string[];
}

function curateImageUrls(rawImages: unknown[], baseUrl: URL): string[] {
  const byKey = new Map<string, string>();
  for (const raw of rawImages.flatMap((item) => arrayFrom(item))) {
    const image = absoluteImageUrl(String(raw || ''), baseUrl);
    if (!image) continue;
    if (/\.(svg|gif)(\?|$)/i.test(image)) continue;
    if (/favicon|apple-touch-icon|logo|placeholder|avatar|profile|\/user\/|airbnb-platform-assets|review-ai-synthesis/i.test(image)) continue;
    const key = imageKey(image);
    const existing = byKey.get(key);
    if (!existing || imageWidth(image) > imageWidth(existing)) byKey.set(key, image);
  }
  return Array.from(byKey.values()).slice(0, 18);
}

function absoluteImageUrl(rawUrl: string, baseUrl: URL): string | null {
  const cleaned = decodeEntities(rawUrl).trim().replace(/[),.;}]+$/g, '');
  if (!cleaned || cleaned.startsWith('data:') || cleaned.startsWith('blob:')) return null;
  try {
    const absolute = new URL(cleaned, baseUrl.toString()).toString();
    if (!/^https?:\/\//i.test(absolute)) return null;
    const imageLikeHost = /muscache|airbnb|cloudinary|googleusercontent|staticflickr|booking|expedia/i.test(new URL(absolute).hostname);
    const imageLikePath = /\/(?:im\/pictures|pictures|images|photos|photo)\//i.test(new URL(absolute).pathname);
    if (!/\.(jpe?g|png|webp)(\?|$)/i.test(absolute) && !absolute.includes('images') && !imageLikeHost && !imageLikePath) return null;
    return absolute;
  } catch {
    return null;
  }
}

function extractAmenities(html: string): string[] {
  const text = decodeEntities(html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').toLowerCase());
  const possible = [
    ['WiFi', /\bwifi\b|wireless internet/],
    ['Kitchen', /\bkitchen\b/],
    ['Parking', /\bparking\b/],
    ['Pool', /\bpool\b/],
    ['Hot tub', /hot tub|spa pool/],
    ['Air conditioning', /air conditioning|\baircon\b/],
    ['Heating', /\bheating\b/],
    ['Washing machine', /washing machine|\bwasher\b/],
    ['Dryer', /\bdryer\b/],
    ['BBQ', /\bbbq\b|barbecue/],
    ['Waterfront', /waterfront|beachfront|ocean view/],
    ['Pet friendly', /pet friendly|pets allowed/],
  ] as const;
  return possible.filter(([, pattern]) => pattern.test(text)).map(([label]) => label).slice(0, 12);
}

function addressFromJsonLd(address: unknown): string {
  if (!address) return '';
  if (typeof address === 'string') return cleanText(address);
  if (typeof address !== 'object') return '';
  const record = address as Record<string, unknown>;
  return [
    record.streetAddress,
    record.addressLocality,
    record.addressRegion,
    record.postalCode,
    record.addressCountry,
  ].map(stringFrom).filter(Boolean).join(', ');
}

function locationFromJsonLd(geo: unknown): { latitude: number | null; longitude: number | null } {
  if (!geo || typeof geo !== 'object') return { latitude: null, longitude: null };
  const record = geo as Record<string, unknown>;
  const latitude = Number(record.latitude);
  const longitude = Number(record.longitude);
  return {
    latitude: Number.isFinite(latitude) ? latitude : null,
    longitude: Number.isFinite(longitude) ? longitude : null,
  };
}

function cityFromAddress(address: string): string {
  return address.split(',').map((part) => part.trim()).filter(Boolean).at(-3) || '';
}

function countryFromAddress(address: string): string {
  return address.split(',').map((part) => part.trim()).filter(Boolean).at(-1) || '';
}

function cityFromHost(hostname: string): string {
  return hostname.replace(/^www\./, '').split('.')[0]?.replace(/[-_]+/g, ' ') || '';
}

function stringFrom(value: unknown): string {
  if (typeof value === 'string') return cleanText(value);
  if (typeof value === 'number') return String(value);
  if (Array.isArray(value)) return stringFrom(value[0]);
  if (value && typeof value === 'object' && 'text' in value) return stringFrom((value as { text?: unknown }).text);
  return '';
}

function extractHostProfile(html: string, records: Record<string, unknown>[], baseUrl: URL): { hostName: string; hostPhoto: string; hostBio: string } {
  const hostCandidates = deepFindObjects(records, (record) => {
    const typeName = rawText(record.__typename ?? record['@type'] ?? record.type);
    const hasHostMarker = /host|owner|user|profile/i.test(typeName) || 'isSuperhost' in record || 'hostId' in record;
    const hasHostData = Boolean(
      record.name ||
      record.firstName ||
      record.hostName ||
      record.displayName ||
      record.pictureUrl ||
      record.profilePictureUrl ||
      record.avatarUrl ||
      record.imageUrl ||
      record.hostDescription ||
      record.hostBio ||
      record.bio ||
      record.about,
    );
    return hasHostMarker && hasHostData;
  });
  const bestHost: Record<string, unknown> = hostCandidates.find((record) => firstUsefulText(
    record.pictureUrl,
    record.profilePictureUrl,
    record.avatarUrl,
    record.imageUrl,
    record.picture,
    record.avatar,
  )) || hostCandidates[0] || {};
  const structuredCandidates = [
    bestHost.name,
    bestHost.firstName,
    bestHost.hostName,
    bestHost.displayName,
    ...records
      .flatMap((record) => [record.host, record.owner, record.creator, record.author, record.founder])
      .map((value) => {
        if (typeof value === 'string') return value;
        if (value && typeof value === 'object') return stringFrom((value as Record<string, unknown>).name);
        return '';
      }),
  ];
  const hostName = [
    ...structuredCandidates,
    rawText(deepFind(records, 'hostName')),
    rawText(deepFind(records, 'localizedHostName')),
    rawText(deepFind(records, 'hostFirstName')),
    html.match(/hosted by\s+([A-Z][A-Za-z' -]{2,80})/i)?.[1] || '',
    html.match(/your host(?: is)?\s+([A-Z][A-Za-z' -]{2,80})/i)?.[1] || '',
  ]
    .map((value) => cleanText(value).replace(/^hosted by\s+/i, ''))
    .find((value) => value && !/^(host|owner|guest|airbnb|superhost)$/i.test(value)) || '';

  const hostImageTag = Array.from(html.matchAll(/<img\b[^>]*>/gi))
    .map((match) => match[0])
    .find((tag) => /\b(alt|class|src)=["'][^"']*(host|owner|profile|avatar)[^"']*["']/i.test(tag));
  const hostImageRaw = firstUsefulText(
    bestHost.pictureUrl,
    bestHost.profilePictureUrl,
    bestHost.avatarUrl,
    bestHost.imageUrl,
    bestHost.picture,
    bestHost.avatar,
    deepFind(records, 'hostThumbnailUrl'),
    deepFind(records, 'hostProfilePhotoUrl'),
    deepFind(records, 'profilePictureUrl'),
    deepFind(records, 'userProfilePictureUrl'),
    hostImageTag?.match(/\ssrc=["']([^"']+)["']/i)?.[1] || '',
  );
  const hostBio = firstUsefulText(
    bestHost.hostDescription,
    bestHost.hostBio,
    bestHost.bio,
    bestHost.about,
    bestHost.localizedAbout,
    bestHost.profileDescription,
    deepFind(records, 'hostDescription'),
    deepFind(records, 'hostBio'),
    deepFind(records, 'hostAbout'),
    deepFind(records, 'localizedHostBio'),
  );
  return {
    hostName,
    hostPhoto: hostImageRaw ? absoluteImageUrl(hostImageRaw, baseUrl) || '' : '',
    hostBio,
  };
}

function arrayFrom(value: unknown): unknown[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function numberFromDeep(record: unknown, keys: string[]): number | null {
  if (!record || typeof record !== 'object') return null;
  const queue = [record as Record<string, unknown>];
  while (queue.length) {
    const item = queue.shift();
    if (!item) continue;
    for (const key of keys) {
      const value = item[key];
      const numeric = typeof value === 'string' ? Number(value.replace(/[^0-9.]/g, '')) : Number(value);
      if (Number.isFinite(numeric) && numeric > 0) return numeric;
    }
    for (const value of Object.values(item)) {
      if (Array.isArray(value)) queue.push(...value.filter((child) => child && typeof child === 'object') as Record<string, unknown>[]);
      if (value && typeof value === 'object') queue.push(value as Record<string, unknown>);
    }
  }
  return null;
}

function imageKey(rawUrl: string): string {
  try {
    const url = new URL(rawUrl);
    return `${url.hostname}${url.pathname}`;
  } catch {
    return rawUrl.split('?')[0];
  }
}

function imageWidth(rawUrl: string): number {
  try {
    const url = new URL(rawUrl);
    return Number(url.searchParams.get('w') || url.searchParams.get('width')) || 0;
  } catch {
    return 0;
  }
}

function cleanText(value: unknown): string {
  return decodeEntities(value).replace(/\s+/g, ' ').trim();
}

function decodeEntities(value: unknown): string {
  return String(value ?? '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

function sendJson(res: ServerResponse, status: number, payload: unknown) {
  if (res.headersSent) return;
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}
