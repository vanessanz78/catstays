import { createReadStream } from 'fs';
import { access, stat } from 'fs/promises';
import { createServer, type IncomingMessage, type ServerResponse } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import apiMiddleware from '../api-server/src/app';
import { handlePreviewApi } from '../api-server/src/preview';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, '../public');
const indexHtmlPath = path.join(publicDir, 'index.html');
const port = Number(process.env.PORT || process.env.STAYDIRECT_PORT || 5000);

if (!Number.isFinite(port) || port <= 0) {
  throw new Error(`Invalid PORT value: ${process.env.PORT || process.env.STAYDIRECT_PORT}`);
}

const server = createServer((req, res) => {
  runMiddleware(req, res, apiMiddleware, () => {
    runMiddleware(req, res, handlePreviewApi, () => {
      if ((req.url || '').startsWith('/api/')) {
        sendJson(res, 404, { error: 'API route not found.' });
        return;
      }
      serveStaticOrSpa(req, res).catch((error) => {
        console.error('[static]', error);
        sendJson(res, 500, { error: 'Internal server error.' });
      });
    });
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`StayDirect listening on 0.0.0.0:${port}`);
});

function runMiddleware(
  req: IncomingMessage,
  res: ServerResponse,
  middleware: (req: IncomingMessage, res: ServerResponse, next: () => void) => void,
  next: () => void,
) {
  if (res.writableEnded || res.headersSent) return;
  middleware(req, res, () => {
    if (!res.writableEnded && !res.headersSent) next();
  });
}

async function serveStaticOrSpa(req: IncomingMessage, res: ServerResponse) {
  if (!['GET', 'HEAD'].includes(req.method || 'GET')) {
    res.statusCode = 405;
    res.setHeader('Allow', 'GET, HEAD');
    res.end();
    return;
  }

  const url = new URL(req.url || '/', 'http://localhost');
  const pathname = decodeURIComponent(url.pathname);
  const filePath = resolvePublicPath(pathname);
  if (filePath) {
    await streamFile(filePath, req, res);
    return;
  }

  await streamFile(indexHtmlPath, req, res, {
    statusCode: 200,
    cacheControl: 'no-cache',
  });
}

function resolvePublicPath(pathname: string) {
  const normalized = pathname === '/' ? '/index.html' : pathname;
  const requestedPath = path.normalize(normalized).replace(/^(\.\.[/\\])+/, '');
  const fullPath = path.resolve(publicDir, `.${requestedPath}`);
  if (!fullPath.startsWith(publicDir)) return null;
  return fullPath;
}

async function streamFile(
  filePath: string,
  req: IncomingMessage,
  res: ServerResponse,
  options: { statusCode?: number; cacheControl?: string } = {},
) {
  try {
    await access(filePath);
    const stats = await stat(filePath);
    if (!stats.isFile()) throw new Error('Not a file');
  } catch {
    if (filePath !== indexHtmlPath) {
      await streamFile(indexHtmlPath, req, res, {
        statusCode: 200,
        cacheControl: 'no-cache',
      });
      return;
    }
    sendJson(res, 500, { error: 'Built frontend not found. Run npm run build first.' });
    return;
  }

  const contentType = contentTypeFor(filePath);
  const cacheControl = options.cacheControl || cacheControlFor(filePath);

  res.statusCode = options.statusCode || 200;
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', cacheControl);
  if (req.method === 'HEAD') {
    res.end();
    return;
  }
  createReadStream(filePath).pipe(res);
}

function contentTypeFor(filePath: string) {
  const ext = path.extname(filePath).toLowerCase();
  const types: Record<string, string> = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.mjs': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.txt': 'text/plain; charset=utf-8',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
  };
  return types[ext] || 'application/octet-stream';
}

function cacheControlFor(filePath: string) {
  if (path.basename(filePath) === 'index.html') return 'no-cache';
  if (filePath.includes(`${path.sep}assets${path.sep}`)) return 'public, max-age=31536000, immutable';
  return 'public, max-age=3600';
}

function sendJson(res: ServerResponse, status: number, payload: unknown) {
  if (res.headersSent) return;
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}
