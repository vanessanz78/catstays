# Preview Import Incident

Date: 2026-06-12

Status: fixed in code and verified both locally and in the Replit workspace; production redeploy still required for live verification.

## User-Visible Symptom

The `/preview` flow accepts a URL and shows the preview form, but clicking `Generate Preview` fails with:

`Could not import that website.`

The failure was reproduced from the live app with:

- An Airbnb listing URL
- `https://delorainecottage.com/`
- `https://example.com/`

## Scope

This is not limited to Airbnb blocking. Local reproduction against the deployed branch showed the same importer failure for simple public HTML pages.

## Technical Finding

Production is running the `deployment-stabilisation` branch, which starts the built Node server via:

`node dist/server/index.js`

The built server routes preview import requests through `api-server/src/preview.ts`.

Local reproduction on `deployment-stabilisation`:

- `npm run build` passed.
- Local `/api/health` returned `200`.
- Local `/api/scrape?url=https%3A%2F%2Fexample.com%2F` returned JSON `502`.
- The error detail was:

`Cannot read properties of undefined (reading 'replace')`

The likely code-level cause is that `cleanText(value: string)` and `decodeEntities(str: string)` assume string input, while scraper parsing passes optional or unknown values from host/profile candidates. In particular, host parsing builds arrays containing undefined values and then maps them through `cleanText`.

## Fix

The preview importer text helpers were hardened in:

- `api-server/src/preview.ts`
- `vite.config.ts`

`cleanText` and `decodeEntities` now safely accept unknown or missing values before normalizing text. This prevents optional scraper fields from crashing the whole import.

## Live Behavior

The live production endpoint currently returns a raw Cloudflare `502` for `/api/scrape`, which is worse than the local JSON error because the front end cannot show a specific importer error.

After the fix was merged into the Replit workspace and pushed as `7b4b0c0`, the Replit workspace endpoint at `127.0.0.1:5000/api/scrape` returned JSON `200` for the reported Airbnb import. The public `https://staydirect.nz/api/scrape` endpoint still returned Cloudflare `502`, so the remaining failure is deployment freshness rather than the importer code path in the workspace.

Follow-up public probes showed:

- `GET https://staydirect.nz/api/health` returned `200` JSON.
- `GET https://staydirect.nz/api/scrape` without a URL returned the expected JSON `400`.
- `GET https://staydirect.nz/api/scrape?url=...` returned raw Cloudflare `502` for `example.com`, `staydirect.nz`, and the reported Airbnb listing.

This confirms the public API route exists and the origin is reachable, but URL processing in the public deployment still fails or crashes before a JSON importer response can be returned.

## Recommended Fix

1. Redeploy the current `deployment-stabilisation` branch through Replit.
2. Verify live `/api/scrape` returns JSON `200` instead of Cloudflare `502`.
3. Validate `/api/scrape` locally and live with:
   - `https://example.com/`
   - `https://delorainecottage.com/`
   - The reported Airbnb listing URL
4. Validate the browser `/preview?url=...` flow on production.
5. If live production still returns Cloudflare `502` after a fresh Replit deployment, inspect Replit deployment logs and Cloudflare origin routing because the workspace runtime is already known-good.

## Local Verification

Validated on the built `deployment-stabilisation` server using `PORT=5055 npm run start`:

- `npm run typecheck -- --pretty false`: passed
- `npm run build`: passed
- `GET /api/health`: returned `200`
- `GET /api/scrape?url=https%3A%2F%2Fexample.com%2F`: returned JSON `200`
- `GET /api/scrape?url=https%3A%2F%2Fdelorainecottage.com%2F`: returned JSON `200`
- `GET /api/scrape?url=https%3A%2F%2Fwww.airbnb.co.nz%2Frooms%2F32071898`: returned JSON `200` with Airbnb listing data, images, host name, and description

Live production still returned Cloudflare `502` after the fix was pushed to GitHub.

## Replit Workspace Verification

After Replit merged and pushed the repair branch as `7b4b0c0`, the Replit workspace reported:

- Git branch `deployment-stabilisation` was up to date with `origin/deployment-stabilisation`.
- Working tree was clean.
- `GET http://127.0.0.1:5000/api/scrape?url=https%3A%2F%2Fwww.airbnb.co.nz%2Frooms%2F32071898` returned `200` JSON with Airbnb listing data.

This confirms no further Git pull is required for this fix while the branch remains at or beyond `7b4b0c0`. The remaining action is Replit production redeploy and live verification.

## Related Documentation

- [Preview System](preview-system.md)
- [Current State Audit](current-state.md)
- [Deployment Status](deployment-status.md)
