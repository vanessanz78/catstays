# Deployment Status

Last updated: 2026-06-12

StayDirect is configured to develop and deploy through Replit, with Cloudflare routing public domains and Supabase providing backend services.

## Replit Configuration

The `.replit` file configures:

- Node.js 20
- Python 3.11
- PostgreSQL 16 module
- Development command: `npm run dev`
- Deployment build command: `npm run build`
- Deployment run command: `npm run start`
- External app port: `5000`

The Replit connector available during this audit could not inspect existing Replit apps because it only exposes apps created in the current chat context. Deployment status was therefore verified through repository configuration and live endpoint probes.

## Environment Variables

Deployment depends on environment variables for services including:

- Supabase URL and anonymous key
- Supabase service role key
- Stripe public and secret keys
- Resend
- Cloudflare API token and zone ID
- Google Places
- OpenAI

Secret values must not be committed to GitHub.

## Live Endpoint Probe

Observed during audit:

| Endpoint | Status |
| --- | --- |
| `https://staydirect.nz` | 200 |
| `https://book.staydirect.nz` | 200 |
| `https://admin.staydirect.nz` | 200 |
| `https://delorainecottage.staydirect.nz` | 200 |
| `https://delorainecottage.com` | 200 |
| `https://staydirect.nz/marketplace` | 200 |
| `https://staydirect.nz/dashboard` | 200 |
| `https://www.staydirect.nz` | 525 Cloudflare SSL handshake failed |

## Preview Import Deployment Check

Observed on 2026-06-12 after the preview import repair was merged into the Replit workspace branch and pushed as `7b4b0c0`:

| Target | Status | Meaning |
| --- | --- | --- |
| Replit workspace `127.0.0.1:5000/api/scrape` | 200 JSON | The workspace code and local Replit process have the importer fix. |
| `https://staydirect.nz/api/scrape` | 502 Cloudflare response | The public deployment had not yet picked up the fixed runtime. |

Follow-up probes showed `https://staydirect.nz/api/health` returns `200` JSON and `https://staydirect.nz/api/scrape` without a URL returns the expected JSON `400`. However, `https://staydirect.nz/api/scrape?url=...` still returns a raw Cloudflare `502` for any supplied URL, including `example.com` and the reported Airbnb listing. This means the public API route exists and the app is reachable, but the live deployment fails when URL processing begins.

No further Git pull is required for this specific fix while the branch remains at or beyond `7b4b0c0`. The next action is to redeploy the Replit production deployment, then re-run the live `/api/scrape` probe and the browser `/preview?url=...` flow. If a fresh redeploy still returns `502`, inspect Replit deployment logs for the `/api/scrape` crash because the public route reaches the app before failing.

## Visual Endpoint Probe

Observed during the 2026-06-12 visual audit:

| Endpoint | HTTP status | Visual result |
| --- | --- | --- |
| `https://staydirect.nz/` | 200 | Public StayDirect marketing home renders correctly. |
| `https://book.staydirect.nz/` | 200 | Marketplace landing renders, but shows "Handpicked stays are coming soon" placeholder. |
| `https://admin.staydirect.nz/` | 200 | Renders public marketing home, not admin-specific UI. |
| `https://delorainecottage.staydirect.nz/` | 200 | Deloraine property site renders correctly. |
| `https://delorainecottage.com/` | 200 | Deloraine custom-domain property site renders correctly. |
| `https://staydirect.nz/marketplace` | 200 | Marketplace route renders with Deloraine as a real featured stay. |
| `https://staydirect.nz/dashboard` | 200 | Redirects unauthenticated users to sign-in. |
| `https://staydirect.nz/my-property/delorainecottage` | 200 | Dev-style property route renders Deloraine guest-facing site. |

Screenshot evidence and route-level notes are stored in [Visual Audit 2026-06-12](visual-audit/2026-06-12/).

## Verification Commands Run

The following checks passed before this documentation commit:

- `npm run typecheck -- --pretty false`
- `npm run build`
- `npm run check:launch`

## Deployment Risks

- Public production may lag behind the Replit workspace after Git pushes; preview import is the current example and needs redeploy/live verification.
- `www.staydirect.nz` SSL failure needs urgent repair.
- `book.staydirect.nz` and `/marketplace` currently show inconsistent marketplace content.
- `admin.staydirect.nz` currently serves the public marketing page, so intended admin routing needs confirmation.
- Supabase migration tracking is not reliable until reconciled.
- Supabase Edge Functions appear undeployed despite a function existing in the repo.
- Cloudflare custom-hostname status could not be verified with the available token.

## Release Rule

Every deployment-impacting change must update this document, `current-state.md`, or both.
