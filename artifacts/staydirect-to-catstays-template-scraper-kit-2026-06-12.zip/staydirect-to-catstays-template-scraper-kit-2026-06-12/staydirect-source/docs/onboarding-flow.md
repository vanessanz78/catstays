# Onboarding Flow

Last updated: 2026-06-12

StayDirect onboarding is designed to get a host from an existing listing or website to a usable direct-booking presence with minimal friction.

## Core Flow

1. Host enters an existing listing or website URL, or starts manually.
2. The scraper reads public accommodation content only.
3. StayDirect creates a preview session and draft property data.
4. The host reviews generated website options.
5. The host chooses design direction, pricing, policies, URL slug, and key property details.
6. StayDirect creates or updates the property in Supabase.
7. The host continues into subscription, payment setup, and dashboard completion.

## Recovered Product Decision

The recovered historical material strongly favored a URL-first journey:

- Import existing public content first.
- Show visual options before asking for full setup work.
- Move setup and business details after the host chooses a version.

This decision should remain the default onboarding shape unless changed in GitHub documentation and product implementation together.

## Public Scraping Boundary

The scraper can import public content such as:

- Property name and summary
- Photos
- Amenities
- Location cues
- Public rate hints
- Existing listing descriptions

The scraper must not claim to import:

- Private reservation data
- Guest records
- Payment cards
- Host-only dashboards
- Platform-private analytics

Those require official APIs, manual imports, or future integration work.

## Property Identity

Property identity must be exact and stable:

- Slugs are unique.
- Subdomain routing uses exact slug matches.
- Custom domains map through `domain_mappings`.
- Prefix matching is not allowed.

The Deloraine Cottage seed path has a canonical property identity:

- Property ID: `70905e83-f782-4501-9f40-12114153ff73`
- Slug: `delorainecottage`

When this property already exists, provisioning should avoid overwriting host-edited fields such as custom domain and content.

## Onboarding Completion Signals

A property should be considered meaningfully onboarded when it has:

- Property name, slug, and host ownership
- Public description and photos
- Location information
- Booking settings or clear booking-call-to-action state
- Pricing or rate guidance
- Policies
- Dashboard access for the host
- Optional subscription and payment setup

## Known Risks

- Preview session schema drift exists in production logs: `preview_sessions.status` is referenced by code but absent in the live database.
- Local/demo fallback paths must not mask production write failures.
- Subscription prompts should not block necessary setup recovery or admin repair flows.
