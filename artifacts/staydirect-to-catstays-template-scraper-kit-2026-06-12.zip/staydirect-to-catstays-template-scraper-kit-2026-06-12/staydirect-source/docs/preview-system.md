# Preview System

Last updated: 2026-06-12

The preview system lets a host see StayDirect website options before committing to full setup.

## Purpose

The preview system should:

- Convert an existing public listing or website into structured property content.
- Generate multiple website directions from the same property data.
- Let the host choose the design direction before completing setup.
- Preserve draft data so the host can continue onboarding.

## Core Files

- `scraper-handoff/README.md`
- `scraper-handoff/scrape.ts`
- `src/lib/previewSessions.ts`
- `src/lib/websiteDesignOptions.ts`
- `src/pages/GeneratedPreviewPage.tsx`
- `src/pages/WebsiteOptionsPage.tsx`
- `src/pages/WebsiteOptionPreviewPage.tsx`

## Website Options

The current option set is:

| Option | Intent |
| --- | --- |
| Original / Source Match | Keep close to the imported source site or listing |
| Modern Showcase | Premium, image-led property presentation |
| Conversion Focus | Clear booking journey and high-intent calls to action |
| Editorial Guide | Place-led, story-rich property and destination experience |

## Preview Session Storage

Preview sessions are stored in Supabase when available, with fallback behavior for legacy or local flows. The application has compatibility paths for older schemas.

Current production risk:

- Live Postgres logs show `column preview_sessions.status does not exist`. Code that expects this field must either be migrated or guarded.
- Preview URL import failed before a preview session could be created. A code fix has been locally verified and awaits production redeploy/live verification. See [Preview Import Incident 2026-06-12](preview-import-incident-2026-06-12.md).

## Guest-Site Preview Rule

`/my-property` in the Replit development environment should show the live guest-facing property site, not a hidden local preview mode. Historical preview behavior hid Host Login and intercepted booking clicks, so preview detection must stay conservative.

## Recovered Product Direction

The recovered historical material treated the preview flow as a critical conversion moment. The host should see attractive site choices before being asked to complete deeper setup. This is the core distinction between a simple form-based onboarding flow and a StayDirect website-generation flow.
