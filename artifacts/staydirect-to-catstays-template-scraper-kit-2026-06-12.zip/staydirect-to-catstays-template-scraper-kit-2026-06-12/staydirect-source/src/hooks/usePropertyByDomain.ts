import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { LOCAL_AUTH_KEY, LOCAL_HOST_ID, readLocalProperty } from '../lib/localSetup';
import { getDeloraineDemoImport } from '../lib/deloraineDemoSite';
import { loadDashboardData } from '../lib/dashboardLocalData';
import {
  getStayDirectSubdomain,
  isCustomDomainHost,
  isMarketplaceHost,
  isPropertyHost,
  isReservedSubdomain,
  logDomainRouting,
  normalizeHostname,
} from '../lib/domainRouting';
import { fetchDomainMappingForHostname } from '../lib/domains';

export type WebsiteContentBlockType = 'text' | 'photos' | 'video' | 'embed' | 'widget' | 'custom';

export interface WebsiteContentBlock {
  id?: string | null;
  title?: string | null;
  type?: WebsiteContentBlockType | null;
  heading?: string | null;
  body?: string | null;
  mediaUrls?: string | null;
  embedCode?: string | null;
  customCss?: string | null;
  buttonLabel?: string | null;
  buttonUrl?: string | null;
}

export interface WebsiteContent {
  source_url?: string | null;
  tagline?: string | null;
  logo_image?: string | null;
  site_title?: string | null;
  favicon_image?: string | null;
  virtual_tour_url?: string | null;
  highlights?: { label: string; iconKey?: string }[] | null;
  amenity_groups?: { title: string; items: string[] }[] | null;
  sleeping_arrangements?: { label: string; iconKey?: string }[] | null;
  house_rules?: { label: string; iconKey?: string }[] | null;
  host?: {
    name?: string | null;
    bio?: string | null;
    image?: string | null;
    links?: { label: string; url: string }[] | null;
  } | null;
  review?: {
    rating?: number | null;
    count?: number | null;
    source?: string | null;
    externalUrl?: string | null;
  } | null;
  reviews?: Array<{
    author?: string | null;
    date?: string | null;
    text?: string | null;
    rating?: number | null;
    source?: string | null;
  }> | null;
  map_directions?: string | null;
  page_sections?: string[] | null;
  custom_sections?: WebsiteContentBlock[] | null;
  marketing_social?: {
    instagram?: string | null;
    facebook?: string | null;
    tiktok?: string | null;
    youtube?: string | null;
    defaultHashtags?: string | null;
    websiteUrl?: string | null;
  } | null;
}

export interface PropertyWithProfile {
  id: string;
  host_id: string;
  name: string;
  type: string;
  address: string;
  suburb?: string | null;
  city: string;
  country: string;
  bedrooms: number;
  bathrooms: number;
  max_guests: number;
  base_price: number;
  cleaning_fee: number;
  tax_rate: number;
  min_nights: number;
  short_description: string;
  full_description: string;
  amenities: string[];
  images: string[] | null;
  check_in_time: string;
  check_out_time: string;
  pets_allowed: boolean;
  smoking_allowed: boolean;
  events_allowed: boolean;
  accent_color: string;
  theme: string;
  slug: string | null;
  custom_domain: string | null;
  stripe_publishable_key: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  contact_email_visible?: boolean | null;
  contact_phone_visible?: boolean | null;
  contact_preference?: 'email' | 'phone' | 'either' | 'booking_only' | null;
  staydirect_email_alias?: string | null;
  website_content?: WebsiteContent | null;
  created_at: string;
  updated_at: string;
  profiles: { name: string; avatar_url: string | null; bio?: string | null; email?: string | null; phone?: string | null } | null;
  subscription_plan?: string | null;
}

interface UsePropertyByDomainResult {
  property: PropertyWithProfile | null;
  loading: boolean;
  error: string | null;
}

const PUBLIC_COLUMNS = [
  'id', 'host_id', 'name', 'slug', 'custom_domain', 'type', 'address', 'suburb', 'city', 'country',
  'bedrooms', 'bathrooms', 'max_guests', 'base_price', 'cleaning_fee',
  'tax_rate', 'min_nights', 'amenities', 'short_description', 'full_description',
  'check_in_time', 'check_out_time', 'pets_allowed', 'smoking_allowed', 'events_allowed',
  'accent_color', 'theme', 'images', 'stripe_publishable_key', 'contact_email', 'contact_phone',
  'contact_email_visible', 'contact_phone_visible', 'contact_preference', 'staydirect_email_alias',
  'website_content',
  'created_at', 'updated_at',
  'profiles(name, avatar_url, bio, email, phone)',
].join(', ');

const LEGACY_PUBLIC_COLUMNS = [
  'id', 'host_id', 'name', 'slug', 'custom_domain', 'type', 'address', 'city', 'country',
  'bedrooms', 'bathrooms', 'max_guests', 'base_price', 'cleaning_fee',
  'tax_rate', 'min_nights', 'amenities', 'short_description', 'full_description',
  'check_in_time', 'check_out_time', 'pets_allowed', 'smoking_allowed', 'events_allowed',
  'accent_color', 'theme', 'images', 'stripe_publishable_key', 'created_at', 'updated_at',
].join(', ');

// Module-level cache so multiple components on the same page share one fetch
let _cache: { data: PropertyWithProfile | null; ts: number; hostname: string; slug?: string } | null = null;
const CACHE_TTL = 30_000; // 30s

function buildDeloraineFallback(hostname = normalizeHostname(window.location.hostname)): PropertyWithProfile {
  const imported = getDeloraineDemoImport();
  const isLocalDeloraine = hostname === 'delorainecottage.localhost';
  const profile = localProfile();

  return {
    id: 'delorainecottage-live',
    host_id: isLocalDeloraine ? LOCAL_HOST_ID : 'delorainecottage-host',
    name: imported.name,
    slug: 'delorainecottage',
    // Local-dev fallback only. Leave empty so the local preview is never redirected.
    custom_domain: null,
    type: 'Villa',
    address: imported.address,
    suburb: '',
    city: imported.city,
    country: imported.country,
    bedrooms: imported.bedrooms,
    bathrooms: imported.bathrooms,
    max_guests: imported.maxGuests,
    base_price: imported.basePrice,
    cleaning_fee: imported.cleaningFee,
    tax_rate: imported.taxRate,
    min_nights: imported.minNights,
    amenities: imported.amenities,
    short_description: imported.shortDescription,
    full_description: imported.fullDescription,
    check_in_time: '03:00 PM',
    check_out_time: '10:00 AM',
    pets_allowed: false,
    smoking_allowed: false,
    events_allowed: false,
    accent_color: '#aa7942',
    theme: 'source-match',
    images: imported.images,
    stripe_publishable_key: null,
    contact_email: profile.email || imported.contactEmail,
    contact_phone: profile.phone || imported.contactPhone,
    contact_email_visible: true,
    contact_phone_visible: true,
    contact_preference: 'either',
    staydirect_email_alias: 'delorainecottage@staydirect.nz',
    created_at: new Date(0).toISOString(),
    updated_at: new Date(0).toISOString(),
    profiles: {
      name: profile.name || 'Vanessa Wilson',
      avatar_url: profile.avatarUrl || null,
      bio: profile.bio || null,
      email: profile.email || null,
      phone: profile.phone || null,
    },
  };
}

function localProfile() {
  return loadDashboardData('profile', {
    name: 'Vanessa Wilson',
    email: 'hello@delorainecottage.com',
    phone: '',
    bio: 'Local host support is available before and during the stay, with contact details included for guest confidence.',
    avatarUrl: '',
  });
}

function withLocalProfile(property: ReturnType<typeof readLocalProperty> | PropertyWithProfile | null): PropertyWithProfile | null {
  if (!property) return null;
  const profile = localProfile();
  return {
    ...(property as PropertyWithProfile),
    contact_email: property.contact_email || profile.email || null,
    contact_phone: property.contact_phone || profile.phone || null,
    contact_phone_visible: Boolean(property.contact_phone_visible ?? Boolean(property.contact_phone || profile.phone)),
    profiles: {
      name: profile.name || 'Vanessa Wilson',
      avatar_url: profile.avatarUrl || null,
      bio: profile.bio || null,
      email: profile.email || null,
      phone: profile.phone || null,
    },
  };
}

export function clearPropertyCache() {
  _cache = null;
}

/**
 * When a property has its own domain set, visitors who land on the StayDirect
 * subdomain ({slug}.staydirect.nz) are forwarded to that domain. StayDirect is
 * hosted on Replit, so this client-side redirect replaces a CNAME setup.
 * Returns the absolute redirect URL, or null when no redirect should happen.
 */
function customDomainRedirectUrl(property: PropertyWithProfile | null): string | null {
  if (!property || typeof window === 'undefined') return null;
  const host = normalizeHostname(window.location.hostname);
  // Only forward from the StayDirect subdomain — never from the custom domain
  // itself or the main platform.
  const isStayDirectSubdomain = host.endsWith('.staydirect.nz') && Boolean(getStayDirectSubdomain(host));
  if (!isStayDirectSubdomain) return null;

  const target = (property.custom_domain || '').trim().toLowerCase();
  if (!target) return null;
  // Never redirect to a StayDirect domain (avoids loops and stale data).
  if (target === 'staydirect.nz' || target.endsWith('.staydirect.nz')) return null;
  if (target === host) return null;

  const path = window.location.pathname;
  // Keep owner login/dashboard reachable on the StayDirect subdomain.
  if (path.startsWith('/host') || path.startsWith('/dashboard')) return null;

  return `https://${target}${window.location.pathname}${window.location.search}`;
}

export function usePropertyByDomain(): UsePropertyByDomainResult {
  const hostname = normalizeHostname(window.location.hostname);
  const pathname = window.location.pathname;
  const blockedHost = isMarketplaceHost(hostname) || isReservedSubdomain(hostname);
  const isDeloraineLocalHost = hostname === 'delorainecottage.localhost';
  const isLocalMainHost =
    hostname === 'localhost' ||
    hostname.includes('127.0.0.1') ||
    hostname.includes('replit.dev');

  // Extract slug from /my-property/:slug paths on dev (localhost / replit.dev)
  const pathSlug =
    !blockedHost &&
    isLocalMainHost
      ? pathname.match(/^\/my-property\/([^\/]+)/)?.[1] || null
      : null;

  const isMainDomainPropertyPreview =
    !blockedHost &&
    isLocalMainHost &&
    (pathname === '/my-property' || pathname.startsWith('/my-property/'));
  const isDeloraineMainDomainPreview = isMainDomainPropertyPreview && pathSlug === 'delorainecottage';
  const isLocalPreviewHost =
    !blockedHost &&
    !isDeloraineLocalHost &&
    localStorage.getItem(LOCAL_AUTH_KEY) === 'true' &&
    isLocalMainHost;
  const localInitial = isLocalPreviewHost ? readLocalProperty() : null;
  // Deloraine production subdomain now loads from Supabase like any real property
  const deloraineInitial = !blockedHost && (isDeloraineLocalHost || isDeloraineMainDomainPreview) ? buildDeloraineFallback(hostname) : null;
  const cachedEntry = _cache && _cache.hostname === hostname && _cache.slug === (pathSlug || undefined) && Date.now() - _cache.ts < CACHE_TTL ? _cache : null;
  const cachedProperty = cachedEntry ? cachedEntry.data : null;
  const [property, setProperty] = useState<PropertyWithProfile | null>(
    blockedHost ? null : localInitial ? withLocalProfile(localInitial) : cachedProperty || deloraineInitial
  );
  const [loading, setLoading] = useState(
    blockedHost || localInitial || deloraineInitial || cachedEntry ? false : true
  );
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isMarketplaceHost(hostname)) {
      logDomainRouting('[Marketplace Host] property lookup blocked');
      _cache = { data: null, ts: Date.now(), hostname, slug: pathSlug || undefined };
      setProperty(null);
      setLoading(false);
      return;
    }

    if (isReservedSubdomain(hostname)) {
      logDomainRouting('[Reserved Subdomain] property lookup blocked', {
        subdomain: getStayDirectSubdomain(hostname),
      });
      _cache = { data: null, ts: Date.now(), hostname, slug: pathSlug || undefined };
      setProperty(null);
      setLoading(false);
      return;
    }

    // Skip fetch if we already have a fresh cached result (cache key includes slug for multi-property)
    if (!isLocalPreviewHost && _cache && _cache.hostname === hostname && _cache.slug === (pathSlug || undefined) && Date.now() - _cache.ts < CACHE_TTL) {
      setProperty(_cache.data);
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const hostname = normalizeHostname(window.location.hostname);
        if (isDeloraineMainDomainPreview) {
          const data = buildDeloraineFallback(hostname);
          _cache = { data, ts: Date.now(), hostname, slug: pathSlug || undefined };
          setProperty(data);
          return;
        }

        if (
          localStorage.getItem(LOCAL_AUTH_KEY) === 'true' &&
          isLocalMainHost
        ) {
          const localProperty = readLocalProperty();
          const data = withLocalProfile(localProperty);
          _cache = { data, ts: Date.now(), hostname, slug: pathSlug || undefined };
          setProperty(data);
          return;
        }

        let matchBy: { slug?: string; custom_domain?: string; fallback?: boolean } = {};

        // On dev (localhost / replit.dev) with slug path: resolve by slug
        if (pathSlug) {
          logDomainRouting('[Slug Path]', { slug: pathSlug, mode: 'dev' });
          matchBy = { slug: pathSlug };
        } else if (hostname === 'delorainecottage.localhost') {
          logDomainRouting('[Property Host]', { subdomain: 'delorainecottage', mode: 'local' });
          matchBy = { slug: 'delorainecottage' };
        } else if (isPropertyHost(hostname) && hostname.endsWith('.staydirect.nz')) {
          const subdomain = getStayDirectSubdomain(hostname);
          logDomainRouting('[Property Host]', { subdomain });
          matchBy = subdomain ? { slug: subdomain } : {};
        } else if (isPropertyHost(hostname) && hostname.endsWith('.localhost')) {
          const subdomain = getStayDirectSubdomain(hostname);
          logDomainRouting('[Property Host]', { subdomain, mode: 'local' });
          matchBy = subdomain ? { slug: subdomain } : {};
        } else if (isCustomDomainHost(hostname)) {
          logDomainRouting('[Custom Domain]', { customDomain: hostname });
          matchBy = { custom_domain: hostname };
        } else {
          logDomainRouting('[Domain Routing] main platform or local preview');
          matchBy = {};
        }

        let data: PropertyWithProfile | null = null;

        const toProperty = (row: unknown, withProfile = true): PropertyWithProfile | null => {
          if (!row || typeof row !== 'object') return null;
          const raw = row as Partial<PropertyWithProfile>;
          const base = {
            ...raw,
            contact_email: raw.contact_email ?? null,
            contact_phone: raw.contact_phone ?? null,
            contact_email_visible: raw.contact_email_visible ?? true,
            contact_phone_visible: raw.contact_phone_visible ?? false,
            contact_preference: raw.contact_preference ?? 'email',
            staydirect_email_alias: raw.staydirect_email_alias ?? null,
            profiles: raw.profiles ?? null,
          };
          return withProfile
            ? (base as PropertyWithProfile)
            : { ...base, profiles: null } as PropertyWithProfile;
        };

        if (matchBy.slug) {
          // Try exact match first
          const { data: row, error: err } = await supabase
            .from('properties')
            .select(PUBLIC_COLUMNS)
            .eq('slug', matchBy.slug)
            .maybeSingle();

          if (err) {
            const { data: row2 } = await supabase
              .from('properties')
              .select(LEGACY_PUBLIC_COLUMNS)
              .eq('slug', matchBy.slug)
              .maybeSingle();
            data = toProperty(row2, false);
          } else {
            data = toProperty(row);
          }

          // No prefix fallback — exact slug only prevents cross-property data bleed.
          // If a slug doesn't match, the user should fix the URL, not silently
          // land on a different property with a similar prefix.
        } else if (matchBy.custom_domain) {
          const domainMapping = await fetchDomainMappingForHostname(matchBy.custom_domain).catch(() => null);
          if (domainMapping?.property_id) {
            const { data: row, error: err } = await supabase
              .from('properties')
              .select(PUBLIC_COLUMNS)
              .eq('id', domainMapping.property_id)
              .maybeSingle();

            if (err) {
              const { data: row2 } = await supabase
                .from('properties')
                .select(LEGACY_PUBLIC_COLUMNS)
                .eq('id', domainMapping.property_id)
                .maybeSingle();
              data = toProperty(row2, false);
            } else {
              data = toProperty(row);
            }
          }

          if (!data) {
            const { data: row, error: err } = await supabase
              .from('properties')
              .select(PUBLIC_COLUMNS)
              .eq('custom_domain', matchBy.custom_domain)
              .maybeSingle();

            if (err) {
              const { data: row2 } = await supabase
                .from('properties')
                .select(LEGACY_PUBLIC_COLUMNS)
                .eq('custom_domain', matchBy.custom_domain)
                .maybeSingle();
              data = toProperty(row2, false);
            } else {
              data = toProperty(row);
            }
          }
        } else {
          // No slug, no subdomain, no custom domain — on the main platform we cannot
          // resolve a property. This prevents cross-property data bleed (no host_id
          // LIMIT 1 fallback) and forces slug-based routing for multi-property hosts.
          // Only local preview and authenticated user paths reach here.
          if (isLocalPreviewHost) {
            const localProperty = readLocalProperty();
            data = withLocalProfile(localProperty);
          }
        }

        // Deloraine production subdomain loads from Supabase — no fallback needed
        if (!data && hostname === 'delorainecottage.localhost') {
          data = buildDeloraineFallback(hostname);
        }

        // Resolve subscription plan before first render so Professional features
        // (e.g. custom_favicon) are available without a second state update.
        // Run concurrently with any remaining setup; await with a short guard so
        // a slow or RLS-blocked query never significantly delays the page paint.
        if (data?.host_id) {
          const subPromise = Promise.resolve(
            supabase
              .from('subscriptions')
              .select('plan, status, trial_ends_at')
              .eq('host_id', data.host_id)
              .order('created_at', { ascending: false })
              .limit(1)
              .maybeSingle()
          ).then(({ data: sub }) => sub?.plan ?? null).catch(() => null);

          // Wait up to 3s; if the subscription query wins first, great — otherwise
          // we fall back to undefined (normalizePlan treats that as 'simple').
          const plan = await Promise.race([
            subPromise,
            new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000)),
          ]);

          if (plan && data) {
            data = { ...data, subscription_plan: plan };
          }
        }

        _cache = { data, ts: Date.now(), hostname, slug: pathSlug || undefined };
        setProperty(data);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setLoading(false);
      }
    })();
  }, [pathname, pathSlug]);

  // The custom domain redirect is now handled by the property owner in Cloudflare.
  // The custom_domain field on the property record is used for display purposes
  // (Settings page, contact info) rather than redirecting away from StayDirect.
  // Keep the redirect hook logic active in case an individual property needs it
  // in the future, but avoid the redirect by disabling the call. 
  // useEffect(() => {
  //   const redirectUrl = customDomainRedirectUrl(property);
  //   if (redirectUrl) {
  //     logDomainRouting('[Custom Domain] forwarding StayDirect subdomain', { redirectUrl });
  //     window.location.replace(redirectUrl);
  //   }
  // }, [property]);

  return { property, loading, error };
}

/**
 * Returns the route prefix for property website links.
 * On a property subdomain (deloraine.staydirect.nz) routes are at root: /gallery
 * On the main site (staydirect.nz/my-property/gallery) routes have a prefix.
 */
export function usePropertyBasePath(): string {
  const hostname = normalizeHostname(window.location.hostname);
  if (isMarketplaceHost(hostname) || isReservedSubdomain(hostname)) {
    return '';
  }
  if (hostname === 'delorainecottage.localhost') {
    return '';
  }
  if (
    hostname === 'localhost' ||
    hostname.includes('127.0.0.1') ||
    hostname.includes('replit.dev') ||
    hostname === 'staydirect.nz' ||
    hostname === 'www.staydirect.nz'
  ) {
    const slugMatch = window.location.pathname.match(/^\/my-property\/([^\/]+)/);
    const slug = slugMatch?.[1];
    return slug ? `/my-property/${slug}` : '/my-property';
  }
  // On any subdomain or custom domain — routes live at root
  return '';
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
