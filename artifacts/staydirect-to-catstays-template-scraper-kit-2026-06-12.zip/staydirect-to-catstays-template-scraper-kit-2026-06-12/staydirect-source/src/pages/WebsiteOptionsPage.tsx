import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Bed, Calendar, Car, Check, CheckCircle, ChefHat, Edit3, ExternalLink, Home, Image as ImageIcon, LogIn, Mail, MapPin, Palette, Phone, Search, Smartphone, Sparkles, Star, Tv, Users, Waves, Wifi, Wind, X } from 'lucide-react';
import { MarketingNav } from '../components/marketing/MarketingNav';
import { apiUrl } from '../lib/api';
import { deloraineDemoSite, getDeloraineDemoImport } from '../lib/deloraineDemoSite';
import { saveDemoProperty } from '../lib/demoData';
import { cacheImportedProperty } from '../lib/localSetup';
import {
  loadPreviewSession,
  previewDataForTemplate,
  readPreviewId,
  rememberPreviewId,
  savePreviewSession,
} from '../lib/previewSessions';
import {
  DEFAULT_COLOUR_SELECTION,
  WEBSITE_COLOUR_THEME_OPTIONS,
  WEBSITE_DESIGN_OPTIONS,
  type ColourSelection,
  type TemplateOption,
} from '../lib/websiteDesignOptions';
import { GuestWebsiteChatbot, buildGuestFaqs } from '../components/property/GuestWebsiteChatbot';
import type { WebsiteContentBlock } from '../hooks/usePropertyByDomain';

export interface ImportedPreviewData {
  propertyId?: string;
  name?: string;
  shortDescription?: string;
  fullDescription?: string;
  city?: string;
  country?: string;
  address?: string;
  images?: string[];
  amenities?: string[];
  reviewSummary?: {
    rating?: number | null;
    count?: number | null;
    source?: string;
    externalUrl?: string;
  };
  googleTourUrl?: string;
  brandColor?: string;
  bedrooms?: number | null;
  bathrooms?: number | null;
  maxGuests?: number | null;
  basePrice?: number | null;
  cleaningFee?: number | null;
  taxRate?: number | null;
  minNights?: number | null;
  logoImage?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  email?: string | null;
  phone?: string | null;
  checkInTime?: string | null;
  checkOutTime?: string | null;
  hostName?: string | null;
  hostPhoto?: string | null;
  hostBio?: string | null;
  hostImage?: string | null;
  hostAvatar?: string | null;
  host?: unknown;
  owner?: unknown;
  profile?: unknown;
  profiles?: unknown;
  reviews?: Array<{ author?: string | null; date?: string | null; text?: string | null; rating?: number | null; source?: string | null }>;
  source?: string;
  sourceUrl?: string;
  customSections?: WebsiteContentBlock[] | null;
  pageSections?: string[] | null;
}

export interface PreviewContent {
  propertyId?: string | null;
  brand: string;
  eyebrow: string;
  headline: string;
  summary: string;
  fullDescription: string;
  location: string;
  gallery: string[];
  sections: Array<{ label: string; detail: string }>;
  amenities: string[];
  bedrooms?: number | null;
  bathrooms?: number | null;
  maxGuests?: number | null;
  basePrice?: number | null;
  cleaningFee?: number | null;
  taxRate?: number | null;
  minNights?: number | null;
  checkInTime?: string | null;
  checkOutTime?: string | null;
  logoImage?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  hostName?: string | null;
  hostPhoto?: string | null;
  hostBio?: string | null;
  reviews?: Array<{ author?: string | null; date?: string | null; text?: string | null; rating?: number | null; source?: string | null }>;
  reviewCopy?: string;
  reviewRating?: number | null;
  reviewCount?: number | null;
  reviewSource?: string;
  reviewUrl?: string;
  googleTourUrl?: string;
  sourceUrl?: string;
  brandColor?: string;
  guidebookItems?: PreviewGuidebookItem[];
  customSections?: WebsiteContentBlock[];
}

const templates = WEBSITE_DESIGN_OPTIONS;
const colourThemeOptions = WEBSITE_COLOUR_THEME_OPTIONS;
const defaultColourSelection = DEFAULT_COLOUR_SELECTION;
const STAYDIRECT_BRAND_RED = '#FF5A5F';

const deloraineImport = getDeloraineDemoImport();
const fallbackGallery = uniqueImages([
  deloraineDemoSite.heroImage,
  deloraineDemoSite.heroAltImage,
  ...deloraineDemoSite.galleryImages.map(([, image]) => image),
]);
const liveDeloraineUrl = 'https://delorainecottage.com/';

function classNames(...parts: Array<string | false | undefined>) {
  return parts.filter(Boolean).join(' ');
}

function headingStyle(template: TemplateOption): React.CSSProperties {
  return {
    fontFamily: template.typography.heading,
    fontWeight: template.typography.headingWeight,
    letterSpacing: 0,
  };
}

function bodyStyle(template: TemplateOption): React.CSSProperties {
  return {
    fontFamily: template.typography.body,
    letterSpacing: 0,
  };
}

function eyebrowStyle(template: TemplateOption): React.CSSProperties {
  return {
    color: template.accent,
    fontWeight: template.typography.eyebrowWeight,
    letterSpacing: '0.22em',
  };
}

function isHexColor(value?: string | null): value is string {
  return Boolean(value && /^#[0-9a-f]{6}$/i.test(value));
}

function templateWithColours(template: TemplateOption, colours: ColourSelection): TemplateOption {
  if (template.id === 'source-match') return template;
  return {
    ...template,
    accentSoft: colours.primaryColor,
    text: colours.secondaryColor,
    accent: colours.accentColor,
  };
}

function readStoredColours(): ColourSelection {
  if (typeof window === 'undefined') return defaultColourSelection;
  const params = new URLSearchParams(window.location.search);
  const themeId =
    params.get('palette') ||
    sessionStorage.getItem('staydirect_selected_colour_theme') ||
    localStorage.getItem('staydirect_selected_colour_theme') ||
    defaultColourSelection.themeId;
  const theme = colourThemeOptions.find((option) => option.id === themeId) || colourThemeOptions[0];
  return {
    themeId: theme.id,
    primaryColor: isHexColor(params.get('primary'))
      ? params.get('primary') as string
      : sessionStorage.getItem('staydirect_selected_primary_colour') || localStorage.getItem('staydirect_selected_primary_colour') || theme.colors[0],
    secondaryColor: isHexColor(params.get('secondary'))
      ? params.get('secondary') as string
      : sessionStorage.getItem('staydirect_selected_secondary_colour') || localStorage.getItem('staydirect_selected_secondary_colour') || theme.colors[1],
    accentColor: isHexColor(params.get('accent'))
      ? params.get('accent') as string
      : sessionStorage.getItem('staydirect_selected_accent_colour') || localStorage.getItem('staydirect_selected_accent_colour') || theme.colors[2],
  };
}

function rememberColours(colours: ColourSelection) {
  if (typeof window === 'undefined') return;
  sessionStorage.setItem('staydirect_selected_colour_theme', colours.themeId);
  sessionStorage.setItem('staydirect_selected_primary_colour', colours.primaryColor);
  sessionStorage.setItem('staydirect_selected_secondary_colour', colours.secondaryColor);
  sessionStorage.setItem('staydirect_selected_accent_colour', colours.accentColor);
  localStorage.setItem('staydirect_selected_colour_theme', colours.themeId);
  localStorage.setItem('staydirect_selected_primary_colour', colours.primaryColor);
  localStorage.setItem('staydirect_selected_secondary_colour', colours.secondaryColor);
  localStorage.setItem('staydirect_selected_accent_colour', colours.accentColor);
}

function colourQuery(colours: ColourSelection) {
  return `palette=${encodeURIComponent(colours.themeId)}&primary=${encodeURIComponent(colours.primaryColor)}&secondary=${encodeURIComponent(colours.secondaryColor)}&accent=${encodeURIComponent(colours.accentColor)}`;
}

function normaliseUrl(value: string | null): string | null {
  const trimmed = value?.trim();
  if (!trimmed) return null;
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

function uniqueImages(images?: string[]): string[] {
  const seen = new Set<string>();
  return (images || [])
    .filter((image) => image && /^https?:\/\//i.test(image))
    .filter((image) => {
      const key = imageKey(image);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function imageKey(image?: string | null): string {
  if (!image) return '';
  try {
    const url = new URL(image);
    return `${url.origin}${url.pathname}`.toLowerCase();
  } catch {
    return image.split('?')[0].toLowerCase();
  }
}

function supportingPhotos(content: PreviewContent, exclude: Array<string | undefined> = []): string[] {
  const photos = content.gallery.length ? content.gallery : fallbackGallery;
  const blocked = new Set(exclude.filter(Boolean).map((image) => imageKey(image)));
  return uniqueImages(photos).filter((image) => !blocked.has(imageKey(image)));
}

function modernShowcasePhotos(content: PreviewContent): string[] {
  const photos = supportingPhotos(content, [content.logoImage || undefined]);
  if (photos.length > 1) return photos.slice(1);
  return photos.length ? photos : content.gallery;
}

function normaliseStored(raw: string | null): string {
  if (!raw) return '';
  try {
    return new URL(raw.trim()).toString();
  } catch {
    return raw.trim();
  }
}

function readActiveImportUrl(): string {
  if (typeof window === 'undefined') return '';
  return normaliseStored(
    sessionStorage.getItem('staydirect_import_url') ||
    localStorage.getItem('staydirect_import_url'),
  );
}

function matchesActiveImport(parsed: ImportedPreviewData | null): boolean {
  if (!parsed) return false;
  const activeUrl = readActiveImportUrl();
  // If there is no active import URL the user is browsing the page directly
  // without having imported anything, so any cached payload is irrelevant.
  if (!activeUrl) return false;
  const storedUrl = normaliseStored(parsed.sourceUrl ?? null);
  return storedUrl === activeUrl;
}

function readStoredPreview(): ImportedPreviewData | null {
  if (typeof window === 'undefined') return null;
  const tryParse = (raw: string | null): ImportedPreviewData | null => {
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw) as ImportedPreviewData;
      if (isLegacyExample(parsed)) return null;
      return parsed;
    } catch {
      return null;
    }
  };

  // Check sessionStorage first (current tab), then localStorage (other tabs via
  // rel=noopener). In every case we require the stored payload's sourceUrl to
  // match the user's active import URL so stale data from a previous import
  // can never leak into a new preview session.
  const candidates = [
    tryParse(sessionStorage.getItem('staydirect_preview_data')),
    tryParse(localStorage.getItem('staydirect_preview_data')),
    tryParse(localStorage.getItem('staydirect_last_imported_property')),
  ];
  for (const candidate of candidates) {
    if (matchesActiveImport(candidate)) return candidate;
  }
  return null;
}

function persistPreviewData(data: ImportedPreviewData) {
  if (typeof window === 'undefined') return;
  try {
    const raw = JSON.stringify(data);
    sessionStorage.setItem('staydirect_preview_data', raw);
    localStorage.setItem('staydirect_preview_data', raw);
  } catch {
    /* storage may be unavailable; ignore */
  }
}

function isLegacyExample(data: ImportedPreviewData | null): boolean {
  const haystack = [
    data?.name,
    data?.shortDescription,
    data?.fullDescription,
    data?.sourceUrl,
  ].filter(Boolean).join(' ');
  return /kingdom|kidz|early learning|centre story|programs/i.test(haystack);
}

function cleanLocationValue(value?: string | null) {
  const text = (value || '').trim();
  if (!text || /^(airbnb|booking\.com|vrbo|website|listing)$/i.test(text)) return '';
  return text;
}

function meaningfulDescription(imported: ImportedPreviewData | null, brand: string, isDeloraine: boolean) {
  const record = (imported || {}) as Record<string, unknown>;
  const candidates = [
    imported?.fullDescription,
    imported?.shortDescription,
    record.description,
    record.about,
    record.aboutText,
    record.propertyDescription,
    record.summary,
    record.overview,
    record.details,
    record.locationDescription,
    record.spaceDescription,
    record.guestAccess,
  ]
    .filter((value): value is string => typeof value === 'string')
    .map((value) => value.trim())
    .filter((value) => value && value.toLowerCase() !== brand.toLowerCase() && value.length > 24);

  const longest = candidates.sort((a, b) => b.length - a.length)[0];
  if (longest) return longest;
  if (isDeloraine) return deloraineDemoSite.fullDescription;
  return 'Your imported property description will appear here once your site finishes loading.';
}

function objectRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function stringValue(value: unknown): string {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.map(stringValue).find(Boolean) || '';
  const record = objectRecord(value);
  if (!record) return '';
  return stringValue(record.name ?? record.fullName ?? record.displayName ?? record.firstName ?? record.title ?? record.url ?? record.src);
}

function nestedValue(record: Record<string, unknown>, path: string[]): unknown {
  let current: unknown = record;
  for (const part of path) {
    const currentRecord = objectRecord(current);
    if (!currentRecord) return undefined;
    current = currentRecord[part];
  }
  return current;
}

function firstText(...values: unknown[]): string | null {
  for (const value of values) {
    const text = stringValue(value).replace(/^hosted by\s+/i, '').trim();
    if (text && text.length > 1 && !/^(host|your host|your local host|airbnb|guest|owner)$/i.test(text)) return text;
  }
  return null;
}

function firstImage(...values: unknown[]): string | null {
  for (const value of values) {
    const text = stringValue(value);
    if (/^https?:\/\//i.test(text) || /^data:image\//i.test(text)) return text;
  }
  return null;
}

function importedHost(imported: ImportedPreviewData | null, isDeloraine: boolean) {
  const record = objectRecord(imported) || {};
  const host = objectRecord(imported?.host) || {};
  const owner = objectRecord(imported?.owner) || {};
  const profile = objectRecord(imported?.profile) || objectRecord(imported?.profiles) || {};
  const hostName = firstText(
    imported?.hostName,
    record.host_name,
    record.ownerName,
    record.owner_name,
    record.hostDisplayName,
    record.host_display_name,
    host.name,
    host.fullName,
    host.displayName,
    host.firstName,
    owner.name,
    owner.fullName,
    owner.displayName,
    profile.name,
    profile.fullName,
    profile.displayName,
    nestedValue(record, ['host', 'profile', 'name']),
    nestedValue(record, ['hostProfile', 'name']),
    nestedValue(record, ['user', 'name']),
  ) || (isDeloraine ? 'Vanessa Wilson' : null);
  const hostPhoto = firstImage(
    imported?.hostPhoto,
    imported?.hostImage,
    imported?.hostAvatar,
    record.host_photo,
    record.host_image,
    record.host_avatar,
    record.ownerPhoto,
    record.ownerImage,
    record.ownerAvatar,
    record.owner_photo,
    record.profileImage,
    record.profile_image,
    record.avatar,
    record.avatar_url,
    host.photo,
    host.image,
    host.picture,
    host.avatar,
    host.pictureUrl,
    host.profilePictureUrl,
    owner.photo,
    owner.image,
    owner.avatar,
    profile.avatar_url,
    profile.image,
    profile.photo,
    nestedValue(record, ['host', 'profile', 'pictureUrl']),
    nestedValue(record, ['hostProfile', 'pictureUrl']),
    nestedValue(record, ['user', 'pictureUrl']),
  );
  const hostBio = firstText(
    imported?.hostBio,
    record.host_bio,
    record.hostBio,
    record.hostAbout,
    record.hostDescription,
    host.bio,
    host.about,
    host.description,
    owner.bio,
    owner.about,
    owner.description,
    profile.bio,
    profile.about,
    nestedValue(record, ['hostProfile', 'bio']),
    nestedValue(record, ['hostProfile', 'about']),
    nestedValue(record, ['hostProfile', 'description']),
    nestedValue(record, ['user', 'bio']),
  );
  return { hostName, hostPhoto, hostBio };
}

function numberValue(value: unknown): number | null {
  const numeric = typeof value === 'string' ? Number(value.replace(/[^0-9.]/g, '')) : Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
}

function readableStayTime(value?: string | null): string | null {
  const text = (value || '').trim();
  if (!text) return null;
  const match = text.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (!match) return text;
  const hour24 = Number(match[1]);
  const minute = match[2];
  if (!Number.isFinite(hour24)) return text;
  const suffix = hour24 >= 12 ? 'PM' : 'AM';
  const hour12 = hour24 % 12 || 12;
  return `${hour12}:${minute} ${suffix}`;
}

function importedReview(imported: ImportedPreviewData | null, isAirbnbSource: boolean) {
  const record = objectRecord(imported) || {};
  const reviewRecord = objectRecord(imported?.reviewSummary) || {};
  const textRating = [imported?.name, imported?.shortDescription, imported?.fullDescription]
    .filter(Boolean)
    .join(' ')
    .match(/★\s*([0-5](?:\.\d{1,2})?)/)?.[1];
  const rating = numberValue(reviewRecord.rating ?? record.ratingAverage ?? record.overallRating ?? record.reviewRating ?? record.rating ?? textRating);
  const count = numberValue(reviewRecord.count ?? record.ratingCount ?? record.overallCount ?? record.reviewCount ?? record.reviewsCount);
  const source = firstText(reviewRecord.source, record.reviewSource, isAirbnbSource ? 'Airbnb' : null) || undefined;
  const externalUrl = firstText(reviewRecord.externalUrl, record.reviewUrl, record.reviewsUrl);
  const copy = count
    ? `${rating ? `${rating.toFixed(2)} star rating from ` : ''}${Math.round(count)} guest review${Math.round(count) === 1 ? '' : 's'}${source ? ` on ${source}` : ''}.`
    : isAirbnbSource
      ? 'Guest reviews are available on Airbnb.'
      : undefined;
  return { rating, count, source, externalUrl, copy };
}

async function enrichImportedPreviewData(imported: ImportedPreviewData): Promise<ImportedPreviewData> {
  const isDeloraine =
    /deloraine/i.test(imported.name || '') ||
    /deloraine/i.test(imported.sourceUrl || '') ||
    /deloraine/i.test(imported.address || '');
  const currentHost = importedHost(imported, isDeloraine);
  const isAirbnbSource = /airbnb\./i.test(imported.sourceUrl || '') || /airbnb/i.test(imported.source || '');
  const currentReview = importedReview(imported, isAirbnbSource);
  if ((currentHost.hostName && currentHost.hostPhoto) && (currentReview.rating || currentReview.count) || !imported.sourceUrl) return imported;

  try {
    const response = await fetch(apiUrl(`/api/scrape?url=${encodeURIComponent(imported.sourceUrl)}`));
    const fresh = await response.json() as ImportedPreviewData;
    if (!response.ok || (fresh as { error?: unknown }).error || isLegacyExample(fresh)) return imported;
    const freshHost = importedHost(fresh, isDeloraine);
    const freshReview = importedReview(fresh, isAirbnbSource);
    const merged = {
      ...imported,
      hostName: currentHost.hostName || freshHost.hostName || imported.hostName,
      hostPhoto: currentHost.hostPhoto || freshHost.hostPhoto || imported.hostPhoto,
      hostBio: currentHost.hostBio || freshHost.hostBio || imported.hostBio,
      reviews: imported.reviews?.length ? imported.reviews : fresh.reviews,
      reviewSummary: imported.reviewSummary || fresh.reviewSummary || (
        freshReview.rating || freshReview.count
          ? {
              rating: freshReview.rating,
              count: freshReview.count,
              source: freshReview.source,
              externalUrl: freshReview.externalUrl || imported.sourceUrl,
            }
          : imported.reviewSummary
      ),
    };
    if (
      merged.hostName !== imported.hostName ||
      merged.hostPhoto !== imported.hostPhoto ||
      merged.hostBio !== imported.hostBio ||
      merged.reviews !== imported.reviews ||
      merged.reviewSummary !== imported.reviewSummary
    ) {
      persistPreviewData(merged);
      cacheImportedProperty(merged);
    }
    return merged;
  } catch {
    return imported;
  }
}

function getDelorainePreview(): ImportedPreviewData {
  return {
    ...deloraineImport,
    brandColor: deloraineDemoSite.palette.accent,
    googleTourUrl: deloraineDemoSite.googleTour,
    logoImage: deloraineDemoSite.logoImage,
    sourceUrl: liveDeloraineUrl,
  };
}

export function contentFromImport(imported: ImportedPreviewData | null): PreviewContent {
  const gallery = uniqueImages(imported?.images);
  const isDeloraine =
    /deloraine/i.test(imported?.name || '') ||
    /deloraine/i.test(imported?.sourceUrl || '') ||
    /deloraine/i.test(imported?.address || '');
  // Only mix in the Deloraine gallery for the Deloraine demo itself. Real
  // imports — even if their gallery is empty — must never inherit Deloraine
  // photos. With no imported data at all we render an empty gallery.
  const photos = isDeloraine
    ? uniqueImages([...gallery, ...fallbackGallery])
    : gallery;
  const brand = imported?.name || 'Your Property';
  const location =
    cleanLocationValue([imported?.city, imported?.country].map(cleanLocationValue).filter(Boolean).join(', ')) ||
    cleanLocationValue(imported?.address) ||
    '';
  const amenities = (imported?.amenities || []).filter(Boolean);
  const isAirbnbSource = /airbnb\./i.test(imported?.sourceUrl || '') || /airbnb/i.test(imported?.source || '');
  const fullDescription = meaningfulDescription(imported, brand, isDeloraine);
  const host = importedHost(imported, isDeloraine);
  const review = importedReview(imported, isAirbnbSource);
  const summary = meaningfulDescription(
    {
      ...imported,
      fullDescription: imported?.shortDescription || imported?.fullDescription,
    },
    brand,
    isDeloraine,
  );
  const reviewCopy = review.copy;

  const sections = [
    { label: 'About', detail: summary },
    { label: 'Gallery', detail: `${photos.length} property photo${photos.length === 1 ? '' : 's'} showing the stay, rooms, gardens, facilities and guest areas.` },
    { label: 'Location', detail: location },
    amenities.length ? { label: 'Amenities', detail: amenities.join(', ') } : null,
    imported?.googleTourUrl ? { label: 'Video or tour', detail: 'A tour or video can be shown as part of the guest research journey.' } : null,
    reviewCopy ? { label: 'Reviews', detail: reviewCopy } : null,
    imported?.basePrice ? { label: 'Booking', detail: `From $${Math.round(imported.basePrice)} per night with clear dates, guests and total before payment.` } : null,
  ].filter(Boolean) as Array<{ label: string; detail: string }>;

  return {
    propertyId: imported?.propertyId || null,
    brand,
    eyebrow: location,
    headline: brand,
    summary,
    fullDescription,
    location,
    gallery: photos,
    sections: sections.length ? sections : [
      { label: 'About', detail: 'Deloraine Cottage copy and page sections.' },
      { label: 'Gallery', detail: 'Deloraine Cottage photo gallery.' },
      { label: 'Contact', detail: 'Map, enquiry and booking action.' },
    ],
    amenities,
    bedrooms: imported?.bedrooms,
    bathrooms: imported?.bathrooms,
    maxGuests: imported?.maxGuests,
    basePrice: imported?.basePrice,
    cleaningFee: imported?.cleaningFee,
    taxRate: imported?.taxRate,
    minNights: imported?.minNights,
    checkInTime: readableStayTime(imported?.checkInTime) || '3:00 PM',
    checkOutTime: readableStayTime(imported?.checkOutTime) || '10:00 AM',
    logoImage: imported?.logoImage || (isDeloraine ? deloraineDemoSite.logoImage : null),
    contactEmail: imported?.contactEmail || imported?.email || (isDeloraine ? deloraineDemoSite.contactEmail : null),
    contactPhone: imported?.contactPhone || imported?.phone || (isDeloraine ? deloraineDemoSite.contactPhone : null),
    hostName: host.hostName,
    hostPhoto: host.hostPhoto,
    hostBio: host.hostBio,
    reviews: imported?.reviews?.filter((review) => review?.text).slice(0, 6),
    reviewCopy,
    reviewRating: review.rating,
    reviewCount: review.count,
    reviewSource: review.source,
    reviewUrl: review.externalUrl || (isAirbnbSource ? imported?.sourceUrl : undefined) || (isDeloraine ? liveDeloraineUrl : undefined),
    googleTourUrl: imported?.googleTourUrl || (isDeloraine ? deloraineDemoSite.googleTour : undefined),
    sourceUrl: imported?.sourceUrl,
    brandColor: imported?.brandColor,
    customSections: (imported?.customSections || []).filter((block) => Boolean(block?.title || block?.heading || block?.body || block?.mediaUrls || block?.embedCode)),
  };
}

function importedAccentColor(imported: ImportedPreviewData | null): string {
  if (imported?.brandColor && /^#[0-9a-f]{6}$/i.test(imported.brandColor)) return imported.brandColor;
  return deloraineDemoSite.palette.accent;
}

function rememberTemplate(template: TemplateOption, content?: PreviewContent) {
  localStorage.setItem('staydirect_selected_site_template', template.id);
  sessionStorage.setItem('staydirect_selected_site_template', template.id);
  localStorage.setItem('staydirect_selected_preview_template', template.id);
  sessionStorage.setItem('staydirect_selected_preview_template', template.id);
  localStorage.setItem('staydirect_selected_dashboard_theme', template.dashboardTheme);
  sessionStorage.setItem('staydirect_selected_dashboard_theme', template.dashboardTheme);
  if (content?.sourceUrl) sessionStorage.setItem('staydirect_import_url', content.sourceUrl);
  saveDemoProperty({
    theme: template.dashboardTheme,
    accent_color: template.id === 'source-match' && content?.sourceUrl
      ? importedAccentColor(content as unknown as ImportedPreviewData)
      : template.accent,
  });
}

function getStoredTemplateId(): string | null {
  if (typeof window === 'undefined') return null;
  return sessionStorage.getItem('staydirect_selected_site_template') || localStorage.getItem('staydirect_selected_site_template');
}

function BrandLockup({
  template,
  content,
  className = 'h-10',
  invert = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  className?: string;
  invert?: boolean;
}) {
  if (content.logoImage) {
    return (
      <img
        src={content.logoImage}
        alt={content.brand}
        className={classNames(className, 'w-auto max-w-[220px] object-contain', invert && 'brightness-0 invert')}
      />
    );
  }

  return (
    <span className="text-xl font-bold" style={{ ...headingStyle(template), color: invert ? '#ffffff' : template.accent }}>
      {content.brand}
    </span>
  );
}

function MiniPreview({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  const editorialPhotos = template.heroStyle === 'poster' || template.heroStyle === 'magazine' || template.heroStyle === 'cards'
    ? modernShowcasePhotos(content)
    : [];
  const modernHero = editorialPhotos[0];
  const primary = modernHero || content.gallery[0];
  const [secondary, tertiary] = editorialPhotos.length
    ? editorialPhotos.filter((photo) => imageKey(photo) !== imageKey(primary))
    : supportingPhotos(content, [primary]);
  const accent = template.accent;

  if (template.heroStyle === 'source') {
    return (
      <div className="overflow-hidden rounded-2xl border border-white/80 bg-[#f7f7f7] text-[#555555] shadow-sm" style={{ fontFamily: 'Montserrat, Arial, sans-serif' }}>
        <div className="flex items-center justify-between border-b border-black/10 bg-[#eeeeee] px-4 py-3">
          <div className="min-w-0">
            {content.logoImage ? (
              <img src={content.logoImage} alt={content.brand} className="h-10 w-auto object-contain" />
            ) : (
              <div className="truncate text-lg font-bold" style={{ color: template.accent, fontFamily: 'Georgia, serif' }}>{content.brand}</div>
            )}
          </div>
          <div className="hidden items-center gap-4 text-xs font-bold uppercase tracking-wide text-[#777777] sm:flex">
            {['Overview', 'Tour', 'Gallery', 'Book'].map((item) => (
              <span key={item}>{item}</span>
            ))}
          </div>
          <div className="rounded-md px-3 py-1.5 text-xs font-bold uppercase text-white" style={{ background: template.accent }}>
            Book
          </div>
        </div>
        <div className="relative h-72">
          <ExpandableBackgroundPhoto src={primary} alt={`${content.brand} preview hero`} />
          <div className="pointer-events-none absolute inset-0 bg-black/38" />
          <div className="absolute inset-x-5 top-1/2 -translate-y-1/2 text-center text-white">
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.22em]">Welcome to the Winterless North</p>
            <h3 className="text-4xl font-bold leading-tight" style={{ fontFamily: 'Georgia, serif' }}>{content.headline}</h3>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-white/90">{content.summary}</p>
          </div>
        </div>
        <div className="grid gap-3 bg-white p-5 sm:grid-cols-3">
          {[
            content.maxGuests ? `${content.maxGuests} guests` : 'Guests',
            content.bedrooms ? `${content.bedrooms} bedrooms` : 'Bedrooms',
            content.bathrooms ? `${content.bathrooms} bathroom${content.bathrooms === 1 ? '' : 's'}` : 'Bathrooms',
          ].map((fact) => (
            <div key={fact} className="rounded-md border border-[#E5E5E5] px-4 py-3 text-center font-bold text-[#555555]">{fact}</div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div
      className="overflow-hidden rounded-2xl border border-white/80 shadow-sm"
      style={{ ...bodyStyle(template), background: template.background, color: template.text }}
    >
      <div className="flex items-center justify-between border-b border-black/5 bg-white/88 px-4 py-3">
        <div className="flex min-w-0 items-center gap-2">
          {content.logoImage ? (
            <BrandLockup template={template} content={content} className="h-9" />
          ) : (
            <>
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-sm font-bold text-white" style={{ background: template.accent }}>
                {content.brand.slice(0, 1).toUpperCase()}
              </div>
              <div className="truncate font-bold" style={headingStyle(template)}>{content.brand}</div>
            </>
          )}
        </div>
          <div className="hidden items-center gap-4 text-xs font-semibold text-[#717171] sm:flex">
          {['About', 'Gallery', 'Location', 'Book'].map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>
        <div className="rounded-full px-3 py-1.5 text-xs font-bold text-white" style={{ background: template.accent }}>
          Book
        </div>
      </div>

      {template.heroStyle === 'poster' ? (
        <>
        <div className="relative h-72 sm:h-80">
          <ExpandableBackgroundPhoto src={primary} alt={`${content.brand} preview hero`} />
          <div className="pointer-events-none absolute inset-0 bg-black/55" />
          <div className="absolute left-5 right-5 top-5 flex items-center justify-between text-white">
            <div className="font-black uppercase tracking-[0.18em]">{content.brand}</div>
            <div className="rounded-md px-3 py-2 text-xs font-black uppercase" style={{ background: accent }}>Book now</div>
          </div>
          <div className="absolute bottom-14 left-5 right-5 text-white">
            <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]">Welcome to the Winterless North</p>
            <h3 className="max-w-xl text-4xl leading-tight sm:text-5xl" style={headingStyle(template)}>{content.headline}</h3>
            <p className="mt-3 max-w-xl text-sm leading-6 text-white/90">{content.summary}</p>
          </div>
          <div className="absolute -bottom-8 left-8 right-8 grid grid-cols-4 rounded-xl bg-white p-3 text-xs shadow-xl">
            {['Check-in', 'Check-out', 'Guests', 'Check rates'].map((item, index) => (
              <div key={item} className={classNames('px-3 py-2', index === 3 && 'rounded-lg text-center font-black text-white')} style={index === 3 ? { background: accent } : undefined}>
                <span className="block text-[10px] font-black uppercase text-[#555555]">{item}</span>
                {index < 3 && <span className="mt-1 block font-bold text-[#1F2E22]">{index === 2 ? '2 guests' : 'Select date'}</span>}
              </div>
            ))}
          </div>
        </div>
        <div className="h-10 bg-white" />
        </>
      ) : template.heroStyle === 'cards' ? (
        <div>
          <div className="relative h-72 overflow-hidden">
            <ExpandableBackgroundPhoto src={primary} alt={`${content.brand} preview hero`} />
            <div className="pointer-events-none absolute inset-0 bg-black/55" />
            <div className="absolute left-5 right-5 top-5 flex items-center justify-between text-white">
              <div className="font-black uppercase tracking-[0.18em]">{content.brand}</div>
              <div className="rounded-md px-3 py-2 text-xs font-black uppercase" style={{ background: template.accent }}>Book now</div>
            </div>
            <div className="absolute bottom-12 left-5 max-w-lg text-white">
              <h3 className="text-4xl leading-tight sm:text-5xl" style={headingStyle(template)}>A quiet escape in the Winterless North</h3>
              <p className="mt-3 line-clamp-2 text-sm leading-6 text-white/90">{content.summary}</p>
            </div>
            <div className="absolute -bottom-0 left-5 right-5 translate-y-1/2 rounded-xl bg-white p-3 shadow-xl">
              <div className="grid grid-cols-4 gap-2 text-xs">
                {['Check-in', 'Check-out', 'Guests', 'Check rates'].map((item, index) => (
                  <div key={item} className={classNames('px-3 py-2', index === 3 && 'rounded-lg text-center font-black text-white')} style={index === 3 ? { background: template.text } : undefined}>
                    <span className="block text-[10px] font-black uppercase text-[#555555]">{item}</span>
                    {index < 3 && <span className="mt-1 block font-bold text-[#1F2A22]">{index === 2 ? '2 guests' : 'Select date'}</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="grid bg-white pt-12 md:grid-cols-2">
            <div className="p-6">
              <p className="mb-3 text-xs font-black uppercase tracking-[0.22em]" style={{ color: template.accent }}>About {content.brand}</p>
              <h4 className="text-2xl leading-tight" style={headingStyle(template)}>A country cottage beside the hosts' home</h4>
              <p className="mt-3 line-clamp-3 text-sm leading-6 text-[#555555]">{content.summary}</p>
            </div>
            {secondary && <ExpandablePhoto src={secondary} alt={`${content.brand} preview detail`} className="h-64 w-full object-cover" />}
          </div>
        </div>
      ) : template.heroStyle === 'magazine' ? (
        <div>
          <div className="relative h-72 overflow-hidden">
            <ExpandableBackgroundPhoto src={primary} alt={`${content.brand} preview hero`} />
            <div className="pointer-events-none absolute inset-0 bg-black/55" />
            <div className="absolute left-5 right-5 top-5 flex items-center justify-between text-white">
              <div className="font-black uppercase tracking-[0.18em]">{content.brand}</div>
              <div className="rounded-md px-3 py-2 text-xs font-black uppercase" style={{ background: template.accent }}>Book your stay</div>
            </div>
            <div className="absolute bottom-8 left-5 max-w-lg text-white">
              <h3 className="text-4xl leading-tight sm:text-5xl" style={headingStyle(template)}>A quiet escape in the Winterless North</h3>
              <p className="mt-3 line-clamp-2 text-sm leading-6 text-white/90">{content.summary}</p>
            </div>
          </div>
          <div className="grid bg-white md:grid-cols-2">
            <div className="p-6">
              <p className="mb-3 text-xs font-black uppercase tracking-[0.22em]" style={{ color: template.accent }}>About {content.brand}</p>
              <h4 className="text-2xl leading-tight" style={headingStyle(template)}>A country cottage beside the hosts' home</h4>
              <p className="mt-3 line-clamp-3 text-sm leading-6 text-[#555555]">{content.summary}</p>
            </div>
            {secondary && <ExpandablePhoto src={secondary} alt={`${content.brand} preview detail`} className="h-64 w-full object-cover" />}
          </div>
        </div>
      ) : (
        <div className="grid gap-4 p-5 md:grid-cols-2">
          <div className="flex flex-col justify-center">
            <p className="mb-3 text-xs uppercase" style={eyebrowStyle(template)}>
              {content.eyebrow}
            </p>
            <h3 className="mb-3 text-3xl leading-tight sm:text-5xl" style={headingStyle(template)}>{content.headline}</h3>
            <p className="line-clamp-5 text-sm leading-6 text-[#555555]">{content.summary}</p>
          </div>
          <ExpandablePhoto src={primary} alt={`${content.brand} preview photo`} className="h-64 w-full rounded-2xl object-cover" />
        </div>
      )}
    </div>
  );
}

function SitePreviewChrome({
  template,
  content,
  children,
  embedded = false,
  liveMode = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  children: React.ReactNode;
  embedded?: boolean;
  liveMode?: boolean;
}) {
  const faqs = buildGuestFaqs({
    propertyName: content.brand,
    city: content.location.split(',')[0],
    country: content.location.split(',').slice(1).join(',').trim(),
    basePrice: content.basePrice,
    cleaningFee: content.cleaningFee,
    taxRate: content.taxRate,
    minNights: content.minNights,
    maxGuests: content.maxGuests,
    bedrooms: content.bedrooms,
    bathrooms: content.bathrooms,
    amenities: content.amenities,
    checkInTime: content.checkInTime,
    checkOutTime: content.checkOutTime,
    contactEmail: content.contactEmail,
    contactPhone: content.contactPhone,
  });

  return (
    <div className={classNames('min-h-screen bg-white', template.typography.toneClass)} style={{ ...bodyStyle(template), color: template.text }}>
      {!embedded && !liveMode && <div className="sticky top-0 z-50 bg-[#FF5A5F] px-4 py-3 text-white shadow-lg sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <Link to="/website-options" className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 font-bold text-[#D01744] shadow-sm hover:bg-[#FFF6F6]">
            <ArrowLeft className="h-4 w-4" />
            Back to StayDirect
          </Link>
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-white/75">StayDirect preview - not part of the property website</p>
            <p className="font-bold text-white">{template.name} for {content.brand}</p>
          </div>
          <Link
            to={`/signup?template=${encodeURIComponent(template.id)}${readPreviewId() ? `&preview=${encodeURIComponent(readPreviewId() || '')}` : ''}`}
            className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 font-bold text-[#D01744] shadow-sm hover:bg-[#FFF6F6]"
          >
            Continue Setup
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>}
      {children}
      {(!embedded) && <GuestWebsiteChatbot
        propertyName={content.brand}
        accent={template.accent}
        faqs={faqs}
        contactEmail={content.contactEmail}
        contactPhone={content.contactPhone}
        propertyId={liveMode ? content.propertyId || undefined : undefined}
        propertyContext={liveMode ? {
          propertyName: content.brand,
          propertyType: null,
          address: null,
          city: content.location.split(',')[0]?.trim() || null,
          country: content.location.split(',').slice(1).join(',').trim() || null,
          description: content.summary || content.fullDescription || null,
          checkInTime: content.checkInTime || null,
          checkOutTime: content.checkOutTime || null,
          maxGuests: content.maxGuests || null,
          bedrooms: content.bedrooms || null,
          bathrooms: content.bathrooms || null,
          minNights: content.minNights || null,
          basePrice: content.basePrice || null,
          cleaningFee: content.cleaningFee || null,
          amenities: content.amenities,
          houseRules: null,
          petsAllowed: null,
          smokingAllowed: null,
          eventsAllowed: null,
          contactEmail: content.contactEmail || null,
          contactPhone: content.contactPhone || null,
        } : undefined}
        guidebookItems={liveMode ? (content.guidebookItems || []).map((item) => ({
          title: item.title,
          category: item.category,
          description: item.description,
          distanceFromProperty: item.distance_from_property,
          hostNote: item.host_note,
        })) : undefined}
      />}
    </div>
  );
}

function StayFacts({ content, template }: { content: PreviewContent; template: TemplateOption }) {
  const facts = [
    content.maxGuests ? `${content.maxGuests} guests` : 'Guests',
    content.bedrooms ? `${content.bedrooms} bedrooms` : null,
    content.bathrooms ? `${content.bathrooms} bathroom${content.bathrooms === 1 ? '' : 's'}` : null,
    content.basePrice ? `From $${Math.round(content.basePrice)} / night` : 'Check dates',
  ].filter(Boolean) as string[];

  return (
    <div className="flex flex-wrap gap-2">
      {facts.map((fact) => (
        <span key={fact} className="rounded-full px-4 py-2 text-sm font-black" style={{ background: template.accentSoft, color: template.accent }}>
          {fact}
        </span>
      ))}
    </div>
  );
}

function PreviewSiteHeader({ template, content, transparent = false }: { template: TemplateOption; content: PreviewContent; transparent?: boolean }) {
  return (
    <header className={classNames('border-b border-black/10 px-5 py-4 sm:px-8', transparent ? 'bg-white/94' : 'bg-white')}>
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-5">
        <a href="#home" className="flex min-w-0 items-center">
          <BrandLockup template={template} content={content} className="h-12" />
        </a>
        <nav className="hidden items-center gap-6 text-sm font-bold uppercase tracking-[0.08em] text-[#555555] md:flex">
          {['About', 'Gallery', 'Amenities', 'Location'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="hover:opacity-70">{item}</a>
          ))}
        </nav>
        <a href="#book" className="shrink-0 rounded-xl px-5 py-3 font-black text-white shadow-sm" style={{ background: template.accent }}>
          Book Now
        </a>
      </div>
    </header>
  );
}

function HorizontalBookingBar({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  return (
    <section id="book" className="border-b border-[#E5E5E5] bg-white px-5 py-5 shadow-sm sm:px-8">
      <div className="mx-auto grid max-w-7xl gap-3 rounded-2xl border border-[#E5E5E5] bg-white p-3 shadow-lg sm:grid-cols-2 md:grid-cols-[1fr_1fr_1fr_1fr_auto]">
        {[
          ['Check-in', 'Select date'],
          ['Check-out', 'Select date'],
          ['Guests', content.maxGuests ? `Up to ${content.maxGuests}` : 'Add guests'],
          ['Price', content.basePrice ? `$${Math.round(content.basePrice)} / night` : 'Check rates'],
        ].map(([label, value]) => (
          <button key={label} type="button" className="rounded-xl px-4 py-3 text-left hover:bg-[#FAFAF8]">
            <span className="block text-xs font-black uppercase tracking-[0.12em] text-[#717171]">{label}</span>
            <span className="mt-1 block font-bold text-[#2F2F2F]">{value}</span>
          </button>
        ))}
        <a href="#booking-details" className="flex items-center justify-center rounded-xl px-6 py-4 font-black text-white sm:col-span-2 md:col-span-1" style={{ background: template.accent }}>
          Search dates
        </a>
      </div>
    </section>
  );
}

type PreviewBookingState = {
  checkIn: string;
  checkOut: string;
  guests: number;
};

function bookingNights(checkIn: string, checkOut: string) {
  if (!checkIn || !checkOut) return 0;
  const start = new Date(checkIn);
  const end = new Date(checkOut);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 0;
  return Math.max(0, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
}

function bookingEstimate(content: PreviewContent, state: PreviewBookingState) {
  const nights = bookingNights(state.checkIn, state.checkOut);
  const nightly = content.basePrice || 0;
  const cleaning = content.cleaningFee || 0;
  const subtotal = nights * nightly + (nights > 0 ? cleaning : 0);
  const tax = content.taxRate ? subtotal * (content.taxRate / 100) : 0;
  return {
    nights,
    total: Math.round((subtotal + tax) * 100) / 100,
  };
}

function liveBookingHref(state: PreviewBookingState) {
  const params = new URLSearchParams();
  if (state.checkIn) params.set('checkIn', state.checkIn);
  if (state.checkOut) params.set('checkOut', state.checkOut);
  if (state.guests) params.set('guests', String(state.guests));
  const query = params.toString();
  return `/booking${query ? `?${query}` : ''}`;
}

function PreviewSignupBookingPrompt({
  template,
  content,
  state,
  onClose,
}: {
  template: TemplateOption;
  content: PreviewContent;
  state: PreviewBookingState;
  onClose: () => void;
}) {
  const estimate = bookingEstimate(content, state);

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/55 p-4">
      <div className="w-full max-w-md overflow-hidden rounded-2xl bg-white shadow-2xl">
        <div className="p-6 text-white" style={{ background: template.accent }}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-white/75">Preview booking</p>
              <h2 className="mt-2 text-2xl leading-tight" style={headingStyle(template)}>Your booking website will be active when you sign up</h2>
            </div>
            <button type="button" onClick={onClose} className="rounded-full bg-white/15 p-2 hover:bg-white/25" aria-label="Close booking preview message">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div className="space-y-4 p-6">
          <p className="leading-7 text-[#555555]">
            This preview shows how guests will choose dates, guests and rates. Once you sign up, this button becomes a live booking flow and you can manage bookings in your dashboard.
          </p>
          <div className="rounded-xl bg-[#FAFAF8] p-4 text-sm text-[#484848]">
            <div className="flex justify-between gap-4"><span>Property</span><strong>{content.brand}</strong></div>
            <div className="mt-2 flex justify-between gap-4"><span>Dates</span><strong>{state.checkIn || 'Check-in'} to {state.checkOut || 'Check-out'}</strong></div>
            <div className="mt-2 flex justify-between gap-4"><span>Guests</span><strong>{state.guests}</strong></div>
            <div className="mt-2 flex justify-between gap-4"><span>Estimated total</span><strong>{estimate.nights ? `$${estimate.total.toFixed(0)}` : 'Select dates'}</strong></div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Link to="/signup" className="inline-flex items-center justify-center rounded-xl px-5 py-3 font-black text-white" style={{ background: template.accent }}>
              Sign up
            </Link>
            <button type="button" onClick={onClose} className="rounded-xl border border-[#D8D8D8] px-5 py-3 font-black text-[#484848] hover:bg-[#F7F7F7]">
              Keep previewing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PreviewBookingBar({
  template,
  content,
  actionBackground,
  liveMode = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  actionBackground?: string;
  liveMode?: boolean;
}) {
  const [state, setState] = useState<PreviewBookingState>({ checkIn: '', checkOut: '', guests: Math.min(2, content.maxGuests || 2) });
  const [showPrompt, setShowPrompt] = useState(false);
  const estimate = bookingEstimate(content, state);

  const updateGuests = (value: string) => {
    const maxGuests = content.maxGuests || 12;
    const guests = Math.min(maxGuests, Math.max(1, Number(value) || 1));
    setState((current) => ({ ...current, guests }));
  };

  const checkRates = () => {
    if (liveMode) {
      window.location.href = liveBookingHref(state);
      return;
    }
    setShowPrompt(true);
  };

  return (
    <section id="book" className="relative z-20 mx-auto -mt-16 max-w-6xl px-5 sm:px-8">
      {!liveMode && showPrompt && <PreviewSignupBookingPrompt template={template} content={content} state={state} onClose={() => setShowPrompt(false)} />}
      <div className="overflow-hidden rounded-xl bg-white shadow-2xl">
        <div className="grid gap-px bg-[#E7E1D8] md:grid-cols-[1fr_1fr_1fr_1.2fr]">
          <label className="bg-white px-7 py-5">
            <span className="flex items-center gap-3 text-xs font-black uppercase tracking-[0.14em] text-[#555555]">
              <Calendar className="h-4 w-4" style={{ color: template.accent }} />
              Check-in
            </span>
            <input
              type="date"
              value={state.checkIn}
              onChange={(event) => setState((current) => ({ ...current, checkIn: event.target.value }))}
              className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-bold"
            />
          </label>
          <label className="bg-white px-7 py-5">
            <span className="flex items-center gap-3 text-xs font-black uppercase tracking-[0.14em] text-[#555555]">
              <Calendar className="h-4 w-4" style={{ color: template.accent }} />
              Check-out
            </span>
            <input
              type="date"
              value={state.checkOut}
              min={state.checkIn || undefined}
              onChange={(event) => setState((current) => ({ ...current, checkOut: event.target.value }))}
              className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-bold"
            />
          </label>
          <label className="bg-white px-7 py-5">
            <span className="flex items-center gap-3 text-xs font-black uppercase tracking-[0.14em] text-[#555555]">
              <Users className="h-4 w-4" style={{ color: template.accent }} />
              Guests
            </span>
            <input
              type="number"
              min={1}
              max={content.maxGuests || 12}
              value={state.guests}
              onChange={(event) => updateGuests(event.target.value)}
              className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-bold"
            />
          </label>
          <button
            type="button"
            onClick={checkRates}
            className="flex flex-col items-center justify-center px-7 py-6 text-sm font-black uppercase tracking-[0.14em] text-white"
            style={{ background: actionBackground || template.accent }}
          >
            <span>Check rates</span>
            <span className="mt-1 text-xs font-bold normal-case tracking-normal text-white/80">
              {estimate.nights ? `${estimate.nights} night${estimate.nights === 1 ? '' : 's'} · $${estimate.total.toFixed(0)}` : 'Select dates'}
            </span>
          </button>
        </div>
        <div className="grid gap-4 px-7 py-4 text-xs font-bold text-[#6E716D] sm:grid-cols-4">
          {['Best Price Guarantee', 'Secure Booking', 'Pay Direct, Save More', 'Local Host Support'].map((item) => (
            <span key={item} className="flex items-center gap-2"><Check className="h-3.5 w-3.5" style={{ color: template.accent }} />{item}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

function BookingStrip({ template, content, compact = false, id = 'booking-details', liveMode = false }: { template: TemplateOption; content: PreviewContent; compact?: boolean; id?: string; liveMode?: boolean }) {
  const [state, setState] = useState<PreviewBookingState>({ checkIn: '', checkOut: '', guests: Math.min(2, content.maxGuests || 2) });
  const [showPrompt, setShowPrompt] = useState(false);
  const estimate = bookingEstimate(content, state);
  const nightly = content.basePrice || 0;
  const maxGuests = content.maxGuests || 12;

  const updateGuests = (value: string) => {
    const guests = Math.min(maxGuests, Math.max(1, Number(value) || 1));
    setState((current) => ({ ...current, guests }));
  };

  return (
    <div id={id} className={classNames('rounded-2xl border border-[#E5E5E5] bg-white p-4 shadow-xl', compact ? '' : 'sm:p-5')}>
      {!liveMode && showPrompt && <PreviewSignupBookingPrompt template={template} content={content} state={state} onClose={() => setShowPrompt(false)} />}
      <div className="mb-4 flex items-baseline justify-between gap-3">
        <p className="text-2xl font-black">{content.basePrice ? `$${Math.round(content.basePrice)}` : 'Check dates'}<span className="text-base font-semibold text-[#717171]">{content.basePrice ? ' / night' : ''}</span></p>
        <p className="text-sm font-bold" style={{ color: template.accent }}>Book direct</p>
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        <label className="rounded-xl border border-[#D8D8D8] p-3">
          <span className="text-xs font-bold uppercase text-[#717171]">Check-in</span>
          <input type="date" value={state.checkIn} onChange={(event) => setState((current) => ({ ...current, checkIn: event.target.value }))} className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-semibold" />
        </label>
        <label className="rounded-xl border border-[#D8D8D8] p-3">
          <span className="text-xs font-bold uppercase text-[#717171]">Check-out</span>
          <input type="date" value={state.checkOut} min={state.checkIn || undefined} onChange={(event) => setState((current) => ({ ...current, checkOut: event.target.value }))} className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-semibold" />
        </label>
        <label className="rounded-xl border border-[#D8D8D8] p-3">
          <span className="text-xs font-bold uppercase text-[#717171]">Guests</span>
          <input type="number" min={1} max={maxGuests} value={state.guests} onChange={(event) => updateGuests(event.target.value)} className="mt-2 w-full rounded-md border border-[#E5E5E5] px-3 py-2 text-sm font-semibold" />
        </label>
      </div>
      <div className="mt-4 rounded-xl bg-[#FAFAF8] p-4 text-sm text-[#484848]">
        <div className="flex justify-between gap-4"><span>{nightly ? `$${Math.round(nightly)} x ${estimate.nights || 0} night${estimate.nights === 1 ? '' : 's'}` : 'Nightly rate'}</span><strong>{nightly && estimate.nights ? `$${(nightly * estimate.nights).toFixed(0)}` : 'Select dates'}</strong></div>
        {content.cleaningFee ? <div className="mt-2 flex justify-between gap-4"><span>Cleaning fee</span><strong>${Math.round(content.cleaningFee)}</strong></div> : null}
        <div className="mt-3 flex justify-between gap-4 border-t border-[#E5E5E5] pt-3 text-base"><span className="font-bold">Estimated total</span><strong style={{ color: template.accent }}>{estimate.nights ? `$${estimate.total.toFixed(0)}` : 'Select dates'}</strong></div>
      </div>
      <button
        type="button"
        onClick={() => {
          if (liveMode) {
            window.location.href = liveBookingHref(state);
            return;
          }
          setShowPrompt(true);
        }}
        className="mt-4 flex w-full items-center justify-center rounded-xl px-5 py-4 font-black text-white"
        style={{ background: template.accent }}
      >
        Reserve Now
      </button>
      <p className="mt-3 text-center text-sm text-[#717171]">Secure direct booking. You will not be charged yet.</p>
    </div>
  );
}

function DropDownBookingPanel({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  return (
    <div id="book" className="mx-auto -mt-20 max-w-6xl px-5 sm:px-8">
      <div className="relative z-20 rounded-3xl border border-[#E5E5E5] bg-white p-5 shadow-2xl">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm uppercase" style={eyebrowStyle(template)}>Book direct</p>
            <h2 className="mt-1 text-2xl text-[#2F2F2F]" style={headingStyle(template)}>Check dates without leaving the page</h2>
          </div>
          <StayFacts content={content} template={template} />
        </div>
        <div className="mt-5 grid gap-3 rounded-2xl bg-[#FAFAF8] p-3 md:grid-cols-[1fr_1fr_1fr_auto]">
          {['Check-in', 'Check-out', 'Guests'].map((label) => (
            <button key={label} type="button" className="rounded-xl bg-white px-4 py-4 text-left shadow-sm">
              <span className="block text-xs font-black uppercase tracking-[0.12em] text-[#717171]">{label}</span>
              <span className="mt-1 block font-bold text-[#2F2F2F]">{label === 'Guests' ? '2 guests' : 'Select date'}</span>
            </button>
          ))}
          <a href="#booking-details" className="flex items-center justify-center rounded-xl px-6 py-4 font-black text-white" style={{ background: template.accent }}>
            See total
          </a>
        </div>
      </div>
    </div>
  );
}

function BookingStepperPanel({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  return (
    <section id="book" className="mx-auto max-w-7xl px-5 pb-8 sm:px-8">
      <div className="rounded-3xl border border-[#E5E5E5] bg-white p-5 shadow-xl">
        <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm uppercase" style={eyebrowStyle(template)}>Plan your stay</p>
            <h2 className="mt-1 text-3xl text-[#2F2F2F]" style={headingStyle(template)}>A guided booking flow</h2>
          </div>
          <a href="#booking-details" className="rounded-xl px-6 py-4 font-black text-white" style={{ background: template.accent }}>
            Start booking
          </a>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ['1', 'Choose dates', 'Guests select check-in and check-out first.'],
            ['2', 'Confirm guests', content.maxGuests ? `Up to ${content.maxGuests} guests can be shown clearly.` : 'Guest count is confirmed before payment.'],
            ['3', 'Secure payment', 'The total is shown before guests continue to Stripe.'],
          ].map(([number, title, body]) => (
            <div key={title} className="rounded-2xl bg-[#FAFAF8] p-5">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full text-sm font-black text-white" style={{ background: template.accent }}>{number}</span>
              <h3 className="mt-4 text-xl text-[#2F2F2F]" style={headingStyle(template)}>{title}</h3>
              <p className="mt-2 leading-7 text-[#5F5F5F]">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function GalleryShowcase({
  template,
  content,
  mode = 'grid',
}: {
  template: TemplateOption;
  content: PreviewContent;
  mode?: 'grid' | 'carousel';
}) {
  const [showAll, setShowAll] = useState(false);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const photos = supportingPhotos(content, [content.gallery[0]]);
  const visiblePhotos = showAll ? photos : photos.slice(0, 10);

  const scrollGallery = (direction: number) => {
    trackRef.current?.scrollBy({ left: direction * 420, behavior: 'smooth' });
  };

  if (mode === 'carousel') {
    return (
      <section id="gallery" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-sm font-black uppercase tracking-[0.28em]" style={{ color: template.accent }}>Gallery</p>
            <h2 className="text-4xl text-[#2F2F2F]" style={headingStyle(template)}>Swipe through the stay</h2>
          </div>
          {photos.length > 1 && (
            <div className="flex gap-2">
              <button type="button" onClick={() => scrollGallery(-1)} className="rounded-full border border-[#D8D8D8] bg-white p-3 shadow-sm" aria-label="Previous photo">
                <ArrowLeft className="h-5 w-5" />
              </button>
              <button type="button" onClick={() => scrollGallery(1)} className="rounded-full border border-[#D8D8D8] bg-white p-3 shadow-sm" aria-label="Next photo">
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
        <div ref={trackRef} className="flex snap-x gap-4 overflow-x-auto pb-4 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {photos.map((image, index) => (
            <figure key={image} className="min-w-[82vw] snap-start overflow-hidden rounded-3xl bg-white shadow-sm sm:min-w-[28rem]">
              <ExpandablePhoto src={image} alt={`${content.brand} photo ${index + 1}`} className="h-80 w-full object-cover" />
              <figcaption className="px-5 py-4 text-sm font-bold text-[#555555]">
                {content.brand} · Photo {index + 1} of {photos.length}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section id="gallery" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
      <div className="mb-7 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-3 text-sm font-black uppercase tracking-[0.28em]" style={{ color: template.accent }}>Gallery</p>
          <h2 className="text-4xl text-[#2F2F2F]" style={headingStyle(template)}>See the stay before you book</h2>
        </div>
        {photos.length > 10 && (
          <button
            type="button"
            onClick={() => setShowAll((value) => !value)}
            className="rounded-xl border border-[#D8D8D8] bg-white px-5 py-3 font-black text-[#484848] shadow-sm"
          >
            {showAll ? 'Show fewer photos' : `Show all ${photos.length} photos`}
          </button>
        )}
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        {visiblePhotos.map((image, index) => (
          <ExpandablePhoto
            key={image}
            src={image}
            alt={`${content.brand} photo ${index + 1}`}
            className={classNames(
              'w-full rounded-2xl object-cover',
              index === 0 ? 'h-96 md:col-span-2 md:row-span-2 md:h-full' : 'h-48'
            )}
          />
        ))}
      </div>
    </section>
  );
}

function AmenitiesShowcase({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  const [showAll, setShowAll] = useState(false);
  const amenities = content.amenities.length ? content.amenities : ['Wifi', 'Parking', 'Kitchen', 'Heating'];
  const visibleAmenities = showAll ? amenities : amenities.slice(0, 10);

  return (
    <section id="amenities" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
      <div className="rounded-3xl border border-[#E5E5E5] bg-[#FAFAF8] p-6 sm:p-8">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-sm uppercase" style={eyebrowStyle(template)}>Amenities</p>
            <h2 className="text-4xl text-[#2F2F2F]" style={headingStyle(template)}>Everything guests need to know</h2>
          </div>
          {amenities.length > 10 && (
            <button
              type="button"
              onClick={() => setShowAll((value) => !value)}
              className="rounded-xl border border-[#D8D8D8] bg-white px-5 py-3 font-black text-[#484848] shadow-sm"
            >
              {showAll ? 'Show fewer amenities' : `Show all ${amenities.length} amenities`}
            </button>
          )}
        </div>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {visibleAmenities.map((amenity) => (
            <div key={amenity} className="rounded-2xl bg-white px-4 py-3 font-bold text-[#484848] shadow-sm">{amenity}</div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FooterContactDetails({ content, className = '' }: { content: PreviewContent; className?: string }) {
  const email = content.contactEmail || 'Contact host via booking request';
  const phone = content.contactPhone || 'Phone available after enquiry';
  const location = content.location || 'Location shared on booking page';

  return (
    <div className={classNames('space-y-3 text-sm text-white/70', className)}>
      <p className="flex items-center gap-2"><Mail className="h-4 w-4 shrink-0" />{email}</p>
      <p className="flex items-center gap-2"><Phone className="h-4 w-4 shrink-0" />{phone}</p>
      <p className="flex items-center gap-2"><MapPin className="h-4 w-4 shrink-0" />{location}</p>
    </div>
  );
}

function footerWebsiteLabel(content: PreviewContent, liveMode?: boolean): string {
  if (liveMode && typeof window !== 'undefined') {
    const host = window.location.host.replace(/^www\./i, '');
    if (host) return host;
  }
  if (content.sourceUrl) {
    try {
      return new URL(normaliseUrl(content.sourceUrl) || content.sourceUrl).host.replace(/^www\./i, '');
    } catch {
      return content.sourceUrl.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/$/, '');
    }
  }
  return content.brand;
}

function FooterHostLoginLink({ liveMode, className = '' }: { liveMode?: boolean; className?: string }) {
  if (!liveMode) return null;
  return (
    <a
      href="/host"
      className={classNames(
        'inline-flex w-fit items-center gap-2 rounded-full border border-white/20 px-4 py-2 text-sm font-bold text-white/80 transition-colors hover:bg-white/10 hover:text-white',
        className,
      )}
    >
      <LogIn className="h-4 w-4" />
      Host login
    </a>
  );
}

function FooterBottomBar({ content, liveMode, className = '' }: { content: PreviewContent; liveMode?: boolean; className?: string }) {
  return (
    <div className={classNames('mx-auto mt-10 grid max-w-7xl gap-3 border-t border-white/10 pt-6 text-xs text-white/50 md:grid-cols-3 md:items-center', className)}>
      <span>{footerWebsiteLabel(content, liveMode)}</span>
      <span className="md:text-center">© 2026 {content.brand}. All rights reserved.</span>
      <a href="https://staydirect.nz" className="hover:text-white/75 md:text-right">
        Powered by <span style={{ color: STAYDIRECT_BRAND_RED }}>StayDirect.nz</span>
      </a>
    </div>
  );
}

function EmbeddedLocationMap({ content, className }: { content: PreviewContent; className?: string }) {
  const query = content.location || content.brand;
  return (
    <iframe
      title={`${content.brand} location map`}
      src={`https://www.google.com/maps?q=${encodeURIComponent(query)}&output=embed`}
      className={classNames('h-72 w-full rounded-xl border border-black/10 shadow-sm', className)}
      loading="lazy"
    />
  );
}

function nearbyPlacesUrl(content: PreviewContent) {
  const location = content.location || content.brand;
  return `https://www.google.com/maps/search/attractions,+walks,+beaches,+museums+near+${encodeURIComponent(location)}`;
}

export type PreviewGuidebookItem = {
  id: string;
  title: string;
  category: string;
  description: string;
  address?: string;
  distance_from_property?: string;
  google_maps_link?: string;
  image_url?: string;
  host_note?: string;
  is_public?: boolean | null;
  source_metadata?: Record<string, unknown>;
};

function readPreviewGuidebook(content: PreviewContent): PreviewGuidebookItem[] {
  if (content.guidebookItems) return content.guidebookItems;
  return [];
}

function usePreviewGuidebook(content: PreviewContent) {
  const [items, setItems] = useState<PreviewGuidebookItem[]>(() => readPreviewGuidebook(content));

  useEffect(() => {
    setItems(readPreviewGuidebook(content));
    const listener = () => setItems(readPreviewGuidebook(content));
    window.addEventListener('staydirect-guidebook-updated', listener);
    window.addEventListener('storage', listener);
    return () => {
      window.removeEventListener('staydirect-guidebook-updated', listener);
      window.removeEventListener('storage', listener);
    };
  }, [content]);

  return items;
}

function FullWidthMapSection({ template, content, className }: { template: TemplateOption; content: PreviewContent; className?: string }) {
  return (
    <section id="map" className={classNames('bg-white px-5 py-16 sm:px-8', className)}>
      <div className="mx-auto max-w-7xl">
        <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: template.accent }}>Map</p>
            <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>{content.location || content.brand}</h2>
          </div>
          <a
            href={nearbyPlacesUrl(content)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex w-fit items-center gap-2 rounded-md px-6 py-3 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm"
            style={{ background: template.accent }}
          >
            See what's nearby
            <ExternalLink className="h-4 w-4" />
          </a>
        </div>
        <EmbeddedLocationMap content={content} className="h-[460px] rounded-2xl" />
      </div>
    </section>
  );
}

function ReviewsHostSection({ template, content, className }: { template: TemplateOption; content: PreviewContent; className?: string }) {
  const roundedRating = content.reviewRating ? Math.round(content.reviewRating * 10) / 10 : null;
  const reviewCount = content.reviewCount ? Math.round(content.reviewCount) : null;
  const reviewSnippets = (content.reviews || []).filter((review) => review.text).slice(0, 2);
  const importedReviewLabel = content.reviewSource ? `${content.reviewSource} reviews` : null;
  const hostBio = content.hostBio || 'Local host support is available before and during the stay, with contact details included for guest confidence.';

  return (
    <section id="host" className={classNames('px-5 py-16 sm:px-8', className)} style={{ background: template.accentSoft }}>
      <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-2">
        <article className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.24em]" style={{ color: template.accent }}>Reviews</p>
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-4xl leading-tight" style={headingStyle(template)}>Guest reviews</h2>
            {importedReviewLabel && (
              <span className="rounded-full border border-black/10 bg-white px-3 py-1 text-xs font-black uppercase tracking-[0.12em] text-[#5F5F5F]">
                {importedReviewLabel}
              </span>
            )}
          </div>
          {(roundedRating || reviewCount) && (
            <div className="mt-5 flex flex-wrap items-center gap-3">
              {roundedRating && (
                <div className="flex items-center gap-1" aria-label={`${roundedRating} star rating`}>
                  {Array.from({ length: 5 }).map((_, index) => (
                    <Star
                      key={index}
                      className="h-5 w-5"
                      fill={index + 1 <= Math.round(roundedRating) ? template.accent : 'transparent'}
                      style={{ color: template.accent }}
                    />
                  ))}
                </div>
              )}
              <p className="font-black text-[#2F2F2F]">
                {roundedRating ? `${roundedRating.toFixed(1)} star rating` : 'Guest rating'}
                {reviewCount ? ` from ${reviewCount} review${reviewCount === 1 ? '' : 's'}` : ''}
                {content.reviewSource ? ` on ${content.reviewSource}` : ''}
              </p>
            </div>
          )}
          <p className="mt-4 leading-7 text-[#5F5F5F]">
            {content.reviewCopy || (content.reviewUrl && content.reviewSource ? `Guest reviews are available on ${content.reviewSource}.` : 'Guest reviews can be shown here once they are available.')}
          </p>
          {reviewSnippets.length > 0 && (
            <div className="mt-5 grid gap-3">
              {reviewSnippets.map((review, index) => (
                <blockquote key={`${review.author || 'guest'}-${index}`} className="rounded-xl border border-black/5 bg-[#FAFAF8] p-4">
                  <p className="leading-7 text-[#484848]">"{review.text}"</p>
                  <footer className="mt-3 text-sm font-bold text-[#717171]">
                    {[review.author || 'Guest', review.date, review.source].filter(Boolean).join(' · ')}
                  </footer>
                </blockquote>
              ))}
            </div>
          )}
          {content.reviewUrl && (
            <a href={content.reviewUrl} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center gap-2 font-black" style={{ color: template.accent }}>
              View reviews
              <ExternalLink className="h-4 w-4" />
            </a>
          )}
        </article>
        <article className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.24em]" style={{ color: template.accent }}>Host</p>
          <div className="flex items-start gap-5">
            {content.hostPhoto ? (
              <img src={content.hostPhoto} alt={content.hostName || `${content.brand} host`} className="h-20 w-20 rounded-full object-cover shadow-sm" />
            ) : (
              <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full text-white shadow-sm" style={{ background: template.accent }}>
                <Home className="h-8 w-8" />
              </div>
            )}
            <div>
              <h2 className="text-3xl leading-tight" style={headingStyle(template)}>{content.hostName || 'Your local host'}</h2>
              <p className="mt-3 leading-7 text-[#5F5F5F]">{hostBio}</p>
              <div className="mt-4 text-sm text-[#5F5F5F]">
                <FooterContactDetails content={content} className="text-[#5F5F5F]" />
              </div>
            </div>
          </div>
        </article>
      </div>
    </section>
  );
}

function PhotoLightbox({
  photo,
  alt,
  onClose,
}: {
  photo: string | null;
  alt: string;
  onClose: () => void;
}) {
  if (!photo) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/82 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Expanded photo">
      <button type="button" className="absolute inset-0 cursor-zoom-out" onClick={onClose} aria-label="Close expanded photo overlay" />
      <div className="relative z-10 max-h-[92vh] w-full max-w-6xl">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 z-20 flex h-11 w-11 items-center justify-center rounded-full bg-white text-[#333333] shadow-lg"
          aria-label="Close expanded photo"
        >
          <X className="h-5 w-5" />
        </button>
        <img src={photo} alt={alt} className="max-h-[92vh] w-full rounded-2xl object-contain shadow-2xl" />
      </div>
    </div>
  );
}

function ExpandablePhoto({
  src,
  alt,
  className,
}: {
  src: string;
  alt: string;
  className: string;
}) {
  const [openPhoto, setOpenPhoto] = useState<string | null>(null);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpenPhoto(src)}
        className="group relative z-10 block w-full cursor-zoom-in overflow-hidden rounded-[inherit] text-left focus:outline-none focus:ring-4 focus:ring-[#FF5A5F]/35"
        aria-label={`Expand ${alt}`}
      >
        <img src={src} alt={alt} className={classNames(className, 'pointer-events-none transition duration-300 group-hover:scale-[1.025]')} />
      </button>
      <PhotoLightbox photo={openPhoto} alt={alt} onClose={() => setOpenPhoto(null)} />
    </>
  );
}

function ExpandableBackgroundPhoto({ src, alt }: { src: string; alt: string }) {
  const [openPhoto, setOpenPhoto] = useState<string | null>(null);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpenPhoto(src)}
        className="absolute inset-0 z-0 block cursor-zoom-in overflow-hidden text-left focus:outline-none focus:ring-4 focus:ring-[#FF5A5F]/35"
        aria-label={`Expand ${alt}`}
      >
        <img
          src={src}
          alt={alt}
          className="h-full w-full object-cover pointer-events-none transition duration-300 hover:scale-[1.015]"
        />
      </button>
      <PhotoLightbox photo={openPhoto} alt={alt} onClose={() => setOpenPhoto(null)} />
    </>
  );
}

function HostDashboardPrompt({
  content,
  className,
  children = 'Host',
}: {
  content: PreviewContent;
  className?: string;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={classNames('text-left', className)}>
        {children}
      </button>
      {open && (
        <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Host dashboard preview">
          <button type="button" className="absolute inset-0 cursor-pointer" onClick={() => setOpen(false)} aria-label="Close host dashboard preview overlay" />
          <div className="relative z-10 w-full max-w-md rounded-2xl bg-white p-6 text-[#333333] shadow-2xl">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-[#F7F7F7] text-[#555555]"
              aria-label="Close host dashboard preview"
            >
              <X className="h-4 w-4" />
            </button>
            <p className="pr-10 text-xs font-black uppercase tracking-[0.18em] text-[#FF5A5F]">Host dashboard</p>
            <h2 className="mt-3 text-3xl font-black leading-tight">This becomes your dashboard when you sign up.</h2>
            <p className="mt-4 leading-7 text-[#666666]">
              Once {content.brand} is active on StayDirect, this Host button will take you to the owner login so you can manage bookings, calendar, photos, guest messages and website details.
            </p>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="mt-6 w-full rounded-xl bg-[#FF5A5F] px-5 py-3 font-black text-white"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function AttractionsNearbyPrompt({
  content,
  className,
  style,
}: {
  content: PreviewContent;
  className?: string;
  style?: React.CSSProperties;
}) {
  const [open, setOpen] = useState(false);
  const guidebookItems = usePreviewGuidebook(content);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={classNames('inline-flex w-fit items-center gap-2 rounded-md px-6 py-3 text-xs font-black uppercase tracking-[0.14em] shadow-sm', className)}
        style={style}
      >
        <MapPin className="h-4 w-4" />
        Attractions nearby
      </button>
      {open && (
        <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Attractions nearby preview">
          <button type="button" className="absolute inset-0 cursor-pointer" onClick={() => setOpen(false)} aria-label="Close attractions nearby preview overlay" />
          <div className="relative z-10 w-full max-w-md rounded-2xl bg-white p-6 text-[#333333] shadow-2xl">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-[#F7F7F7] text-[#555555]"
              aria-label="Close attractions nearby preview"
            >
              <X className="h-4 w-4" />
            </button>
            <p className="pr-10 text-xs font-black uppercase tracking-[0.18em] text-[#FF5A5F]">Attractions nearby</p>
            <h2 className="mt-3 text-3xl font-black leading-tight">Local favourites near {content.brand}</h2>
            <div className="mt-5 max-h-[62vh] space-y-4 overflow-y-auto pr-1">
              {guidebookItems.length ? guidebookItems.slice(0, 6).map((item) => (
                <article key={item.id || item.title} className="overflow-hidden rounded-2xl border border-[#EEEEEE] bg-[#FAFAF8] text-left">
                  {item.image_url ? <img src={item.image_url} alt={item.title} className="h-36 w-full object-cover" loading="lazy" /> : null}
                  <div className="space-y-2 p-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full bg-white px-3 py-1 text-[11px] font-black uppercase tracking-[0.12em] text-[#666666]">{String(item.category || 'Local').replace(/_/g, ' ')}</span>
                      {item.distance_from_property ? <span className="rounded-full bg-white px-3 py-1 text-[11px] font-black text-[#00A699]">{item.distance_from_property}</span> : null}
                    </div>
                    <h3 className="text-lg font-black text-[#333333]">{item.title}</h3>
                    <p className="text-sm leading-6 text-[#666666]">{item.description}</p>
                    {item.google_maps_link ? (
                      <a href={item.google_maps_link} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-black text-[#00A699]">
                        Open map <ExternalLink className="h-4 w-4" />
                      </a>
                    ) : null}
                  </div>
                </article>
              )) : (
                <p className="leading-7 text-[#666666]">
                  Nearby recommendations will appear here as soon as the host adds local favourites in StayDirect.
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="mt-6 w-full rounded-xl bg-[#FF5A5F] px-5 py-3 font-black text-white"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function ExpandableAmenityIcons({
  amenities,
  icons,
  accent,
  dark = false,
  initialCount = 8,
}: {
  amenities: string[];
  icons: Array<typeof Wifi>;
  accent: string;
  dark?: boolean;
  initialCount?: number;
}) {
  const [showAll, setShowAll] = useState(false);
  const visible = showAll ? amenities : amenities.slice(0, initialCount);
  const hidden = Math.max(0, amenities.length - visible.length);

  return (
    <>
      <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4 lg:grid-cols-8">
        {visible.map((amenity, index) => {
          const AmenityIcon = icons[index % icons.length];
          return (
            <div key={`${amenity}-${index}`} className={classNames('flex flex-col items-center gap-3 text-sm font-semibold', dark ? 'text-white/86' : 'text-[#4B514B]')}>
              <AmenityIcon className="h-7 w-7" style={{ color: accent }} />
              <span>{amenity}</span>
            </div>
          );
        })}
      </div>
      {hidden > 0 || showAll ? (
        <button
          type="button"
          onClick={() => setShowAll((value) => !value)}
          className={classNames('mt-8 inline-flex rounded-md border px-5 py-3 text-xs font-black uppercase tracking-[0.14em]', dark ? 'border-white/30 text-white' : 'border-[#D8D8D8] text-[#333333]')}
        >
          {showAll ? 'Show fewer amenities' : `See ${hidden} more amenities`}
        </button>
      ) : null}
    </>
  );
}

function ExpandablePhotoGrid({
  photos,
  content,
  accent,
  initialCount = 4,
}: {
  photos: string[];
  content: PreviewContent;
  accent: string;
  initialCount?: number;
}) {
  const [showAll, setShowAll] = useState(false);
  const uniquePhotos = uniqueImages(photos);
  const visible = showAll ? uniquePhotos : uniquePhotos.slice(0, initialCount);
  const hidden = Math.max(0, uniquePhotos.length - visible.length);

  return (
    <div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {visible.map((photo, index) => (
          <ExpandablePhoto
            key={`${photo}-${index}`}
            src={photo}
            alt={`${content.brand} photo ${index + 1}`}
            className="h-52 w-full rounded-xl object-cover shadow-md"
          />
        ))}
      </div>
      {hidden > 0 || showAll ? (
        <button
          type="button"
          onClick={() => setShowAll((value) => !value)}
          className="mt-6 inline-flex rounded-md px-5 py-3 text-xs font-black uppercase tracking-[0.14em] text-white"
          style={{ background: accent }}
        >
          {showAll ? 'Show fewer photos' : `See ${hidden} more photos`}
        </button>
      ) : null}
    </div>
  );
}

function PublicGuidebookSection({
  template,
  content,
  className,
  compact = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  className?: string;
  compact?: boolean;
}) {
  const guidebookItems = usePreviewGuidebook(content);
  const [showAll, setShowAll] = useState(false);
  if (!guidebookItems.length) return null;
  const firstRowCount = 3;
  const visibleItems = showAll ? guidebookItems : guidebookItems.slice(0, firstRowCount);
  const hiddenCount = Math.max(0, guidebookItems.length - firstRowCount);

  return (
    <section id="guidebook" className={classNames('bg-[#FAFAF8] px-5 py-20 sm:px-8', className)}>
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 max-w-3xl">
          <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: template.accent }}>Local guidebook</p>
          <h2 className={classNames('leading-tight text-[#252525]', compact ? 'text-3xl md:text-4xl' : 'text-4xl md:text-5xl')} style={headingStyle(template)}>
            Explore nearby
          </h2>
          <p className="mt-4 text-lg leading-8 text-[#5F5F5F]">
            Curated local favourites for easy days out, scenic stops, and memorable moments close to your stay.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {visibleItems.map((item) => {
            const duration = item.source_metadata?.estimated_duration as string | undefined;
            return (
              <article key={item.id || item.title} className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.08)]">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.title} className="h-72 w-full object-cover" loading="lazy" />
                ) : null}
                <div className="space-y-4 p-6">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full bg-[#F4F1EC] px-3 py-1 text-[11px] font-black uppercase tracking-[0.14em] text-[#5F5F5F]">
                      {String(item.category || 'Local favourite').replace(/_/g, ' ')}
                    </span>
                    {item.distance_from_property ? (
                      <span className="rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-[0.12em]" style={{ background: `${template.accent}18`, color: template.accent }}>
                        {item.distance_from_property}
                      </span>
                    ) : null}
                    {duration ? (
                      <span className="rounded-full bg-[#F7F7F7] px-3 py-1 text-[11px] font-black uppercase tracking-[0.12em] text-[#6F6F6F]">{duration}</span>
                    ) : null}
                  </div>
                  <div>
                    <h3 className="text-2xl leading-tight text-[#252525]" style={headingStyle(template)}>{item.title}</h3>
                    <p className="mt-3 leading-7 text-[#5F5F5F]">{item.description}</p>
                  </div>
                  {item.host_note ? (
                    <div className="rounded-xl border border-black/5 bg-[#FFF8EF] p-4 text-sm leading-6 text-[#6F5738]">
                      <span className="font-black">Host tip: </span>{item.host_note}
                    </div>
                  ) : null}
                  {item.google_maps_link ? (
                    <a href={item.google_maps_link} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-black uppercase tracking-[0.12em]" style={{ color: template.accent }}>
                      Get directions <ExternalLink className="h-4 w-4" />
                    </a>
                  ) : null}
                </div>
              </article>
            );
          })}
        </div>
        {hiddenCount > 0 || showAll ? (
          <div className="mt-8 flex justify-center">
            <button
              type="button"
              onClick={() => setShowAll((value) => !value)}
              className="rounded-md px-6 py-3 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm"
              style={{ background: template.accent }}
            >
              {showAll ? 'Show fewer things to do' : `Explore ${hiddenCount} more things to do`}
            </button>
          </div>
        ) : null}
      </div>
    </section>
  );
}

function customBlockMediaUrls(block: WebsiteContentBlock): string[] {
  return uniqueImages(
    String(block.mediaUrls || '')
      .split(/[\n,]+/)
      .map((url) => url.trim())
      .filter(Boolean),
  );
}

function customBlockLabel(block: WebsiteContentBlock): string {
  switch (block.type) {
    case 'photos':
      return 'Photo story';
    case 'video':
      return 'Video tour';
    case 'embed':
      return 'Embedded guide';
    case 'widget':
      return 'Guest tool';
    case 'custom':
      return 'Feature block';
    case 'text':
    default:
      return 'Guest guide';
  }
}

function PublicCustomBlockEmbed({ block }: { block: WebsiteContentBlock }) {
  const embed = (block.embedCode || '').trim();
  if (!embed) return null;

  if (/^https?:\/\//i.test(embed)) {
    return (
      <iframe
        title={`${block.heading || block.title || 'Guest information'} embed`}
        src={embed}
        className="mt-6 h-80 w-full rounded-2xl border border-black/10 bg-white shadow-sm"
        loading="lazy"
      />
    );
  }

  if (/<iframe[\s>]/i.test(embed)) {
    return (
      <div
        className="mt-6 overflow-hidden rounded-2xl border border-black/10 bg-white shadow-sm [&_iframe]:min-h-80 [&_iframe]:w-full"
        dangerouslySetInnerHTML={{ __html: embed }}
      />
    );
  }

  return (
    <pre className="mt-6 overflow-auto rounded-2xl border border-black/10 bg-white p-4 text-sm leading-6 text-[#555555]">
      {embed}
    </pre>
  );
}

function PublicCustomContentSections({ template, content, className }: { template: TemplateOption; content: PreviewContent; className?: string }) {
  const blocks = (content.customSections || []).filter((block) => block.heading || block.title || block.body || block.mediaUrls || block.embedCode);
  if (!blocks.length) return null;

  return (
    <section id="custom-content" className={classNames('bg-white px-5 py-20 sm:px-8', className)}>
      <div className="mx-auto grid max-w-7xl gap-8">
        {blocks.map((block, index) => {
          const id = String(block.id || block.title || block.heading || `custom-${index}`).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `custom-${index}`;
          const title = (block.heading || block.title || 'Guest information').trim();
          const media = customBlockMediaUrls(block).slice(0, 10);
          const hasEmbed = Boolean((block.embedCode || '').trim());
          const buttonLabel = (block.buttonLabel || '').trim();
          const buttonUrl = (block.buttonUrl || '').trim();
          const sectionCssId = `public-custom-${id}-${index}`;

          return (
            <article
              key={`${id}-${index}`}
              id={id}
              className="overflow-hidden rounded-2xl border border-black/10 bg-[#FAFAF8] p-6 shadow-[0_18px_45px_rgba(15,23,42,0.08)] md:p-8"
            >
              {block.customCss?.trim() ? <style>{`#${sectionCssId}{${block.customCss}}`}</style> : null}
              <div id={sectionCssId}>
                <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: template.accent }}>
                  {customBlockLabel(block)}
                </p>
                <h2 className="text-3xl leading-tight text-[#252525] md:text-4xl" style={headingStyle(template)}>{title}</h2>
                {block.body?.trim() ? (
                  <div className="mt-5 max-w-3xl whitespace-pre-line text-lg leading-8 text-[#5F5F5F]">
                    {block.body.trim()}
                  </div>
                ) : null}

                {media.length > 0 ? (
                  <div className={classNames('mt-7 grid gap-4', media.length === 1 ? '' : 'sm:grid-cols-2 lg:grid-cols-3')}>
                    {media.map((src, photoIndex) => (
                      <ExpandablePhoto
                        key={`${src}-${photoIndex}`}
                        src={src}
                        alt={`${title} photo ${photoIndex + 1}`}
                        className={classNames(media.length === 1 ? 'h-[360px]' : 'h-64', 'w-full rounded-xl object-cover shadow-sm')}
                      />
                    ))}
                  </div>
                ) : null}

                {hasEmbed ? <PublicCustomBlockEmbed block={block} /> : null}

                {buttonLabel ? (
                  <a
                    href={buttonUrl || '#book'}
                    target={buttonUrl && !buttonUrl.startsWith('#') ? '_blank' : undefined}
                    rel={buttonUrl && !buttonUrl.startsWith('#') ? 'noopener noreferrer' : undefined}
                    className="mt-7 inline-flex rounded-md px-6 py-3 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm"
                    style={{ background: template.accent }}
                  >
                    {buttonLabel}
                  </a>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function GuestInformationShowcase({ template, content }: { template: TemplateOption; content: PreviewContent }) {
  const details = [
    {
      title: 'Reviews',
      body: content.reviewCopy || 'Guest reviews can be shown on the page once they are available.',
      action: content.reviewUrl ? { label: 'View reviews', href: content.reviewUrl } : null,
    },
    {
      title: 'Tour',
      body: content.googleTourUrl ? 'Guests can open the virtual tour and see the space before they book.' : 'A video or virtual tour can be added when available.',
      action: content.googleTourUrl ? { label: 'Open tour', href: content.googleTourUrl } : null,
    },
    {
      title: 'Booking details',
      body: [
        content.basePrice ? `From $${Math.round(content.basePrice)} per night` : 'Rates shown when dates are selected',
        content.cleaningFee ? `$${Math.round(content.cleaningFee)} cleaning fee` : null,
        content.minNights ? `${content.minNights} night minimum` : null,
      ].filter(Boolean).join(' · '),
      action: null,
    },
    {
      title: 'Contact',
      body: [content.contactEmail, content.contactPhone].filter(Boolean).join(' · ') || 'Contact details can be shown for guest confidence.',
      action: null,
    },
  ];

  return (
    <section id="guest-details" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
      <div className="mb-7">
        <p className="mb-3 text-sm uppercase" style={eyebrowStyle(template)}>Good to know</p>
        <h2 className="text-4xl text-[#2F2F2F]" style={headingStyle(template)}>Useful details before booking</h2>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {details.map((detail) => (
          <article key={detail.title} className="rounded-3xl border border-[#E5E5E5] bg-white p-6 shadow-sm">
            <h3 className="text-2xl text-[#2F2F2F]" style={headingStyle(template)}>{detail.title}</h3>
            <p className="mt-3 leading-7 text-[#5F5F5F]">{detail.body}</p>
            {detail.action && (
              <a
                href={detail.action.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center gap-2 font-black"
                style={{ color: template.accent }}
              >
                {detail.action.label}
                <ExternalLink className="h-4 w-4" />
              </a>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}

function descriptionParagraphs(content: PreviewContent): string[] {
  const base = (content.fullDescription || content.summary)
    .split(/\n+|(?<=\.)\s+(?=[A-Z])/)
    .map((part) => part.trim())
    .filter(Boolean);
  const facts = [
    content.maxGuests ? `The cottage welcomes up to ${content.maxGuests} guests.` : null,
    content.bedrooms ? `There ${content.bedrooms === 1 ? 'is' : 'are'} ${content.bedrooms} bedroom${content.bedrooms === 1 ? '' : 's'} set up for comfortable stays.` : null,
    content.bathrooms ? `Guests have ${content.bathrooms} bathroom${content.bathrooms === 1 ? '' : 's'} available during their stay.` : null,
    content.minNights ? `The minimum stay is ${content.minNights} night${content.minNights === 1 ? '' : 's'}.` : null,
  ].filter(Boolean) as string[];
  const locationCopy = content.location
    ? `Guests will find the stay in ${content.location}, with clear directions and local context before they book.`
    : null;

  return [...base, facts.join(' '), locationCopy].filter((paragraph): paragraph is string => Boolean(paragraph));
}

function PropertyStorySection({
  template,
  content,
  compact = false,
  editorial = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  compact?: boolean;
  editorial?: boolean;
}) {
  const paragraphs = descriptionParagraphs(content);
  const [heroPhoto, secondPhoto] = supportingPhotos(content, [content.gallery[0]]);
  const included = [
    content.basePrice ? `From $${Math.round(content.basePrice)} per night` : null,
    content.cleaningFee ? `$${Math.round(content.cleaningFee)} cleaning fee` : null,
    content.taxRate ? `${content.taxRate}% GST shown before payment` : null,
    content.contactEmail ? content.contactEmail : null,
    content.contactPhone ? content.contactPhone : null,
  ].filter(Boolean) as string[];

  return (
    <section id="about" className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
      <div className={classNames('grid gap-10', compact ? 'lg:grid-cols-[1.05fr_0.95fr]' : 'lg:grid-cols-[0.9fr_1.1fr]')}>
        <div>
          <p className="mb-3 text-sm uppercase" style={eyebrowStyle(template)}>About the stay</p>
          <h2 className="text-4xl leading-tight text-[#2F2F2F] md:text-5xl" style={headingStyle(template)}>
            {editorial ? `The story of ${content.brand}` : `Stay at ${content.brand}`}
          </h2>
          <div className="mt-6 space-y-5 text-lg leading-8 text-[#5F5F5F]">
            {paragraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
          <div className="mt-8">
            <StayFacts content={content} template={template} />
          </div>
        </div>

        <div className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-[1.25fr_0.75fr]">
            {heroPhoto && <ExpandablePhoto src={heroPhoto} alt={`${content.brand} detail`} className="h-80 w-full rounded-3xl object-cover shadow-sm" />}
            {secondPhoto && <ExpandablePhoto src={secondPhoto} alt={`${content.brand} guest space`} className="h-80 w-full rounded-3xl object-cover shadow-sm" />}
          </div>
          {included.length > 0 && (
            <div className="rounded-3xl border border-[#E5E5E5] bg-white p-6 shadow-sm">
              <h3 className="text-2xl text-[#2F2F2F]" style={headingStyle(template)}>Booking details guests can check</h3>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {included.map((item) => (
                  <div key={item} className="rounded-2xl border border-[#E5E5E5] px-4 py-3 font-bold text-[#484848]">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function OriginalPhotoGrid({ content }: { content: PreviewContent }) {
  const [showAll, setShowAll] = useState(false);
  const photos = supportingPhotos(content, [content.gallery[0]]);
  const visiblePhotos = showAll ? photos : photos.slice(0, 10);

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {visiblePhotos.map((image, index) => (
          <ExpandablePhoto key={image} src={image} alt={`${content.brand} photo ${index + 1}`} className="h-72 w-full rounded-sm object-cover shadow-sm" />
        ))}
      </div>
      {photos.length > 10 && (
        <div className="mt-8 text-center">
          <button
            type="button"
            onClick={() => setShowAll((value) => !value)}
            className="rounded-md border border-[#AA7942] bg-white px-6 py-3 font-bold uppercase tracking-wide text-[#AA7942]"
          >
            {showAll ? 'Show fewer photos' : `Show all ${photos.length} photos`}
          </button>
        </div>
      )}
    </>
  );
}

function OriginalAmenityGrid({ content }: { content: PreviewContent }) {
  const [showAll, setShowAll] = useState(false);
  const amenities = content.amenities.length ? content.amenities : ['Wifi', 'Parking', 'Kitchen', 'Heating'];
  const visibleAmenities = showAll ? amenities : amenities.slice(0, 10);

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {visibleAmenities.map((amenity) => (
          <div key={amenity} className="rounded-sm border border-[#dddddd] bg-[#f7f7f7] px-5 py-4 font-semibold capitalize text-[#555555]">{amenity}</div>
        ))}
      </div>
      {amenities.length > 10 && (
        <div className="mt-8 text-center">
          <button
            type="button"
            onClick={() => setShowAll((value) => !value)}
            className="rounded-md border border-[#AA7942] bg-white px-6 py-3 font-bold uppercase tracking-wide text-[#AA7942]"
          >
            {showAll ? 'Show fewer amenities' : `Show all ${amenities.length} amenities`}
          </button>
        </div>
      )}
    </>
  );
}

export function FullTemplateSite({ template, content, embedded = false, liveMode = false }: { template: TemplateOption; content: PreviewContent; embedded?: boolean; liveMode?: boolean }) {
  if (template.heroStyle === 'source') return <OriginalSourceSite template={template} content={content} embedded={embedded} liveMode={liveMode} />;
  if (template.heroStyle === 'poster') return <ModernShowcaseSite template={template} content={content} embedded={embedded} liveMode={liveMode} />;
  if (template.heroStyle === 'cards') return <ConversionSite template={template} content={content} embedded={embedded} liveMode={liveMode} />;
  if (template.heroStyle === 'magazine') return <EditorialSite template={template} content={content} embedded={embedded} liveMode={liveMode} />;
  return <ModernShowcaseSite template={template} content={content} embedded={embedded} liveMode={liveMode} />;
}

function OriginalSourceSite({ template, content, embedded = false, liveMode = false }: { template: TemplateOption; content: PreviewContent; embedded?: boolean; liveMode?: boolean }) {
  const hero = content.gallery[0];
  const [second] = supportingPhotos(content, [hero]);
  const sourceNav = [
    ['Overview', '#overview'],
    ['Tour', '#tour'],
    ['Gallery', '#gallery'],
    ['Amenities', '#amenities'],
    ['Local guide', '#guidebook'],
    ['Map', '#map'],
  ];
  const reviewSnippets = (content.reviews || []).filter((review) => review.text).slice(0, 2);
  const faqs = buildGuestFaqs({
    propertyName: content.brand,
    city: content.location.split(',')[0],
    country: content.location.split(',').slice(1).join(',').trim(),
    basePrice: content.basePrice,
    cleaningFee: content.cleaningFee,
    taxRate: content.taxRate,
    minNights: content.minNights,
    maxGuests: content.maxGuests,
    bedrooms: content.bedrooms,
    bathrooms: content.bathrooms,
    amenities: content.amenities,
    checkInTime: content.checkInTime,
    checkOutTime: content.checkOutTime,
    contactEmail: content.contactEmail,
    contactPhone: content.contactPhone,
  });

  return (
    <SitePreviewChrome template={template} content={content} embedded={embedded} liveMode={liveMode}>
      <div className="min-h-screen bg-[#f7f7f7] text-[#555555]" style={{ fontFamily: 'Montserrat, Arial, sans-serif' }}>
        <header className={classNames('z-40 border-b border-black/10 bg-[#eeeeee]/95 backdrop-blur', embedded ? 'relative' : liveMode ? 'sticky top-0' : 'sticky top-[76px]')}>
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-5 px-4 py-3 sm:px-6 lg:px-8">
            <a href="#home" className="flex items-center gap-3">
              {content.logoImage ? (
                <img src={content.logoImage} alt={content.brand} className="h-14 w-auto object-contain" />
              ) : (
                <span className="text-2xl font-bold" style={{ color: template.accent, fontFamily: 'Georgia, serif' }}>{content.brand}</span>
              )}
            </a>
            <nav className="hidden items-center gap-6 text-sm font-bold uppercase tracking-wide text-[#777777] lg:flex">
              {sourceNav.map(([item, href]) => (
                <a key={item} href={href} className="hover:text-[#aa7942]">{item}</a>
              ))}
            </nav>
            <a href="#book" className="rounded-md px-5 py-3 text-sm font-bold uppercase tracking-wide text-white shadow-sm transition hover:opacity-90" style={{ backgroundColor: template.accent }}>
              Book Now
            </a>
          </div>
        </header>

        <main>
          <section id="home" className="relative min-h-[78vh] overflow-hidden">
            <ExpandableBackgroundPhoto src={hero} alt={`${content.brand} exterior`} />
            <div className="pointer-events-none absolute inset-0 bg-black/42" />
            <div className="relative z-10 mx-auto flex min-h-[78vh] max-w-6xl flex-col items-center justify-center px-4 text-center text-white">
              <p className="mb-4 text-lg italic" style={{ fontFamily: '"Roboto Condensed", Georgia, serif' }}>
                Welcome to the Winterless North
              </p>
              <h1 className="max-w-5xl text-5xl font-bold leading-tight md:text-7xl" style={{ fontFamily: 'Georgia, serif' }}>
                {content.headline}
              </h1>
              <p className="mt-5 max-w-3xl text-xl leading-relaxed text-white/95">{content.summary}</p>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <a href="#book" className="rounded-md px-7 py-3.5 font-bold uppercase tracking-wide text-white" style={{ backgroundColor: template.accent }}>
                  Book Now
                </a>
                <a href="#tour" className="rounded-md border border-white/70 bg-white/10 px-7 py-3.5 font-bold uppercase tracking-wide text-white backdrop-blur hover:bg-white/20">
                  Virtual Tour
                </a>
              </div>
            </div>
          </section>

          <section className="border-b border-[#dddddd] bg-white py-5">
            <div className="mx-auto grid max-w-5xl grid-cols-2 gap-4 px-4 text-center sm:grid-cols-4">
              {[
                content.maxGuests ? `${content.maxGuests} guests` : 'Guests',
                content.bedrooms ? `${content.bedrooms} bedrooms` : 'Bedrooms',
                '3 king-size beds',
                content.bathrooms ? `${content.bathrooms} bathroom${content.bathrooms === 1 ? '' : 's'}` : 'Bathrooms',
              ].map((fact) => (
                <div key={fact} className="font-semibold text-[#555555]">{fact}</div>
              ))}
            </div>
          </section>

          <section id="overview" className="bg-white py-20">
            <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-4 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:px-8">
              <div>
                <div className="mb-8 text-center">
                  <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>{content.location}</p>
                  <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>A country cottage beside the hosts' home</h2>
                </div>
                <div className="space-y-5 text-lg leading-relaxed text-[#5f5f5f]">
                  {descriptionParagraphs(content).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
                  <p>Relish the peace and quiet, apart from native bird song, with Tui and Kereru being frequent visitors.</p>
                  <p>Enjoy garden views, comfortable bedrooms, a self-contained kitchen and the simple confidence of booking directly.</p>
                </div>
              </div>
              <div className="overflow-hidden rounded-sm bg-[#eeeeee] shadow-xl">
                {second && <ExpandablePhoto src={second} alt={`${content.brand} garden view`} className="h-full min-h-[520px] w-full object-cover" />}
              </div>
            </div>
          </section>

          <section id="gallery" className="py-20" style={{ backgroundColor: '#f4f0ea' }}>
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="mb-8 text-center">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Gallery</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>Explore the cottage</h2>
              </div>
              <OriginalPhotoGrid content={content} />
            </div>
          </section>

          <section id="amenities" className="bg-white py-20">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="mb-8 text-center">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Amenities</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>Comforts included</h2>
              </div>
              <OriginalAmenityGrid content={content} />
            </div>
          </section>

          <section id="tour" className="py-20" style={{ backgroundColor: '#f4f0ea' }}>
            <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_1fr] lg:px-8">
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Tour</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>View the cottage before you arrive</h2>
                <p className="mt-5 text-lg leading-8 text-[#5f5f5f]">Take a closer look at the rooms, gardens and guest spaces so you can book with confidence.</p>
                {content.googleTourUrl && (
                  <a href={content.googleTourUrl} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex rounded-md px-6 py-3 font-bold uppercase tracking-wide text-white" style={{ backgroundColor: template.accent }}>
                    Open virtual tour
                  </a>
                )}
              </div>
              <div className="overflow-hidden rounded-sm bg-white shadow-xl">
                {content.googleTourUrl ? (
                  <iframe title={`${content.brand} virtual tour`} src={content.googleTourUrl} className="h-[420px] w-full border-0" loading="lazy" />
                ) : (
                  second ? (
                    <ExpandablePhoto src={second} alt={`${content.brand} tour preview`} className="h-[420px] w-full object-cover" />
                  ) : (
                    <div className="flex h-[420px] items-center justify-center bg-[#f7f7f7] px-6 text-center text-[#777777]">
                      Add a virtual tour or additional photo to show this section.
                    </div>
                  )
                )}
              </div>
            </div>
          </section>

          <section id="map" className="bg-white py-20">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
              <div className="mb-8 text-center">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Map</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>{content.location}</h2>
              </div>
              <iframe
                title={`${content.brand} location map`}
                src={`https://www.google.com/maps?q=${encodeURIComponent(content.location)}&output=embed`}
                className="h-[420px] w-full rounded-sm border border-[#dddddd] shadow-sm"
                loading="lazy"
              />
              <div className="mt-6 text-center">
                <AttractionsNearbyPrompt content={content} className="border border-[#AA7942] bg-white text-[#AA7942]" />
              </div>
            </div>
          </section>

          <PublicGuidebookSection template={template} content={content} compact />
          <PublicCustomContentSections template={template} content={content} />

          <section id="host" className="py-20" style={{ backgroundColor: '#f4f0ea' }}>
            <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
              <article className="rounded-sm bg-white p-6 shadow-sm">
                <h3 className="text-2xl font-bold text-[#333333]" style={{ fontFamily: 'Georgia, serif' }}>Reviews</h3>
                <p className="mt-3 leading-7 text-[#5f5f5f]">{content.reviewCopy || (content.reviewUrl && content.reviewSource ? `Guest reviews are available on ${content.reviewSource}.` : 'Guest reviews are shown here once available.')}</p>
                {reviewSnippets.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {reviewSnippets.map((review, index) => (
                      <blockquote key={`${review.author || 'guest'}-${index}`} className="rounded-sm border border-[#dddddd] bg-[#f7f7f7] p-4">
                        <p className="text-sm leading-6 text-[#555555]">"{review.text}"</p>
                        <footer className="mt-2 text-xs font-bold uppercase tracking-wide text-[#777777]">
                          {[review.author || 'Guest', review.date, review.source].filter(Boolean).join(' · ')}
                        </footer>
                      </blockquote>
                    ))}
                  </div>
                )}
                {content.reviewUrl && <a href={content.reviewUrl} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex font-bold" style={{ color: template.accent }}>View reviews</a>}
              </article>
              <article className="rounded-sm bg-white p-6 shadow-sm">
                <h3 className="text-2xl font-bold text-[#333333]" style={{ fontFamily: 'Georgia, serif' }}>Contact</h3>
                <p className="mt-3 leading-7 text-[#5f5f5f]">{[content.contactEmail, content.contactPhone].filter(Boolean).join(' · ') || 'Contact details are available after enquiry.'}</p>
              </article>
              <article className="rounded-sm bg-white p-6 shadow-sm">
                <h3 className="text-2xl font-bold text-[#333333]" style={{ fontFamily: 'Georgia, serif' }}>Booking details</h3>
                <p className="mt-3 leading-7 text-[#5f5f5f]">
                  {content.basePrice ? `From $${Math.round(content.basePrice)} per night. ` : ''}
                  {content.cleaningFee ? `Cleaning fee $${Math.round(content.cleaningFee)}. ` : ''}
                  {content.minNights ? `${content.minNights} night minimum.` : ''}
                </p>
              </article>
            </div>
          </section>

          <section id="faq" className="bg-white py-20">
            <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
              <div className="mb-8 text-center">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Guest FAQ</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>Good to know before booking</h2>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                {faqs.slice(0, 6).map((faq) => (
                  <article key={faq.question} className="rounded-sm border border-[#dddddd] bg-[#f7f7f7] p-5">
                    <h3 className="font-bold text-[#333333]">{faq.question}</h3>
                    <p className="mt-2 leading-7 text-[#5f5f5f]">{faq.answer}</p>
                  </article>
                ))}
              </div>
            </div>
          </section>

          <section id="book" className="bg-white py-20">
            <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_28rem] lg:px-8">
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em]" style={{ color: template.accent }}>Book direct</p>
                <h2 className="text-3xl font-bold text-[#333333] md:text-4xl" style={{ fontFamily: 'Georgia, serif' }}>Plan your stay at {content.brand}</h2>
                <p className="mt-5 text-lg leading-8 text-[#5f5f5f]">Choose dates, confirm guests and see the total clearly before payment.</p>
              </div>
              <BookingStrip template={template} content={content} compact liveMode={liveMode} />
            </div>
          </section>
        </main>

        <footer id="host" className="bg-[#333333] px-5 py-12 text-white sm:px-8">
          <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-3">
            <div>
              {content.logoImage ? (
                <img src={content.logoImage} alt={content.brand} className="mb-4 h-16 w-auto brightness-0 invert" />
              ) : (
                <p className="text-2xl font-bold" style={{ fontFamily: 'Georgia, serif' }}>{content.brand}</p>
              )}
              <p className="text-white/70">Your perfect getaway awaits. Book directly for the best rates.</p>
            </div>
            <div>
              <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">About host</p>
              <p className="text-sm leading-7 text-white/70">Local host support is available before and during the stay.</p>
            </div>
            <div>
              <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Get in touch</p>
              <FooterContactDetails content={content} />
              <FooterHostLoginLink liveMode={liveMode} className="mt-4" />
            </div>
          </div>
          <FooterBottomBar content={content} liveMode={liveMode} />
        </footer>
      </div>
    </SitePreviewChrome>
  );
}

function ModernShowcaseSite({ template, content, embedded = false, liveMode = false }: { template: TemplateOption; content: PreviewContent; embedded?: boolean; liveMode?: boolean }) {
  const showcasePhotos = modernShowcasePhotos(content);
  const hero = showcasePhotos[0] || content.gallery[0];
  const photos = showcasePhotos.filter((photo) => imageKey(photo) !== imageKey(hero));
  const accent = template.accent;
  const dark = template.text;
  const cream = template.accentSoft;
  const amenityIcons = [Wifi, ChefHat, Car, Wind, Waves, Tv, Calendar, Users];
  const amenityLabels = content.amenities.length ? content.amenities : ['Wifi', 'Kitchen', 'Parking', 'Air conditioning', 'Heating', 'Washing machine', 'Dryer', 'BBQ'];
  const allPhotos = uniqueImages([hero, ...photos]);
  const locationPhoto = photos[4] || photos[3] || photos[0] || hero;

  return (
    <SitePreviewChrome template={template} content={content} embedded={embedded} liveMode={liveMode}>
      <div className="min-h-screen bg-white" style={{ ...bodyStyle(template), color: dark }}>
      <main>
        <section id="home" className="relative min-h-[650px] overflow-hidden">
          <ExpandableBackgroundPhoto src={hero} alt={`${content.brand} hero`} />
          <div className="pointer-events-none absolute inset-0 bg-black/60" />
          <div className="relative z-10 mx-auto flex min-h-[650px] max-w-7xl flex-col px-5 text-white sm:px-8">
            <header className="flex items-center justify-between py-7 text-sm font-black uppercase tracking-[0.18em]">
              <a href="#home" className="flex items-center gap-2">
                <Sparkles className="h-4 w-4" style={{ color: accent }} />
                <span>{content.brand}</span>
              </a>
              <nav className="hidden items-center gap-8 text-[11px] text-white/80 lg:flex">
                {[
                  ['Overview', '#overview'],
                  ['Stay', '#overview'],
                  ['Gallery', '#gallery'],
                  ['Amenities', '#amenities'],
                  ['Local guide', '#guidebook'],
                  ['Location', '#location'],
                ].map(([item, href]) => (
                  <a key={item} href={href} className="hover:text-white">{item}</a>
                ))}
              </nav>
              <a href="#book" className="rounded-md px-5 py-3 text-[11px] text-white shadow-sm" style={{ background: accent }}>
                Book now
              </a>
            </header>

            <div className="flex flex-1 flex-col justify-center pb-20">
              <p className="mb-5 text-xs font-black uppercase tracking-[0.35em] text-white/90">Welcome to the Winterless North</p>
              <h1 className="max-w-4xl text-6xl leading-[0.95] md:text-8xl" style={headingStyle(template)}>{content.headline}</h1>
              <p className="mt-6 max-w-2xl text-xl leading-9 text-white/90">{content.summary}</p>
              <div className="mt-8 flex flex-wrap gap-4">
                <a href="#book" className="rounded-md px-7 py-4 text-sm font-black uppercase tracking-[0.14em] text-white shadow-sm" style={{ background: accent }}>
                  Book your stay
                </a>
                <a href="#gallery" className="rounded-md border border-white/70 px-7 py-4 text-sm font-black uppercase tracking-[0.14em] text-white backdrop-blur hover:bg-white/10">
                  View gallery
                </a>
              </div>
            </div>
          </div>
        </section>

        <PreviewBookingBar template={template} content={content} liveMode={liveMode} />

        <section id="overview" className="mx-auto grid max-w-7xl gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>About {content.brand}</p>
            <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Relax, unwind and feel at home</h2>
            <div className="mt-6 max-w-xl space-y-4 leading-8 text-[#555555]">
              {descriptionParagraphs(content).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
            </div>
            <ul className="mt-6 space-y-2 text-sm font-semibold text-[#394239]">
              {['Self-contained cottage', 'Peaceful garden setting', 'Great base to explore', 'Book direct for the best rates'].map((item) => (
                <li key={item} className="flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} />{item}</li>
              ))}
            </ul>
            <a href="#gallery" className="mt-7 inline-flex rounded-md border px-6 py-3 text-xs font-black uppercase tracking-[0.14em]" style={{ borderColor: accent, color: accent }}>
              Explore the cottage
            </a>
          </div>
          {photos[0] && <ExpandablePhoto src={photos[0]} alt={`${content.brand} interior`} className="h-[360px] w-full rounded-xl object-cover shadow-xl" />}
        </section>

        <section id="amenities" className="py-14" style={{ background: cream }}>
          <div className="mx-auto max-w-7xl px-5 text-center sm:px-8">
            <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Amenities</p>
            <h2 className="text-3xl" style={headingStyle(template)}>Everything you need for a comfortable stay</h2>
            <ExpandableAmenityIcons amenities={amenityLabels} icons={amenityIcons} accent={accent} />
          </div>
        </section>

        <section id="gallery" className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[0.42fr_0.58fr] lg:items-center">
          <div>
            <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Gallery</p>
            <h2 className="text-4xl leading-tight" style={headingStyle(template)}>Explore the cottage</h2>
            <p className="mt-4 leading-7 text-[#555555]">Take a closer look at the spaces and surrounds.</p>
          </div>
          <ExpandablePhotoGrid photos={allPhotos} content={content} accent={accent} initialCount={4} />
        </section>

        <section id="location" className="grid bg-white lg:grid-cols-2">
          {locationPhoto && <ExpandablePhoto src={locationPhoto} alt={`${content.brand} local area`} className="h-[420px] w-full object-cover lg:h-full" />}
          <div className="flex flex-col justify-center px-8 py-16 lg:px-20">
            <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Location</p>
            <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Close to nature and local attractions</h2>
            <p className="mt-5 max-w-lg leading-8 text-[#555555]">{content.location || 'Beaches, walks, landmarks and local favourites are just a short drive away.'}</p>
            <ul className="mt-6 space-y-2 text-sm font-semibold text-[#394239]">
              {['Nearby beaches and walks', 'Local cafés and shops', 'Easy arrival details'].map((item) => (
                <li key={item} className="flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} />{item}</li>
              ))}
            </ul>
            <a href={nearbyPlacesUrl(content)} target="_blank" rel="noopener noreferrer" className="mt-7 inline-flex w-fit items-center gap-2 rounded-md border px-6 py-3 text-xs font-black uppercase tracking-[0.14em]" style={{ borderColor: accent, color: accent }}>
              See what's nearby <ExternalLink className="h-4 w-4" />
            </a>
            <AttractionsNearbyPrompt content={content} className="mt-3 border bg-white" style={{ borderColor: accent, color: accent }} />
          </div>
        </section>

        <PublicGuidebookSection template={template} content={content} />
        <PublicCustomContentSections template={template} content={content} />
        <FullWidthMapSection template={template} content={content} />
        <ReviewsHostSection template={template} content={content} />

        <footer className="px-5 py-12 text-white sm:px-8" style={{ background: dark }}>
          <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-3">
            <div>
              <p className="text-xl font-black uppercase tracking-[0.14em]">{content.brand}</p>
              <p className="mt-4 max-w-sm text-sm leading-7 text-white/70">{content.summary}</p>
              <p className="mt-5 text-sm font-black uppercase tracking-[0.16em] text-white">About host</p>
              <p className="mt-2 text-sm leading-7 text-white/70">Local host support is available before and during the stay.</p>
            </div>
            <div>
              <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Quick links</p>
              <div className="grid gap-2 text-sm text-white/70">
                {[
                  ['Overview', '#overview'],
                  ['Stay', '#overview'],
                  ['Gallery', '#gallery'],
                  ['Amenities', '#amenities'],
                  ['Local guide', '#guidebook'],
                  ['Location', '#location'],
                ].map(([item, href]) => (
                  <a key={item} href={href} className="hover:text-white">{item}</a>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Get in touch</p>
              <FooterContactDetails content={content} />
              <FooterHostLoginLink liveMode={liveMode} className="mt-4" />
            </div>
          </div>
          <FooterBottomBar content={content} liveMode={liveMode} />
        </footer>
      </main>
      </div>
    </SitePreviewChrome>
  );
}

function ConversionSite({ template, content, embedded = false, liveMode = false }: { template: TemplateOption; content: PreviewContent; embedded?: boolean; liveMode?: boolean }) {
  const conversionPhotos = modernShowcasePhotos(content);
  const hero = conversionPhotos[0] || content.gallery[0];
  const photos = conversionPhotos.filter((photo) => imageKey(photo) !== imageKey(hero));
  const accent = template.accent;
  const dark = template.text;
  const cream = template.accentSoft;
  const amenityLabels = content.amenities.length ? content.amenities : ['Wifi', 'Kitchen', 'Parking', 'Air conditioning', 'Heating', 'Washing machine', 'Dryer', 'BBQ'];
  const amenityIcons = [Wifi, Calendar, Bed, Sparkles, Waves, Tv, ChefHat, Car];
  const allPhotos = uniqueImages([hero, ...photos]);
  const locationPhoto = photos[4] || photos[3] || photos[0] || hero;

  return (
    <SitePreviewChrome template={template} content={content} embedded={embedded} liveMode={liveMode}>
      <div className="min-h-screen bg-white" style={{ ...bodyStyle(template), color: dark }}>
        <main>
          <section id="home" className="relative min-h-[610px] overflow-hidden">
            <ExpandableBackgroundPhoto src={hero} alt={`${content.brand} hero`} />
            <div className="pointer-events-none absolute inset-0 bg-black/58" />
            <div className="relative z-10 mx-auto flex min-h-[610px] max-w-7xl flex-col px-5 text-white sm:px-8">
              <header className="flex items-center justify-between py-7 text-sm font-black uppercase tracking-[0.18em]">
                <a href="#home" className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" style={{ color: accent }} />
                  <span>{content.brand}</span>
                </a>
                <nav className="hidden items-center gap-7 text-[11px] text-white/80 lg:flex">
                  {[
                    ['Overview', '#overview'],
                    ['Stay', '#overview'],
                    ['Gallery', '#gallery'],
                    ['Amenities', '#amenities'],
                    ['Local guide', '#guidebook'],
                    ['Location', '#location'],
                  ].map(([item, href]) => (
                    <a key={item} href={href} className="hover:text-white">{item}</a>
                  ))}
                </nav>
                <a href="#book" className="rounded-md px-5 py-3 text-[11px] text-white shadow-sm" style={{ background: accent }}>
                  Book now
                </a>
              </header>

              <div className="flex flex-1 flex-col justify-center pb-24">
                <h1 className="max-w-3xl text-5xl leading-tight md:text-7xl" style={headingStyle(template)}>A quiet escape in the Winterless North</h1>
                <p className="mt-5 max-w-2xl text-lg leading-8 text-white/90">{content.summary}</p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <a href="#book" className="rounded-md px-6 py-4 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm" style={{ background: accent }}>
                    Book your stay
                  </a>
                  <a href="#gallery" className="rounded-md border border-white/70 px-6 py-4 text-xs font-black uppercase tracking-[0.14em] text-white backdrop-blur hover:bg-white/10">
                    View gallery
                  </a>
                </div>
              </div>
            </div>
          </section>

          <PreviewBookingBar template={template} content={content} actionBackground={dark} liveMode={liveMode} />

          <section id="overview" className="mx-auto grid max-w-7xl gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <div>
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>About {content.brand}</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>A country cottage beside the hosts' home</h2>
              <div className="mt-6 max-w-xl space-y-4 leading-8 text-[#555555]">
                {descriptionParagraphs(content).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              </div>
              <ul className="mt-6 space-y-2 text-sm font-semibold text-[#394239]">
                {['Self-contained cottage', 'Peaceful garden setting', 'Great base to explore', 'Book direct for the best rates'].map((item) => (
                  <li key={item} className="flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} />{item}</li>
                ))}
              </ul>
              <a href="#gallery" className="mt-7 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em]" style={{ color: accent }}>
                Learn more about your stay <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            {photos[0] && <ExpandablePhoto src={photos[0]} alt={`${content.brand} bedroom`} className="h-[360px] w-full rounded-xl object-cover shadow-xl" />}
          </section>

          <section id="amenities" className="py-16 text-white" style={{ background: dark }}>
            <div className="mx-auto max-w-7xl px-5 text-center sm:px-8">
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Comforts included</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Everything you need for a relaxing stay</h2>
              <ExpandableAmenityIcons amenities={amenityLabels} icons={amenityIcons} accent={accent} dark />
            </div>
          </section>

          <section id="gallery" className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[0.36fr_0.64fr] lg:items-center">
            <div>
              <p className="mb-3 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Explore the cottage</p>
              <h2 className="text-4xl leading-tight" style={headingStyle(template)}>Take a look around</h2>
              <p className="mt-4 leading-7 text-[#555555]">Explore the rooms, gardens and guest spaces before you arrive.</p>
            </div>
            <ExpandablePhotoGrid photos={allPhotos} content={content} accent={accent} initialCount={4} />
          </section>

          <section id="location" className="grid bg-white lg:grid-cols-[0.58fr_0.42fr]">
            {locationPhoto && <ExpandablePhoto src={locationPhoto} alt={`${content.brand} local area`} className="h-[420px] w-full object-cover lg:h-full" />}
            <div className="flex flex-col justify-center px-8 py-20 lg:px-20" style={{ background: cream }}>
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Location</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Close to nature and local attractions</h2>
              <p className="mt-5 max-w-lg leading-8 text-[#555555]">{content.location || 'Beaches, walks, landmarks and local favourites are just a short drive away.'}</p>
              <ul className="mt-6 space-y-2 text-sm font-semibold text-[#394239]">
                {['Nearby beaches and walks', 'Coastal walks and lookouts', 'Local cafés and shops'].map((item) => (
                  <li key={item} className="flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} />{item}</li>
                ))}
              </ul>
              <a href={nearbyPlacesUrl(content)} target="_blank" rel="noopener noreferrer" className="mt-7 inline-flex w-fit items-center gap-2 rounded-md px-6 py-3 text-xs font-black uppercase tracking-[0.14em] text-white" style={{ background: dark }}>
                See what's nearby <ExternalLink className="h-4 w-4" />
              </a>
              <AttractionsNearbyPrompt content={content} className="mt-3 text-white" style={{ background: accent }} />
            </div>
          </section>

          <PublicGuidebookSection template={template} content={content} />
          <PublicCustomContentSections template={template} content={content} />
          <FullWidthMapSection template={template} content={content} />
          <ReviewsHostSection template={template} content={content} />

          <footer className="px-5 py-12 text-white sm:px-8" style={{ background: dark }}>
            <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-[1fr_0.8fr_1fr_0.9fr]">
              <div>
                <p className="text-xl font-black uppercase tracking-[0.14em]">{content.brand}</p>
                <p className="mt-4 max-w-sm text-sm leading-7 text-white/70">{content.summary}</p>
                <p className="mt-5 text-sm font-black uppercase tracking-[0.16em] text-white">About host</p>
                <p className="mt-2 text-sm leading-7 text-white/70">Local host support is available before and during the stay.</p>
                <div className="mt-5 flex gap-3 text-white/70">
                  <Home className="h-5 w-5" />
                  <Bed className="h-5 w-5" />
                  <MapPin className="h-5 w-5" />
                </div>
              </div>
              <div>
                <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Quick links</p>
                <div className="grid gap-2 text-sm text-white/70">
                  {[
                    ['Overview', '#overview'],
                    ['Stay', '#overview'],
                    ['Gallery', '#gallery'],
                    ['Amenities', '#amenities'],
                    ['Local guide', '#guidebook'],
                    ['Location', '#location'],
                  ].map(([item, href]) => (
                    <a key={item} href={href} className="hover:text-white">{item}</a>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Get in touch</p>
                <FooterContactDetails content={content} />
                <FooterHostLoginLink liveMode={liveMode} className="mt-4" />
                <p className="mt-3 text-sm text-white/70">We're here to help make your stay perfect.</p>
              </div>
              <div className="rounded-md border border-white/20 p-5">
                <h2 className="text-2xl leading-tight" style={headingStyle(template)}>Ready to relax?</h2>
                <p className="mt-2 text-sm text-white/70">Choose your dates and book direct for the best rates.</p>
                <a href="#book" className="mt-5 inline-flex rounded-md px-5 py-3 text-xs font-black uppercase tracking-[0.14em] text-white" style={{ background: accent }}>
                  Check availability
                </a>
              </div>
            </div>
            <FooterBottomBar content={content} liveMode={liveMode} />
          </footer>
        </main>
      </div>
    </SitePreviewChrome>
  );
}

function EditorialSite({ template, content, embedded = false, liveMode = false }: { template: TemplateOption; content: PreviewContent; embedded?: boolean; liveMode?: boolean }) {
  const editorialPhotos = modernShowcasePhotos(content);
  const hero = editorialPhotos[0] || content.gallery[0];
  const photos = editorialPhotos.filter((photo) => imageKey(photo) !== imageKey(hero));
  const accent = template.accent;
  const dark = template.text;
  const cream = template.accentSoft;
  const amenityLabels = content.amenities.length ? content.amenities : ['Wifi', 'Kitchen', 'Parking', 'Air conditioning', 'Heating', 'Washing machine', 'Dryer', 'BBQ'];
  const amenityIcons = [Wifi, ChefHat, Car, Wind, Waves, Tv, Calendar, Home];
  const allPhotos = uniqueImages([hero, ...photos]);
  const locationPhoto = photos[4] || photos[3] || photos[0] || hero;

  return (
    <SitePreviewChrome template={template} content={content} embedded={embedded} liveMode={liveMode}>
      <div className="min-h-screen bg-white" style={{ ...bodyStyle(template), color: dark }}>
        <main>
          <section id="home" className="relative min-h-[620px] overflow-hidden">
            <ExpandableBackgroundPhoto src={hero} alt={`${content.brand} hero`} />
            <div className="pointer-events-none absolute inset-0 bg-black/55" />
            <div className="relative z-10 mx-auto flex min-h-[620px] max-w-7xl flex-col px-5 text-white sm:px-8">
              <header className="flex items-center justify-between py-7 text-sm font-black uppercase tracking-[0.18em]">
                <a href="#home" className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" style={{ color: accent }} />
                  <span>{content.brand}</span>
                </a>
                <nav className="hidden items-center gap-7 text-[11px] text-white/80 lg:flex">
                  {[
                    ['Overview', '#overview'],
                    ['Stay', '#overview'],
                    ['Gallery', '#gallery'],
                    ['Amenities', '#amenities'],
                    ['Local guide', '#guidebook'],
                    ['Location', '#location'],
                  ].map(([item, href]) => (
                    <a key={item} href={href} className="hover:text-white">{item}</a>
                  ))}
                </nav>
                <a href="#book" className="rounded-md px-5 py-3 text-[11px] text-white shadow-sm" style={{ background: accent }}>
                  Book your stay
                </a>
              </header>

              <div className="flex flex-1 flex-col justify-center pb-24">
                <h1 className="max-w-3xl text-5xl leading-tight md:text-7xl" style={headingStyle(template)}>A quiet escape in the Winterless North</h1>
                <p className="mt-6 max-w-2xl text-lg leading-8 text-white/90">{content.summary}</p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <a href="#book" className="rounded-md px-6 py-4 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm" style={{ background: accent }}>
                    Book your stay
                  </a>
                  <a href="#gallery" className="rounded-md border border-white/70 px-6 py-4 text-xs font-black uppercase tracking-[0.14em] text-white backdrop-blur hover:bg-white/10">
                    View gallery
                  </a>
                </div>
              </div>
            </div>
          </section>

          <PreviewBookingBar template={template} content={content} liveMode={liveMode} />

          <section id="overview" className="grid bg-white lg:grid-cols-2">
            <div className="flex flex-col justify-center px-8 py-20 lg:px-20">
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>About {content.brand}</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>A country cottage beside the hosts' home</h2>
              <div className="mt-6 max-w-xl space-y-4 leading-8 text-[#555555]">
                {descriptionParagraphs(content).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              </div>
              <a href="#gallery" className="mt-7 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em]" style={{ color: dark }}>
                Learn more about your stay <ArrowRight className="h-4 w-4" />
              </a>
            </div>
            {photos[0] && <ExpandablePhoto src={photos[0]} alt={`${content.brand} bedroom`} className="h-[420px] w-full object-cover lg:h-full" />}
          </section>

          <section className="grid bg-white lg:grid-cols-2">
            {photos[1] && <ExpandablePhoto src={photos[1]} alt={`${content.brand} kitchen`} className="h-[420px] w-full object-cover lg:h-full" />}
            <div id="amenities" className="flex flex-col justify-center px-8 py-20 lg:px-20">
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Comforts included</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Everything you need for a relaxing stay</h2>
              <ExpandableAmenityIcons amenities={amenityLabels} icons={amenityIcons} accent={accent} />
            </div>
          </section>

          <section id="gallery" className="grid bg-white lg:grid-cols-[0.45fr_0.55fr]">
            <div className="flex flex-col justify-center px-8 py-20 lg:px-20">
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Explore the cottage</p>
              <h2 className="text-4xl leading-tight" style={headingStyle(template)}>Take a look around</h2>
              <p className="mt-5 max-w-md leading-7 text-[#555555]">Explore the rooms, gardens and guest spaces before you arrive.</p>
            </div>
            <div className="p-5 lg:p-8">
              <ExpandablePhotoGrid photos={allPhotos} content={content} accent={accent} initialCount={4} />
            </div>
          </section>

          <section id="location" className="grid bg-white lg:grid-cols-[0.58fr_0.42fr]">
            {locationPhoto && <ExpandablePhoto src={locationPhoto} alt={`${content.brand} local area`} className="h-[420px] w-full object-cover lg:h-full" />}
            <div className="flex flex-col justify-center px-8 py-20 lg:px-20">
              <p className="mb-4 text-xs font-black uppercase tracking-[0.28em]" style={{ color: accent }}>Location</p>
              <h2 className="text-4xl leading-tight md:text-5xl" style={headingStyle(template)}>Close to nature and local attractions</h2>
              <p className="mt-5 max-w-lg leading-8 text-[#555555]">{content.location || 'Beaches, walks, landmarks and local favourites are just a short drive away.'}</p>
              <ul className="mt-6 space-y-2 text-sm font-semibold text-[#394239]">
                {['Beaches, walks and lookouts', 'Local cafés and shops', 'Easy arrival details'].map((item) => (
                  <li key={item} className="flex items-center gap-2"><Check className="h-4 w-4" style={{ color: accent }} />{item}</li>
                ))}
              </ul>
              <a href={nearbyPlacesUrl(content)} target="_blank" rel="noopener noreferrer" className="mt-7 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em]" style={{ color: dark }}>
                See what's nearby <ExternalLink className="h-4 w-4" />
              </a>
              <AttractionsNearbyPrompt content={content} className="mt-3 border bg-white" style={{ borderColor: dark, color: dark }} />
            </div>
          </section>

          <PublicGuidebookSection template={template} content={content} />
          <PublicCustomContentSections template={template} content={content} />
          <FullWidthMapSection template={template} content={content} />
          <ReviewsHostSection template={template} content={content} />

          <section className="px-5 py-8 sm:px-8" style={{ background: cream }}>
            <div className="mx-auto flex max-w-7xl flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <Calendar className="h-9 w-9" style={{ color: accent }} />
                <div>
                  <h2 className="text-3xl leading-tight" style={headingStyle(template)}>Ready to relax?</h2>
                  <p className="text-sm text-[#555555]">Choose your dates and book direct for the best rates.</p>
                </div>
              </div>
              <a href="#book" className="rounded-md px-7 py-4 text-xs font-black uppercase tracking-[0.14em] text-white shadow-sm" style={{ background: accent }}>
                Check availability
              </a>
            </div>
          </section>

          <footer className="px-5 py-12 text-white sm:px-8" style={{ background: '#222222' }}>
            <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-[1fr_0.8fr_1fr_0.8fr]">
              <div>
                <p className="text-xl font-black uppercase tracking-[0.14em]">{content.brand}</p>
                <p className="mt-4 max-w-sm text-sm leading-7 text-white/70">{content.summary}</p>
                <p className="mt-5 text-sm font-black uppercase tracking-[0.16em] text-white">About host</p>
                <p className="mt-2 text-sm leading-7 text-white/70">Local host support is available before and during the stay.</p>
                <div className="mt-5 flex gap-3 text-white/70">
                  <Home className="h-5 w-5" />
                  <Bed className="h-5 w-5" />
                  <MapPin className="h-5 w-5" />
                </div>
              </div>
              <div>
                <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Quick links</p>
                <div className="grid gap-2 text-sm text-white/70">
                  {[
                    ['Overview', '#overview'],
                    ['Stay', '#overview'],
                    ['Gallery', '#gallery'],
                    ['Amenities', '#amenities'],
                    ['Local guide', '#guidebook'],
                    ['Location', '#location'],
                  ].map(([item, href]) => (
                    <a key={item} href={href} className="hover:text-white">{item}</a>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-4 text-sm font-black uppercase tracking-[0.16em]">Get in touch</p>
                <FooterContactDetails content={content} />
                <FooterHostLoginLink liveMode={liveMode} className="mt-4" />
                <p className="mt-3 text-sm text-white/70">We're here to help make your stay perfect.</p>
              </div>
              <div className="flex items-center justify-start md:justify-end">
                <div className="flex h-32 w-32 items-center justify-center rounded-full border border-white/20 text-center text-lg uppercase tracking-[0.18em] text-white/80" style={headingStyle(template)}>
                  {content.brand.split(' ').slice(0, 2).join(' ')}
                </div>
              </div>
            </div>
            <FooterBottomBar content={content} liveMode={liveMode} />
          </footer>
        </main>
      </div>
    </SitePreviewChrome>
  );
}

function PropertySections({
  template,
  content,
  galleryFirst = false,
  compact = false,
  editorial = false,
}: {
  template: TemplateOption;
  content: PreviewContent;
  galleryFirst?: boolean;
  compact?: boolean;
  editorial?: boolean;
}) {
  const faqs = buildGuestFaqs({
    propertyName: content.brand,
    city: content.location.split(',')[0],
    country: content.location.split(',').slice(1).join(',').trim(),
    basePrice: content.basePrice,
    cleaningFee: content.cleaningFee,
    taxRate: content.taxRate,
    minNights: content.minNights,
    maxGuests: content.maxGuests,
    bedrooms: content.bedrooms,
    bathrooms: content.bathrooms,
    amenities: content.amenities,
    checkInTime: content.checkInTime,
    checkOutTime: content.checkOutTime,
    contactEmail: content.contactEmail,
    contactPhone: content.contactPhone,
  });
  const gallery = <GalleryShowcase template={template} content={content} mode={galleryFirst ? 'carousel' : 'grid'} />;
  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(content.location)}&output=embed`;

  return (
    <>
      {galleryFirst && gallery}
      <PropertyStorySection template={template} content={content} compact={compact} editorial={editorial} />
      {!galleryFirst && gallery}
      <AmenitiesShowcase template={template} content={content} />
      <section id="location" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-[1fr_28rem]">
          <div>
            <p className="mb-3 text-sm uppercase" style={eyebrowStyle(template)}>Location</p>
            <h2 className="text-4xl text-[#2F2F2F]" style={headingStyle(template)}>{content.location}</h2>
            <p className="mt-4 text-lg leading-8 text-[#5F5F5F]">Guests can review the location, nearby highlights, and booking details before they commit.</p>
            <iframe
              title={`${content.brand} location map`}
              src={mapSrc}
              className="mt-6 h-80 w-full rounded-3xl border border-[#E5E5E5] shadow-sm"
              loading="lazy"
            />
          </div>
          <BookingStrip template={template} content={content} compact />
        </div>
      </section>
      <GuestInformationShowcase template={template} content={content} />
      <section id="faq" className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="rounded-3xl border border-[#E5E5E5] bg-white p-6 shadow-sm sm:p-8">
          <p className="mb-3 text-sm uppercase" style={eyebrowStyle(template)}>Guest FAQ</p>
          <h2 className="text-3xl text-[#2F2F2F]" style={headingStyle(template)}>Answers before they book</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {faqs.slice(0, 4).map((faq) => (
              <article key={faq.question} className="rounded-2xl border border-[#E5E5E5] bg-[#FAFAF8] p-5">
                <h3 className="font-black text-[#2F2F2F]">{faq.question}</h3>
                <p className="mt-2 leading-7 text-[#5F5F5F]">{faq.answer}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <footer className="mt-10 border-t border-[#E5E5E5] bg-[#222222] px-5 py-10 text-white sm:px-8">
        <div className="mx-auto max-w-7xl">
          <div>
            <p className="text-xl" style={headingStyle(template)}>{content.brand}</p>
            <p className="mt-2 text-white/70">Direct bookings with clear prices and secure checkout.</p>
          </div>
        </div>
        <FooterBottomBar content={content} />
      </footer>
    </>
  );
}

function hasActiveImport(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return Boolean(
      sessionStorage.getItem('staydirect_import_url') ||
      localStorage.getItem('staydirect_import_url'),
    );
  } catch {
    return false;
  }
}

export function TemplatePreviewPage() {
  const { templateId } = useParams();
  const activeTemplateId = templateId || templates[0].id;
  const [imported, setImported] = useState<ImportedPreviewData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      const params = new URLSearchParams(window.location.search);
      const previewId = params.get('preview') || readPreviewId() || '';

      // 1. Load from Supabase by id (works across tabs and survives refresh).
      if (previewId) {
        const row = await loadPreviewSession(previewId);
        if (!cancelled && row?.scraped_data) {
          rememberPreviewId(row.id);
          const data = await enrichImportedPreviewData(previewDataForTemplate(row, activeTemplateId) as unknown as ImportedPreviewData);
          persistPreviewData(data);
          cacheImportedProperty(data);
          setImported(data);
          setLoading(false);
          return;
        }
      }

      // 2. Fall back to whatever was persisted locally.
      const stored = readStoredPreview();
      if (!cancelled && stored && !isLegacyExample(stored)) {
        const data = await enrichImportedPreviewData(stored);
        if (cancelled) return;
        setImported(data);
        setLoading(false);
        return;
      }

      // 3. Last resort: re-scrape the active import URL.
      const targetUrl =
        sessionStorage.getItem('staydirect_import_url') ||
        localStorage.getItem('staydirect_import_url');
      if (targetUrl) {
        try {
          const response = await fetch(apiUrl(`/api/scrape?url=${encodeURIComponent(targetUrl)}`));
          const data = await response.json();
          if (!cancelled && response.ok && !data.error && !isLegacyExample(data)) {
            persistPreviewData(data);
            cacheImportedProperty(data);
            const newId = await savePreviewSession(targetUrl, data as unknown as Record<string, unknown>);
            if (newId && !cancelled) rememberPreviewId(newId);
            setImported(data);
          }
        } catch {
          /* leave imported as null so the empty state renders */
        }
      }

      if (!cancelled) setLoading(false);
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const colours = readStoredColours();
  const template = templateWithColours(templates.find((item) => item.id === activeTemplateId) || templates[0], colours);
  const content = useMemo(() => contentFromImport(imported), [imported]);

  useEffect(() => {
    rememberColours(colours);
    rememberTemplate(template, content);
  }, [colours, content, template]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F7F7F7]">
        <p className="text-[#717171]">Loading your preview…</p>
      </div>
    );
  }

  if (!imported) {
    return <TemplatePreviewEmptyState />;
  }

  return <FullTemplateSite template={template} content={content} />;
}

function TemplatePreviewEmptyState() {
  return (
    <div className="min-h-screen bg-[#F7F7F7] px-4 py-20">
      <div className="mx-auto max-w-2xl rounded-3xl border border-[#EBEBEB] bg-white p-10 text-center shadow-sm">
        <h1 className="text-2xl font-bold text-[#222]">No preview available yet</h1>
        <p className="mt-4 text-[#717171]">
          Go back to StayDirect, paste your listing or website URL, and generate a preview first.
          The four layout previews use the imported content from that URL.
        </p>
        <Link
          to="/"
          className="mt-8 inline-flex items-center justify-center rounded-xl bg-[#D01744] px-6 py-3 font-bold text-white shadow-sm hover:bg-[#B01438]"
        >
          Back to StayDirect
        </Link>
      </div>
    </div>
  );
}

export default function WebsiteOptionsPage() {
  const navigate = useNavigate();
  const [selectedId, setSelectedId] = useState(() => getStoredTemplateId() || templates[0].id);
  const [colours, setColours] = useState<ColourSelection>(() => readStoredColours());
  const [imported, setImported] = useState<ImportedPreviewData | null>(() => readStoredPreview());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadContent() {
      const params = new URLSearchParams(window.location.search);
      const queryPreviewId = params.get('preview') || '';
      const previewId = queryPreviewId || readPreviewId() || '';

      // 1. Primary path: load URL + scraped data straight from Supabase by id.
      if (previewId) {
        setLoading(true);
        const row = await loadPreviewSession(previewId);
        if (!cancelled && row?.scraped_data) {
          rememberPreviewId(row.id);
          const data = await enrichImportedPreviewData(previewDataForTemplate(row, selectedId) as unknown as ImportedPreviewData);
          if (cancelled) return;
          if (data.sourceUrl) {
            sessionStorage.setItem('staydirect_import_url', data.sourceUrl);
            localStorage.setItem('staydirect_import_url', data.sourceUrl);
          }
          persistPreviewData(data);
          cacheImportedProperty(data);
          setImported(data);
          setLoading(false);
          return;
        }
        if (!cancelled) setLoading(false);
      }

      // 2. Legacy/fallback path: read whatever was last persisted locally.
      const stored = readStoredPreview();
      if (stored && !isLegacyExample(stored) && uniqueImages(stored.images).length > 0) {
        const data = await enrichImportedPreviewData(stored);
        if (cancelled) return;
        setImported(data);
        return;
      }

      // 3. Final fallback: re-scrape the active import URL. Never inject mock.
      const targetUrl = normaliseUrl(
        params.get('url') || sessionStorage.getItem('staydirect_import_url'),
      );
      if (targetUrl) {
        setLoading(true);
        try {
          const response = await fetch(apiUrl(`/api/scrape?url=${encodeURIComponent(targetUrl)}`));
          const data = await response.json();
          if (!cancelled && response.ok && !data.error && !isLegacyExample(data)) {
            sessionStorage.setItem('staydirect_import_url', targetUrl);
            localStorage.setItem('staydirect_import_url', targetUrl);
            persistPreviewData(data);
            cacheImportedProperty(data);
            // Persist this re-scrape so subsequent loads find it by id too.
            const newId = await savePreviewSession(targetUrl, data as unknown as Record<string, unknown>);
            if (newId && !cancelled) rememberPreviewId(newId);
            setImported(data);
            return;
          }
        } catch {
          /* fall through to empty state */
        } finally {
          if (!cancelled) setLoading(false);
        }
      }

      if (!cancelled) setImported((prev) => prev ?? null);
    }

    loadContent();

    return () => {
      cancelled = true;
    };
  }, []);

  const content = useMemo(() => contentFromImport(imported), [imported]);
  const selectedBase = templates.find((template) => template.id === selectedId) || templates[0];
  const selected = templateWithColours(selectedBase, colours);
  const previewIdForLinks = (() => {
    if (typeof window === 'undefined') return '';
    const params = new URLSearchParams(window.location.search);
    return params.get('preview') || readPreviewId() || '';
  })();
  const previewParams = [previewIdForLinks ? `preview=${encodeURIComponent(previewIdForLinks)}` : '', colourQuery(colours)].filter(Boolean).join('&');
  const previewQuery = previewParams ? `?${previewParams}` : '';
  const selectedPreviewHref = `/website-options/preview/${selected.id}${previewQuery}`;
  const templatePreviewHref = (id: string) =>
    `/website-options/preview/${id}${previewQuery}`;
  const originalWebsiteHref = normaliseUrl(content.sourceUrl || imported?.sourceUrl || readActiveImportUrl()) || templatePreviewHref(templates[0].id);

  function chooseTemplate(template: TemplateOption) {
    setSelectedId(template.id);
    const themedTemplate = templateWithColours(template, colours);
    rememberColours(colours);
    rememberTemplate(themedTemplate, content);
  }

  function applyColourTheme(theme: typeof colourThemeOptions[number]) {
    const nextColours = {
      themeId: theme.id,
      primaryColor: theme.colors[0],
      secondaryColor: theme.colors[1],
      accentColor: theme.colors[2],
    };
    setColours(nextColours);
    rememberColours(nextColours);
    rememberTemplate(templateWithColours(selectedBase, nextColours), content);
  }

  function updateColour(key: keyof Omit<ColourSelection, 'themeId'>, value: string) {
    const nextColours = { ...colours, themeId: 'custom-colour', [key]: value };
    setColours(nextColours);
    rememberColours(nextColours);
    rememberTemplate(templateWithColours(selectedBase, nextColours), content);
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#484848]">
      <MarketingNav />

      <section className="bg-[#FF5A5F] px-4 py-16 text-white sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/16 px-4 py-2 text-sm font-bold">
              <Sparkles className="h-4 w-4" />
              Original website plus three redesign previews
            </div>
            <h1 className="text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
              Preview four complete looks for your website.
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-white/86">
              The first option recreates the original website, then the next three options use the same photos, copy, contact details, location, amenities and booking information in different clean layouts.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href="#options" className="inline-flex items-center rounded-2xl bg-white px-6 py-4 font-bold text-[#D01744] shadow-lg">
                View the four previews
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
              <a href={originalWebsiteHref} target="_blank" rel="noopener noreferrer" className="inline-flex items-center rounded-2xl border border-white/70 px-6 py-4 font-bold text-white">
                View original website
                <ExternalLink className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="rounded-[28px] bg-white/18 p-3 shadow-2xl">
            <MiniPreview template={selected} content={content} />
          </div>
        </div>
      </section>

      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-4 sm:grid-cols-3">
          {[
            { icon: Smartphone, title: 'One page by default', detail: 'Anchored sections keep mobile browsing quick and easy.' },
            { icon: Edit3, title: 'Everything editable', detail: 'Owners can add, update, hide, reorder or delete sections.' },
            { icon: Search, title: 'SEO built in', detail: 'Titles, descriptions, headings, image alt text and local details stay editable.' },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.title} className="rounded-3xl border border-[#EBEBEB] bg-white p-6 shadow-sm">
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#FF5A5F] text-white">
                  <Icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold">{item.title}</h3>
                <p className="mt-2 leading-7 text-[#717171]">{item.detail}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section id="options" className="px-4 pb-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 grid gap-6 lg:grid-cols-[0.65fr_1fr]">
            <div>
              <p className="mb-3 text-sm font-bold uppercase tracking-[0.35em] text-[#00A699]">Preview styles</p>
              <h2 className="text-4xl font-bold leading-tight sm:text-5xl">Original plus three redesigned options</h2>
            </div>
            <p className="max-w-3xl text-lg leading-8 text-[#717171]">
              Preview the same property content across four layouts. The selected design is saved for signup and the dashboard so your chosen style does not reset.
            </p>
          </div>

          <div className="mb-8 rounded-[28px] border border-[#EBEBEB] bg-white p-5 shadow-sm">
            <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-[0.28em] text-[#00A699]">
                  <Palette className="h-4 w-4" />
                  Colour palette
                </p>
                <h3 className="text-2xl font-bold text-[#484848]">See every layout in different colours</h3>
                <p className="mt-1 text-sm leading-6 text-[#717171]">
                  Choose a palette or fine tune the colours. The cards and full previews below update to match.
                </p>
              </div>
              <button
                type="button"
                onClick={() => applyColourTheme(colourThemeOptions[0])}
                className="text-sm font-semibold text-[#717171] hover:text-[#FF5A5F]"
              >
                Reset to Modern Showcase
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-4 lg:grid-cols-7">
              {colourThemeOptions.map((theme) => {
                const active =
                  colours.primaryColor.toLowerCase() === theme.colors[0].toLowerCase() &&
                  colours.secondaryColor.toLowerCase() === theme.colors[1].toLowerCase() &&
                  colours.accentColor.toLowerCase() === theme.colors[2].toLowerCase();
                return (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => applyColourTheme(theme)}
                    className={`rounded-2xl border-2 bg-white p-3 text-left transition-all ${active ? 'border-[#4F7CFF] bg-[#EFF6FF] shadow-md' : 'border-[#E2E8F0] hover:border-[#94A3B8]'}`}
                  >
                    <div className="flex gap-1.5">
                      {theme.colors.map((color) => (
                        <span key={color} className="h-7 w-7 rounded-full border border-[#E2E8F0]" style={{ background: color }} />
                      ))}
                    </div>
                    <p className="mt-3 text-sm font-bold text-[#334155]">{theme.name}</p>
                    <p className="text-xs text-[#94A3B8]">{theme.font}</p>
                  </button>
                );
              })}
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-3">
              {[
                ['Primary Colour', 'primaryColor'],
                ['Secondary Colour', 'secondaryColor'],
                ['Accent Colour', 'accentColor'],
              ].map(([label, key]) => {
                const colorValue = colours[key as keyof Omit<ColourSelection, 'themeId'>];
                return (
                  <label key={key} className="flex items-center gap-3 rounded-2xl border border-[#EBEBEB] bg-[#FAFAFA] p-3">
                    <input
                      type="color"
                      value={colorValue}
                      onChange={(event) => updateColour(key as keyof Omit<ColourSelection, 'themeId'>, event.target.value)}
                      className="h-12 w-14 shrink-0 cursor-pointer rounded-xl border border-[#CBD5E1] bg-white p-1"
                    />
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-[#484848]">{label}</span>
                      <span className="block font-mono text-xs text-[#717171]">{colorValue}</span>
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="space-y-8">
            {templates.map((template) => {
              const themedTemplate = templateWithColours(template, colours);
              return (
                <article
                  key={template.id}
                  className="rounded-[28px] border border-[#EBEBEB] bg-white p-4 shadow-sm transition hover:shadow-xl sm:p-6"
                >
                  <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                      <p className="mb-2 text-sm font-bold uppercase tracking-[0.28em]" style={{ color: themedTemplate.accent }}>
                        {template.shortName}
                      </p>
                      <div className="flex flex-wrap items-center gap-3">
                        <h3 className="text-3xl font-bold">{template.name}</h3>
                      </div>
                      <p className="mt-2 max-w-3xl text-lg leading-8 text-[#717171]">{template.tagline}</p>
                      <p className="mt-2 max-w-3xl text-sm font-semibold text-[#484848]">{template.bestFor}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {selectedId === template.id && (
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-[#EFFFFD] px-3 py-2 text-sm font-bold text-[#008A7A]">
                          <CheckCircle className="h-4 w-4" /> Selected
                        </span>
                      )}
                      <Link
                        to={templatePreviewHref(template.id)}
                        onClick={() => chooseTemplate(template)}
                        className="inline-flex items-center rounded-2xl border border-[#D8D8D8] bg-white px-5 py-3 font-bold text-[#484848] shadow-sm hover:bg-[#FAFAF8]"
                      >
                        Expand
                        <ExternalLink className="ml-2 h-5 w-5" />
                      </Link>
                      <button
                        type="button"
                        onClick={() => {
                          chooseTemplate(template);
                          const previewId = readPreviewId();
                          const query = new URLSearchParams({ template: template.id });
                          if (previewId) query.set('preview', previewId);
                          navigate(`/signup?${query.toString()}`);
                        }}
                        className="inline-flex items-center rounded-2xl bg-[#FF5A5F] px-5 py-3 font-bold text-white shadow-sm hover:bg-[#E6474D]"
                      >
                        Continue Setup
                        <ArrowRight className="ml-2 h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  <div className="h-[720px] overflow-y-auto rounded-3xl border border-[#E5E5E5] bg-white shadow-inner">
                    <FullTemplateSite template={themedTemplate} content={content} embedded />
                  </div>
                </article>
              );
            })}
          </div>

          <div className="mt-8 rounded-[28px] border border-[#FFD1D4] bg-[#FFF0F1] p-6 sm:flex sm:items-center sm:justify-between">
            <div>
              <h3 className="text-2xl font-bold">Ready to preview {content.brand}?</h3>
              <p className="mt-2 text-[#717171]">
                {loading ? 'Still checking for the latest website content.' : 'Open any option as a full website preview and scroll it like a real guest would.'}
              </p>
            </div>
            <a
              href={originalWebsiteHref}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex items-center rounded-2xl bg-[#FF5A5F] px-6 py-4 font-bold text-white shadow-sm hover:bg-[#E6474D] sm:mt-0"
            >
              View original website
              <ExternalLink className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
