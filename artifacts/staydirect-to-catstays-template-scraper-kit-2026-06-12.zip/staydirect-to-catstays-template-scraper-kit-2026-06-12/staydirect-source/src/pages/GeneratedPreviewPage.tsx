import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowRight,
  BedDouble,
  Calendar,
  CheckCircle,
  ExternalLink,
  Globe,
  Home,
  LayoutGrid,
  Loader2,
  MapPin,
  RefreshCw,
  Sparkles,
  Star,
  Users,
  Wifi,
} from 'lucide-react';
import { MarketingNav } from '../components/marketing/MarketingNav';
import { Button } from '../components/design-system/Button';
import { BookingWidget } from '../components/design-system/BookingWidget';
import { apiUrl } from '../lib/api';
import { deloraineDemoSite, getDeloraineDemoImport } from '../lib/deloraineDemoSite';
import { cacheImportedProperty } from '../lib/localSetup';
import { savePreviewSession, readPreviewId } from '../lib/previewSessions';

interface ScrapeResult {
  name: string;
  shortDescription: string;
  fullDescription: string;
  city: string;
  country: string;
  phone: string;
  images: string[];
  amenities: string[];
  amenityDetails?: string[];
  address?: string;
  latitude?: number | null;
  longitude?: number | null;
  locationDescription?: string;
  reviews?: Array<{ author: string; date?: string; text: string; rating?: number | null; source?: string }>;
  reviewSummary?: { rating: number | null; count: number | null; source: string; externalUrl?: string };
  googleTourUrl?: string;
  brandColor?: string;
  fontFamily?: string;
  bedrooms: number | null;
  bathrooms: number | null;
  maxGuests: number | null;
  basePrice: number | null;
  cleaningFee?: number | null;
  taxRate?: number | null;
  minNights?: number | null;
  logoImage?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  sourceUrl: string;
  source: 'airbnb' | 'generic';
  error?: string;
}

const fallbackImage = 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80';
const deloraineAmenities = [
  'Wireless broadband internet',
  'Fully self-contained kitchen',
  'Free parking',
  'Shared outdoor swimming pool',
  'Outdoor hot tub',
  'Air conditioning',
  'Heating',
  'Washing machine',
  'Clothes dryer',
  'Dishwasher',
  'BBQ gas',
  'Outdoor fire pit',
  'High chair',
  'Bed linen',
  'Towels',
  'Hair dryer',
  'Iron and board',
  'Satellite TV',
  'Smoke detector',
  'Carbon monoxide detector',
  'Fire extinguisher',
  'First aid kit',
  'Children welcome',
  'Accessible 24/7',
];

const previewStyleOptions = [
  { id: 'source-match', label: 'Original' },
  { id: 'modern-showcase', label: 'Modern' },
  { id: 'editorial-guide', label: 'Editorial' },
  { id: 'conversion-focus', label: 'Conversion' },
];

function PreviewStyleThumbnail({
  styleId,
  title,
  heroImage,
}: {
  styleId: string;
  title: string;
  heroImage: string;
}) {
  if (styleId === 'source-match') {
    return (
      <div className="flex h-full overflow-hidden rounded-xl border border-white/10 bg-white text-[#484848]">
        <div className="flex min-h-0 w-full flex-col">
          <div className="flex h-9 items-center justify-between px-3">
            <div className="h-3 w-16 rounded-full bg-[#C89557]/40" />
            <div className="flex gap-2">
              <span className="h-2 w-8 rounded-full bg-[#484848]/20" />
              <span className="h-2 w-8 rounded-full bg-[#484848]/20" />
              <span className="h-2 w-8 rounded-full bg-[#484848]/20" />
            </div>
          </div>
          <div className="relative min-h-0 flex-1 overflow-hidden">
            <img src={heroImage} alt={`${title} original preview`} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/40" />
            <div className="absolute inset-x-3 top-1/2 -translate-y-1/2 text-center">
              <p className="text-[9px] font-black uppercase tracking-[0.22em] text-white/90">Welcome to the Winterless North</p>
              <p className="mt-1 truncate font-serif text-2xl font-black text-white">{title}</p>
            </div>
          </div>
          <div className="grid h-16 grid-cols-3 gap-2 p-3">
            <span className="rounded-lg border border-[#E5E5E5] bg-white" />
            <span className="rounded-lg border border-[#E5E5E5] bg-white" />
            <span className="rounded-lg border border-[#E5E5E5] bg-white" />
          </div>
        </div>
      </div>
    );
  }

  if (styleId === 'modern-showcase') {
    return (
      <div className="flex h-full overflow-hidden rounded-xl border border-white/10 bg-white text-[#484848]">
        <div className="flex min-h-0 w-full flex-col">
          <div className="flex h-9 items-center justify-between px-3">
            <div className="h-3 w-14 rounded-full bg-[#C89557]/40" />
            <div className="flex gap-2">
              <span className="h-2 w-7 rounded-full bg-[#484848]/18" />
              <span className="h-2 w-7 rounded-full bg-[#484848]/18" />
              <span className="h-2 w-7 rounded-full bg-[#484848]/18" />
            </div>
          </div>
          <div className="relative min-h-0 flex-1 overflow-hidden">
            <img src={heroImage} alt={`${title} modern preview`} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/42" />
            <div className="absolute left-4 top-5 max-w-[78%]">
              <p className="text-[9px] font-black uppercase tracking-[0.22em] text-white/90">{title}</p>
              <p className="mt-2 font-serif text-3xl font-black leading-none text-white">{title}</p>
            </div>
            <div className="absolute bottom-0 left-4 right-4 grid grid-cols-[1fr_1fr_1fr_1.2fr] overflow-hidden rounded-t-xl bg-white text-[8px] font-bold text-[#1F2E22]">
              <span className="p-2">Check-in</span>
              <span className="p-2">Check-out</span>
              <span className="p-2">Guests</span>
              <span className="bg-[#C89557] p-2 text-center text-white">Check rates</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (styleId === 'editorial-guide') {
    return (
      <div className="h-full overflow-hidden rounded-xl border border-white/10 bg-white text-[#1F2E22]">
        <div className="grid h-full grid-cols-[0.9fr_1fr]">
          <div className="flex flex-col justify-center p-5">
            <p className="text-[8px] font-black uppercase tracking-[0.22em] text-[#C89557]">About the stay</p>
            <p className="mt-3 font-serif text-3xl font-black leading-tight">A quiet escape in the Winterless North</p>
          </div>
          <div className="relative">
            <img src={heroImage} alt={`${title} editorial preview`} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/18" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full overflow-hidden rounded-xl border border-white/10 bg-white text-[#1F2E22]">
      <div className="flex min-h-0 w-full flex-col">
        <div className="relative min-h-0 flex-1 overflow-hidden">
          <img src={heroImage} alt={`${title} conversion preview`} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-black/45" />
          <div className="absolute left-4 top-5 max-w-[75%]">
            <p className="text-[8px] font-black uppercase tracking-[0.22em] text-white/80">{title}</p>
            <p className="mt-3 font-serif text-3xl font-black leading-tight text-white">A quiet escape in the Winterless North</p>
          </div>
          <div className="absolute right-3 top-3 rounded-xl bg-[#C89557] px-3 py-2 text-[9px] font-black uppercase text-white">Book</div>
        </div>
        <div className="grid h-16 grid-cols-2 gap-2 p-3">
          <span className="rounded-lg bg-[#F7F4EF]" />
          <span className="rounded-lg bg-[#F7F4EF]" />
        </div>
      </div>
    </div>
  );
}

const amenityLabels: Record<string, string> = {
  wifi: 'WiFi',
  kitchen: 'Kitchen',
  parking: 'Parking',
  pool: 'Pool',
  gym: 'Gym',
  ac: 'Air conditioning',
  heating: 'Heating',
  washer: 'Washer',
  dryer: 'Dryer',
  tv: 'TV',
  dishwasher: 'Dishwasher',
  iron: 'Iron',
  workspace: 'Workspace',
  bbq: 'BBQ',
  fireplace: 'Fireplace',
  hot_tub: 'Hot tub',
  ev_charger: 'EV charger',
  beach_access: 'Beach access',
  mountain_view: 'Mountain view',
  waterfront: 'Waterfront',
  cot: 'Cot',
  high_chair: 'High chair',
  pets_allowed: 'Pets allowed',
  accessible: 'Accessible',
};

function normaliseUrl(raw: string) {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  return trimmed.startsWith('http') ? trimmed : `https://${trimmed}`;
}

function isDelorainePreviewUrl(sourceUrl: string) {
  try {
    const hostname = new URL(sourceUrl).hostname.replace(/^www\./, '').toLowerCase();
    return (
      hostname === 'delorainecottage.localhost' ||
      hostname === 'delorainecottage.staydirect.nz' ||
      hostname === 'delorainecottage.com'
    );
  } catch {
    return false;
  }
}

function cleanName(name: string) {
  return name
    .replace(/\s*[·•]\s*(?:★|☆|\d[\d.,]?\d*\s+(?:bedroom|bed|bath|guest)).*/i, '')
    .replace(/\s*[\-|]\s*(Airbnb|Booking\.com|Vacation Rental|Holiday Let).*/i, '')
    .trim();
}

function getAirbnbReviewUrl(sourceUrl: string) {
  try {
    const url = new URL(sourceUrl);
    url.hash = 'reviews';
    return url.toString();
  } catch {
    return sourceUrl;
  }
}

function organiseImages(images: string[], source?: ScrapeResult['source']) {
  const unique = images.filter((image, index) => images.indexOf(image) === index);
  if (unique.length <= 1) {
    return { heroImage: unique[0] ?? fallbackImage, galleryImages: unique.length ? unique : [fallbackImage] };
  }

  const heroIndex = source === 'airbnb' ? 1 : 0;
  const heroImage = unique[heroIndex] ?? unique[0];
  const galleryImages = unique.filter((_, index) => index !== heroIndex);

  return {
    heroImage,
    galleryImages: [...galleryImages, heroImage],
  };
}

function buildLocalPreviewFallback(sourceUrl: string): ScrapeResult | null {
  try {
    new URL(sourceUrl);
  } catch {
    return null;
  }

  if (!isDelorainePreviewUrl(sourceUrl)) return null;

  const deloraine = getDeloraineDemoImport();

  return {
    ...deloraine,
    phone: deloraine.contactPhone ?? '',
    amenities: deloraine.amenities,
    amenityDetails: deloraineAmenities,
    latitude: -35.726725,
    longitude: 174.357263,
    locationDescription:
      'Set in a quiet rural pocket of Whangarei, close enough for town basin cafes, restaurants and beaches while still feeling peaceful and private.',
    reviews: [],
    reviewSummary: undefined,
    googleTourUrl: deloraineDemoSite.googleTour,
    brandColor: deloraineDemoSite.palette.accent,
    fontFamily: 'Montserrat, Arial, sans-serif',
    sourceUrl,
    source: 'generic',
  };
}

export default function GeneratedPreviewPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const initialUrlParam = normaliseUrl(params.get('url') ?? '');
  const [urlInput, setUrlInput] = useState(params.get('url') ?? sessionStorage.getItem('staydirect_import_url') ?? '');
  const [data, setData] = useState<ScrapeResult | null>(() => {
    if (initialUrlParam && isDelorainePreviewUrl(initialUrlParam)) {
      return buildLocalPreviewFallback(initialUrlParam);
    }
    const stored = sessionStorage.getItem('staydirect_preview_data') || localStorage.getItem('staydirect_preview_data');
    if (!stored) return null;
    try {
      const parsed = JSON.parse(stored) as ScrapeResult;
      if (initialUrlParam && parsed.sourceUrl && normaliseUrl(parsed.sourceUrl) !== initialUrlParam) {
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showAllPhotos, setShowAllPhotos] = useState(false);
  const [showAllAmenities, setShowAllAmenities] = useState(false);
  const [bookingNotice, setBookingNotice] = useState('');
  const [selectedStyleId, setSelectedStyleId] = useState(() =>
    sessionStorage.getItem('staydirect_selected_site_template') ||
    localStorage.getItem('staydirect_selected_site_template') ||
    'source-match',
  );

  const targetUrl = normaliseUrl(params.get('url') ?? '');

  const generate = async (rawUrl = urlInput) => {
    const target = normaliseUrl(rawUrl);
    if (!target) {
      setError('Paste a listing or website URL first.');
      return;
    }

    setLoading(true);
    setError('');
    sessionStorage.setItem('staydirect_import_url', target);
    localStorage.setItem('staydirect_import_url', target);

    const localFallback = buildLocalPreviewFallback(target);
    if (localFallback) {
      const cleaned = { ...localFallback, name: cleanName(localFallback.name) || 'Your Property' };
      sessionStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
      localStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
      cacheImportedProperty(cleaned);
      void savePreviewSession(target, cleaned as unknown as Record<string, unknown>);
      setData(cleaned);
      setUrlInput(target);
      setError('');
      navigate(`/preview?url=${encodeURIComponent(target)}`, { replace: true });
      setLoading(false);
      return;
    }

    try {
      const res = await fetch(apiUrl(`/api/scrape?url=${encodeURIComponent(target)}`), {
        headers: { Accept: 'application/json' },
      });
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('The preview importer is not connected in this environment yet.');
      }
      const payload: ScrapeResult = await res.json();
      if (!res.ok || payload.error) {
        throw new Error(payload.error || 'Could not import that website.');
      }
      const cleaned = { ...payload, name: cleanName(payload.name) || 'Your Property' };
      sessionStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
      localStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
      cacheImportedProperty(cleaned);
      // Persist the URL + scraped payload to Supabase so the four template
      // preview pages can reload the exact same data by id from any tab.
      void savePreviewSession(target, cleaned as unknown as Record<string, unknown>);
      setData(cleaned);
      setUrlInput(target);
      navigate(`/preview?url=${encodeURIComponent(target)}`, { replace: true });
    } catch (err) {
      const fallback = buildLocalPreviewFallback(target);
      if (fallback) {
        const cleaned = { ...fallback, name: cleanName(fallback.name) || 'Your Property' };
        sessionStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
        localStorage.setItem('staydirect_preview_data', JSON.stringify(cleaned));
        cacheImportedProperty(cleaned);
        void savePreviewSession(target, cleaned as unknown as Record<string, unknown>);
        setData(cleaned);
        setUrlInput(target);
        setError('');
        navigate(`/preview?url=${encodeURIComponent(target)}`, { replace: true });
      } else {
        setError(
          err instanceof TypeError
            ? 'The importer service is not running right now. Please try again in a moment.'
            : err instanceof Error
              ? err.message
              : 'Could not import that website.',
        );
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const savedTarget = normaliseUrl(sessionStorage.getItem('staydirect_import_url') ?? '');
    const initialTarget = targetUrl || savedTarget;
    const isMissingLocation = !data?.address && typeof data?.latitude !== 'number' && typeof data?.longitude !== 'number';

    if (initialTarget && (targetUrl || !data || isMissingLocation)) {
      generate(initialTarget);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setShowAllPhotos(false);
    setShowAllAmenities(false);
    setBookingNotice('');
  }, [data?.sourceUrl]);

  const preview = useMemo(() => {
    if (!data) return null;
    const importedImages = data.images.length > 0 ? data.images : [fallbackImage];
    const { heroImage, galleryImages } = organiseImages(importedImages, data.source);
    const title = cleanName(data.name) || 'Your Property';
    const description =
      data.fullDescription || data.shortDescription || 'Your one-page website preview will appear here.';
    const amenities = data.amenityDetails?.length ? data.amenityDetails : data.amenities.length > 0 ? data.amenities : ['wifi', 'kitchen', 'parking'];
    const accentColor = data.brandColor && /^#[0-9a-f]{6}$/i.test(data.brandColor) ? data.brandColor : '#FF385C';
    return { images: galleryImages, heroImage, title, description, amenities, accentColor, fontFamily: data.fontFamily };
  }, [data]);

  const hasCoordinates = typeof data?.latitude === 'number' && typeof data?.longitude === 'number';
  const mapUrl = hasCoordinates
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${(data.longitude as number) - 0.03}%2C${(data.latitude as number) - 0.03}%2C${(data.longitude as number) + 0.03}%2C${(data.latitude as number) + 0.03}&layer=mapnik&marker=${data.latitude}%2C${data.longitude}`
    : data?.address
      ? `https://www.google.com/maps?q=${encodeURIComponent(data.address)}&output=embed`
      : '';
  const mapLink = hasCoordinates
    ? `https://www.openstreetmap.org/?mlat=${data?.latitude}&mlon=${data?.longitude}#map=13/${data?.latitude}/${data?.longitude}`
    : data?.address
      ? `https://www.openstreetmap.org/search?query=${encodeURIComponent(data.address)}`
      : '';

  const rememberSelectedStyle = (styleId: string) => {
    setSelectedStyleId(styleId);
    sessionStorage.setItem('staydirect_selected_site_template', styleId);
    localStorage.setItem('staydirect_selected_site_template', styleId);
    sessionStorage.setItem('staydirect_selected_preview_template', styleId);
    localStorage.setItem('staydirect_selected_preview_template', styleId);
  };

  const continueSetup = (styleId = selectedStyleId) => {
    rememberSelectedStyle(styleId);
    if (data) {
      sessionStorage.setItem('staydirect_preview_data', JSON.stringify(data));
      localStorage.setItem('staydirect_preview_data', JSON.stringify(data));
      cacheImportedProperty(data);
    }
    const importUrl = normaliseUrl(urlInput);
    sessionStorage.setItem('staydirect_import_url', importUrl);
    localStorage.setItem('staydirect_import_url', importUrl);
    const previewId = readPreviewId();
    const query = new URLSearchParams({ template: styleId });
    if (previewId) query.set('preview', previewId);
    navigate(`/signup?${query.toString()}`);
  };

  return (
    <div className="min-h-screen bg-[#F7F7F7]">
      <MarketingNav />

      <section className="bg-gradient-to-br from-[#FF5A5F] to-[#FF385C] px-4 py-12 text-white">
        <div className="mx-auto max-w-5xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-2 text-sm font-semibold">
            <Sparkles className="h-4 w-4" />
            Instant one-page preview
          </div>
          <h1 className="mb-4 text-4xl font-bold md:text-5xl">See your direct booking site before you sign up</h1>
          <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90">
            Paste an existing guest accommodation listing or website and StayDirect will pull the photos, description, amenities and location into a draft website.
          </p>
          <div className="mx-auto flex max-w-3xl flex-col gap-3 rounded-2xl bg-white p-3 shadow-2xl sm:flex-row">
            <input
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://your-property-site.com or accommodation listing URL"
              className="min-h-[52px] flex-1 rounded-xl px-4 text-[#484848] outline-none"
            />
            <Button onClick={() => generate()} disabled={loading} size="lg" className="shrink-0">
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <RefreshCw className="h-5 w-5" />}
              Generate Preview
            </Button>
          </div>
          {error && <p className="mt-4 rounded-xl bg-white/15 px-4 py-3 text-sm font-semibold text-white">{error}</p>}
        </div>
      </section>

      {!preview && !loading && (
        <section className="mx-auto max-w-5xl px-4 py-16 text-center">
          <Globe className="mx-auto mb-4 h-12 w-12 text-[#FF385C]" />
          <h2 className="mb-3 text-3xl font-bold text-[#484848]">Paste a URL to create a preview</h2>
          <p className="text-[#717171]">The preview will appear here, then you can create an account to save and edit it.</p>
        </section>
      )}

      {loading && (
        <section className="mx-auto max-w-5xl px-4 py-16 text-center">
          <Loader2 className="mx-auto mb-4 h-12 w-12 animate-spin text-[#FF385C]" />
          <h2 className="mb-3 text-3xl font-bold text-[#484848]">Building your preview</h2>
          <p className="text-[#717171]">Pulling photos, descriptions, amenities and booking details where available.</p>
        </section>
      )}

      {preview && (
        <section className="bg-white" style={preview.fontFamily ? { fontFamily: `${preview.fontFamily}, Inter, sans-serif` } : undefined}>
          <div className="border-b border-[#22323A] bg-[#101820] px-4 py-5 text-white">
            <div className="mx-auto max-w-7xl">
              <div className="mb-4 flex justify-end">
                <Link
                  to={(() => {
                    const previewId = readPreviewId();
                    return previewId ? `/website-options?preview=${previewId}` : '/website-options';
                  })()}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-black text-[#101820] transition hover:bg-[#FFF1F2] hover:text-[#FF385C]"
                >
                  <LayoutGrid className="h-4 w-4" />
                  View all four previews
                  <ExternalLink className="h-4 w-4" />
                </Link>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {previewStyleOptions.map((style) => {
                  const selected = selectedStyleId === style.id;
                  const previewId = readPreviewId();
                  const fullPreviewPath = previewId ? `/website-options/preview/${style.id}?preview=${previewId}` : `/website-options/preview/${style.id}`;
                  return (
                    <article
                      key={style.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => rememberSelectedStyle(style.id)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          rememberSelectedStyle(style.id);
                        }
                      }}
                      className={`group flex min-h-[340px] cursor-pointer flex-col rounded-2xl border p-3 transition md:min-h-[370px] ${selected ? 'border-[#FF385C] bg-white/10 shadow-lg shadow-[#FF385C]/15' : 'border-white/16 bg-white/5 hover:border-white/35'}`}
                    >
                      <Link to={fullPreviewPath} target="_blank" className="block min-h-0 flex-1" onClick={(event) => event.stopPropagation()}>
                        <div className="relative h-full">
                          <PreviewStyleThumbnail styleId={style.id} title={preview.title} heroImage={preview.heroImage} />
                          {selected && (
                            <div className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-[#FF385C] text-white">
                              <CheckCircle className="h-4 w-4" />
                            </div>
                          )}
                        </div>
                      </Link>
                      <h3 className="mt-3 text-base font-black">{style.label}</h3>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>
          <header className="sticky top-0 z-40 border-b border-[#EBEBEB] bg-white/95 backdrop-blur">
            <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
              <a href="#preview-home" className="flex items-center">
                {data?.logoImage ? (
                  <img src={data.logoImage} alt={preview.title} className="max-h-14 w-auto object-contain" />
                ) : (
                  <span className="text-2xl font-bold" style={{ color: preview.accentColor }}>{preview.title}</span>
                )}
              </a>
              <div className="hidden items-center gap-7 font-medium text-[#484848] md:flex">
                <a href="#preview-about">About</a>
                <a href="#preview-gallery">Gallery</a>
                <a href="#preview-amenities">Amenities</a>
                <a href="#preview-location">Location</a>
                {data?.googleTourUrl && <a href="#preview-tour">Tour</a>}
                <a href="#preview-reviews">Reviews</a>
                <a href="#preview-book">Book</a>
              </div>
              <a href="#preview-book" className="rounded-xl px-5 py-3 font-semibold text-white" style={{ backgroundColor: preview.accentColor }}>Book Now</a>
            </div>
          </header>

          <div id="preview-home" className="relative min-h-[620px] overflow-hidden">
            <img src={preview.heroImage} alt={preview.title} className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/25 to-black/20" />
            <div className="relative z-10 mx-auto flex min-h-[620px] max-w-6xl flex-col items-center justify-center px-4 text-center text-white">
              <h2 className="mb-5 text-5xl font-bold md:text-7xl">{preview.title}</h2>
              <p className="mb-6 max-w-3xl text-xl text-white/90">{data?.shortDescription || preview.description.slice(0, 180)}</p>
              <div className="flex flex-wrap justify-center gap-4 text-white/90">
                {(data?.city || data?.country) && (
                  <span className="inline-flex items-center gap-2"><MapPin className="h-5 w-5" />{[data.city, data.country].filter(Boolean).join(', ')}</span>
                )}
                {data?.maxGuests && <span className="inline-flex items-center gap-2"><Users className="h-5 w-5" />{data.maxGuests} guests</span>}
                {data?.bedrooms && <span className="inline-flex items-center gap-2"><BedDouble className="h-5 w-5" />{data.bedrooms} bedrooms</span>}
              </div>
            </div>
          </div>

          <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_380px] lg:px-8">
            <main className="space-y-16">
              <section id="preview-about">
                <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>About</p>
                <h3 className="mb-5 text-3xl font-bold text-[#484848]">Property story</h3>
                <div className="whitespace-pre-line text-lg leading-relaxed text-[#717171]">{preview.description}</div>
              </section>

              <section id="preview-gallery">
                <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>Gallery</p>
                <h3 className="mb-5 text-3xl font-bold text-[#484848]">Photos</h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {(showAllPhotos ? preview.images : preview.images.slice(0, 4)).map((image, index) => (
                    <img
                      key={`${image}-${index}`}
                      src={image}
                      alt={`${preview.title} ${index + 1}`}
                      className="h-72 w-full rounded-xl object-cover"
                      loading={index < 4 ? 'eager' : 'lazy'}
                    />
                  ))}
                </div>
                {preview.images.length > 4 && (
                  <button
                    type="button"
                    onClick={() => setShowAllPhotos((current) => !current)}
                    className="mt-5 rounded-xl border bg-white px-5 py-3 font-bold transition-colors hover:bg-[#FFF1F2]"
                    style={{ borderColor: preview.accentColor, color: preview.accentColor }}
                  >
                    {showAllPhotos ? 'Show fewer photos' : `Show all ${preview.images.length} photos`}
                  </button>
                )}
              </section>

              <section id="preview-amenities">
                <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>Amenities</p>
                <h3 className="mb-5 text-3xl font-bold text-[#484848]">What guests can expect</h3>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {(showAllAmenities ? preview.amenities : preview.amenities.slice(0, 10)).map((amenity) => (
                    <div key={amenity} className="flex items-center gap-3 rounded-xl border border-[#EBEBEB] p-4">
                      {amenity === 'wifi' || amenity.toLowerCase() === 'wifi' ? <Wifi className="h-5 w-5 text-[#00A699]" /> : <CheckCircle className="h-5 w-5 text-[#00A699]" />}
                      <span className="font-medium text-[#484848]">{amenityLabels[amenity] ?? amenity.replace(/_/g, ' ')}</span>
                    </div>
                  ))}
                </div>
                {preview.amenities.length > 10 && (
                  <button
                    type="button"
                    onClick={() => setShowAllAmenities((current) => !current)}
                    className="mt-5 rounded-xl border bg-white px-5 py-3 font-bold transition-colors hover:bg-[#FFF1F2]"
                    style={{ borderColor: preview.accentColor, color: preview.accentColor }}
                  >
                    {showAllAmenities ? 'Show fewer amenities' : `Show all ${preview.amenities.length} amenities`}
                  </button>
                )}
              </section>

              {(data?.address || data?.locationDescription || mapUrl || mapLink) && (
                <section id="preview-location">
                  <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>Location</p>
                  <h3 className="mb-5 text-3xl font-bold text-[#484848]">Where guests will be</h3>
                  {data?.address && (
                    <p className="mb-4 flex items-center gap-2 text-lg font-semibold text-[#484848]">
                      <MapPin className="h-5 w-5" style={{ color: preview.accentColor }} />
                      {data.address}
                    </p>
                  )}
                  {data?.locationDescription && (
                    <p className="mb-5 whitespace-pre-line text-lg leading-relaxed text-[#717171]">{data.locationDescription}</p>
                  )}
                  {mapUrl && (
                    <div className="overflow-hidden rounded-xl border border-[#EBEBEB] bg-[#F7F7F7]">
                      <iframe
                        title={`${preview.title} map`}
                        src={mapUrl}
                        className="h-[360px] w-full"
                        loading="lazy"
                      />
                    </div>
                  )}
                  {!mapUrl && data?.address && (
                    <div className="rounded-xl border border-[#EBEBEB] bg-[#F7F7F7] p-6">
                      <p className="mb-2 font-bold text-[#484848]">Map preview</p>
                      <p className="text-[#717171]">{data.address}</p>
                    </div>
                  )}
                  {mapLink && (
                    <a
                      href={mapLink}
                      className="mt-4 inline-flex items-center gap-2 rounded-xl px-5 py-3 font-bold text-white shadow-sm"
                      style={{ backgroundColor: preview.accentColor }}
                    >
                      Open map
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </section>
              )}

              {data?.googleTourUrl && (
                <section id="preview-tour">
                  <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>Virtual tour</p>
                  <h3 className="mb-5 text-3xl font-bold text-[#484848]">Look around before you book</h3>
                  <div className="overflow-hidden rounded-xl border border-[#EBEBEB] bg-[#F7F7F7]">
                    <iframe
                      title={`${preview.title} virtual tour`}
                      src={data.googleTourUrl}
                      className="h-[460px] w-full"
                      loading="lazy"
                    />
                  </div>
                </section>
              )}

              {(data?.reviewSummary || (data?.reviews && data.reviews.length > 0)) && (
                <section id="preview-reviews">
                  <p className="mb-2 text-sm font-bold uppercase tracking-[0.24em]" style={{ color: preview.accentColor }}>Reviews</p>
                  <h3 className="mb-5 text-3xl font-bold text-[#484848]">Guest feedback</h3>
                  {data.reviewSummary && (
                    <div className="mb-5 rounded-xl border border-[#EBEBEB] bg-[#F7F7F7] p-4">
                      <div className="mb-4 flex flex-wrap items-center gap-3">
                        <Star className="h-5 w-5 fill-[#FFB400] text-[#FFB400]" />
                        <span className="font-bold text-[#484848]">{data.reviewSummary.rating?.toFixed(2) ?? 'Rated'}</span>
                        {data.reviewSummary.count && <span className="text-[#717171]">{data.reviewSummary.count} reviews on {data.reviewSummary.source}</span>}
                      </div>
                      {data.source === 'airbnb' && (data.reviewSummary.externalUrl || data.sourceUrl) && (
                        <a
                          href={data.reviewSummary.externalUrl || getAirbnbReviewUrl(data.sourceUrl)}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-2 rounded-xl px-5 py-3 font-bold text-white shadow-sm"
                          style={{ backgroundColor: preview.accentColor }}
                        >
                          Read guest reviews on Airbnb
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                  )}
                  {data.reviews && data.reviews.length > 0 && (
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      {data.reviews.map((review, index) => (
                        <article key={`${review.author}-${index}`} className="rounded-xl border border-[#EBEBEB] p-5">
                          <div className="mb-3 flex items-center justify-between gap-3">
                            <p className="font-bold text-[#484848]">{review.author}</p>
                            <span className="text-sm text-[#717171]">{review.source ?? 'Airbnb'}</span>
                          </div>
                          <p className="text-[#717171]">{review.text}</p>
                        </article>
                      ))}
                    </div>
                  )}
                </section>
              )}
            </main>

            <aside id="preview-book" className="space-y-4">
              <BookingWidget
                basePrice={data?.basePrice ?? 0}
                cleaningFee={data?.cleaningFee ?? 0}
                taxRate={data?.taxRate ?? 0}
                minNights={data?.minNights ?? 1}
                accentColor={preview.accentColor}
                priceLabel="Date-based pricing"
                onBook={() => {
                  setBookingNotice('This is still a draft preview, so bookings are not live yet. Create an account to save this property and connect the real booking checkout.');
                }}
              />
              {bookingNotice && (
                <div className="rounded-2xl border border-[#FF385C]/20 bg-[#FFF1F2] p-4 text-sm font-semibold text-[#484848]">
                  {bookingNotice}
                </div>
              )}
              <div className="rounded-2xl border border-[#EBEBEB] bg-[#F7F7F7] p-5">
                <h4 className="mb-2 flex items-center gap-2 font-bold text-[#484848]"><Calendar className="h-5 w-5" />Draft preview</h4>
                <p className="mb-4 text-sm text-[#717171]">Create your account to save this preview, edit the content, connect payments and publish.</p>
                <Button onClick={() => continueSetup()} fullWidth>
                  Create Account & Save
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </aside>
          </div>

          <section className="bg-[#F7F7F7] px-4 py-12 text-center">
            <Home className="mx-auto mb-4 h-10 w-10 text-[#FF385C]" />
            <h3 className="mb-3 text-3xl font-bold text-[#484848]">This is only the first draft</h3>
            <p className="mx-auto mb-6 max-w-2xl text-[#717171]">
              StayDirect will save this preview into your dashboard so you can change colours, text, photos, pricing and booking settings before publishing.
            </p>
            <Button onClick={() => continueSetup()} size="lg">
              Continue Setup
              <ExternalLink className="h-5 w-5" />
            </Button>
          </section>
        </section>
      )}
    </div>
  );
}
