import { supabase } from './supabase';

export interface PreviewSessionRow {
  id: string;
  url: string;
  scraped_data: Record<string, unknown>;
  layout_previews?: Record<string, PreviewLayoutPayload>;
  selected_template?: string | null;
  created_at: string;
}

export interface PreviewLayoutPayload {
  template_id: string;
  name: string;
  path: string;
  scraped_data: Record<string, unknown>;
  colours: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

const PREVIEW_LAYOUTS = [
  {
    template_id: 'source-match',
    name: 'Original Website',
    colours: { primary: '#FFFFFF', secondary: '#333333', accent: '#AA7942' },
  },
  {
    template_id: 'modern-showcase',
    name: 'Modern Showcase',
    colours: { primary: '#F7F4EF', secondary: '#1F2E22', accent: '#4A684F' },
  },
  {
    template_id: 'conversion-focus',
    name: 'Conversion Focus',
    colours: { primary: '#F5F2EC', secondary: '#1F2A22', accent: '#C89A4B' },
  },
  {
    template_id: 'editorial-guide',
    name: 'Editorial Guide',
    colours: { primary: '#F3EFEA', secondary: '#1F2A22', accent: '#4A5A44' },
  },
] as const;

const PREVIEW_ID_KEY = 'staydirect_preview_id';

export function rememberPreviewId(id: string) {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.setItem(PREVIEW_ID_KEY, id);
    localStorage.setItem(PREVIEW_ID_KEY, id);
  } catch {
    /* storage unavailable — ignore */
  }
}

export function readPreviewId(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return (
      sessionStorage.getItem(PREVIEW_ID_KEY) ||
      localStorage.getItem(PREVIEW_ID_KEY)
    );
  } catch {
    return null;
  }
}

export function clearPreviewId() {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.removeItem(PREVIEW_ID_KEY);
    localStorage.removeItem(PREVIEW_ID_KEY);
  } catch {
    /* ignore */
  }
}

export function buildLayoutPreviews(scrapedData: Record<string, unknown>): Record<string, PreviewLayoutPayload> {
  return Object.fromEntries(
    PREVIEW_LAYOUTS.map((layout) => [
      layout.template_id,
      {
        ...layout,
        path: `/website-options/preview/${layout.template_id}`,
        scraped_data: scrapedData,
      },
    ]),
  );
}

export function previewDataForTemplate(
  row: PreviewSessionRow,
  templateId: string,
): Record<string, unknown> {
  return row.layout_previews?.[templateId]?.scraped_data || row.scraped_data;
}

export async function savePreviewSession(
  url: string,
  scrapedData: Record<string, unknown>,
  options: {
    layoutPreviews?: Record<string, PreviewLayoutPayload>;
    selectedTemplate?: string;
  } = {},
): Promise<string | null> {
  try {
    const layoutPreviews = options.layoutPreviews || buildLayoutPreviews(scrapedData);
    const insertPayload = {
      url,
      scraped_data: scrapedData,
      layout_previews: layoutPreviews,
      selected_template: options.selectedTemplate || 'source-match',
    };
    const { data, error } = await supabase
      .from('preview_sessions')
      .insert(insertPayload)
      .select('id')
      .single();
    if (error && /layout_previews|selected_template/i.test(error.message)) {
      const { data: legacyData, error: legacyError } = await supabase
        .from('preview_sessions')
        .insert({ url, scraped_data: scrapedData })
        .select('id')
        .single();
      if (legacyError || !legacyData?.id) {
        console.warn('[previewSessions] legacy insert failed', legacyError?.message);
        return null;
      }
      rememberPreviewId(legacyData.id);
      return legacyData.id;
    }
    if (error || !data?.id) {
      console.warn('[previewSessions] insert failed', error?.message);
      return null;
    }
    rememberPreviewId(data.id);
    return data.id;
  } catch (err) {
    console.warn('[previewSessions] insert threw', err);
    return null;
  }
}

export async function loadPreviewSession(id: string): Promise<PreviewSessionRow | null> {
  if (!id) return null;
  try {
    const { data, error } = await supabase
      .from('preview_sessions')
      .select('id, url, scraped_data, layout_previews, selected_template, created_at')
      .eq('id', id)
      .maybeSingle();
    if (error && /layout_previews|selected_template/i.test(error.message)) {
      const { data: legacyData, error: legacyError } = await supabase
        .from('preview_sessions')
        .select('id, url, scraped_data, created_at')
        .eq('id', id)
        .maybeSingle();
      if (legacyError) {
        console.warn('[previewSessions] legacy load failed', legacyError.message);
        return null;
      }
      return legacyData as PreviewSessionRow | null;
    }
    if (error) {
      console.warn('[previewSessions] load failed', error.message);
      return null;
    }
    return data as PreviewSessionRow | null;
  } catch (err) {
    console.warn('[previewSessions] load threw', err);
    return null;
  }
}
