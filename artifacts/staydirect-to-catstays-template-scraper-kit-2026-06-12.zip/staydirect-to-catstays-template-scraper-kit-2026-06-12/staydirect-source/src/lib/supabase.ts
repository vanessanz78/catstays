import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string) || 'https://placeholder.supabase.co';
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string) || 'placeholder-anon-key';

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn('[StayDirect] Missing Supabase environment variables. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to enable backend features.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Property = {
  id: string;
  host_id: string;
  name: string;
  type: string;
  address: string;
  suburb?: string | null;
  city: string;
  country: string;
  bedrooms: number;
  bathrooms: number;
  max_guests: number;
  base_price: number;
  cleaning_fee: number;
  tax_rate: number;
  min_nights: number;
  short_description: string;
  full_description: string;
  amenities: string[];
  images: string[];
  check_in_time: string;
  check_out_time: string;
  pets_allowed: boolean;
  smoking_allowed: boolean;
  events_allowed: boolean;
  accent_color: string;
  theme: string;
  slug: string | null;
  custom_domain: string | null;
  stripe_publishable_key: string | null;
  marketplace_enabled?: boolean;
  marketplace_status?: 'draft' | 'published' | 'paused' | 'archived';
  marketplace_headline?: string | null;
  marketplace_short_description?: string | null;
  marketplace_featured_image?: string | null;
  marketplace_category?: string | null;
  marketplace_tags?: string[];
  marketplace_search_priority?: number;
  marketplace_booking_mode?: 'host_site' | 'marketplace' | 'both';
  marketplace_featured?: boolean;
  marketplace_destination?: string | null;
  marketplace_collection_slugs?: string[];
  marketplace_quality_score?: number;
  marketplace_review_score?: number | null;
  marketplace_conversion_score?: number;
  marketplace_last_reviewed_at?: string | null;
  instant_booking?: boolean;
  occupancy?: number;
  nightly_price?: number | null;
  latitude?: number | null;
  longitude?: number | null;
  contact_email?: string | null;
  contact_phone?: string | null;
  contact_email_visible?: boolean | null;
  contact_phone_visible?: boolean | null;
  contact_preference?: 'email' | 'phone' | 'either' | 'booking_only' | null;
  staydirect_email_alias?: string | null;
  website_content?: import('../hooks/usePropertyByDomain').WebsiteContent | null;
  door_code?: string | null;
  lockbox_code?: string | null;
  wifi_name?: string | null;
  wifi_password?: string | null;
  parking_instructions?: string | null;
  checkin_instructions?: string | null;
  checkout_instructions?: string | null;
  house_rules?: string | null;
  pool_spa_notes?: string | null;
  shared_property_notes?: string | null;
  created_at: string;
  updated_at: string;
};

export type Booking = {
  id: string;
  property_id: string | null;
  host_id: string;
  guest_name: string;
  guest_email: string;
  guest_phone: string;
  check_in: string;
  check_out: string;
  guests: number;
  nights: number;
  total: number;
  total_before_discount?: number | null;
  promotion_id?: string | null;
  promotion_code?: string | null;
  promotion_discount?: number | null;
  promotion_snapshot?: Record<string, unknown> | null;
  upsells?: Array<Record<string, unknown>> | null;
  upsell_total?: number | null;
  status: 'pending' | 'confirmed' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'refunded';
  notes: string;
  booking_date: string;
  created_at: string;
};

export type Subscription = {
  id: string;
  host_id: string;
  plan: string;
  status: 'trialing' | 'active' | 'cancelled' | 'past_due';
  trial_ends_at: string;
  created_at: string;
};

export type Profile = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  bio: string | null;
  avatar_url?: string | null;
  created_at: string;
};
