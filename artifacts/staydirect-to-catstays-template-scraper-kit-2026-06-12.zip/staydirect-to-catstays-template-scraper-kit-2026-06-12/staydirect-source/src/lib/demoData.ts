import type { Booking, Property, Subscription } from './supabase';
import { apiUrl } from './api';
import { getDeloraineDemoImport } from './deloraineDemoSite';
import { supabase } from './supabase';

export const DEMO_HOST_ID = 'demo-host';
const BOOKINGS_KEY = 'staydirect_demo_bookings';
const PROPERTY_KEY = 'staydirect_demo_property';
const DEMO_DATA_VERSION_KEY = 'staydirect_demo_data_version';
const DEMO_DATA_VERSION = '2026-05-28-upsell-revenue-v1';
const DEMO_IMPORT_URL = 'https://delorainecottage.com/en/overview';
const LEGACY_DEMO_BOOKING_PATTERN =
  /Amelia Brown|Liam Carter|Margaret Leslie|Heidi Jacobs|Karen Manukonga|Cathryn Dawn|Talia Demo|Ava Demo|demo-booking-review-|amelia@example\.com|liam@example\.com|margaret@example\.com|heidi@example\.com|karen@example\.com|cathryn@example\.com|mlesli\.687330@guest\.booking\.com/i;

// The canonical demo property in Supabase — Deloraine Stone Cottage (slug: "delorainecottage")
export const DEMO_PROPERTY_SUPABASE_ID = '70905e83-f782-4501-9f40-12114153ff73';

type DemoImportResult = {
  name?: string;
  shortDescription?: string;
  fullDescription?: string;
  city?: string;
  country?: string;
  address?: string;
  images?: string[];
  amenities?: string[];
  bedrooms?: number | null;
  bathrooms?: number | null;
  maxGuests?: number | null;
  basePrice?: number | null;
};

type DemoChannel = 'Direct' | 'Airbnb' | 'Booking.com';

type DemoReviewSeed = {
  rating: number;
  title: string;
  body: string;
  source?: 'direct' | 'airbnb' | 'booking_com' | 'vrbo' | 'manual_import';
  featured?: boolean;
  pinned?: boolean;
  hostResponse?: string | null;
};

type DemoStaySeed = {
  id: string;
  checkIn: string;
  nights: number;
  nightlyRate: number;
  cleaningFee?: number;
  discount?: number;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  guests: number;
  booked: string;
  channel: DemoChannel;
  guestLocation: string;
  status?: Booking['status'];
  paymentStatus?: Booking['payment_status'];
  notes?: string;
  review?: DemoReviewSeed;
  promoCode?: string;
  promoId?: string;
  promoName?: string;
  promoDiscountType?: string;
  promoDiscountValue?: number;
};

export type DemoReviewRecord = {
  id: string;
  property_id: string;
  booking_id: string;
  guest_id: string | null;
  rating: number;
  title: string | null;
  body: string;
  status: 'pending' | 'approved' | 'rejected' | 'reported';
  host_response: string | null;
  host_responded_at: string | null;
  source: 'direct' | 'airbnb' | 'booking_com' | 'vrbo' | 'manual_import';
  featured: boolean;
  pinned: boolean;
  published_at: string | null;
  created_at: string;
  bookings: Pick<Booking, 'guest_name' | 'guest_email' | 'check_in' | 'check_out'>;
};

export type DemoReviewRequestRecord = {
  id: string;
  property_id: string;
  booking_id: string;
  host_id: string;
  guest_email: string;
  guest_name: string;
  source: 'direct' | 'airbnb' | 'booking_com' | 'vrbo' | 'manual_import';
  status: 'scheduled' | 'queued' | 'sent' | 'reminded' | 'submitted' | 'cancelled';
  send_after: string;
  sent_at: string | null;
  reminder_after: string | null;
  reminded_at: string | null;
  token?: string;
  created_at: string;
};

function usableImages(images: unknown): string[] {
  return Array.isArray(images)
    ? images.filter((image): image is string => typeof image === 'string' && image.trim().length > 0)
    : [];
}

function imageIdentity(image: string): string {
  try {
    const url = new URL(image);
    return `${url.hostname}${url.pathname}`;
  } catch {
    return image.split('?')[0];
  }
}

function deloraineImageIdentities(): Set<string> {
  return new Set(usableImages(getDeloraineDemoImport().images).map(imageIdentity));
}

function hasDeloraineWebsitePhotos(images: unknown): boolean {
  const usable = usableImages(images);
  const canonicalImages = deloraineImageIdentities();
  return usable.length >= 4 && usable.slice(0, 4).every((image) => canonicalImages.has(imageIdentity(image)));
}

function mergeImportedProperty(base: Property, imported: DemoImportResult): Property {
  return {
    ...base,
    name: imported.name?.trim() || base.name,
    address: imported.address?.trim() || base.address,
    city: imported.city?.trim() || base.city,
    country: imported.country?.trim() || base.country,
    bedrooms: imported.bedrooms ?? base.bedrooms,
    bathrooms: imported.bathrooms ?? base.bathrooms,
    max_guests: imported.maxGuests ?? base.max_guests,
    base_price: imported.basePrice ?? base.base_price,
    short_description: imported.shortDescription?.trim() || base.short_description,
    full_description: imported.fullDescription?.trim() || base.full_description,
    amenities: imported.amenities?.length ? imported.amenities : base.amenities,
    images: usableImages(imported.images).length ? usableImages(imported.images) : base.images,
    updated_at: new Date().toISOString(),
  };
}

function getStoredDemoProperty(): Property | null {
  const stored = localStorage.getItem(PROPERTY_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored) as Property;
  } catch {
    return null;
  }
}

/**
 * Returns true ONLY when the authenticated user is the demo account.
 * Does NOT check localStorage — the AuthContext is the single source of truth
 * for whether a session is real or demo. This prevents a stale demo flag in
 * localStorage from ever leaking demo data into a real host's dashboard.
 */
export function isDemoHost(user?: { id?: string; isDemo?: boolean } | null) {
  return user?.isDemo === true || user?.id === DEMO_HOST_ID;
}

// Offline fallback — mirrors the real Deloraine Stone Cottage Supabase record.
// Only used when Supabase is completely unreachable.
export const demoProperty: Property = {
  id: DEMO_PROPERTY_SUPABASE_ID,
  host_id: DEMO_HOST_ID,
  name: 'Deloraine Stone Cottage',
  type: 'cottage',
  address: '50 Konini Street, Whangarei, Northland, New Zealand 0112',
  city: 'Whangarei',
  country: 'New Zealand',
  bedrooms: 3,
  bathrooms: 1,
  max_guests: 6,
  base_price: 220,
  cleaning_fee: 75,
  tax_rate: 15,
  min_nights: 2,
  short_description: 'A peaceful stone cottage set in flowering rural gardens near Whangarei.',
  full_description:
    'Deloraine Stone Cottage is set in a beautiful rural landscape amongst flowering gardens. The cottage has three king bedrooms, a fully self-contained kitchen, dining for six, laundry facilities, flat-screen TV, outdoor pool access, fire pit, playground and peaceful garden views.',
  amenities: ['wifi', 'parking', 'pool', 'kitchen', 'ac', 'tv', 'washer', 'dryer', 'dishwasher', 'bbq', 'heating'],
  images: [],
  check_in_time: '15:00',
  check_out_time: '10:00',
  pets_allowed: false,
  smoking_allowed: false,
  events_allowed: false,
  accent_color: '#FF5A5F',
  theme: 'onepage',
  slug: 'delorainecottage',
  custom_domain: null,
  stripe_publishable_key: null,
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

export const demoSubscription: Subscription = {
  id: 'demo-subscription',
  host_id: DEMO_HOST_ID,
  plan: 'professional',
  status: 'trialing',
  trial_ends_at: new Date(Date.now() + 13 * 24 * 60 * 60 * 1000).toISOString(),
  created_at: new Date().toISOString(),
};

const demoStayLedger: DemoStaySeed[] = [
  {
    id: 'demo-stay-2025-06-06-ava',
    checkIn: '2025-06-06',
    nights: 2,
    nightlyRate: 235,
    guestName: 'Ava Thompson',
    guestEmail: 'ava.thompson@example.com',
    guestPhone: '+64 21 555 010',
    guests: 2,
    booked: '2025-05-12',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked for a late arrival after work.',
    review: {
      rating: 5,
      title: 'Warm, peaceful and easy',
      body: 'The cottage was warm, peaceful and exactly what we needed for a winter weekend. Vanessa made arrival simple and the local tips were genuinely useful.',
      featured: true,
      pinned: true,
      hostResponse: 'Thank you Ava. I am so pleased the cottage gave you an easy winter reset.',
    },
  },
  {
    id: 'demo-stay-2025-06-20-noah',
    checkIn: '2025-06-20',
    nights: 3,
    nightlyRate: 245,
    guestName: 'Noah Williams',
    guestEmail: 'noah.williams@example.com',
    guestPhone: '+64 22 555 011',
    guests: 4,
    booked: '2025-05-28',
    channel: 'Airbnb',
    guestLocation: 'Hamilton',
    notes: 'Family trip, asked whether the fire pit was available.',
  },
  {
    id: 'demo-stay-2025-07-04-mia',
    checkIn: '2025-07-04',
    nights: 2,
    nightlyRate: 250,
    guestName: 'Mia Brown',
    guestEmail: 'mia.brown@example.com',
    guestPhone: '+64 21 555 012',
    guests: 2,
    booked: '2025-06-10',
    channel: 'Direct',
    guestLocation: 'Wellington',
    notes: 'Wanted recommendations for rainy-day walks.',
    review: {
      rating: 4,
      title: 'Lovely cottage and easy check-in',
      body: 'The pre-arrival details were clear and check-in was straightforward. We especially appreciated the local tips and the quiet garden setting.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2025-07-18-lucas',
    checkIn: '2025-07-18',
    nights: 4,
    nightlyRate: 260,
    guestName: 'Lucas Wilson',
    guestEmail: 'lucas.wilson@example.com',
    guestPhone: '+64 27 555 013',
    guests: 5,
    booked: '2025-06-22',
    channel: 'Booking.com',
    guestLocation: 'Tauranga',
    notes: 'Children asked about playground and pool access.',
  },
  {
    id: 'demo-stay-2025-08-01-olivia',
    checkIn: '2025-08-01',
    nights: 3,
    nightlyRate: 255,
    guestName: 'Olivia Taylor',
    guestEmail: 'olivia.taylor@example.com',
    guestPhone: '+64 21 555 014',
    guests: 3,
    booked: '2025-07-02',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Celebrating an anniversary, asked for quiet dinner ideas.',
    review: {
      rating: 5,
      title: 'A private little retreat',
      body: 'Beautifully hosted and wonderfully quiet. We loved waking up to the gardens and being close enough to town for dinner.',
      source: 'direct',
      featured: true,
    },
  },
  {
    id: 'demo-stay-2025-08-15-jack',
    checkIn: '2025-08-15',
    nights: 2,
    nightlyRate: 260,
    guestName: 'Jack Martin',
    guestEmail: 'jack.martin@example.com',
    guestPhone: '+64 22 555 015',
    guests: 2,
    booked: '2025-07-24',
    channel: 'Airbnb',
    guestLocation: 'Kerikeri',
    notes: 'Asked for mountain biking spots nearby.',
  },
  {
    id: 'demo-stay-2025-09-05-grace',
    checkIn: '2025-09-05',
    nights: 3,
    nightlyRate: 280,
    guestName: 'Grace Lee',
    guestEmail: 'grace.lee@example.com',
    guestPhone: '+64 21 555 016',
    guests: 4,
    booked: '2025-08-11',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked about early check-in for a wedding nearby.',
    review: {
      rating: 5,
      title: 'Great base for a Northland weekend',
      body: 'The cottage was spotless, calm and beautifully prepared. It felt private without being far from Whangarei.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2025-09-19-theo',
    checkIn: '2025-09-19',
    nights: 4,
    nightlyRate: 285,
    guestName: 'Theo Harris',
    guestEmail: 'theo.harris@example.com',
    guestPhone: '+64 27 555 017',
    guests: 5,
    booked: '2025-08-21',
    channel: 'Booking.com',
    guestLocation: 'New Plymouth',
    notes: 'Asked about laundry access for a longer road trip.',
  },
  {
    id: 'demo-stay-2025-10-03-ruby',
    checkIn: '2025-10-03',
    nights: 2,
    nightlyRate: 295,
    guestName: 'Ruby Clark',
    guestEmail: 'ruby.clark@example.com',
    guestPhone: '+64 21 555 018',
    guests: 2,
    booked: '2025-09-10',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked whether a later checkout was possible.',
    review: {
      rating: 5,
      title: 'Peaceful and beautifully cared for',
      body: 'Everything felt thoughtful, from the welcome details to the local guide. We left feeling completely reset.',
      source: 'direct',
      hostResponse: 'Thank you Ruby. You were wonderful guests and are welcome back any time.',
    },
  },
  {
    id: 'demo-stay-2025-10-17-harper',
    checkIn: '2025-10-17',
    nights: 3,
    nightlyRate: 305,
    guestName: 'Harper Scott',
    guestEmail: 'harper.scott@example.com',
    guestPhone: '+64 22 555 019',
    guests: 4,
    booked: '2025-09-18',
    channel: 'Airbnb',
    guestLocation: 'Rotorua',
    notes: 'Asked for family-friendly walks and cafes.',
  },
  {
    id: 'demo-stay-2025-10-24-isla',
    checkIn: '2025-10-24',
    nights: 3,
    nightlyRate: 330,
    guestName: 'Isla Walker',
    guestEmail: 'isla.walker@example.com',
    guestPhone: '+64 21 555 020',
    guests: 4,
    booked: '2025-10-01',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Labour weekend stay, asked about garden seating.',
    review: {
      rating: 5,
      title: 'A perfect long weekend',
      body: 'A peaceful long weekend in a cottage that felt personal, private and very easy to settle into.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2025-11-07-leo',
    checkIn: '2025-11-07',
    nights: 2,
    nightlyRate: 320,
    guestName: 'Leo Young',
    guestEmail: 'leo.young@example.com',
    guestPhone: '+64 27 555 021',
    guests: 2,
    booked: '2025-10-08',
    channel: 'Direct',
    guestLocation: 'Whangarei',
    notes: 'Local anniversary getaway.',
  },
  {
    id: 'demo-stay-2025-11-21-sienna',
    checkIn: '2025-11-21',
    nights: 4,
    nightlyRate: 335,
    guestName: 'Sienna King',
    guestEmail: 'sienna.king@example.com',
    guestPhone: '+64 21 555 022',
    guests: 5,
    booked: '2025-10-24',
    channel: 'Booking.com',
    guestLocation: 'Auckland',
    notes: 'Group asked about cooking facilities and parking.',
  },
  {
    id: 'demo-stay-2025-12-05-mila',
    checkIn: '2025-12-05',
    nights: 3,
    nightlyRate: 405,
    guestName: 'Mila Wright',
    guestEmail: 'mila.wright@example.com',
    guestPhone: '+64 21 555 023',
    guests: 4,
    booked: '2025-11-02',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked for beach recommendations and local markets.',
    review: {
      rating: 5,
      title: 'Summer started properly',
      body: 'Quiet mornings, beautiful gardens and easy access to Whangarei. The cottage was even lovelier than the photos.',
      source: 'direct',
      featured: true,
    },
  },
  {
    id: 'demo-stay-2025-12-20-emily',
    checkIn: '2025-12-20',
    nights: 5,
    nightlyRate: 495,
    guestName: 'Emily Green',
    guestEmail: 'emily.green@example.com',
    guestPhone: '+64 22 555 024',
    guests: 6,
    booked: '2025-10-30',
    channel: 'Direct',
    guestLocation: 'Wellington',
    notes: 'Christmas family stay, asked about kitchen equipment.',
    review: {
      rating: 5,
      title: 'Christmas at the cottage was magic',
      body: 'The cottage made our Christmas feel relaxed and special. Plenty of space, lovely gardens and thoughtful hosting from start to finish.',
      source: 'direct',
      pinned: true,
    },
  },
  {
    id: 'demo-stay-2025-12-28-daniel',
    checkIn: '2025-12-28',
    nights: 4,
    nightlyRate: 510,
    guestName: 'Daniel Hall',
    guestEmail: 'daniel.hall@example.com',
    guestPhone: '+64 21 555 025',
    guests: 4,
    booked: '2025-11-12',
    channel: 'Airbnb',
    guestLocation: 'Christchurch',
    notes: 'New Year stay, asked about restaurants open nearby.',
  },
  {
    id: 'demo-stay-2026-01-03-riley',
    checkIn: '2026-01-03',
    nights: 5,
    nightlyRate: 520,
    guestName: 'Riley Guest',
    guestEmail: 'riley.guest@example.com',
    guestPhone: '+64 21 555 026',
    guests: 4,
    booked: '2025-11-28',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Returning guest, asked to revisit Abbey Caves.',
    review: {
      rating: 5,
      title: 'Even better the second time',
      body: 'We came back because the first stay was so easy. Deloraine is peaceful, beautifully kept and the direct booking process was simple.',
      source: 'direct',
      featured: true,
    },
  },
  {
    id: 'demo-stay-2026-01-16-zoe',
    checkIn: '2026-01-16',
    nights: 3,
    nightlyRate: 500,
    guestName: 'Zoe Adams',
    guestEmail: 'zoe.adams@example.com',
    guestPhone: '+64 22 555 027',
    guests: 3,
    booked: '2025-12-08',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked about child-friendly swimming spots.',
  },
  {
    id: 'demo-stay-2026-01-24-ethan',
    checkIn: '2026-01-24',
    nights: 4,
    nightlyRate: 515,
    guestName: 'Ethan Baker',
    guestEmail: 'ethan.baker@example.com',
    guestPhone: '+64 21 555 028',
    guests: 5,
    booked: '2025-12-18',
    channel: 'Booking.com',
    guestLocation: 'Auckland',
    notes: 'Auckland Anniversary weekend, asked about parking for two cars.',
  },
  {
    id: 'demo-stay-2026-02-06-aria',
    checkIn: '2026-02-06',
    nights: 3,
    nightlyRate: 480,
    guestName: 'Aria Hill',
    guestEmail: 'aria.hill@example.com',
    guestPhone: '+64 27 555 029',
    guests: 4,
    booked: '2026-01-04',
    channel: 'Direct',
    guestLocation: 'Hamilton',
    notes: 'Waitangi weekend stay, asked for beach day ideas.',
    review: {
      rating: 5,
      title: 'Beautiful Waitangi weekend',
      body: 'A great location for exploring Northland while still having a quiet place to come home to each evening.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2026-02-20-mason',
    checkIn: '2026-02-20',
    nights: 2,
    nightlyRate: 430,
    guestName: 'Mason Roberts',
    guestEmail: 'mason.roberts@example.com',
    guestPhone: '+64 21 555 030',
    guests: 2,
    booked: '2026-01-24',
    channel: 'Airbnb',
    guestLocation: 'Auckland',
    notes: 'Asked about a local winery stop on the way north.',
  },
  {
    id: 'demo-stay-2026-03-06-lily',
    checkIn: '2026-03-06',
    nights: 3,
    nightlyRate: 380,
    guestName: 'Lily Evans',
    guestEmail: 'lily.evans@example.com',
    guestPhone: '+64 22 555 031',
    guests: 3,
    booked: '2026-02-10',
    channel: 'Direct',
    guestLocation: 'Tauranga',
    notes: 'Asked about scenic lookouts for sunset.',
    review: {
      rating: 4,
      title: 'Quiet and well hosted',
      body: 'A lovely stay with clear communication and a peaceful garden setting. The local guidebook was a nice touch.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2026-03-20-oscar',
    checkIn: '2026-03-20',
    nights: 2,
    nightlyRate: 360,
    guestName: 'Oscar Turner',
    guestEmail: 'oscar.turner@example.com',
    guestPhone: '+64 21 555 032',
    guests: 2,
    booked: '2026-02-24',
    channel: 'Booking.com',
    guestLocation: 'Rotorua',
    notes: 'Asked whether the cottage suited a quiet work retreat.',
  },
  {
    id: 'demo-stay-2026-04-03-charlotte',
    checkIn: '2026-04-03',
    nights: 4,
    nightlyRate: 375,
    guestName: 'Charlotte Reed',
    guestEmail: 'charlotte.reed@example.com',
    guestPhone: '+64 21 555 033',
    guests: 4,
    booked: '2026-03-01',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Easter break, asked about family-friendly hikes.',
    review: {
      rating: 5,
      title: 'A restful Easter break',
      body: 'The setting is calm and private, and the cottage had everything our family needed. We would happily book direct again.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2026-04-17-henry',
    checkIn: '2026-04-17',
    nights: 3,
    nightlyRate: 370,
    guestName: 'Henry Bell',
    guestEmail: 'henry.bell@example.com',
    guestPhone: '+64 22 555 034',
    guests: 3,
    booked: '2026-03-19',
    channel: 'Airbnb',
    guestLocation: 'Napier',
    notes: 'Asked about EV charging nearby.',
  },
  {
    id: 'demo-stay-2026-04-30-jamie-alex',
    checkIn: '2026-04-30',
    nights: 3,
    nightlyRate: 285,
    discount: 120,
    promoCode: 'MIDWEEK',
    promoId: '2',
    promoName: 'Midweek Escape',
    promoDiscountType: 'fixed',
    promoDiscountValue: 45,
    guestName: 'Jamie & Alex',
    guestEmail: 'jamie.alex@example.com',
    guestPhone: '+64 21 555 035',
    guests: 2,
    booked: '2026-04-01',
    channel: 'Direct',
    guestLocation: 'Whangarei',
    notes: 'Local repeat enquiry converted after a direct-link share.',
    review: {
      rating: 5,
      title: 'Such an easy local getaway',
      body: 'We wanted somewhere nearby that still felt like an escape. Deloraine was exactly that.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2026-05-04-jordan-casey',
    checkIn: '2026-05-04',
    nights: 4,
    nightlyRate: 305,
    guestName: 'Jordan & Casey',
    guestEmail: 'jordan.casey@example.com',
    guestPhone: '+64 22 555 036',
    guests: 5,
    booked: '2026-04-10',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Asked about pool access and check-in instructions.',
    review: {
      rating: 5,
      title: 'Perfect for our family',
      body: 'The beds were comfortable, the kitchen was well set up and the kids loved the garden. Communication was excellent.',
      source: 'direct',
    },
  },
  {
    id: 'demo-stay-2026-05-08-riley',
    checkIn: '2026-05-08',
    nights: 3,
    nightlyRate: 310,
    discount: 85,
    promoCode: 'DIRECT10',
    promoId: '1',
    promoName: 'Book Direct Welcome',
    promoDiscountType: 'percentage',
    promoDiscountValue: 10,
    guestName: 'Riley Guest',
    guestEmail: 'riley.guest@example.com',
    guestPhone: '+64 21 555 026',
    guests: 4,
    booked: '2026-04-20',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Returning guest. Arriving after 6pm and asked about the pool.',
    review: {
      rating: 5,
      title: 'Peaceful, private and beautifully presented',
      body: 'The perfect weekend escape. Peaceful, private and beautifully presented. We loved coming back to Deloraine.',
      source: 'direct',
      featured: true,
      hostResponse: 'Thank you Riley, it is always lovely to host you.',
    },
  },
  {
    id: 'demo-stay-2026-05-15-taylor-family',
    checkIn: '2026-05-15',
    nights: 2,
    nightlyRate: 320,
    guestName: 'Taylor Family',
    guestEmail: 'taylor.family@example.com',
    guestPhone: '+64 22 555 037',
    guests: 3,
    booked: '2026-04-24',
    channel: 'Airbnb',
    guestLocation: 'Kerikeri',
    notes: 'Asked for a cot and nearby cafe recommendations.',
    review: {
      rating: 4,
      title: 'Comfortable family stay',
      body: 'A comfortable stay with helpful communication. The local recommendations made planning our weekend much easier.',
      source: 'airbnb',
    },
  },
  {
    id: 'demo-stay-2026-05-22-leo-example',
    checkIn: '2026-05-22',
    nights: 2,
    nightlyRate: 315,
    guestName: 'Leo Example',
    guestEmail: 'leo.example@example.com',
    guestPhone: '+64 27 555 038',
    guests: 2,
    booked: '2026-04-26',
    channel: 'Direct',
    guestLocation: 'Auckland',
    notes: 'Wants early check-in if available.',
  },
  {
    id: 'demo-stay-2026-06-04-margaret',
    checkIn: '2026-06-04',
    nights: 2,
    nightlyRate: 285,
    guestName: 'Margaret Leslie',
    guestEmail: 'margaret.leslie@example.com',
    guestPhone: '+64 21 555 039',
    guests: 2,
    booked: '2026-04-20',
    channel: 'Booking.com',
    guestLocation: 'Auckland',
    status: 'cancelled',
    paymentStatus: 'refunded',
    notes: 'Cancelled after payment confusion; refunded in full.',
  },
  {
    id: 'demo-stay-2026-06-05-sophie',
    checkIn: '2026-06-05',
    nights: 3,
    nightlyRate: 290,
    guestName: 'Sophie Carter',
    guestEmail: 'sophie.carter@example.com',
    guestPhone: '+64 21 555 040',
    guests: 2,
    booked: '2026-05-05',
    channel: 'Direct',
    guestLocation: 'Wellington',
    paymentStatus: 'pending',
    notes: 'Asked for a balance payment link and local dinner spots.',
  },
  {
    id: 'demo-stay-2026-06-20-nick',
    checkIn: '2026-06-20',
    nights: 3,
    nightlyRate: 330,
    guestName: 'Nick Chen',
    guestEmail: 'nick.chen@example.com',
    guestPhone: '+64 22 555 041',
    guests: 4,
    booked: '2026-05-18',
    channel: 'Direct',
    guestLocation: 'Auckland',
    paymentStatus: 'pending',
    notes: 'School holiday family stay, asked about Abbey Caves.',
  },
  {
    id: 'demo-stay-2026-07-10-priya',
    checkIn: '2026-07-10',
    nights: 4,
    nightlyRate: 350,
    guestName: 'Priya Singh',
    guestEmail: 'priya.singh@example.com',
    guestPhone: '+64 21 555 042',
    guests: 4,
    booked: '2026-05-22',
    channel: 'Direct',
    guestLocation: 'Christchurch',
    paymentStatus: 'pending',
    notes: 'Winter school holiday booking; wants a rainy-day itinerary.',
  },
];

function datePlusDays(date: string, days: number) {
  const next = new Date(`${date}T00:00:00`);
  next.setDate(next.getDate() + days);
  return next.toISOString().slice(0, 10);
}

function stayTotal(stay: DemoStaySeed) {
  const cleaning = stay.cleaningFee ?? demoProperty.cleaning_fee;
  return Math.max(0, Math.round(stay.nightlyRate * stay.nights + cleaning - (stay.discount || 0)));
}

function reviewSourceFor(stay: DemoStaySeed): DemoReviewRecord['source'] {
  if (stay.review?.source) return stay.review.source;
  if (stay.channel === 'Airbnb') return 'airbnb';
  if (stay.channel === 'Booking.com') return 'booking_com';
  return 'direct';
}

function reviewSourceForBooking(booking: Booking): DemoReviewRecord['source'] {
  const channel = String((booking as unknown as { channel?: string }).channel || '').toLowerCase();
  if (channel.includes('airbnb')) return 'airbnb';
  if (channel.includes('booking')) return 'booking_com';
  return 'direct';
}

function demoUpsellsForStay(stay: DemoStaySeed) {
  const selected: Array<Record<string, unknown>> = [];
  const add = (id: number, icon: string, name: string, description: string, price: number, imageUrl: string, source: 'checkout' | 'manual' | 'check_in_email' = 'checkout') => {
    selected.push({
      id,
      icon,
      name,
      description,
      price,
      priceType: 'flat',
      quantity: 1,
      source,
      addedAt: `${stay.booked}T11:30:00.000Z`,
      imageUrl,
      paymentState: stay.paymentStatus === 'pending' ? 'pending' : 'paid',
      addedBy: source === 'checkout' ? 'guest' : source === 'manual' ? 'host' : 'automation',
      chargeMode: source === 'checkout' ? 'pay_now' : 'add_to_balance',
      basePrice: price,
      calculatedPrice: price,
    });
  };
  if (stay.channel === 'Direct' && stay.guests <= 2) {
    add(1, '🧺', 'Breakfast Hamper', 'Local bread, eggs, preserves, fruit and coffee ready for arrival.', 65, '/upsells/breakfast-hamper.jpg');
  }
  if (/fire pit|winter|family|school/i.test(stay.notes || '') || stay.guests >= 4) {
    add(2, '🔥', 'Fire Pit Bundle', 'Firewood, kindling and marshmallows for an evening outside.', 35, '/upsells/fire-pit-bundle.jpg', stay.channel === 'Direct' ? 'checkout' : 'manual');
  }
  if (stay.nights >= 4) {
    add(3, '🧹', 'Mid-stay Refresh', 'Fresh towels, linen change and a quick reset for longer stays.', 95, '/upsells/mid-stay-refresh.jpg', 'check_in_email');
  }
  if (stay.channel === 'Direct' && stay.checkIn >= '2025-12-01' && stay.checkIn <= '2026-03-31') {
    add(4, '🍷', 'Local Wine & Cheese', 'A handpicked selection of local wine and cheese on arrival.', 55, '/upsells/local-wine-cheese.jpg');
  }
  return selected;
}

function bookingFromStay(stay: DemoStaySeed): Booking {
  const upsells = demoUpsellsForStay(stay);
  const upsellTotal = upsells.reduce((sum, upsell) => sum + Number(upsell.price || 0) * Number(upsell.quantity || 1), 0);
  const total = stayTotal(stay) + upsellTotal;
  const discount = stay.discount || 0;
  const promoCode = stay.promoCode || (discount > 0 && stay.channel === 'Direct' ? 'DIRECT10' : '');
  const booking: Record<string, unknown> = {
    id: stay.id,
    property_id: DEMO_PROPERTY_SUPABASE_ID,
    host_id: DEMO_HOST_ID,
    guest_name: stay.guestName,
    guest_email: stay.guestEmail,
    guest_phone: stay.guestPhone,
    check_in: stay.checkIn,
    check_out: datePlusDays(stay.checkIn, stay.nights),
    guests: stay.guests,
    nights: stay.nights,
    total,
    status: stay.status || 'confirmed',
    payment_status: stay.paymentStatus || (stay.checkIn < '2026-05-26' ? 'paid' : 'pending'),
    notes: stay.notes || '',
    booking_date: stay.booked,
    created_at: `${stay.booked}T10:00:00.000Z`,
    channel: stay.channel,
    guest_location: stay.guestLocation,
    cleaning_fee: stay.cleaningFee ?? demoProperty.cleaning_fee,
    discount_amount: stay.discount || 0,
    room_rate: stay.nightlyRate * stay.nights,
    upsells,
    upsell_total: upsellTotal,
  };
  if (promoCode && discount > 0) {
    booking.total_before_discount = total + discount;
    booking.promotion_id = stay.promoId || (promoCode === 'MIDWEEK' ? '2' : '1');
    booking.promotion_code = promoCode;
    booking.promotion_discount = discount;
    booking.promotion_snapshot = {
      id: booking.promotion_id,
      code: promoCode,
      name: stay.promoName || (promoCode === 'MIDWEEK' ? 'Midweek Escape' : 'Book Direct Welcome'),
      discount_type: stay.promoDiscountType || (promoCode === 'MIDWEEK' ? 'fixed' : 'percentage'),
      discount_value: stay.promoDiscountValue ?? (promoCode === 'MIDWEEK' ? 45 : 10),
    };
  }
  return booking as Booking;
}

function makeDemoEarningsBookings(): Booking[] {
  return demoStayLedger.map(bookingFromStay);
}

function isCompletedPaidStay(booking: Booking, now = '2026-05-26') {
  return booking.status === 'confirmed' && booking.payment_status === 'paid' && booking.check_out <= now;
}

function resetDemoDerivedCaches() {
  if (typeof localStorage === 'undefined') return;
  [
    'staydirect_demo_booking_management',
    'staydirect_demo_inbox_threads',
    'staydirect_demo_notifications_seeded_v3',
    'staydirect_dashboard_notifications',
    'staydirect_dashboard_notifications:demo@staydirect.local',
  ].forEach((key) => localStorage.removeItem(key));
}

function persistCanonicalDemoBookings() {
  const next = makeDemoEarningsBookings();
  localStorage.setItem(BOOKINGS_KEY, JSON.stringify(next));
  localStorage.setItem(DEMO_DATA_VERSION_KEY, DEMO_DATA_VERSION);
  resetDemoDerivedCaches();
  return next;
}

function demoBookingsAreCoherent(bookings: Booking[]) {
  if (bookings.length < 30) return false;
  if (bookings.some((booking) => LEGACY_DEMO_BOOKING_PATTERN.test(JSON.stringify(booking)))) return false;
  if (bookings.some((booking) => booking.property_id && booking.property_id !== DEMO_PROPERTY_SUPABASE_ID)) return false;
  const ids = new Set(bookings.map((booking) => booking.id));
  return demoStayLedger.every((stay) => ids.has(stay.id));
}

/**
 * Synchronous fallback for places that need immediate demo data.
 * It reads the saved imported demo property first, then falls back to a
 * photo-empty shell. Photos should come from host uploads or scraper imports,
 * never from a baked-in dashboard gallery.
 */
export function getDemoProperty(): Property {
  const stored = getStoredDemoProperty();
  if (stored && hasDeloraineWebsitePhotos(stored.images)) {
    return stored;
  }

  const next = mergeImportedProperty(stored ?? demoProperty, getDeloraineDemoImport());
  saveDemoProperty(next);
  return next;
}

/**
 * Loads the demo property, then imports Deloraine from the scraper when the
 * saved record has not yet been populated with website photos. This mirrors
 * the real flow: dashboard photos are uploaded by the host or created by a
 * website import, and the website reads from that saved property data.
 */
export async function fetchDemoProperty(): Promise<Property> {
  let baseProperty = getStoredDemoProperty() ?? demoProperty;

  try {
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .eq('slug', 'delorainecottage')
      .maybeSingle();

    if (!error && data) {
      baseProperty = { ...data, images: usableImages(data.images) } as Property;
      console.log('[StayDirect] Demo property loaded from Supabase:', {
        source: 'supabase',
        propertyId: baseProperty.id,
        propertyName: baseProperty.name,
        photoCount: baseProperty.images?.length ?? 0,
        slug: baseProperty.slug,
      });
    }
  } catch { /* network error — fall through to offline fallback */ }

  if (hasDeloraineWebsitePhotos(baseProperty.images)) {
    return baseProperty;
  }

  try {
    const response = await fetch(apiUrl(`/api/scrape?url=${encodeURIComponent(DEMO_IMPORT_URL)}`));
    const imported = (await response.json()) as DemoImportResult & { error?: string };
    if (response.ok && !imported.error) {
      const next = mergeImportedProperty(baseProperty, imported);
      if (hasDeloraineWebsitePhotos(next.images)) {
        saveDemoProperty(next);
        supabase
          .from('properties')
          .update({
            name: next.name,
            address: next.address,
            city: next.city,
            country: next.country,
            bedrooms: next.bedrooms,
            bathrooms: next.bathrooms,
            max_guests: next.max_guests,
            base_price: next.base_price,
            short_description: next.short_description,
            full_description: next.full_description,
            amenities: next.amenities,
            images: next.images,
            updated_at: next.updated_at,
          })
          .eq('id', next.id)
          .then(({ error: syncError }) => {
            if (syncError) {
              console.info('[StayDirect] Demo import saved locally; database sync skipped:', syncError.message);
            }
          });
        return next;
      }
    }
  } catch {
    // The dashboard still works with the stored property or empty-photo fallback.
  }

  if (!hasDeloraineWebsitePhotos(baseProperty.images)) {
    const next = mergeImportedProperty(baseProperty, getDeloraineDemoImport());
    saveDemoProperty(next);
    supabase
      .from('properties')
      .update({
        name: next.name,
        address: next.address,
        city: next.city,
        country: next.country,
        bedrooms: next.bedrooms,
        bathrooms: next.bathrooms,
        max_guests: next.max_guests,
        base_price: next.base_price,
        short_description: next.short_description,
        full_description: next.full_description,
        amenities: next.amenities,
        images: next.images,
        updated_at: next.updated_at,
      })
      .eq('id', next.id)
      .then(({ error: syncError }) => {
        if (syncError) {
          console.info('[StayDirect] Demo website photos saved locally; database sync skipped:', syncError.message);
        }
      });
    return next;
  }

  return baseProperty;
}

export function saveDemoProperty(property: Partial<Property>) {
  const next = { ...demoProperty, ...property, updated_at: new Date().toISOString() };
  localStorage.setItem(PROPERTY_KEY, JSON.stringify(next));
  return next;
}

export function getDemoBookings(): Booking[] {
  if (typeof localStorage === 'undefined') return makeDemoEarningsBookings();
  if (localStorage.getItem(DEMO_DATA_VERSION_KEY) !== DEMO_DATA_VERSION) {
    return persistCanonicalDemoBookings();
  }
  const stored = localStorage.getItem(BOOKINGS_KEY);
  if (!stored) return persistCanonicalDemoBookings();
  try {
    const parsed = JSON.parse(stored) as Booking[];
    if (!demoBookingsAreCoherent(parsed)) return persistCanonicalDemoBookings();
    return parsed;
  } catch {
    return persistCanonicalDemoBookings();
  }
}

export function saveDemoBookings(bookings: Booking[]) {
  localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
  localStorage.setItem(DEMO_DATA_VERSION_KEY, DEMO_DATA_VERSION);
  window.dispatchEvent(new CustomEvent('staydirect-bookings-updated'));
}

export function reseedDemoData() {
  return persistCanonicalDemoBookings();
}

export function getDemoReviews(): DemoReviewRecord[] {
  const bookingsById = new Map(getDemoBookings().map((booking) => [booking.id, booking]));
  return demoStayLedger
    .filter((stay) => stay.review)
    .map((stay, index) => {
      const booking = bookingsById.get(stay.id) || bookingFromStay(stay);
      const createdAt = `${datePlusDays(booking.check_out, 2)}T19:30:00.000Z`;
      const approved = index !== 2;
      return {
        id: `demo-review-${booking.id}`,
        property_id: DEMO_PROPERTY_SUPABASE_ID,
        booking_id: booking.id,
        guest_id: null,
        rating: stay.review!.rating,
        title: stay.review!.title,
        body: stay.review!.body,
        status: approved ? 'approved' : 'pending',
        host_response: stay.review!.hostResponse ?? null,
        host_responded_at: stay.review!.hostResponse ? `${datePlusDays(booking.check_out, 3)}T09:00:00.000Z` : null,
        source: reviewSourceFor(stay),
        featured: Boolean(stay.review!.featured),
        pinned: Boolean(stay.review!.pinned),
        published_at: approved ? `${datePlusDays(booking.check_out, 2)}T20:00:00.000Z` : null,
        created_at: createdAt,
        bookings: {
          guest_name: booking.guest_name,
          guest_email: booking.guest_email,
          check_in: booking.check_in,
          check_out: booking.check_out,
        },
      } satisfies DemoReviewRecord;
    })
    .filter((review) => {
      const booking = bookingsById.get(review.booking_id);
      return booking ? isCompletedPaidStay(booking) : false;
    })
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function getDemoReviewRequests(): DemoReviewRequestRecord[] {
  const reviewed = new Set(getDemoReviews().map((review) => review.booking_id));
  return getDemoBookings()
    .filter((booking) => isCompletedPaidStay(booking) && !reviewed.has(booking.id))
    .slice(0, 3)
    .map((booking, index) => ({
      id: `demo-review-request-${booking.id}`,
      property_id: DEMO_PROPERTY_SUPABASE_ID,
      booking_id: booking.id,
      host_id: DEMO_HOST_ID,
      guest_email: booking.guest_email,
      guest_name: booking.guest_name,
      source: reviewSourceForBooking(booking),
      status: index === 0 ? 'scheduled' : 'sent',
      send_after: `${datePlusDays(booking.check_out, 2)}T10:00:00.000Z`,
      sent_at: index === 0 ? null : `${datePlusDays(booking.check_out, 2)}T10:05:00.000Z`,
      reminder_after: `${datePlusDays(booking.check_out, 5)}T10:00:00.000Z`,
      reminded_at: null,
      token: `demo-review-token-${booking.id}`,
      created_at: `${datePlusDays(booking.check_out, 1)}T08:00:00.000Z`,
    }));
}

export function getDemoReviewEligibleBookings() {
  const reviewed = new Set(getDemoReviews().map((review) => review.booking_id));
  const requested = new Set(getDemoReviewRequests().map((request) => request.booking_id));
  return getDemoBookings()
    .filter((booking) => isCompletedPaidStay(booking) && !reviewed.has(booking.id) && !requested.has(booking.id))
    .sort((a, b) => new Date(b.check_out).getTime() - new Date(a.check_out).getTime());
}

export function getDemoDashboardNotifications() {
  const bookings = getDemoBookings();
  const nextArrival = bookings
    .filter((booking) => booking.status === 'confirmed' && booking.check_in >= '2026-05-26')
    .sort((a, b) => a.check_in.localeCompare(b.check_in))[0];
  const pendingPayment = bookings
    .filter((booking) => booking.status === 'confirmed' && booking.payment_status === 'pending')
    .sort((a, b) => a.check_in.localeCompare(b.check_in))[0];
  const latestReview = getDemoReviews()[0];
  const notifications = [];
  if (pendingPayment) {
    notifications.push({
      id: `demo-payment-${pendingPayment.id}`,
      type: 'payment',
      title: 'Payment due',
      body: `${pendingPayment.guest_name} has a balance due before check-in.`,
      actionPath: `/dashboard/bookings?reservation=${pendingPayment.id}`,
      createdAt: '2026-05-25T09:20:00.000Z',
      read: false,
    });
  }
  if (nextArrival) {
    notifications.push({
      id: `demo-arrival-${nextArrival.id}`,
      type: 'booking',
      title: 'Upcoming arrival',
      body: `${nextArrival.guest_name} arrives on ${nextArrival.check_in}.`,
      actionPath: `/dashboard/bookings?reservation=${nextArrival.id}`,
      createdAt: '2026-05-25T08:45:00.000Z',
      read: false,
    });
  }
  if (latestReview) {
    notifications.push({
      id: `demo-review-${latestReview.booking_id}`,
      type: 'message',
      title: 'New guest review',
      body: `${latestReview.bookings.guest_name} left a ${latestReview.rating}-star review.`,
      actionPath: '/dashboard/reviews',
      createdAt: latestReview.created_at,
      read: true,
    });
  }
  notifications.push({
    id: 'demo-calendar-sync-current',
    type: 'calendar',
    title: 'Calendar sync',
    body: 'Direct and channel reservations are aligned for the demo calendar.',
    actionPath: '/dashboard/calendar',
    createdAt: '2026-05-25T08:15:00.000Z',
    read: true,
  });
  return notifications;
}
