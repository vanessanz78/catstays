import type { Booking, Property, Subscription } from './supabase';
import { deloraineDemoSite, getDeloraineDemoImport } from './deloraineDemoSite';

export const LOCAL_AUTH_KEY = 'staydirect_local_host_auth';
export const LOCAL_PROPERTY_KEY = 'staydirect_local_property';
export const LOCAL_BOOKINGS_KEY = 'staydirect_local_bookings';
export const LOCAL_IMPORT_CACHE_KEY = 'staydirect_last_imported_property';
export const LOCAL_SIGNUP_DRAFT_KEY = 'staydirect_signup_draft';
export const LOCAL_HOST_ID = 'local-host';
export const DELORAINE_LOCAL_HOSTNAME = 'delorainecottage.localhost';
export const DELORAINE_HOST_EMAIL = 'hello@delorainecottage.com';
export const DELORAINE_HOST_PASSWORD = '50KONINI';
const DELORAINE_LOCAL_PROPERTY_ID = 'delorainecottage-live';
const DELORAINE_LATITUDE = -35.72672507320615;
const DELORAINE_LONGITUDE = 174.357262638811;

type UserLike = {
  id?: string;
  app_metadata?: Record<string, unknown>;
};

type SignupDraft = {
  name?: string;
  email?: string;
  propertyName?: string;
  subdomain?: string;
  slug?: string;
};

type PropertyDraft = Partial<Property> & {
  name?: string;
  propertyName?: string;
};

export type ImportedPropertyDraft = {
  name?: string;
  shortDescription?: string;
  fullDescription?: string;
  city?: string;
  country?: string;
  address?: string;
  suburb?: string;
  images?: string[];
  amenities?: string[];
  amenityDetails?: string[];
  bedrooms?: number | null;
  bathrooms?: number | null;
  maxGuests?: number | null;
  basePrice?: number | null;
  brandColor?: string;
  checkInTime?: string;
  checkOutTime?: string;
  contactEmail?: string;
  contactPhone?: string;
  email?: string;
  phone?: string;
  cleaningFee?: number | null;
  taxRate?: number | null;
  minNights?: number | null;
  petsAllowed?: boolean;
  smokingAllowed?: boolean;
  eventsAllowed?: boolean;
  houseRules?: string[];
  rules?: string[];
  sourceUrl?: string;
};

const fallbackDate = () => new Date().toISOString();

const localAmenityMatchers: Array<[string, RegExp]> = [
  ['wifi', /wi[-\s]?fi|wireless|internet|broadband/i],
  ['parking', /parking|garage|car\s?park/i],
  ['pool', /pool|swimming/i],
  ['kitchen', /kitchen|self[-\s]?contained|cooking|cooktop|oven|microwave|fridge/i],
  ['ac', /air\s?conditioning|a\/c|cooling/i],
  ['tv', /\btv\b|television|satellite/i],
  ['washer', /washer|washing machine|laundry/i],
  ['dryer', /dryer|clothes dryer/i],
  ['dishwasher', /dishwasher/i],
  ['workspace', /workspace|desk|office/i],
  ['gym', /gym|fitness/i],
  ['bbq', /bbq|barbecue|barbeque/i],
  ['fireplace', /fireplace|fire pit|wood burner|woodburner/i],
  ['hottub', /hot\s?tub|spa|jacuzzi/i],
  ['heating', /heating|heater|heat pump/i],
];

function normaliseLocalAmenities(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  const result = new Set<string>();
  values.forEach((value) => {
    if (typeof value !== 'string') return;
    const compact = value.toLowerCase().replace(/[^a-z0-9]+/g, '');
    const exact = localAmenityMatchers.find(([key]) => key === compact);
    if (exact) {
      result.add(exact[0]);
      return;
    }

    const match = localAmenityMatchers.find(([, pattern]) => pattern.test(value));
    if (match) result.add(match[0]);
  });
  return Array.from(result);
}

function readJsonStorage<T>(storage: Storage | undefined, key: string): T | null {
  if (!storage) return null;
  const stored = storage.getItem(key);
  if (!stored) return null;
  try {
    return JSON.parse(stored) as T;
  } catch {
    return null;
  }
}

function browserStorage() {
  if (typeof window === 'undefined') return { local: undefined, session: undefined };
  return { local: window.localStorage, session: window.sessionStorage };
}

export function cacheImportedProperty(data: unknown) {
  const { local } = browserStorage();
  if (!local) return;
  local.setItem(LOCAL_IMPORT_CACHE_KEY, JSON.stringify(data));
  const sourceUrl = typeof data === 'object' && data !== null && 'sourceUrl' in data
    ? (data as { sourceUrl?: unknown }).sourceUrl
    : null;
  if (typeof sourceUrl === 'string' && sourceUrl.trim()) {
    local.setItem('staydirect_import_url', sourceUrl);
  }
}

export function readImportedProperty(): ImportedPropertyDraft | null {
  const { local, session } = browserStorage();
  return (
    readJsonStorage<ImportedPropertyDraft>(local, LOCAL_IMPORT_CACHE_KEY) ||
    readJsonStorage<ImportedPropertyDraft>(local, 'staydirect_preview_data') ||
    readJsonStorage<ImportedPropertyDraft>(session, 'staydirect_preview_data')
  );
}

export function readSignupDraft(): SignupDraft {
  const { local, session } = browserStorage();
  const stored = session?.getItem(LOCAL_SIGNUP_DRAFT_KEY) || local?.getItem(LOCAL_SIGNUP_DRAFT_KEY);
  if (!stored) return {};
  try {
    return JSON.parse(stored) as SignupDraft;
  } catch {
    return {};
  }
}

function text(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function sameText(a: string, b: string): boolean {
  return Boolean(a && b && a.toLowerCase() === b.toLowerCase());
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function uniqueImages(values: Array<string | undefined | null>): string[] {
  return Array.from(new Set(values.filter((value): value is string => Boolean(value?.trim()))));
}

function isPlaceholderLocalProperty(property: PropertyDraft | null | undefined): boolean {
  if (!property) return true;
  const name = text(property.name || property.propertyName).toLowerCase();
  const slug = text(property.slug).toLowerCase();
  const hasRealCore =
    Boolean(text(property.full_description)) &&
    Boolean(property.images?.length) &&
    Number(property.base_price || 0) > 0 &&
    Boolean(text(property.contact_email));

  return (
    !hasRealCore ||
    !name ||
    name === 'your property' ||
    name === 'my property' ||
    name === 'cottage in whangarei' ||
    name.includes('loft') ||
    (Boolean(slug) && slug !== 'delorainecottage')
  );
}

function makeDeloraineSeedInput(input: PropertyDraft = {}): PropertyDraft {
  const imported = getDeloraineDemoImport();
  const images = uniqueImages([
    deloraineDemoSite.logoImage,
    deloraineDemoSite.heroImage,
    deloraineDemoSite.heroAltImage,
    ...deloraineDemoSite.galleryImages.map(([, image]) => image),
    ...(imported.images || []),
  ]);

  return {
    ...input,
    id: DELORAINE_LOCAL_PROPERTY_ID,
    host_id: LOCAL_HOST_ID,
    name: deloraineDemoSite.name,
    propertyName: deloraineDemoSite.name,
    type: deloraineDemoSite.type,
    address: deloraineDemoSite.address,
    suburb: '',
    city: deloraineDemoSite.city,
    country: deloraineDemoSite.country,
    bedrooms: deloraineDemoSite.bedrooms,
    bathrooms: deloraineDemoSite.bathrooms,
    max_guests: deloraineDemoSite.maxGuests,
    base_price: deloraineDemoSite.basePrice,
    cleaning_fee: deloraineDemoSite.cleaningFee,
    tax_rate: deloraineDemoSite.taxRate,
    min_nights: deloraineDemoSite.minNights,
    short_description: deloraineDemoSite.shortDescription,
    full_description: [
      deloraineDemoSite.fullDescription,
      'Relish the peace and quiet, apart from native bird song, with Tui and Kereru being frequent visitors.',
      'Enjoy garden views, comfortable bedrooms, a self-contained kitchen and the simple confidence of booking directly.',
    ].join('\n\n'),
    amenities: deloraineDemoSite.amenities,
    images,
    check_in_time: '03:00 PM',
    check_out_time: '10:00 AM',
    pets_allowed: false,
    smoking_allowed: false,
    events_allowed: false,
    accent_color: deloraineDemoSite.palette.accent,
    theme: 'source-match',
    slug: 'delorainecottage',
    custom_domain: 'delorainecottage.staydirect.nz',
    marketplace_enabled: true,
    marketplace_status: 'published',
    marketplace_headline: 'A country cottage beside flowering gardens',
    marketplace_short_description:
      'A peaceful stone cottage set in flowering rural gardens near Whangarei, with king bedrooms, indoor-outdoor living, garden views and direct booking.',
    marketplace_featured_image: deloraineDemoSite.heroImage,
    marketplace_category: 'family-friendly',
    marketplace_tags: ['northland', 'whangarei', 'hidden-gem', 'country-cottage', 'garden-stay', 'family-friendly'],
    marketplace_search_priority: 100,
    marketplace_booking_mode: 'both',
    marketplace_featured: true,
    marketplace_destination: 'northland',
    marketplace_collection_slugs: ['hidden-gems', 'family-friendly', 'northland-escapes'],
    marketplace_quality_score: 95,
    marketplace_conversion_score: 80,
    instant_booking: true,
    occupancy: deloraineDemoSite.maxGuests,
    nightly_price: deloraineDemoSite.basePrice,
    latitude: DELORAINE_LATITUDE,
    longitude: DELORAINE_LONGITUDE,
    contact_email: deloraineDemoSite.contactEmail,
    contact_phone: deloraineDemoSite.contactPhone,
  };
}

export function isLocalHost(user: UserLike | null | undefined): boolean {
  return user?.id === LOCAL_HOST_ID || user?.app_metadata?.provider === 'local_setup';
}

export function isDeloraineLocalHostName(hostname?: string): boolean {
  const value = hostname || (typeof window !== 'undefined' ? window.location.hostname : '');
  return value === DELORAINE_LOCAL_HOSTNAME;
}

function isDeloraineLocalDashboardContext(): boolean {
  if (isDeloraineLocalHostName()) return true;
  const draft = readSignupDraft();
  if (text(draft.email).toLowerCase() === DELORAINE_HOST_EMAIL) return true;
  if (text(draft.subdomain || draft.slug).toLowerCase() === 'delorainecottage') return true;

  const existing = readJsonStorage<PropertyDraft>(browserStorage().local, LOCAL_PROPERTY_KEY);
  return (
    existing?.id === DELORAINE_LOCAL_PROPERTY_ID ||
    text(existing?.slug).toLowerCase() === 'delorainecottage' ||
    text(existing?.custom_domain).toLowerCase() === 'delorainecottage.staydirect.nz' ||
    text(existing?.custom_domain).toLowerCase() === 'delorainecottage.com'
  );
}

export function localSetupActive(): boolean {
  return localStorage.getItem(LOCAL_AUTH_KEY) === 'true' || sessionStorage.getItem('staydirect_local_setup') === 'true';
}

export function readLocalBookings(): Booking[] {
  const stored = localStorage.getItem(LOCAL_BOOKINGS_KEY);
  if (!stored) return [];
  try {
    return JSON.parse(stored) as Booking[];
  } catch {
    return [];
  }
}

export function saveLocalBookings(bookings: Booking[]) {
  localStorage.setItem(LOCAL_BOOKINGS_KEY, JSON.stringify(bookings));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('staydirect-bookings-updated'));
  }
}

export function makeLocalSubscription(): Subscription {
  const now = new Date();
  const trialEnds = new Date(now);
  trialEnds.setDate(now.getDate() + 14);
  return {
    id: 'local-trial',
    host_id: LOCAL_HOST_ID,
    plan: 'professional',
    status: 'trialing',
    trial_ends_at: trialEnds.toISOString(),
    created_at: now.toISOString(),
  };
}

export function makeLocalProperty(input: PropertyDraft = {}): Property {
  const draft = readSignupDraft();
  const imported = readImportedProperty();
  const now = fallbackDate();
  const importedAmenities = normaliseLocalAmenities(imported?.amenityDetails?.length ? imported.amenityDetails : imported?.amenities);
  const inputAmenities = normaliseLocalAmenities(input.amenities);
  const inputName = text(input.name || input.propertyName);
  const draftName = text(draft.propertyName);
  const importedName = text(imported?.name);
  const draftSlug = text(draft.subdomain || draft.slug);
  const savedNameIsJustImported = sameText(inputName, importedName);
  const name = savedNameIsJustImported && draftName
    ? draftName
    : inputName || draftName || importedName || 'Your Property';
  const importedRuleText = [
    ...(imported?.houseRules || []),
    ...(imported?.rules || []),
    ...(imported?.amenities || []),
    ...(imported?.amenityDetails || []),
  ].join(' ');
  const importedSlug = importedName ? slugify(importedName) : '';
  const inputSlug = text(input.slug);
  const inputNameSlug = inputName ? slugify(inputName) : '';
  const shouldReplaceSavedSlug =
    (savedNameIsJustImported && sameText(inputSlug, importedSlug)) ||
    Boolean(draftName && inputName && !sameText(inputName, draftName) && sameText(inputSlug, inputNameSlug));
  const slug = inputSlug && !shouldReplaceSavedSlug
    ? inputSlug
    : draftSlug || slugify(name);
  const taxRate = input.tax_rate ?? imported?.taxRate ?? 15;

  return {
    id: input.id || 'local-property',
    host_id: LOCAL_HOST_ID,
    name,
    type: input.type || 'guest accommodation',
    address: input.address || imported?.address || '',
    suburb: input.suburb || imported?.suburb || '',
    city: input.city || imported?.city || '',
    country: input.country || imported?.country || 'New Zealand',
    bedrooms: Number(input.bedrooms || imported?.bedrooms || 1),
    bathrooms: Number(input.bathrooms || imported?.bathrooms || 1),
    max_guests: Number(input.max_guests || imported?.maxGuests || 2),
    base_price: Number(input.base_price || imported?.basePrice || 0),
    cleaning_fee: Number(input.cleaning_fee || imported?.cleaningFee || 0),
    tax_rate: Number(taxRate) || 15,
    min_nights: Number(input.min_nights || imported?.minNights || 1),
    short_description: input.short_description || imported?.shortDescription || '',
    full_description: input.full_description || imported?.fullDescription || '',
    amenities: inputAmenities.length ? inputAmenities : importedAmenities,
    images: input.images?.length ? input.images : imported?.images || [],
    check_in_time: input.check_in_time || imported?.checkInTime || '15:00',
    check_out_time: input.check_out_time || imported?.checkOutTime || '10:00',
    pets_allowed: input.pets_allowed ?? imported?.petsAllowed ?? /pets?\s+(allowed|welcome)|dog[-\s]?friendly|pet[-\s]?friendly/i.test(importedRuleText),
    smoking_allowed: input.smoking_allowed ?? imported?.smokingAllowed ?? /smoking\s+(allowed|permitted)|smoke[-\s]?friendly/i.test(importedRuleText),
    events_allowed: input.events_allowed ?? imported?.eventsAllowed ?? /(events?|parties|gatherings?)\s+(allowed|permitted|welcome)/i.test(importedRuleText),
    accent_color: input.accent_color || imported?.brandColor || '#FF5A5F',
    theme: input.theme || 'onepage',
    slug: slug || null,
    custom_domain: input.custom_domain || null,
    stripe_publishable_key: input.stripe_publishable_key || null,
    marketplace_enabled: input.marketplace_enabled ?? false,
    marketplace_status: input.marketplace_status || 'draft',
    marketplace_headline: input.marketplace_headline || name,
    marketplace_short_description: input.marketplace_short_description || input.short_description || imported?.shortDescription || '',
    marketplace_featured_image: input.marketplace_featured_image || (input.images?.[0] || imported?.images?.[0] || null),
    marketplace_category: input.marketplace_category || null,
    marketplace_tags: input.marketplace_tags || [],
    marketplace_search_priority: input.marketplace_search_priority ?? 0,
    marketplace_booking_mode: input.marketplace_booking_mode || 'host_site',
    marketplace_featured: input.marketplace_featured ?? false,
    marketplace_destination: input.marketplace_destination || slugify(input.city || imported?.city || 'northland'),
    marketplace_collection_slugs: input.marketplace_collection_slugs || [],
    marketplace_quality_score: input.marketplace_quality_score ?? 50,
    marketplace_review_score: input.marketplace_review_score ?? null,
    marketplace_conversion_score: input.marketplace_conversion_score ?? 0,
    marketplace_last_reviewed_at: input.marketplace_last_reviewed_at || null,
    instant_booking: input.instant_booking ?? false,
    occupancy: input.occupancy || Number(input.max_guests || imported?.maxGuests || 2),
    nightly_price: input.nightly_price ?? Number(input.base_price || imported?.basePrice || 0),
    latitude: input.latitude ?? null,
    longitude: input.longitude ?? null,
    contact_email: input.contact_email || imported?.contactEmail || imported?.email || null,
    contact_phone: input.contact_phone || imported?.contactPhone || imported?.phone || null,
    contact_email_visible: input.contact_email_visible ?? true,
    contact_phone_visible: input.contact_phone_visible ?? false,
    contact_preference: input.contact_preference || 'email',
    staydirect_email_alias: input.staydirect_email_alias || (slug ? `${slug.replace(/-/g, '').slice(0, 32)}@staydirect.nz` : null),
    website_content: input.website_content ?? null,
    created_at: input.created_at || now,
    updated_at: input.updated_at || now,
  };
}

export function readLocalProperty(): Property | null {
  if (isDeloraineLocalDashboardContext()) {
    const stored = localStorage.getItem(LOCAL_PROPERTY_KEY);
    const raw = stored ? readJsonStorage<PropertyDraft>(localStorage, LOCAL_PROPERTY_KEY) : null;
    if (isPlaceholderLocalProperty(raw)) return ensureDeloraineLocalProperty(true);
  }

  const stored = localStorage.getItem(LOCAL_PROPERTY_KEY);
  if (!stored) return makeLocalProperty();
  try {
    const raw = JSON.parse(stored) as PropertyDraft;
    const next = makeLocalProperty(raw);
    if (raw.name !== next.name || raw.slug !== next.slug) {
      localStorage.setItem(LOCAL_PROPERTY_KEY, JSON.stringify(next));
    }
    return next;
  } catch {
    return makeLocalProperty();
  }
}

export function saveLocalProperty(property: PropertyDraft): Property {
  const next = makeLocalProperty(property);
  localStorage.setItem(LOCAL_PROPERTY_KEY, JSON.stringify(next));
  localStorage.setItem(LOCAL_AUTH_KEY, 'true');
  const importedName = text(readImportedProperty()?.name);
  if (next.name && !sameText(next.name, importedName)) {
    const existingDraft = readSignupDraft();
    const draft = JSON.stringify({ ...existingDraft, propertyName: next.name, subdomain: next.slug || existingDraft.subdomain });
    localStorage.setItem(LOCAL_SIGNUP_DRAFT_KEY, draft);
    sessionStorage.setItem(LOCAL_SIGNUP_DRAFT_KEY, draft);
  }
  if (!localStorage.getItem(LOCAL_BOOKINGS_KEY)) saveLocalBookings([]);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('staydirect-property-updated', { detail: next }));
  }
  return next;
}

export function makeDeloraineLocalProperty(input: PropertyDraft = {}): Property {
  cacheImportedProperty(getDeloraineDemoImport());
  return makeLocalProperty(makeDeloraineSeedInput(input));
}

export function ensureDeloraineLocalProperty(force = false): Property | null {
  if (!isDeloraineLocalDashboardContext()) return null;

  const existing = readJsonStorage<PropertyDraft>(localStorage, LOCAL_PROPERTY_KEY);
  if (!force && existing && !isPlaceholderLocalProperty(existing)) {
    return makeLocalProperty(existing);
  }

  const next = makeDeloraineLocalProperty(existing || {});
  localStorage.setItem(LOCAL_PROPERTY_KEY, JSON.stringify(next));
  localStorage.setItem(LOCAL_AUTH_KEY, 'true');

  const draft = JSON.stringify({
    ...readSignupDraft(),
    name: 'Vanessa Wilson',
    email: DELORAINE_HOST_EMAIL,
    propertyName: deloraineDemoSite.name,
    subdomain: 'delorainecottage',
    slug: 'delorainecottage',
  });
  localStorage.setItem(LOCAL_SIGNUP_DRAFT_KEY, draft);
  sessionStorage.setItem(LOCAL_SIGNUP_DRAFT_KEY, draft);

  if (!localStorage.getItem(LOCAL_BOOKINGS_KEY)) saveLocalBookings([]);
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('staydirect-property-updated', { detail: next }));
  }
  return next;
}
