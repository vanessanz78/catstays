import { apiUrl } from './api';
import { defaultPromotions, loadDashboardData, saveDashboardData, type PromotionItem } from './dashboardLocalData';
import { supabase, type Booking } from './supabase';

export type PromotionDiscountType = 'percentage' | 'fixed' | 'free_night' | 'no_cleaning_fee';
export type PromotionStatus = 'active' | 'inactive' | 'scheduled' | 'expired';

export type PromotionRules = {
  minNights: number;
  weekdaysOnly: boolean;
  directBookingsOnly: boolean;
  returningGuestsOnly: boolean;
  bookingWindowDays: number | null;
};

export type PromotionCampaign = {
  id: string;
  propertyId?: string | null;
  hostId?: string | null;
  name: string;
  code: string;
  discountType: PromotionDiscountType;
  discountValue: number;
  startsAt: string;
  endsAt: string;
  usageLimit: number | null;
  usageCount: number;
  active: boolean;
  rules: PromotionRules;
  imageUrl?: string | null;
  revenueGenerated: number;
  showOnWebsite: boolean;
  featureInMarketing: boolean;
  showAtCheckout: boolean;
  createdAt?: string;
  updatedAt?: string;
};

export type PromotionQuoteInput = {
  propertyId?: string | null;
  code: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  accommodation: number;
  cleaningFee: number;
  taxRate: number;
  upsellTotal: number;
  guestEmail?: string;
  bookingSource?: 'direct' | 'ota' | 'manual';
  isReturningGuest?: boolean;
  today?: string;
};

export type PromotionQuote = {
  ok: boolean;
  message: string;
  promotionId?: string;
  promotionCode?: string;
  promotionName?: string;
  discountType?: PromotionDiscountType;
  discountValue?: number;
  accommodationDiscount: number;
  cleaningFeeDiscount: number;
  discountAmount: number;
  taxesBeforeDiscount: number;
  taxesAfterDiscount: number;
  totalBeforeDiscount: number;
  totalAfterDiscount: number;
  promotionSnapshot?: Record<string, unknown>;
};

export type PromotionAttributionRecord = {
  id: string;
  promotionId?: string | null;
  propertyId?: string | null;
  hostId?: string | null;
  bookingId: string;
  promotionCode: string;
  guestName?: string | null;
  guestEmail?: string | null;
  checkIn?: string | null;
  checkOut?: string | null;
  nights: number;
  discountAmount: number;
  bookingTotalBeforeDiscount: number;
  bookingTotalAfterDiscount: number;
  bookingDate: string;
  bookingStatus?: string | null;
  paymentStatus?: string | null;
  source: 'booking' | 'redemption';
};

export type PromotionPerformance = {
  promotion: PromotionCampaign;
  usageCount: number;
  bookingsGenerated: number;
  revenueGenerated: number;
  discountGiven: number;
  averageBookingValue: number;
  conversionRate: number;
  directBookingUplift: number;
};

export type PromotionTimelinePoint = {
  key: string;
  label: string;
  uses: number;
  revenue: number;
};

export type PromotionAnalytics = {
  activePromotions: number;
  totalUses: number;
  bookingsGenerated: number;
  revenueGenerated: number;
  discountGiven: number;
  averageBookingValue: number;
  conversionRate: number;
  directBookingUplift: number;
  attributedBookings: PromotionAttributionRecord[];
  perPromotion: PromotionPerformance[];
  performanceById: Record<string, PromotionPerformance>;
  performanceByCode: Record<string, PromotionPerformance>;
  timeline: PromotionTimelinePoint[];
  bestPerforming: PromotionPerformance | null;
  lowestConversion: PromotionPerformance | null;
  expiredCampaigns: number;
  scheduledCampaigns: number;
  weeklySummary: {
    headline: string;
    lines: string[];
  };
};

const DEFAULT_RULES: PromotionRules = {
  minNights: 1,
  weekdaysOnly: false,
  directBookingsOnly: true,
  returningGuestsOnly: false,
  bookingWindowDays: null,
};

const DEFAULT_PROMO_IMAGES = [
  'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=80',
  'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80',
  'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=900&q=80',
];

const LOCAL_REDEMPTIONS_KEY = 'staydirect_promotion_redemptions';

function ymd(value: string | Date) {
  const date = typeof value === 'string' ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return '';
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function addDays(value: Date, days: number) {
  const next = new Date(value);
  next.setDate(next.getDate() + days);
  return next;
}

function safeNumber(value: unknown, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function clampMoney(value: number, max: number) {
  return Math.max(0, Math.min(Math.round(value * 100) / 100, Math.max(0, max)));
}

function readJsonStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJsonStorage<T>(key: string, value: T) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

function monthKey(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return ymd(new Date()).slice(0, 7);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

function monthLabel(key: string) {
  const [year, month] = key.split('-').map(Number);
  if (!year || !month) return key;
  return new Date(year, month - 1, 1).toLocaleDateString('en-NZ', { month: 'short' });
}

function parseRules(row: Record<string, any>, minNightsFallback = 1): PromotionRules {
  const metadata = row.metadata && typeof row.metadata === 'object' ? row.metadata : {};
  const rules = row.rules && typeof row.rules === 'object' ? row.rules : metadata.rules || {};
  return {
    ...DEFAULT_RULES,
    minNights: Math.max(1, Math.floor(safeNumber(rules.minNights ?? rules.min_nights ?? row.min_nights, minNightsFallback))),
    weekdaysOnly: Boolean(rules.weekdaysOnly ?? rules.weekdays_only ?? false),
    directBookingsOnly: rules.directBookingsOnly ?? rules.direct_bookings_only ?? true,
    returningGuestsOnly: Boolean(rules.returningGuestsOnly ?? rules.returning_guests_only ?? false),
    bookingWindowDays: rules.bookingWindowDays ?? rules.booking_window_days
      ? Math.max(1, Math.floor(safeNumber(rules.bookingWindowDays ?? rules.booking_window_days, 1)))
      : null,
  };
}

function visibilityFlag(input: Record<string, any>, key: 'showOnWebsite' | 'featureInMarketing' | 'showAtCheckout', fallback = true) {
  const metadata = input.metadata && typeof input.metadata === 'object' ? input.metadata : {};
  const snakeKey = key.replace(/[A-Z]/g, (match) => `_${match.toLowerCase()}`);
  return Boolean(input[key] ?? input[snakeKey] ?? metadata[key] ?? metadata[snakeKey] ?? fallback);
}

export function normalizePromotion(input: Partial<PromotionItem> & Record<string, any>, index = 0): PromotionCampaign {
  const metadata = input.metadata && typeof input.metadata === 'object' ? input.metadata : {};
  const discountType = String(metadata.discount_type ?? input.discountType ?? input.discount_type ?? input.type ?? 'percentage') as PromotionDiscountType;
  const value = safeNumber(input.discountValue ?? input.discount_value ?? input.discount ?? input.value, discountType === 'no_cleaning_fee' ? 100 : 10);
  const startsAt = String(input.startsAt ?? input.starts_at ?? input.validFrom ?? input.valid_from ?? ymd(new Date()));
  const endsAt = String(input.endsAt ?? input.ends_at ?? input.validTo ?? input.valid_to ?? ymd(addDays(new Date(), 90)));
  const usageLimit = input.usageLimit ?? input.usage_limit ?? input.maxUses ?? input.max_uses;
  const usageCount = safeNumber(input.usageCount ?? input.usage_count ?? input.uses, 0);
  const active = input.active ?? String(input.status || '').toLowerCase() === 'active';
  return {
    id: String(input.id ?? `local-${Date.now()}-${index}`),
    propertyId: input.propertyId ?? input.property_id ?? null,
    hostId: input.hostId ?? input.host_id ?? null,
    name: String(input.name || 'Direct booking offer'),
    code: String(input.code || '').trim().toUpperCase(),
    discountType: ['percentage', 'fixed', 'free_night', 'no_cleaning_fee'].includes(discountType) ? discountType : 'percentage',
    discountValue: Math.max(0, value),
    startsAt,
    endsAt,
    usageLimit: usageLimit === null || usageLimit === undefined || usageLimit === '' ? null : Math.max(1, Math.floor(safeNumber(usageLimit, 1))),
    usageCount: Math.max(0, Math.floor(usageCount)),
    active: Boolean(active),
    rules: parseRules(input, safeNumber(input.minNights ?? input.min_nights, 1)),
    imageUrl: input.imageUrl ?? input.image_url ?? input.heroImageUrl ?? input.hero_image_url ?? metadata.image_url ?? DEFAULT_PROMO_IMAGES[index % DEFAULT_PROMO_IMAGES.length],
    revenueGenerated: safeNumber(input.revenueGenerated ?? input.revenue_generated ?? metadata.revenue_generated, 0),
    showOnWebsite: visibilityFlag(input, 'showOnWebsite', true),
    featureInMarketing: visibilityFlag(input, 'featureInMarketing', true),
    showAtCheckout: visibilityFlag(input, 'showAtCheckout', true),
    createdAt: input.createdAt ?? input.created_at,
    updatedAt: input.updatedAt ?? input.updated_at,
  };
}

export function promotionStatus(promo: PromotionCampaign, today = ymd(new Date())): PromotionStatus {
  if (!promo.active) return 'inactive';
  if (promo.startsAt && promo.startsAt > today) return 'scheduled';
  if (promo.endsAt && promo.endsAt < today) return 'expired';
  if (promo.usageLimit && promo.usageCount >= promo.usageLimit) return 'expired';
  return 'active';
}

export function describePromotion(promo: PromotionCampaign) {
  if (promo.discountType === 'percentage') return `${promo.discountValue}% off`;
  if (promo.discountType === 'fixed') return `$${promo.discountValue.toFixed(0)} off`;
  if (promo.discountType === 'free_night') return '1 free night';
  return 'No cleaning fee';
}

export function loadLocalPromotions(): PromotionCampaign[] {
  const raw = loadDashboardData<any[]>('promotions', defaultPromotions);
  return raw.map((item, index) => normalizePromotion(item, index)).filter((item) => item.code);
}

export function saveLocalPromotions(promotions: PromotionCampaign[]) {
  saveDashboardData('promotions', promotions.map((promo) => ({
    ...promo,
    discount: promo.discountValue,
    type: promo.discountType,
    minNights: promo.rules.minNights,
    validFrom: promo.startsAt,
    validTo: promo.endsAt,
    uses: promo.usageCount,
    maxUses: promo.usageLimit ?? 0,
    showOnWebsite: promo.showOnWebsite,
    featureInMarketing: promo.featureInMarketing,
    showAtCheckout: promo.showAtCheckout,
  })));
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('staydirect-promotions-updated', { detail: promotions }));
  }
}

function attributionFromBooking(booking: Partial<Booking> & Record<string, any>): PromotionAttributionRecord | null {
  const snapshot = booking.promotion_snapshot && typeof booking.promotion_snapshot === 'object' ? booking.promotion_snapshot as Record<string, any> : {};
  const code = String(booking.promotion_code || booking.promotionCode || snapshot.code || '').trim().toUpperCase();
  const discount = safeNumber(booking.promotion_discount ?? booking.promotionDiscount ?? snapshot.discountAmount, 0);
  if (!code || discount <= 0) return null;

  const totalAfterDiscount = safeNumber(booking.total, 0);
  const totalBeforeDiscount = safeNumber(booking.total_before_discount ?? booking.totalBeforeDiscount, totalAfterDiscount + discount);
  const bookingDate = String(booking.booking_date || booking.created_at || booking.createdAt || booking.check_in || new Date().toISOString());

  return {
    id: `booking-${String(booking.id || code)}`,
    promotionId: (booking.promotion_id ?? booking.promotionId ?? snapshot.id ?? null) as string | null,
    propertyId: (booking.property_id ?? booking.propertyId ?? null) as string | null,
    hostId: (booking.host_id ?? booking.hostId ?? null) as string | null,
    bookingId: String(booking.id || `${code}-${bookingDate}`),
    promotionCode: code,
    guestName: (booking.guest_name ?? booking.guestName ?? null) as string | null,
    guestEmail: (booking.guest_email ?? booking.guestEmail ?? null) as string | null,
    checkIn: (booking.check_in ?? booking.checkIn ?? null) as string | null,
    checkOut: (booking.check_out ?? booking.checkOut ?? null) as string | null,
    nights: Math.max(1, Math.floor(safeNumber(booking.nights, 1))),
    discountAmount: discount,
    bookingTotalBeforeDiscount: totalBeforeDiscount,
    bookingTotalAfterDiscount: totalAfterDiscount,
    bookingDate,
    bookingStatus: (booking.status ?? null) as string | null,
    paymentStatus: (booking.payment_status ?? booking.paymentStatus ?? null) as string | null,
    source: 'booking',
  };
}

function attributionFromRedemption(row: Record<string, any>): PromotionAttributionRecord | null {
  const code = String(row.code || row.promotion_code || '').trim().toUpperCase();
  const discount = safeNumber(row.discount_amount, 0);
  if (!code || discount <= 0) return null;
  return {
    id: String(row.id || `redemption-${row.booking_id}-${code}`),
    promotionId: (row.promotion_id ?? null) as string | null,
    propertyId: (row.property_id ?? null) as string | null,
    hostId: (row.host_id ?? null) as string | null,
    bookingId: String(row.booking_id || `${code}-${row.created_at || Date.now()}`),
    promotionCode: code,
    guestName: (row.guest_name ?? null) as string | null,
    guestEmail: (row.guest_email ?? null) as string | null,
    checkIn: (row.check_in ?? null) as string | null,
    checkOut: (row.check_out ?? null) as string | null,
    nights: Math.max(1, Math.floor(safeNumber(row.nights, 1))),
    discountAmount: discount,
    bookingTotalBeforeDiscount: safeNumber(row.booking_total_before_discount, 0),
    bookingTotalAfterDiscount: safeNumber(row.booking_total_after_discount, 0),
    bookingDate: String(row.created_at || new Date().toISOString()),
    bookingStatus: (row.booking_status ?? null) as string | null,
    paymentStatus: (row.payment_status ?? null) as string | null,
    source: 'redemption',
  };
}

export function loadLocalPromotionRedemptions(): PromotionAttributionRecord[] {
  return readJsonStorage<PromotionAttributionRecord[]>(LOCAL_REDEMPTIONS_KEY, []);
}

export function recordLocalPromotionRedemption(booking: Partial<Booking> & Record<string, any>) {
  const attribution = attributionFromBooking(booking);
  if (!attribution) return;

  const existing = loadLocalPromotionRedemptions();
  if (existing.some((item) => item.bookingId === attribution.bookingId && item.promotionCode === attribution.promotionCode)) return;

  const nextRedemptions = [attribution, ...existing].slice(0, 200);
  writeJsonStorage(LOCAL_REDEMPTIONS_KEY, nextRedemptions);

  const promotions = loadLocalPromotions();
  const nextPromotions = promotions.map((promo) => {
    if (promo.id !== attribution.promotionId && promo.code !== attribution.promotionCode) return promo;
    return {
      ...promo,
      usageCount: promo.usageCount + 1,
      revenueGenerated: Math.round((promo.revenueGenerated + attribution.bookingTotalAfterDiscount) * 100) / 100,
      updatedAt: new Date().toISOString(),
    };
  });
  saveLocalPromotions(nextPromotions);
}

export async function loadSupabasePromotionRedemptions(propertyId: string): Promise<PromotionAttributionRecord[]> {
  const { data, error } = await supabase
    .from('promotion_redemptions')
    .select('*')
    .eq('property_id', propertyId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map((row) => attributionFromRedemption(row as Record<string, any>)).filter(Boolean) as PromotionAttributionRecord[];
}

function buildTimeline(records: PromotionAttributionRecord[]): PromotionTimelinePoint[] {
  const validDates = records
    .map((record) => new Date(record.bookingDate).getTime())
    .filter((time) => Number.isFinite(time));
  const anchor = validDates.length ? new Date(Math.max(...validDates)) : new Date();
  const keys: string[] = [];
  for (let i = 5; i >= 0; i -= 1) {
    const date = new Date(anchor.getFullYear(), anchor.getMonth() - i, 1);
    keys.push(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`);
  }
  const buckets = new Map(keys.map((key) => [key, { key, label: monthLabel(key), uses: 0, revenue: 0 }]));
  records.forEach((record) => {
    const key = monthKey(record.bookingDate);
    const bucket = buckets.get(key);
    if (!bucket) return;
    bucket.uses += 1;
    bucket.revenue += record.bookingTotalAfterDiscount;
  });
  return Array.from(buckets.values()).map((point) => ({
    ...point,
    revenue: Math.round(point.revenue * 100) / 100,
  }));
}

export function buildPromotionAnalytics(
  promotions: PromotionCampaign[],
  bookings: Array<Partial<Booking> & Record<string, any>> = [],
  redemptions: PromotionAttributionRecord[] = [],
): PromotionAnalytics {
  const deduped = new Map<string, PromotionAttributionRecord>();
  redemptions.forEach((record) => deduped.set(`${record.bookingId}:${record.promotionCode}`, record));
  bookings.forEach((booking) => {
    const record = attributionFromBooking(booking);
    if (record) deduped.set(`${record.bookingId}:${record.promotionCode}`, record);
  });

  const attributedBookings = Array.from(deduped.values())
    .filter((record) => record.bookingStatus !== 'cancelled' && record.paymentStatus !== 'refunded')
    .sort((a, b) => new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime());

  const directBookings = bookings.filter((booking) => {
    const status = String(booking.status || '').toLowerCase();
    const paymentStatus = String(booking.payment_status || booking.paymentStatus || '').toLowerCase();
    const source = String(booking.booking_source || booking.bookingSource || 'direct').toLowerCase();
    return status !== 'cancelled' && paymentStatus !== 'refunded' && source !== 'ota';
  });
  const directBookingCount = Math.max(1, directBookings.length);
  const directBookingRevenue = directBookings.reduce((sum, booking) => sum + safeNumber(booking.total, 0), 0);
  const revenueBase = Math.max(1, directBookingRevenue);

  const performanceById: Record<string, PromotionPerformance> = {};
  const performanceByCode: Record<string, PromotionPerformance> = {};
  const perPromotion = promotions.map((promotion) => {
    const records = attributedBookings.filter((record) => (
      (record.promotionId && record.promotionId === promotion.id) || record.promotionCode === promotion.code
    ));
    const usageCount = records.length;
    const revenueGenerated = records.reduce((sum, record) => sum + record.bookingTotalAfterDiscount, 0);
    const discountGiven = records.reduce((sum, record) => sum + record.discountAmount, 0);
    const performance: PromotionPerformance = {
      promotion,
      usageCount,
      bookingsGenerated: usageCount,
      revenueGenerated: Math.round(revenueGenerated * 100) / 100,
      discountGiven: Math.round(discountGiven * 100) / 100,
      averageBookingValue: usageCount > 0 ? Math.round((revenueGenerated / usageCount) * 100) / 100 : 0,
      conversionRate: Math.round((usageCount / directBookingCount) * 1000) / 10,
      directBookingUplift: Math.round((revenueGenerated / revenueBase) * 1000) / 10,
    };
    performanceById[promotion.id] = performance;
    performanceByCode[promotion.code] = performance;
    return performance;
  });

  const totalUses = attributedBookings.length;
  const revenueGenerated = attributedBookings.reduce((sum, record) => sum + record.bookingTotalAfterDiscount, 0);
  const discountGiven = attributedBookings.reduce((sum, record) => sum + record.discountAmount, 0);
  const bestPerforming = perPromotion
    .filter((item) => item.usageCount > 0)
    .sort((a, b) => b.revenueGenerated - a.revenueGenerated || b.usageCount - a.usageCount)[0] || null;
  const activePerformances = perPromotion.filter((item) => promotionStatus({ ...item.promotion, usageCount: item.usageCount }) === 'active');
  const lowestConversion = activePerformances.length
    ? [...activePerformances].sort((a, b) => a.conversionRate - b.conversionRate || a.revenueGenerated - b.revenueGenerated)[0]
    : null;

  const activePromotions = promotions.filter((promo) => {
    const usageCount = performanceById[promo.id]?.usageCount ?? 0;
    return promotionStatus({ ...promo, usageCount }) === 'active';
  }).length;
  const scheduledCampaigns = promotions.filter((promo) => promotionStatus({ ...promo, usageCount: performanceById[promo.id]?.usageCount ?? 0 }) === 'scheduled').length;
  const expiredCampaigns = promotions.filter((promo) => promotionStatus({ ...promo, usageCount: performanceById[promo.id]?.usageCount ?? 0 }) === 'expired').length;

  const weeklyLines = totalUses > 0
    ? [
      `${totalUses} promoted booking${totalUses === 1 ? '' : 's'} attributed this period.`,
      `$${Math.round(revenueGenerated).toLocaleString('en-NZ')} NZD in promoted booking revenue.`,
      bestPerforming ? `${bestPerforming.promotion.name} is currently the strongest offer.` : 'No single offer is leading yet.',
    ]
    : [
      'No bookings have redeemed a promotion yet.',
      'Promotions will appear here after guests apply a promo code at checkout.',
      activePromotions > 0 ? `${activePromotions} active offer${activePromotions === 1 ? '' : 's'} are ready to track.` : 'Create an active offer to start measuring conversion.',
    ];

  return {
    activePromotions,
    totalUses,
    bookingsGenerated: totalUses,
    revenueGenerated: Math.round(revenueGenerated * 100) / 100,
    discountGiven: Math.round(discountGiven * 100) / 100,
    averageBookingValue: totalUses > 0 ? Math.round((revenueGenerated / totalUses) * 100) / 100 : 0,
    conversionRate: Math.round((totalUses / directBookingCount) * 1000) / 10,
    directBookingUplift: Math.round((revenueGenerated / revenueBase) * 1000) / 10,
    attributedBookings,
    perPromotion,
    performanceById,
    performanceByCode,
    timeline: buildTimeline(attributedBookings),
    bestPerforming,
    lowestConversion,
    expiredCampaigns,
    scheduledCampaigns,
    weeklySummary: {
      headline: totalUses > 0 ? 'Promotions are included in weekly host summaries.' : 'Promotion reporting is ready for the next redemption.',
      lines: weeklyLines,
    },
  };
}

export async function loadSupabasePromotions(propertyId: string): Promise<PromotionCampaign[]> {
  const { data, error } = await supabase
    .from('host_promotions')
    .select('*')
    .eq('property_id', propertyId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map((row, index) => normalizePromotion(row as Record<string, any>, index));
}

export async function upsertSupabasePromotion(promo: PromotionCampaign, hostId: string, propertyId: string) {
  const row = {
    id: promo.id.startsWith('local-') ? undefined : promo.id,
    host_id: hostId,
    property_id: propertyId,
    name: promo.name,
    code: promo.code.trim().toUpperCase(),
    discount: promo.discountValue,
    discount_type: promo.discountType,
    min_nights: promo.rules.minNights,
    valid_from: promo.startsAt || null,
    valid_to: promo.endsAt || null,
    max_uses: promo.usageLimit,
    uses: promo.usageCount,
    active: promo.active,
    discount_value: promo.discountValue,
    starts_at: promo.startsAt || null,
    ends_at: promo.endsAt || null,
    usage_limit: promo.usageLimit,
    usage_count: promo.usageCount,
    status: promo.active ? 'active' : 'inactive',
    rules: promo.rules,
    image_url: promo.imageUrl,
    revenue_generated: promo.revenueGenerated,
    show_on_website: promo.showOnWebsite,
    feature_in_marketing: promo.featureInMarketing,
    show_at_checkout: promo.showAtCheckout,
    metadata: {
      rules: promo.rules,
      image_url: promo.imageUrl,
      revenue_generated: promo.revenueGenerated,
      show_on_website: promo.showOnWebsite,
      feature_in_marketing: promo.featureInMarketing,
      show_at_checkout: promo.showAtCheckout,
    },
  };
  const { data, error } = await supabase
    .from('host_promotions')
    .upsert(row, { onConflict: 'id' })
    .select('*')
    .maybeSingle();
  if (error) {
    const fallback = {
      host_id: hostId,
      property_id: propertyId,
      name: promo.name,
      code: promo.code.trim().toUpperCase(),
      discount: promo.discountValue,
      discount_type: promo.discountType === 'free_night' || promo.discountType === 'no_cleaning_fee' ? 'fixed' : promo.discountType,
      min_nights: promo.rules.minNights,
      valid_from: promo.startsAt || null,
      valid_to: promo.endsAt || null,
      max_uses: promo.usageLimit,
      uses: promo.usageCount,
      active: promo.active,
      metadata: {
        discount_type: promo.discountType,
        rules: promo.rules,
        image_url: promo.imageUrl,
        revenue_generated: promo.revenueGenerated,
        show_on_website: promo.showOnWebsite,
        feature_in_marketing: promo.featureInMarketing,
        show_at_checkout: promo.showAtCheckout,
      },
    };
    const retry = await supabase
      .from('host_promotions')
      .upsert(fallback, { onConflict: 'property_id,code' })
      .select('*')
      .maybeSingle();
    if (retry.error) throw retry.error;
    return normalizePromotion(retry.data as Record<string, any>);
  }
  return normalizePromotion(data as Record<string, any>);
}

export async function deleteSupabasePromotion(id: string) {
  const { error } = await supabase.from('host_promotions').delete().eq('id', id);
  if (error) throw error;
}

function everyBookedNightIsWeekday(checkIn: string, nights: number) {
  for (let i = 0; i < nights; i += 1) {
    const date = addDays(new Date(checkIn), i);
    const day = date.getDay();
    if (day === 0 || day === 5 || day === 6) return false;
  }
  return true;
}

export function quotePromotionLocally(promotions: PromotionCampaign[], input: PromotionQuoteInput): PromotionQuote {
  const code = input.code.trim().toUpperCase();
  const totalBeforeDiscount = input.accommodation + input.cleaningFee + (input.accommodation * input.taxRate / 100) + input.upsellTotal;
  const empty: PromotionQuote = {
    ok: false,
    message: 'Enter a valid promo code.',
    accommodationDiscount: 0,
    cleaningFeeDiscount: 0,
    discountAmount: 0,
    taxesBeforeDiscount: input.accommodation * input.taxRate / 100,
    taxesAfterDiscount: input.accommodation * input.taxRate / 100,
    totalBeforeDiscount,
    totalAfterDiscount: totalBeforeDiscount,
  };

  if (!code) return empty;
  const promo = promotions.find((item) => item.code === code);
  if (!promo) return { ...empty, message: 'That promo code was not found.' };

  const today = input.today || ymd(new Date());
  const status = promotionStatus(promo, today);
  if (status === 'inactive') return { ...empty, message: 'That promo code is not active.' };
  if (status === 'scheduled') return { ...empty, message: 'That promo code is not valid yet.' };
  if (status === 'expired') return { ...empty, message: 'That promo code has expired or reached its usage limit.' };
  if (!promo.showAtCheckout) return { ...empty, message: 'That promo code is not available at checkout.' };
  if (promo.rules.minNights && input.nights < promo.rules.minNights) {
    return { ...empty, message: `This offer requires a minimum stay of ${promo.rules.minNights} night${promo.rules.minNights === 1 ? '' : 's'}.` };
  }
  if (promo.rules.weekdaysOnly && !everyBookedNightIsWeekday(input.checkIn, input.nights)) {
    return { ...empty, message: 'This offer is only available for weekday stays.' };
  }
  if (promo.rules.directBookingsOnly && input.bookingSource && input.bookingSource !== 'direct') {
    return { ...empty, message: 'This offer is only available for direct bookings.' };
  }
  if (promo.rules.returningGuestsOnly && !input.isReturningGuest) {
    return { ...empty, message: 'This offer is for returning guests only.' };
  }
  if (promo.rules.bookingWindowDays) {
    const todayTime = new Date(today).getTime();
    const checkInTime = new Date(input.checkIn).getTime();
    const daysUntilArrival = Math.ceil((checkInTime - todayTime) / 86400000);
    if (daysUntilArrival > promo.rules.bookingWindowDays) {
      return { ...empty, message: `This offer is available within ${promo.rules.bookingWindowDays} days of arrival.` };
    }
  }

  let accommodationDiscount = 0;
  let cleaningFeeDiscount = 0;
  if (promo.discountType === 'percentage') {
    accommodationDiscount = input.accommodation * (promo.discountValue / 100);
  } else if (promo.discountType === 'fixed') {
    accommodationDiscount = promo.discountValue;
  } else if (promo.discountType === 'free_night') {
    accommodationDiscount = input.nights > 0 ? input.accommodation / input.nights : 0;
  } else if (promo.discountType === 'no_cleaning_fee') {
    cleaningFeeDiscount = input.cleaningFee;
  }

  accommodationDiscount = clampMoney(accommodationDiscount, input.accommodation);
  cleaningFeeDiscount = clampMoney(cleaningFeeDiscount, input.cleaningFee);
  const discountedAccommodation = Math.max(0, input.accommodation - accommodationDiscount);
  const discountedCleaning = Math.max(0, input.cleaningFee - cleaningFeeDiscount);
  const taxesBeforeDiscount = input.accommodation * input.taxRate / 100;
  const taxesAfterDiscount = discountedAccommodation * input.taxRate / 100;
  const totalAfterDiscount = discountedAccommodation + discountedCleaning + taxesAfterDiscount + input.upsellTotal;
  const discountAmount = totalBeforeDiscount - totalAfterDiscount;

  return {
    ok: discountAmount > 0,
    message: discountAmount > 0
      ? `Promo applied — you saved $${discountAmount.toFixed(0)}.`
      : 'This code does not change the current booking total.',
    promotionId: promo.id,
    promotionCode: promo.code,
    promotionName: promo.name,
    discountType: promo.discountType,
    discountValue: promo.discountValue,
    accommodationDiscount,
    cleaningFeeDiscount,
    discountAmount,
    taxesBeforeDiscount,
    taxesAfterDiscount,
    totalBeforeDiscount,
    totalAfterDiscount,
    promotionSnapshot: {
      id: promo.id,
      code: promo.code,
      name: promo.name,
      discount_type: promo.discountType,
      discount_value: promo.discountValue,
      rules: promo.rules,
    },
  };
}

export function promotionMarketingCopy(promo: PromotionCampaign) {
  const offer = describePromotion(promo).toLowerCase();
  const expiry = promo.endsAt ? ` Book by ${new Date(promo.endsAt).toLocaleDateString('en-NZ', { day: 'numeric', month: 'short' })}.` : '';
  return `Use code ${promo.code} for ${offer}.${expiry}`;
}

export function promotionCtaText(promo: PromotionCampaign) {
  if (promo.discountType === 'free_night') return `Use code ${promo.code}`;
  if (promo.discountType === 'no_cleaning_fee') return `No cleaning fee with ${promo.code}`;
  return `Use code ${promo.code}`;
}

export function activePromotionsForMarketing(promotions: PromotionCampaign[], today?: string) {
  return promotions.filter((promo) => {
    const status = promotionStatus(promo, today);
    return promo.featureInMarketing && status !== 'inactive' && status !== 'expired';
  });
}

export function activeWebsitePromotions(promotions: PromotionCampaign[], today?: string) {
  return promotions.filter((promo) => promo.showOnWebsite && promotionStatus(promo, today) === 'active');
}

export async function loadPublicWebsitePromotions(propertyId?: string | null): Promise<PromotionCampaign[]> {
  if (propertyId) {
    try {
      const res = await fetch(apiUrl(`/api/promotions/public?propertyId=${encodeURIComponent(propertyId)}`));
      const data = await res.json().catch(() => ({}));
      if (res.ok && Array.isArray(data.promotions)) {
        return data.promotions.map((item: Record<string, any>, index: number) => normalizePromotion(item, index));
      }
    } catch (error) {
      if (import.meta.env.DEV) console.warn('[promotions] public promotions unavailable, using local fallback:', error);
    }
  }
  return activeWebsitePromotions(loadLocalPromotions());
}

export async function validatePromotionForCheckout(input: PromotionQuoteInput): Promise<PromotionQuote> {
  if (input.propertyId) {
    try {
      const res = await fetch(apiUrl('/api/promotions/validate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data) return data as PromotionQuote;
      if (data?.message || data?.error) throw new Error(String(data.message || data.error));
    } catch (error) {
      if (import.meta.env.DEV) console.warn('[promotions] API validation unavailable, using local fallback:', error);
    }
  }
  return quotePromotionLocally(loadLocalPromotions(), input);
}
