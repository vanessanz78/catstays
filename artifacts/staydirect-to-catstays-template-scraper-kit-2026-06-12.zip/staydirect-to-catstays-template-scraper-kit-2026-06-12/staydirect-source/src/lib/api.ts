const configuredApiUrl = import.meta.env.VITE_API_BASE_URL as string | undefined;

function isLocalBrowserHost(hostname: string) {
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname.endsWith('.localhost');
}

function isLoopbackApiUrl(value: string) {
  try {
    const url = new URL(value);
    return url.hostname === 'localhost' || url.hostname === '127.0.0.1';
  } catch {
    return false;
  }
}

function resolveApiBaseUrl() {
  const configured = (configuredApiUrl || '').replace(/\/$/, '');
  if (
    typeof window !== 'undefined' &&
    isLocalBrowserHost(window.location.hostname) &&
    configured &&
    isLoopbackApiUrl(configured)
  ) {
    return '';
  }
  return (configured || import.meta.env.BASE_URL || '').replace(/\/$/, '');
}

export const API_BASE_URL = resolveApiBaseUrl();

export function apiUrl(path: string): string {
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}
