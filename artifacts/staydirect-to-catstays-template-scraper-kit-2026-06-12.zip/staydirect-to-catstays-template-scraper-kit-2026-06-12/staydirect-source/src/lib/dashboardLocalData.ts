const STORAGE_PREFIX = 'staydirect_dashboard_';
const LEGACY_DASHBOARD_NAME_PATTERN =
  /Amelia Brown|Cathryn Dawn|Margaret Leslie|Liam Carter|Heidi Jacobs|Karen Manukonga|mlesli\.687330/i;

export type ReviewItem = {
  id: number;
  guest: string;
  source: 'Direct' | 'Airbnb' | 'Booking.com' | 'Google';
  rating: number;
  stayDate: string;
  review: string;
  response?: string;
  published: boolean;
};

export type PromotionItem = {
  id: number;
  name: string;
  code: string;
  discount: number;
  type: string;
  minNights: number;
  validFrom: string;
  validTo: string;
  active: boolean;
  uses: number;
  maxUses: number;
};

export type UpsellPriceType = 'flat' | 'per_night' | 'per_guest' | 'percentage' | 'free' | 'per_person' | 'per_trip' | 'per_couple';
export type UpsellStatus = 'active' | 'scheduled' | 'inactive' | 'archived';

export type UpsellItem = {
  id: number | string;
  icon: string;
  name: string;
  description: string;
  price: number;
  priceType: UpsellPriceType | string;
  active: boolean;
  totalBooked: number;
  imageUrl?: string;
  status?: UpsellStatus;
  startsAt?: string | null;
  endsAt?: string | null;
  sortOrder?: number;
  revenueGenerated?: number;
  checkoutEnabled?: boolean;
  guestMessageEnabled?: boolean;
  marketingEnabled?: boolean;
};

export type BookingUpsell = Pick<UpsellItem, 'id' | 'icon' | 'name' | 'description' | 'price' | 'priceType'> & {
  quantity: number;
  source: 'checkout' | 'manual' | 'check_in_email';
  addedAt: string;
  imageUrl?: string;
  paymentState?: 'included' | 'pending' | 'paid' | 'refunded';
  addedBy?: 'guest' | 'host' | 'automation';
  chargeMode?: 'pay_now' | 'pay_later' | 'add_to_balance';
  basePrice?: number;
  calculatedPrice?: number;
};

export type GuidebookSection = {
  id: number;
  icon: string;
  title: string;
  content: string;
};

export type CheckInBookData = {
  checkInTime: string;
  checkOutTime: string;
  address: string;
  parkingInstructions: string;
  wifiName: string;
  wifiPassword: string;
  accessInstructions: string;
  houseRules: string;
  rubbishRecyclingInstructions: string;
  heatingCoolingInstructions: string;
  emergencyContacts: string;
  hostContactDetails: string;
  directions: string;
  whatToBring: string;
  checkoutInstructions: string;
  includeInPreArrivalEmail: boolean;
  sendHoursBeforeCheckIn: number;
  lastManualSendAt?: string;
};

export type LocalGuidebookCategory =
  | 'local_cafe'
  | 'restaurant'
  | 'beach'
  | 'walk'
  | 'free_thing'
  | 'rainy_day'
  | 'family_friendly'
  | 'hidden_gem'
  | 'supermarket'
  | 'pharmacy'
  | 'petrol_station'
  | 'emergency_service'
  | 'host_recommendation';

export type LocalGuidebookItem = {
  id: number;
  title: string;
  category: LocalGuidebookCategory;
  description: string;
  address: string;
  distanceFromProperty: string;
  googleMapsLink: string;
  googlePlaceId: string;
  image: string;
  hostNote: string;
  recommended: boolean;
  isPublic: boolean;
};

export const defaultReviews: ReviewItem[] = [];

export const defaultPromotions: PromotionItem[] = [
  {
    id: 1,
    name: 'Book Direct Welcome',
    code: 'DIRECT10',
    discount: 10,
    type: 'percentage',
    minNights: 2,
    validFrom: '2026-05-01',
    validTo: '2026-08-31',
    active: true,
    uses: 0,
    maxUses: 50,
  },
  {
    id: 2,
    name: 'Midweek Escape',
    code: 'MIDWEEK',
    discount: 45,
    type: 'fixed',
    minNights: 2,
    validFrom: '2026-05-01',
    validTo: '2026-12-15',
    active: true,
    uses: 0,
    maxUses: 30,
  },
];

export const defaultUpsells: UpsellItem[] = [
  {
    id: 1,
    icon: '🧺',
    name: 'Breakfast Hamper',
    description: 'Local bread, eggs, preserves, fruit and coffee ready for arrival.',
    price: 65,
    priceType: 'flat',
    active: true,
    totalBooked: 0,
    status: 'active',
    sortOrder: 1,
    imageUrl: '/upsells/breakfast-hamper.jpg',
    checkoutEnabled: true,
    guestMessageEnabled: true,
    marketingEnabled: true,
  },
  {
    id: 2,
    icon: '🔥',
    name: 'Fire Pit Bundle',
    description: 'Firewood, kindling and marshmallows for an evening outside.',
    price: 35,
    priceType: 'flat',
    active: true,
    totalBooked: 0,
    status: 'active',
    sortOrder: 2,
    imageUrl: '/upsells/fire-pit-bundle.jpg',
    checkoutEnabled: true,
    guestMessageEnabled: true,
    marketingEnabled: true,
  },
  {
    id: 3,
    icon: '🧹',
    name: 'Mid-stay Refresh',
    description: 'Fresh towels, linen change and a quick reset for longer stays.',
    price: 95,
    priceType: 'flat',
    active: false,
    totalBooked: 0,
    status: 'scheduled',
    startsAt: '2026-06-01',
    sortOrder: 3,
    imageUrl: '/upsells/mid-stay-refresh.jpg',
    checkoutEnabled: true,
    guestMessageEnabled: true,
    marketingEnabled: false,
  },
  {
    id: 4,
    icon: '🍷',
    name: 'Local Wine & Cheese',
    description: 'A handpicked selection of local wine and cheese on arrival.',
    price: 55,
    priceType: 'flat',
    active: true,
    totalBooked: 0,
    status: 'active',
    sortOrder: 4,
    imageUrl: '/upsells/local-wine-cheese.jpg',
    checkoutEnabled: true,
    guestMessageEnabled: true,
    marketingEnabled: true,
  },
  {
    id: 5,
    icon: '🐾',
    name: 'Pet Welcome Pack',
    description: 'Treats, bowl, bags and a cosy bed for guests travelling with a pet.',
    price: 25,
    priceType: 'flat',
    active: true,
    totalBooked: 0,
    status: 'active',
    sortOrder: 5,
    imageUrl: '/upsells/pet-welcome-pack.jpg',
    checkoutEnabled: true,
    guestMessageEnabled: true,
    marketingEnabled: true,
  },
];

export const defaultGuidebookSections: GuidebookSection[] = [
  {
    id: 1,
    icon: '🔑',
    title: 'Check-in',
    content: 'Check-in is from 3:00 PM. Your access details are sent after the final balance is paid.',
  },
  {
    id: 2,
    icon: '📶',
    title: 'WiFi',
    content: 'Network: Deloraine Guest\nPassword: Provided in your pre-arrival message.',
  },
  {
    id: 3,
    icon: '🍽️',
    title: 'Local favourites',
    content: 'Town Basin is a short drive away for restaurants, cafes and riverside walks.',
  },
];

export const defaultCheckInBook: CheckInBookData = {
  checkInTime: '3:00 PM',
  checkOutTime: '10:00 AM',
  address: '50 Konini St, Whangarei, Northland, New Zealand 0112',
  parkingInstructions: 'Please park in the marked guest parking area near the cottage entrance.',
  wifiName: 'Deloraine Guest',
  wifiPassword: 'Provided in your pre-arrival message.',
  accessInstructions: 'Access details are sent after the final balance is paid. Use the private entrance and follow the path to the cottage.',
  houseRules: 'Please respect the quiet rural setting, keep noise low at night, and leave the cottage tidy.',
  rubbishRecyclingInstructions: 'Use the labelled rubbish and recycling bins. Please separate glass, recycling, and general waste.',
  heatingCoolingInstructions: 'Use the heat pump for heating and cooling. Please turn it off when you leave for the day.',
  emergencyContacts: 'For emergencies call 111. For urgent stay issues, contact the host on the number provided in your booking email.',
  hostContactDetails: 'hello@delorainecottage.com',
  directions: 'From central Whangarei, follow signs toward Onerahi and use your map app for the final approach to Konini Street.',
  whatToBring: 'Bring personal toiletries, beach towels if heading to the coast, and any food or drinks you would like during your stay.',
  checkoutInstructions: 'Please wash used dishes, place rubbish in the bins, turn off heating/cooling, lock up, and message the host once you have left.',
  includeInPreArrivalEmail: true,
  sendHoursBeforeCheckIn: 24,
};

export const localGuidebookCategoryLabels: Record<LocalGuidebookCategory, string> = {
  local_cafe: 'Local cafe',
  restaurant: 'Restaurant',
  beach: 'Beach',
  walk: 'Walk',
  free_thing: 'Free thing to do',
  rainy_day: 'Rainy day activity',
  family_friendly: 'Family-friendly',
  hidden_gem: 'Hidden gem',
  supermarket: 'Supermarket',
  pharmacy: 'Pharmacy',
  petrol_station: 'Petrol station',
  emergency_service: 'Emergency service',
  host_recommendation: 'Host recommendation',
};

export const defaultLocalGuidebookItems: LocalGuidebookItem[] = [
  {
    id: 1,
    title: 'Town Basin',
    category: 'local_cafe',
    description: 'A relaxed riverside area with cafes, restaurants, galleries, and an easy waterfront walk.',
    address: 'Town Basin, Whangarei',
    distanceFromProperty: 'About 15 minutes by car',
    googleMapsLink: 'https://www.google.com/maps/search/?api=1&query=Town+Basin+Whangarei',
    googlePlaceId: '',
    image: '',
    hostNote: 'A good first stop for coffee, a wander, and easy dinner options.',
    recommended: true,
    isPublic: true,
  },
  {
    id: 2,
    title: 'Whangarei Falls',
    category: 'walk',
    description: 'A beautiful waterfall with a short loop walk and picnic spots nearby.',
    address: 'Boundary Road, Tikipunga, Whangarei',
    distanceFromProperty: 'About 25 minutes by car',
    googleMapsLink: 'https://www.google.com/maps/search/?api=1&query=Whangarei+Falls',
    googlePlaceId: '',
    image: '',
    hostNote: 'Easy, scenic, and lovely after rain.',
    recommended: true,
    isPublic: true,
  },
  {
    id: 3,
    title: 'Tutukaka Coast',
    category: 'beach',
    description: 'A coastal drive with beaches, lookouts, marina dining, and access toward the Poor Knights Islands.',
    address: 'Tutukaka, Northland',
    distanceFromProperty: 'About 40 minutes by car',
    googleMapsLink: 'https://www.google.com/maps/search/?api=1&query=Tutukaka+Coast',
    googlePlaceId: '',
    image: '',
    hostNote: 'Worth the drive if you want a proper Northland beach day.',
    recommended: true,
    isPublic: true,
  },
  {
    id: 4,
    title: 'Abbey Caves',
    category: 'hidden_gem',
    description: 'A more adventurous local cave walk with glow worms in the right conditions.',
    address: 'Abbey Caves Road, Whangarei',
    distanceFromProperty: 'About 20 minutes by car',
    googleMapsLink: 'https://www.google.com/maps/search/?api=1&query=Abbey+Caves+Whangarei',
    googlePlaceId: '',
    image: '',
    hostNote: 'Check conditions before you go and wear suitable footwear.',
    recommended: false,
    isPublic: true,
  },
  {
    id: 5,
    title: 'Onerahi shops',
    category: 'supermarket',
    description: 'Handy local shops for groceries, essentials, and quick supplies.',
    address: 'Onerahi, Whangarei',
    distanceFromProperty: 'About 5 minutes by car',
    googleMapsLink: 'https://www.google.com/maps/search/?api=1&query=Onerahi+shops+Whangarei',
    googlePlaceId: '',
    image: '',
    hostNote: 'Useful for topping up supplies without driving into town.',
    recommended: true,
    isPublic: true,
  },
];

export function loadDashboardData<T>(key: string, fallback: T): T {
  const stored = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
  if (!stored) return fallback;
  try {
    const parsed = JSON.parse(stored) as T;
    if (LEGACY_DASHBOARD_NAME_PATTERN.test(JSON.stringify(parsed))) {
      localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(fallback));
      return fallback;
    }
    return parsed;
  } catch {
    return fallback;
  }
}

export function saveDashboardData<T>(key: string, value: T) {
  localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(value));
}
