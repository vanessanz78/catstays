export interface TemplateOption {
  id: string;
  dashboardTheme: 'onepage' | 'modern' | 'classic' | 'minimal';
  name: string;
  shortName: string;
  tagline: string;
  bestFor: string;
  accent: string;
  accentSoft: string;
  background: string;
  text: string;
  heroStyle: 'source' | 'poster' | 'cards' | 'magazine';
  typography: {
    body: string;
    heading: string;
    headingWeight: number;
    eyebrowWeight: number;
    heroAlign: 'left' | 'center';
    toneClass: string;
  };
  layoutNotes: string[];
  seoNotes: string[];
}

export interface ColourSelection {
  themeId: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
}

export const WEBSITE_DESIGN_OPTIONS: TemplateOption[] = [
  {
    id: 'source-match',
    dashboardTheme: 'onepage',
    name: 'Original Website',
    shortName: 'Original',
    tagline: 'A close match to the current website first, so owners can see the site they already have before comparing new layouts.',
    bestFor: 'The primary option for owners who want their current website recreated first, then improved only if they choose another style.',
    accent: '#AA7942',
    accentSoft: '#F7EFE6',
    background: '#FFFFFF',
    text: '#333333',
    heroStyle: 'source',
    typography: {
      body: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      heading: 'Georgia, "Times New Roman", serif',
      headingWeight: 700,
      eyebrowWeight: 800,
      heroAlign: 'left',
      toneClass: 'classic-type',
    },
    layoutNotes: ['Primary original preview', 'Current logo, colours, nav and photo treatment', 'Existing page flow preserved first'],
    seoNotes: ['Current page structure carried through', 'Editable title and description', 'Alt text prompts for property photos'],
  },
  {
    id: 'modern-showcase',
    dashboardTheme: 'modern',
    name: 'Modern Showcase',
    shortName: 'Showcase',
    tagline: 'A photo-first website where the hero image leads, then a same-page booking panel opens beneath the headline.',
    bestFor: 'Properties with strong photography, scenic settings, or a visual point of difference.',
    accent: '#4A684F',
    accentSoft: '#F7F4EF',
    background: '#FFFFFF',
    text: '#1F2E22',
    heroStyle: 'poster',
    typography: {
      body: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      heading: '"Playfair Display", Georgia, "Times New Roman", serif',
      headingWeight: 700,
      eyebrowWeight: 900,
      heroAlign: 'left',
      toneClass: 'modern-type',
    },
    layoutNotes: ['Large image hero', 'Same-page booking panel', 'Expandable gallery and guest research sections'],
    seoNotes: ['Fast lazy-loaded images', 'Location-rich captions', 'Review and map sections on page'],
  },
  {
    id: 'conversion-focus',
    dashboardTheme: 'minimal',
    name: 'Conversion Focus',
    shortName: 'Conversion',
    tagline: 'A streamlined website with a side booking card that keeps dates, guests, price and trust signals close to the top.',
    bestFor: 'Owners who want fewer clicks, clearer decisions and more direct enquiries.',
    accent: '#C89A4B',
    accentSoft: '#F5F2EC',
    background: '#FFFFFF',
    text: '#1F2A22',
    heroStyle: 'cards',
    typography: {
      body: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      heading: '"Playfair Display", Georgia, "Times New Roman", serif',
      headingWeight: 700,
      eyebrowWeight: 900,
      heroAlign: 'left',
      toneClass: 'conversion-type',
    },
    layoutNotes: ['Strong booking hero', 'Simple booking bar', 'Dark amenities band'],
    seoNotes: ['Trust signals near booking action', 'Clear section labels', 'Location and gallery content on page'],
  },
  {
    id: 'editorial-guide',
    dashboardTheme: 'classic',
    name: 'Editorial Guide',
    shortName: 'Guide',
    tagline: 'A story-led website with a guided step-through booking panel for guests who want a little more context first.',
    bestFor: 'Character stays, retreats and one-property hosts with a richer story to tell.',
    accent: '#4A5A44',
    accentSoft: '#F3EFEA',
    background: '#FFFFFF',
    text: '#1F2A22',
    heroStyle: 'magazine',
    typography: {
      body: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      heading: '"Playfair Display", Georgia, "Times New Roman", serif',
      headingWeight: 700,
      eyebrowWeight: 900,
      heroAlign: 'left',
      toneClass: 'editorial-type',
    },
    layoutNotes: ['Warm editorial hero', 'Alternating story and image blocks', 'Calm booking prompt'],
    seoNotes: ['Clear section hierarchy', 'Location and amenity content on page', 'Mobile-first image storytelling'],
  },
];

export const WEBSITE_COLOUR_THEME_OPTIONS = [
  { id: 'modern-showcase-colour', name: 'Modern Showcase', font: 'Playfair Display', colors: ['#F7F4EF', '#1F2E22', '#4A684F'] },
  { id: 'conversion-focus-colour', name: 'Conversion Focus', font: 'Playfair Display', colors: ['#F5F2EC', '#1F2A22', '#C89A4B'] },
  { id: 'modern-colour', name: 'Modern', font: 'Inter', colors: ['#F8FAFC', '#315CEB', '#F2A32A'] },
  { id: 'classic-colour', name: 'Classic', font: 'Playfair Display', colors: ['#FFF7E8', '#93491B', '#D78128'] },
  { id: 'nature-colour', name: 'Nature', font: 'Nunito', colors: ['#EFFBF5', '#327D3D', '#8BCB3A'] },
  { id: 'ocean-colour', name: 'Ocean', font: 'Raleway', colors: ['#EDF7FF', '#2F7C95', '#53B6D0'] },
  { id: 'luxury-colour', name: 'Luxury', font: 'Cormorant Garamond', colors: ['#171717', '#A45A21', '#FFF3C5'] },
  { id: 'minimal-colour', name: 'Minimal', font: 'DM Sans', colors: ['#FFFFFF', '#141519', '#777982'] },
];

export const DEFAULT_COLOUR_SELECTION: ColourSelection = {
  themeId: WEBSITE_COLOUR_THEME_OPTIONS[0].id,
  primaryColor: WEBSITE_COLOUR_THEME_OPTIONS[0].colors[0],
  secondaryColor: WEBSITE_COLOUR_THEME_OPTIONS[0].colors[1],
  accentColor: WEBSITE_COLOUR_THEME_OPTIONS[0].colors[2],
};
