import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, Menu, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { StayDirectLogo } from '../brand/StayDirectLogo';
import { Button } from '../design-system/Button';
import { useAuth } from '../../contexts/AuthContext';
import { marketplaceHomeUrl } from '../../lib/marketplaceUrl';

export function MarketingNav() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSignInModal, setShowSignInModal] = useState(false);
  const [signInData, setSignInData] = useState({ email: '', password: '' });
  const [signingIn, setSigningIn] = useState(false);
  const [error, setError] = useState('');
  const [demoMenuOpen, setDemoMenuOpen] = useState(false);
  const demoMenuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { signIn, demoSignIn, user } = useAuth();
  const staysUrl = marketplaceHomeUrl();

  useEffect(() => {
    if (!demoMenuOpen) return;

    const closeOnOutsidePress = (event: MouseEvent | TouchEvent) => {
      if (!demoMenuRef.current?.contains(event.target as Node)) {
        setDemoMenuOpen(false);
      }
    };

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setDemoMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', closeOnOutsidePress);
    document.addEventListener('touchstart', closeOnOutsidePress);
    document.addEventListener('keydown', closeOnEscape);

    return () => {
      document.removeEventListener('mousedown', closeOnOutsidePress);
      document.removeEventListener('touchstart', closeOnOutsidePress);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [demoMenuOpen]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setSigningIn(true);
    setError('');

    const { error: authError } = await signIn(signInData.email, signInData.password);
    if (authError) {
      setError(authError);
      setSigningIn(false);
      return;
    }

    setShowSignInModal(false);
    setSignInData({ email: '', password: '' });
    setSigningIn(false);
    navigate('/dashboard');
  };

  const handleDemoDashboard = () => {
    demoSignIn();
    setMobileMenuOpen(false);
    setDemoMenuOpen(false);
    navigate('/dashboard');
  };

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="fixed left-0 right-0 top-0 z-[80] hidden items-center justify-between border-b border-[#EBEBEB] bg-white px-8 py-5 shadow-sm md:flex">
        <div className="flex items-center gap-8">
          <Link to="/" aria-label="StayDirect home">
            <StayDirectLogo markClassName="h-11 w-11" textClassName="text-2xl font-bold text-[#FF385C]" />
          </Link>
          <div className="flex items-center gap-6">
            <a href={staysUrl} className="text-[#484848] hover:text-[#FF385C] transition-colors font-medium">
              Stays
            </a>
            <Link to="/features" className="text-[#484848] hover:text-[#00A699] transition-colors font-medium">
              Features
            </Link>
            <Link to="/how-it-works" className="text-[#484848] hover:text-[#00A699] transition-colors font-medium">
              How It Works
            </Link>
            <Link to="/pricing" className="text-[#484848] hover:text-[#00A699] transition-colors font-medium">
              Pricing
            </Link>
            <div
              ref={demoMenuRef}
              className="relative"
              onMouseEnter={() => setDemoMenuOpen(true)}
              onMouseLeave={() => setDemoMenuOpen(false)}
            >
              <button
                type="button"
                className="flex items-center gap-1 text-[#484848] font-medium transition-colors hover:text-[#00A699]"
                aria-haspopup="menu"
                aria-expanded={demoMenuOpen}
                onClick={() => setDemoMenuOpen((open) => !open)}
              >
                Demos
                <ChevronDown className={`h-4 w-4 transition-transform ${demoMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              <div
                role="menu"
                className={`absolute left-0 top-full z-50 mt-2 w-72 rounded-xl border border-[#EBEBEB] bg-white shadow-xl transition-all ${
                  demoMenuOpen ? 'visible translate-y-0 opacity-100' : 'invisible -translate-y-1 opacity-0 pointer-events-none'
                }`}
              >
                <Link to="/example" role="menuitem" className="block px-4 py-3 text-[#484848] hover:bg-[#F7F7F7] hover:text-[#00A699] transition-colors rounded-t-xl" onClick={() => setDemoMenuOpen(false)}>
                  <div className="font-semibold">Deloraine Cottage</div>
                  <div className="text-xs text-[#717171]">Live one-page demo</div>
                </Link>
                <button
                  type="button"
                  role="menuitem"
                  onClick={handleDemoDashboard}
                  className="block w-full border-t border-[#EBEBEB] px-4 py-3 text-left text-[#484848] transition-colors hover:bg-[#F7F7F7] hover:text-[#00A699]"
                >
                  <div className="font-semibold">Dashboard - Deloraine Cottage</div>
                  <div className="text-xs text-[#717171]">Backend management demo</div>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <Link to="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
          ) : (
            <Button variant="ghost" onClick={() => setShowSignInModal(true)}>Sign In</Button>
          )}
          <Link to="/signup">
            <Button variant="primary">Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <nav className="fixed left-0 right-0 top-0 z-[80] flex items-center justify-between border-b border-[#EBEBEB] bg-white px-4 py-4 shadow-sm md:hidden">
        <Link to="/" aria-label="StayDirect home">
          <StayDirectLogo markClassName="h-10 w-10" textClassName="text-xl font-bold text-[#FF385C]" />
        </Link>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-[#484848]"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed left-0 right-0 top-[73px] z-[70] border-b border-[#EBEBEB] bg-white py-4 shadow-lg md:hidden">
          <div className="flex flex-col gap-3 px-4">
            <a href={staysUrl} className="text-[#484848] hover:text-[#FF385C] py-2 font-medium" onClick={() => setMobileMenuOpen(false)}>Stays</a>
            <Link to="/features" className="text-[#484848] hover:text-[#00A699] py-2 font-medium" onClick={() => setMobileMenuOpen(false)}>Features</Link>
            <Link to="/how-it-works" className="text-[#484848] hover:text-[#00A699] py-2 font-medium" onClick={() => setMobileMenuOpen(false)}>How It Works</Link>
            <Link to="/pricing" className="text-[#484848] hover:text-[#00A699] py-2 font-medium" onClick={() => setMobileMenuOpen(false)}>Pricing</Link>
            <div className="py-2">
              <div className="font-medium text-[#717171] text-sm mb-2">Demos</div>
              <Link to="/example" className="text-[#484848] hover:text-[#00A699] py-1 pl-4 font-medium block" onClick={() => setMobileMenuOpen(false)}>Deloraine Cottage</Link>
              <button type="button" className="text-left text-[#484848] hover:text-[#00A699] py-1 pl-4 font-medium block" onClick={handleDemoDashboard}>Dashboard - Deloraine Cottage</button>
            </div>
            <div className="border-t border-[#EBEBEB] pt-3 mt-2 flex flex-col gap-2">
              {user ? (
                <Link to="/dashboard" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" fullWidth>Dashboard</Button>
                </Link>
              ) : (
                <Button variant="ghost" fullWidth onClick={() => { setMobileMenuOpen(false); setShowSignInModal(true); }}>Sign In</Button>
              )}
              <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="primary" fullWidth>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      )}

      <div aria-hidden="true" className="hidden h-[85px] md:block" />
      <div aria-hidden="true" className="h-[73px] md:hidden" />

      {/* Sign In Modal */}
      {showSignInModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full">
            <div className="border-b border-[#EBEBEB] px-6 py-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-[#484848]">Welcome Back</h2>
              <button onClick={() => setShowSignInModal(false)} className="p-2 hover:bg-[#F7F7F7] rounded-lg transition-colors">
                <X className="w-5 h-5 text-[#717171]" />
              </button>
            </div>

            <form onSubmit={handleSignIn} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-[#484848] mb-2">Email Address</label>
                <input
                  type="email"
                  required
                  value={signInData.email}
                  onChange={(e) => setSignInData({ ...signInData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#EBEBEB] focus:outline-none focus:ring-2 focus:ring-[#00A699] focus:border-transparent"
                  placeholder="you@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#484848] mb-2">Password</label>
                <input
                  type="password"
                  required
                  value={signInData.password}
                  onChange={(e) => setSignInData({ ...signInData, password: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#EBEBEB] focus:outline-none focus:ring-2 focus:ring-[#00A699] focus:border-transparent"
                  placeholder="Enter your password"
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-xl">
                  <p className="text-red-700 text-sm">{error}</p>
                </div>
              )}

              <Button type="submit" variant="secondary" size="lg" fullWidth disabled={signingIn} className="bg-[#00A699] hover:bg-[#008B80]">
                {signingIn ? 'Signing In...' : 'Sign In to Dashboard'}
              </Button>

              <div className="text-center pt-4 border-t border-[#EBEBEB]">
                <p className="text-sm text-[#717171]">
                  Don't have an account?{' '}
                  <Link to="/signup" className="text-[#00A699] font-semibold hover:underline" onClick={() => setShowSignInModal(false)}>
                            Create an account
                  </Link>
                </p>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
