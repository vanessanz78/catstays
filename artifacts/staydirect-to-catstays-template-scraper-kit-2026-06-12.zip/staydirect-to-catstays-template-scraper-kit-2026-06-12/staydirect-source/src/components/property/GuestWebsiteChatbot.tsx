import React, { useMemo, useRef, useState } from 'react';
import { Bot, Mail, MessageCircle, Phone, Send, X } from 'lucide-react';
import { apiUrl } from '../../lib/api';

export type GuestFaq = {
  question: string;
  answer: string;
};

export type GuestPropertyFaqInput = {
  propertyName?: string | null;
  city?: string | null;
  country?: string | null;
  address?: string | null;
  basePrice?: string | number | null;
  cleaningFee?: string | number | null;
  taxRate?: string | number | null;
  minNights?: string | number | null;
  maxGuests?: string | number | null;
  bedrooms?: string | number | null;
  bathrooms?: string | number | null;
  amenities?: string[] | null;
  checkInTime?: string | null;
  checkOutTime?: string | null;
  petsAllowed?: boolean | null;
  smokingAllowed?: boolean | null;
  eventsAllowed?: boolean | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
};

export type ChatbotPropertyContext = {
  propertyName: string;
  propertyType?: string | null;
  address?: string | null;
  city?: string | null;
  country?: string | null;
  description?: string | null;
  checkInTime?: string | null;
  checkOutTime?: string | null;
  maxGuests?: number | null;
  bedrooms?: number | null;
  bathrooms?: number | null;
  minNights?: number | null;
  basePrice?: number | null;
  cleaningFee?: number | null;
  amenities?: string[];
  houseRules?: string | null;
  petsAllowed?: boolean | null;
  smokingAllowed?: boolean | null;
  eventsAllowed?: boolean | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
};

export type ChatbotGuidebookItem = {
  title: string;
  category: string;
  description?: string | null;
  distanceFromProperty?: string | null;
  hostNote?: string | null;
};

type ChatMessage = {
  author: 'guest' | 'assistant';
  body: string;
};

function cleanText(value?: string | number | null) {
  return String(value ?? '').trim();
}

function positiveNumber(value?: string | number | null) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : null;
}

function sentenceList(items: string[]) {
  if (items.length <= 1) return items[0] || '';
  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

function formatFaqTime(value?: string | null) {
  const text = cleanText(value);
  if (!text) return '';
  const match = text.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
  if (!match) return text;
  const hour24 = Number(match[1]);
  const minute = match[2];
  if (!Number.isFinite(hour24)) return text;
  const suffix = hour24 >= 12 ? 'PM' : 'AM';
  const hour12 = hour24 % 12 || 12;
  return `${hour12}:${minute} ${suffix}`;
}

export function buildGuestFaqs(input: GuestPropertyFaqInput): GuestFaq[] {
  const propertyName = cleanText(input.propertyName) || 'this stay';
  const city = cleanText(input.city);
  const country = cleanText(input.country);
  const location = [city, country].filter(Boolean).join(', ') || cleanText(input.address) || 'the listed location';
  const basePrice = positiveNumber(input.basePrice);
  const cleaningFee = positiveNumber(input.cleaningFee);
  const taxRate = positiveNumber(input.taxRate);
  const minNights = positiveNumber(input.minNights);
  const maxGuests = positiveNumber(input.maxGuests);
  const bedrooms = positiveNumber(input.bedrooms);
  const bathrooms = positiveNumber(input.bathrooms);
  const amenities = (input.amenities || []).filter(Boolean).slice(0, 8);
  const checkInTime = formatFaqTime(input.checkInTime) || '3:00 PM';
  const checkOutTime = formatFaqTime(input.checkOutTime) || '10:00 AM';
  const contactOptions = [
    cleanText(input.contactEmail) ? `email ${cleanText(input.contactEmail)}` : '',
    cleanText(input.contactPhone) ? `call ${cleanText(input.contactPhone)}` : '',
  ].filter(Boolean);

  return [
    {
      question: `How do I book ${propertyName}?`,
      answer: 'Choose your check-in date, check-out date and guest count, then continue to the secure booking step. You can review the full price before payment.',
    },
    {
      question: 'What time is check-in and check-out?',
      answer: `Check-in is from ${checkInTime} and check-out is by ${checkOutTime}.`,
    },
    {
      question: 'How many guests can stay?',
      answer: `${propertyName} sleeps ${maxGuests || 'the listed number of'} guests${bedrooms ? ` across ${bedrooms} bedroom${bedrooms === 1 ? '' : 's'}` : ''}${bathrooms ? ` with ${bathrooms} bathroom${bathrooms === 1 ? '' : 's'}` : ''}.`,
    },
    {
      question: 'What amenities are included?',
      answer: amenities.length
        ? `Included amenities include ${sentenceList(amenities.map((amenity) => amenity.replace(/-/g, ' ')))}.`
        : 'The amenities section lists what is included for your stay.',
    },
    {
      question: 'Where is the property located?',
      answer: `${propertyName} is in ${location}. Check the location section for map and nearby details before booking.`,
    },
    {
      question: 'What does it cost?',
      answer: basePrice
        ? `The nightly rate starts from NZ $${basePrice}${cleaningFee ? `, with a NZ $${cleaningFee} cleaning fee` : ''}${taxRate ? ` and ${taxRate}% GST shown in the total` : ''}.`
        : 'Enter your dates and guest count to see the current total before payment.',
    },
    {
      question: 'Are pets, smoking or parties allowed?',
      answer: `${input.petsAllowed ? 'Pets are allowed' : 'Pets are not listed as allowed'}. ${input.smokingAllowed ? 'Smoking is allowed in the listed areas' : 'Smoking is not allowed'}. ${input.eventsAllowed ? 'Events are allowed by arrangement' : 'Parties and events are not allowed'}.`,
    },
    {
      question: 'How can I contact the host?',
      answer: contactOptions.length
        ? `You can ${sentenceList(contactOptions)}.`
        : 'Use the contact or booking form and the host will get back to you.',
    },
  ];
}

function answerFromFaqs(question: string, faqs: GuestFaq[], contactEmail?: string | null, contactPhone?: string | null) {
  const normalized = question.toLowerCase();
  const contactAnswer = [
    contactEmail ? `Email: ${contactEmail}` : '',
    contactPhone ? `Phone: ${contactPhone}` : '',
  ].filter(Boolean).join('\n');

  if (/contact|phone|email|host|person|human|call/.test(normalized) && contactAnswer) {
    return `${contactAnswer}\n\nI can also send a message to the host if you'd like.`;
  }

  const scored = faqs
    .map((faq) => {
      const words = faq.question.toLowerCase().split(/[^a-z0-9]+/).filter((word) => word.length > 3);
      return { faq, score: words.filter((word) => normalized.includes(word)).length };
    })
    .sort((a, b) => b.score - a.score);

  return scored[0]?.score ? scored[0].faq.answer : 'I can help with booking, dates, guests, amenities, policies, location and host contact details. Try one of the suggested questions below.';
}

export function GuestWebsiteChatbot({
  propertyName,
  accent = '#FF5A5F',
  faqs,
  contactEmail,
  contactPhone,
  propertyId,
  propertyContext,
  guidebookItems,
  position = 'fixed',
  className = '',
}: {
  propertyName: string;
  accent?: string;
  faqs: GuestFaq[];
  contactEmail?: string | null;
  contactPhone?: string | null;
  propertyId?: string | null;
  propertyContext?: ChatbotPropertyContext;
  guidebookItems?: ChatbotGuidebookItem[];
  position?: 'fixed' | 'absolute';
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    { author: 'assistant', body: `Hi, I'm here to help with questions about ${propertyName} — check-in, amenities, local tips and more. What would you like to know?` },
  ]);
  const [typing, setTyping] = useState(false);
  const [handoffOpen, setHandoffOpen] = useState(false);
  const [handoffName, setHandoffName] = useState('');
  const [handoffEmail, setHandoffEmail] = useState('');
  const [handoffMessage, setHandoffMessage] = useState('');
  const [handoffSending, setHandoffSending] = useState(false);
  const [handoffError, setHandoffError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const quickQuestions = useMemo(() => faqs.slice(0, 4), [faqs]);
  const lastGuestMessage = useMemo(
    () => [...messages].reverse().find((message) => message.author === 'guest')?.body || '',
    [messages],
  );

  const useAI = Boolean(propertyContext);

  function openHandoffForm() {
    setHandoffOpen(true);
    setHandoffError('');
    if (!handoffMessage.trim()) {
      setHandoffMessage(lastGuestMessage);
    }
  }

  async function sendHandoff(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!propertyId || handoffSending) return;
    const email = handoffEmail.trim();
    const message = handoffMessage.trim() || lastGuestMessage.trim();
    if (!email) {
      setHandoffError('Please enter your email so the host can reply.');
      return;
    }
    if (!message) {
      setHandoffError('Please add a message for the host.');
      return;
    }

    setHandoffSending(true);
    setHandoffError('');
    try {
      const res = await fetch(apiUrl('/api/inquiries'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          property_id: propertyId,
          guest_name: handoffName.trim() || 'Website visitor',
          guest_email: email,
          subject: `Guest question for ${propertyName}`,
          message,
          source: 'guest_chatbot',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(String(data.error || 'Could not send message.'));
      }
      setMessages((prev) => [...prev, { author: 'assistant', body: `I've sent that to the host. They'll reply to ${email}.` }]);
      setHandoffOpen(false);
      setHandoffMessage('');
    } catch (error) {
      setHandoffError(error instanceof Error ? error.message : 'Could not send message.');
    } finally {
      setHandoffSending(false);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
  }

  async function ask(text: string) {
    const trimmed = text.trim();
    if (!trimmed || typing) return;
    setInput('');

    const userMsg: ChatMessage = { author: 'guest', body: trimmed };
    setMessages((prev) => [...prev, userMsg]);

    if (!useAI) {
      const answer = answerFromFaqs(trimmed, faqs, contactEmail, contactPhone);
      setMessages((prev) => [...prev, { author: 'assistant', body: answer }]);
      return;
    }

    setTyping(true);
    try {
      const res = await fetch(apiUrl('/api/chatbot'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          propertyContext,
          guidebookItems: guidebookItems || [],
          history: messages.slice(-10),
        }),
      });
      const data = await res.json().catch(() => ({}));
      const reply = res.ok
        ? String(data.reply || '')
        : String(data.error || "Sorry, I couldn't get a response. Try a quick question below or contact the host directly.");
      setMessages((prev) => [...prev, { author: 'assistant', body: reply }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { author: 'assistant', body: 'Sorry, something went wrong. Please try again or contact the host directly.' },
      ]);
    } finally {
      setTyping(false);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
  }

  return (
    <div className={`${position === 'fixed' ? 'fixed' : 'absolute'} bottom-5 right-5 z-40 ${className}`}>
      {open && (
        <div className="mb-3 w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-[#E5E5E5] bg-white shadow-2xl">
          <div className="flex items-center justify-between gap-3 px-4 py-3 text-white" style={{ backgroundColor: accent }}>
            <div className="flex min-w-0 items-center gap-2">
              <Bot className="h-5 w-5 shrink-0" />
              <div className="min-w-0">
                <p className="truncate text-sm font-black">{propertyName} help</p>
                <p className="truncate text-xs text-white/82">Ask about this stay</p>
              </div>
            </div>
            <button type="button" onClick={() => setOpen(false)} className="rounded-full p-1 text-white/85 hover:bg-white/15" aria-label="Close chat">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="max-h-72 space-y-3 overflow-y-auto bg-[#FAFAF8] p-4">
            {messages.map((message, index) => (
              <div
                key={`${message.author}-${index}`}
                className={`rounded-2xl px-3 py-2 text-sm leading-6 ${message.author === 'assistant' ? 'bg-white text-[#484848]' : 'ml-auto bg-[#222222] text-white'}`}
                style={{ maxWidth: '90%', ...(message.author === 'guest' ? { marginLeft: 'auto' } : {}) }}
              >
                {message.body}
              </div>
            ))}
            {typing && (
              <div className="flex items-center gap-1.5 rounded-2xl bg-white px-3 py-2.5">
                <span className="h-2 w-2 animate-bounce rounded-full bg-[#B0B0B0]" style={{ animationDelay: '0ms' }} />
                <span className="h-2 w-2 animate-bounce rounded-full bg-[#B0B0B0]" style={{ animationDelay: '150ms' }} />
                <span className="h-2 w-2 animate-bounce rounded-full bg-[#B0B0B0]" style={{ animationDelay: '300ms' }} />
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              {quickQuestions.map((faq) => (
                <button
                  key={faq.question}
                  type="button"
                  onClick={() => ask(faq.question)}
                  disabled={typing}
                  className="rounded-full border border-[#D8D8D8] bg-white px-3 py-1.5 text-left text-xs font-bold text-[#484848] hover:border-[#B0B0B0] disabled:opacity-50"
                >
                  {faq.question}
                </button>
              ))}
            </div>
            {(contactEmail || contactPhone) && (
              <div className="space-y-1 rounded-2xl bg-white p-3 text-xs text-[#717171]">
                {contactEmail && <p className="flex items-center gap-2"><Mail className="h-3.5 w-3.5" /> {contactEmail}</p>}
                {contactPhone && <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" /> {contactPhone}</p>}
              </div>
            )}
            {propertyId && (
              <div className="rounded-2xl bg-white p-3">
                {!handoffOpen ? (
                  <button
                    type="button"
                    onClick={openHandoffForm}
                    className="w-full rounded-xl px-3 py-2 text-sm font-black text-white"
                    style={{ backgroundColor: accent }}
                  >
                    Message the host
                  </button>
                ) : (
                  <form className="space-y-2" onSubmit={sendHandoff}>
                    <input
                      value={handoffName}
                      onChange={(event) => setHandoffName(event.target.value)}
                      placeholder="Your name"
                      className="w-full rounded-xl border border-[#D8D8D8] px-3 py-2 text-sm"
                    />
                    <input
                      type="email"
                      value={handoffEmail}
                      onChange={(event) => setHandoffEmail(event.target.value)}
                      placeholder="Your email"
                      className="w-full rounded-xl border border-[#D8D8D8] px-3 py-2 text-sm"
                      required
                    />
                    <textarea
                      value={handoffMessage}
                      onChange={(event) => setHandoffMessage(event.target.value)}
                      placeholder="What would you like to ask?"
                      rows={3}
                      className="w-full resize-none rounded-xl border border-[#D8D8D8] px-3 py-2 text-sm"
                      required
                    />
                    {handoffError && <p className="text-xs font-bold text-[#D01744]">{handoffError}</p>}
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        disabled={handoffSending}
                        className="flex-1 rounded-xl px-3 py-2 text-sm font-black text-white disabled:opacity-55"
                        style={{ backgroundColor: accent }}
                      >
                        {handoffSending ? 'Sending...' : 'Send to host'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setHandoffOpen(false);
                          setHandoffError('');
                        }}
                        className="rounded-xl border border-[#D8D8D8] px-3 py-2 text-sm font-bold text-[#484848]"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          <form
            className="flex gap-2 border-t border-[#EBEBEB] bg-white p-3"
            onSubmit={(event) => {
              event.preventDefault();
              ask(input);
            }}
          >
            <input
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder={typing ? 'Thinking…' : 'Ask a question'}
              disabled={typing}
              className="min-w-0 flex-1 rounded-xl border border-[#D8D8D8] px-3 py-2 text-sm focus:outline-none focus:ring-2 disabled:opacity-60"
              style={{ '--tw-ring-color': accent } as React.CSSProperties}
            />
            <button type="submit" disabled={typing || !input.trim()} className="rounded-xl px-3 py-2 text-white disabled:opacity-50" style={{ backgroundColor: accent }} aria-label="Send question">
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-14 w-14 items-center justify-center rounded-full text-white shadow-2xl transition hover:scale-105"
        style={{ backgroundColor: accent }}
        aria-label="Open stay chatbot"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    </div>
  );
}
