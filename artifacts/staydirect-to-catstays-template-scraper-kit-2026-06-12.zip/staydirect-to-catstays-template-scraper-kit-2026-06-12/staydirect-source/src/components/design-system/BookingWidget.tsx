import React, { useState } from 'react';
import { Calendar, Users, ArrowRight, Tag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { describePromotion, type PromotionCampaign } from '../../lib/promotions';

interface BookingWidgetProps {
  basePrice: number;
  cleaningFee: number;
  taxRate: number;
  minNights: number;
  accentColor?: string;
  bookingPath?: string;
  priceLabel?: string;
  previewMode?: boolean;
  promotion?: PromotionCampaign | null;
  onBook?: (details: { checkIn: string; checkOut: string; guests: number; nights: number }) => void;
  onPreviewBook?: () => void;
}

export function BookingWidget({
  basePrice,
  cleaningFee,
  taxRate,
  minNights,
  accentColor = '#FF5A5F',
  bookingPath = '/booking',
  priceLabel = 'Select dates for pricing',
  previewMode = false,
  promotion = null,
  onBook,
  onPreviewBook,
}: BookingWidgetProps) {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(2);

  const calculateNights = () => {
    if (!checkIn || !checkOut) return 0;
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    return Math.max(0, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
  };

  const nights = calculateNights();
  const hasKnownPrice = basePrice > 0;
  const subtotal = nights * basePrice;
  const tax = subtotal * (taxRate / 100);
  const total = hasKnownPrice ? subtotal + (nights > 0 ? cleaningFee : 0) + tax : 0;

  const handleBook = () => {
    if (previewMode) {
      onPreviewBook?.();
      return;
    }

    if (onBook) {
      onBook({ checkIn, checkOut, guests, nights });
      return;
    }

    if (!checkIn || !checkOut || nights < minNights) return;

    if (/^https?:\/\//i.test(bookingPath)) {
      window.location.href = bookingPath;
      return;
    }

    const params = new URLSearchParams({ checkIn, checkOut, guests: String(guests) });
    if (promotion?.showAtCheckout) params.set('promo', promotion.code);
    navigate(`${bookingPath}?${params.toString()}`);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-[#EBEBEB] p-6 sticky top-24">
      <div className="flex items-baseline gap-1 mb-5">
        {hasKnownPrice ? (
          <>
            <span className="text-3xl font-bold text-[#484848]">${basePrice}</span>
            <span className="text-[#717171]">/ night</span>
          </>
        ) : (
          <span className="text-2xl font-bold text-[#484848]">{priceLabel}</span>
        )}
      </div>

      {promotion?.showAtCheckout && (
        <div className="mb-4 rounded-2xl border border-[#EBEBEB] bg-[#FFF7F5] p-4">
          <div className="flex items-start gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white" style={{ backgroundColor: accentColor }}>
              <Tag className="h-4 w-4" />
            </span>
            <div>
              <p className="text-sm font-black text-[#484848]">{promotion.name}</p>
              <p className="mt-1 text-xs leading-5 text-[#717171]">
                Enter <span className="font-mono font-black text-[#484848]">{promotion.code}</span> at checkout for {describePromotion(promotion).toLowerCase()}.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="border border-[#EBEBEB] rounded-xl overflow-hidden mb-3">
        <div className="grid grid-cols-2 divide-x divide-[#EBEBEB]">
          <div className="p-3">
            <label className="block text-xs font-semibold text-[#484848] uppercase tracking-wide mb-1">Check-in</label>
            <input
              type="date"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full text-sm text-[#484848] focus:outline-none bg-transparent"
            />
          </div>
          <div className="p-3">
            <label className="block text-xs font-semibold text-[#484848] uppercase tracking-wide mb-1">Check-out</label>
            <input
              type="date"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
              min={checkIn || new Date().toISOString().split('T')[0]}
              className="w-full text-sm text-[#484848] focus:outline-none bg-transparent"
            />
          </div>
        </div>
        <div className="border-t border-[#EBEBEB] p-3">
          <label className="block text-xs font-semibold text-[#484848] uppercase tracking-wide mb-1">Guests</label>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setGuests(Math.max(1, guests - 1))}
              className="w-7 h-7 rounded-full border border-[#EBEBEB] flex items-center justify-center text-[#484848] hover:border-[#484848] transition-colors"
            >
              -
            </button>
            <span className="text-sm text-[#484848] font-medium">{guests} guest{guests !== 1 ? 's' : ''}</span>
            <button
              onClick={() => setGuests(guests + 1)}
              className="w-7 h-7 rounded-full border border-[#EBEBEB] flex items-center justify-center text-[#484848] hover:border-[#484848] transition-colors"
            >
              +
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleBook}
        disabled={!previewMode && !onBook && (!checkIn || !checkOut || nights < minNights)}
        className="w-full py-3.5 rounded-xl font-semibold text-white text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        style={{ backgroundColor: accentColor }}
      >
        Reserve Now
        <ArrowRight className="w-5 h-5" />
      </button>

      {nights > 0 && hasKnownPrice && (
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between text-[#717171]">
            <span>${basePrice} × {nights} night{nights !== 1 ? 's' : ''}</span>
            <span className="text-[#484848]">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-[#717171]">
            <span>Cleaning fee</span>
            <span className="text-[#484848]">${cleaningFee.toFixed(2)}</span>
          </div>
          {taxRate > 0 && (
            <div className="flex justify-between text-[#717171]">
              <span>GST ({taxRate}%)</span>
              <span className="text-[#484848]">${tax.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-semibold text-[#484848] pt-2 border-t border-[#EBEBEB]">
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
        </div>
      )}

      {nights > 0 && !hasKnownPrice && (
        <p className="mt-4 text-sm text-[#717171]">
          This source uses date-based pricing. Guests can select dates in the live booking checkout to see the exact total.
        </p>
      )}

      {nights > 0 && nights < minNights && (
        <p className="text-xs text-red-500 mt-2 text-center">
          Minimum stay is {minNights} nights
        </p>
      )}

      <p className="text-xs text-[#717171] text-center mt-3">You won't be charged yet</p>
    </div>
  );
}
