import React from 'react';
import { cn } from '../../lib/utils';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  children: React.ReactNode;
}

export function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  children,
  className = '',
  ...props
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center gap-2 rounded-xl font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer';

  const variants = {
    primary: 'bg-[#FF5A5F] text-white hover:bg-[#FF4449] active:bg-[#E63E43] shadow-sm hover:shadow-md',
    secondary: 'bg-[#00A699] text-white hover:bg-[#008B80] active:bg-[#007A70] shadow-sm hover:shadow-md',
    outline: 'border-2 border-[#919191] text-[#484848] hover:border-[#006B60] hover:text-[#006B60] hover:bg-[#F7F7F7]',
    ghost: 'text-[#484848] hover:bg-[#F7F7F7] hover:text-[#006B60]',
    danger: 'bg-[#FF385C] text-white hover:bg-[#E61E4D] active:bg-[#C13584] shadow-sm hover:shadow-md',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-5 py-2.5 text-base',
    lg: 'px-7 py-3.5 text-lg',
  };

  const widthClass = fullWidth ? 'w-full' : '';

  return (
    <button
      className={cn(baseStyles, variants[variant], sizes[size], widthClass, className)}
      {...props}
    >
      {children}
    </button>
  );
}
