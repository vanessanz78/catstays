import React, { Suspense, lazy, useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation, useParams, useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { useKeepAlive } from './hooks/useKeepAlive';
import { supabase } from './lib/supabase';
import { usePropertyByDomain } from './hooks/usePropertyByDomain';
import { SupportChatbot } from './components/marketing/SupportChatbot';
import { FeatureGate } from './components/dashboard/FeatureGate';
import { isDeloraineHost } from './components/property/DeloraineSiteChrome';
import { HOST_PROPERTY_KEY } from './lib/dashboardScope';
import { isMainPlatformHost, isMarketplaceHost, isPropertyHost } from './lib/domainRouting';
import { LOCAL_HOST_ID, isDeloraineLocalHostName } from './lib/localSetup';
import type { FeatureId } from './lib/entitlements';

// Marketing Pages
const HomePage = lazy(() => import('./pages/HomePage'));
const FeaturesPage = lazy(() => import('./pages/FeaturesPage'));
const HowItWorksPage = lazy(() => import('./pages/HowItWorksPage'));
const PricingPage = lazy(() => import('./pages/PricingPage'));
const FAQPage = lazy(() => import('./pages/FAQPage'));
const SignUpPage = lazy(() => import('./pages/SignUpPage'));
const SignInPage = lazy(() => import('./pages/SignInPage'));
const GeneratedPreviewPage = lazy(() => import('./pages/GeneratedPreviewPage'));
const WebsiteOptionsPage = lazy(() => import('./pages/WebsiteOptionsPage'));
const TemplatePreviewPage = lazy(() => import('./pages/WebsiteOptionsPage').then((module) => ({ default: module.TemplatePreviewPage })));
const {
  AboutPage,
  BlogPage,
  BlogAdminPage,
  BlogArticlePage,
  CommunityPage,
  ContactPage,
  CookiePolicyPage,
  HelpArticlePage,
  HelpCentrePage,
  PrivacyPolicyPage,
  TermsPage,
} = {
  AboutPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.AboutPage }))),
  BlogPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.BlogPage }))),
  BlogAdminPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.BlogAdminPage }))),
  BlogArticlePage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.BlogArticlePage }))),
  CommunityPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.CommunityPage }))),
  ContactPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.ContactPage }))),
  CookiePolicyPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.CookiePolicyPage }))),
  HelpArticlePage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.HelpArticlePage }))),
  HelpCentrePage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.HelpCentrePage }))),
  PrivacyPolicyPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.PrivacyPolicyPage }))),
  TermsPage: lazy(() => import('./pages/MarketingContentPages').then((module) => ({ default: module.TermsPage }))),
};

// Demo Pages
const DemoPage = lazy(() => import('./pages/DemoPage'));
const ExamplePage = lazy(() => import('./pages/ExamplePage'));

// Dashboard Pages
const DashboardHome = lazy(() => import('./pages/dashboard/DashboardHome'));
const BookingsPage = lazy(() => import('./pages/dashboard/BookingsPage'));
const CalendarPage = lazy(() => import('./pages/dashboard/CalendarPage'));
const PropertyEditorPage = lazy(() => import('./pages/dashboard/PropertyEditorPage'));
const MessagingPage = lazy(() => import('./pages/dashboard/MessagingPage'));
const GuestsPage = lazy(() => import('./pages/dashboard/GuestsPage'));
const ReviewsPage = lazy(() => import('./pages/dashboard/ReviewsPage'));
const EarningsPage = lazy(() => import('./pages/dashboard/EarningsPage'));
const PromotionsPage = lazy(() => import('./pages/dashboard/PromotionsPage'));
const MarketingStudioPage = lazy(() => import('./pages/dashboard/MarketingStudioPage'));
const AccountingPage = lazy(() => import('./pages/dashboard/AccountingPage'));
const CheckInBookPage = lazy(() => import('./pages/dashboard/CheckInBookPage'));
const LocalGuidebookPage = lazy(() => import('./pages/dashboard/LocalGuidebookPage?guidebookRefresh=20260525'));
const UpsellsPage = lazy(() => import('./pages/dashboard/UpsellsPage'));
const SettingsPage = lazy(() => import('./pages/dashboard/SettingsPage'));
const BillingSettingsPage = lazy(() => import('./pages/dashboard/BillingSettingsPage'));
const PricingDashboardPage = lazy(() => import('./pages/dashboard/PricingDashboardPage'));
const IntegrationsPage = lazy(() => import('./pages/dashboard/IntegrationsPage'));
const MarketplaceSettingsPage = lazy(() => import('./pages/dashboard/MarketplaceSettingsPage'));
const MarketplaceAnalyticsPage = lazy(() => import('./pages/dashboard/MarketplaceAnalyticsPage'));
const MarketplaceOnboardingPage = lazy(() => import('./pages/dashboard/MarketplaceOnboardingPage'));
const GuestAccountPage = lazy(() => import('./pages/account/GuestAccountPage'));
const ReviewSubmissionPage = lazy(() => import('./pages/ReviewSubmissionPage'));
const AdminPanelPage = lazy(() => import('./pages/admin/AdminPanelPage'));

// Property Pages
const MyPropertyHome = lazy(() => import('./pages/my-property/MyPropertyHome'));
const MyPropertyOnePage = lazy(() => import('./pages/my-property/MyPropertyOnePage'));
const MyPropertyAbout = lazy(() => import('./pages/my-property/MyPropertyAbout'));
const MyPropertyGallery = lazy(() => import('./pages/my-property/MyPropertyGallery'));
const MyPropertyLocation = lazy(() => import('./pages/my-property/MyPropertyLocation'));
const MyPropertyReviews = lazy(() => import('./pages/my-property/MyPropertyReviews'));

// Booking Pages
const BookingFlow = lazy(() => import('./pages/booking/BookingFlow'));
const BookingConfirmation = lazy(() => import('./pages/booking/BookingConfirmation'));

// Auth
const AuthCallbackPage = lazy(() => import('./pages/AuthCallbackPage'));
const ForgotPasswordPage = lazy(() => import('./pages/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('./pages/ResetPasswordPage'));
const HostLoginPage = lazy(() => import('./pages/HostLoginPage'));

// Onboarding
const OnboardingWizard = lazy(() => import('./pages/OnboardingWizard'));
const MarketplaceRoutes = lazy(() => import('./routes/MarketplaceRoutes'));

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 5 * 60 * 1000, retry: 1 } },
});

function LoadingSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8]">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-[#FF5A5F] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-[#717171]">Loading...</p>
      </div>
    </div>
  );
}

function ScrollToTop() {
  const { pathname, search, hash } = useLocation();

  useEffect(() => {
    if (hash) return;
    window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  }, [pathname, search, hash]);

  return null;
}

/**
 * Maps any stored theme value to its canonical dashboardTheme key.
 * Handles both the current format (dashboardTheme values like 'classic') and
 * any legacy records that stored the templateId (e.g. 'editorial-guide').
 */
function normaliseWebsiteTheme(theme?: string | null) {
  switch (theme) {
    // Template IDs → dashboardTheme (legacy / safety mapping)
    case 'source-match':      return 'onepage';
    case 'modern-showcase':   return 'modern';
    case 'conversion-focus':  return 'minimal';
    case 'editorial-guide':   return 'classic';
    // dashboardTheme values — pass through as-is
    case 'onepage':
    case 'modern':
    case 'classic':
    case 'minimal':
      return theme;
    default:
      return 'onepage';
  }
}

/** Set of all dashboard-theme values that use the one-page website renderer. */
const ONE_PAGE_THEMES = new Set(['onepage', 'modern', 'classic', 'minimal']);

/**
 * Renders the property website from the theme saved on the property record.
 * The dashboard design selector writes this value, and every public/preview
 * route resolves through the same switch so "View Website" matches selection.
 *
 * All four named themes (onepage/modern/classic/minimal) use MyPropertyOnePage.
 * MyPropertyHome is kept as a fallback for unknown/unset theme values only.
 */
function PropertyHomeEntry() {
  const { slug } = useParams();
  const { property, loading } = usePropertyByDomain();

  if (slug?.toLowerCase() === 'delorainecottage') {
    return <ExamplePage mode="live" />;
  }

  if (loading) return <LoadingSpinner />;
  const theme = normaliseWebsiteTheme(property?.theme);

  if (ONE_PAGE_THEMES.has(theme)) {
    return (
      <Suspense fallback={<LoadingSpinner />}>
        <MyPropertyOnePage />
      </Suspense>
    );
  }
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <MyPropertyHome />
    </Suspense>
  );
}

function PropertySiteHomeEntry() {
  if (isDeloraineHost()) {
    return <ExamplePage mode="live" />;
  }
  return <PropertyHomeEntry />;
}

function PropertySiteSectionEntry({
  fallback,
  deloraineTarget,
}: {
  fallback: React.ReactNode;
  deloraineTarget: string;
}) {
  if (isDeloraineHost()) return <Navigate to={deloraineTarget} replace />;
  return <>{fallback}</>;
}

function EmailConfirmationGate({ email }: { email: string }) {
  const { resendConfirmation } = useAuth();
  const [resent, setResent] = useState(false);
  const [resending, setResending] = useState(false);
  const [resendError, setResendError] = useState('');

  const handleResend = async () => {
    setResending(true);
    setResendError('');
    const { error } = await resendConfirmation(email);
    setResending(false);
    if (error) {
      setResendError(error);
    } else {
      setResent(true);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="min-h-screen bg-[#F7F7F7] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-sm border border-[#EBEBEB] p-8 text-center">
        <div className="w-20 h-20 bg-[#00A69915] rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-[#00A699]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-[#484848] mb-3">Confirm your email</h2>
        <p className="text-[#717171] mb-2">
          We sent a confirmation link to <strong className="text-[#484848]">{email}</strong>
        </p>
        <p className="text-[#717171] mb-8">
          Click the link in the email to activate your account, then return to this page.
        </p>

        {resent ? (
          <div className="p-3 bg-green-50 border border-green-200 rounded-xl mb-4">
            <p className="text-green-700 text-sm font-medium">Confirmation email resent!</p>
          </div>
        ) : (
          <button
            onClick={handleResend}
            disabled={resending}
            className="w-full py-3 px-6 bg-[#FF5A5F] text-white font-semibold rounded-xl hover:bg-[#FF385C] disabled:opacity-60 transition-colors mb-3"
          >
            {resending ? 'Sending…' : 'Resend confirmation email'}
          </button>
        )}

        {resendError && (
          <p className="text-red-600 text-sm mb-3">{resendError}</p>
        )}

        <button
          onClick={handleSignOut}
          className="text-sm text-[#717171] hover:text-[#484848] transition-colors"
        >
          Sign out and use a different account
        </button>
      </div>
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <LoadingSpinner />;
  if (!user) return <Navigate to="/signin" replace />;

  if (user.isDemo && isPropertySubdomain()) return <Navigate to="/host" replace />;

  if (!user.isDemo && !user.email_confirmed_at && user.email) {
    return <EmailConfirmationGate email={user.email} />;
  }

  if (isPropertySubdomain() && location.pathname.startsWith('/dashboard')) {
    return <PropertyDashboardOwnerGate>{children}</PropertyDashboardOwnerGate>;
  }

  return <>{children}</>;
}

function PropertyDashboardOwnerGate({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const { property, loading } = usePropertyByDomain();

  if (loading) return <LoadingSpinner />;
  if (!user || user.isDemo) return <Navigate to="/host" replace />;
  if (!property) return <Navigate to="/host?error=property-not-found" replace />;
  const isAllowedLocalOwner = isDeloraineLocalHostName() && user.id === LOCAL_HOST_ID;
  if (property.host_id !== user.id && !isAllowedLocalOwner) return <Navigate to="/host?error=wrong-account" replace />;

  sessionStorage.setItem(HOST_PROPERTY_KEY, property.id);
  return <>{children}</>;
}

/** Returns true when the browser is on a property subdomain (e.g. deloraine.staydirect.nz) */
function isPropertySubdomain(): boolean {
  return isPropertyHost();
}

function DashboardRoutes() {
  const gated = (featureId: FeatureId, child: React.ReactNode) => (
    <ProtectedRoute>
      <FeatureGate featureId={featureId}>{child}</FeatureGate>
    </ProtectedRoute>
  );

  return (
    <>
      <Route path="/dashboard" element={<ProtectedRoute><DashboardHome /></ProtectedRoute>} />
      <Route path="/dashboard/bookings" element={gated('bookings', <BookingsPage />)} />
      <Route path="/dashboard/calendar" element={gated('calendar', <CalendarPage />)} />
      <Route path="/dashboard/property" element={gated('property', <PropertyEditorPage />)} />
      <Route path="/dashboard/messages" element={gated('messages', <MessagingPage />)} />
      <Route path="/dashboard/guests" element={gated('guests', <GuestsPage />)} />
      <Route path="/dashboard/reviews" element={gated('reviews', <ReviewsPage />)} />
      <Route path="/dashboard/earnings" element={gated('earnings', <EarningsPage />)} />
      <Route path="/dashboard/analytics" element={gated('earnings', <Navigate to="/dashboard/earnings" replace />)} />
      <Route path="/dashboard/promotions" element={gated('promotions', <PromotionsPage />)} />
      <Route path="/dashboard/marketing" element={gated('marketing_studio', <MarketingStudioPage />)} />
      <Route path="/dashboard/accounting" element={gated('accounting', <AccountingPage />)} />
      <Route path="/dashboard/check-in-book" element={gated('check_in_book', <CheckInBookPage />)} />
      <Route path="/dashboard/local-guidebook" element={gated('local_guidebook', <LocalGuidebookPage />)} />
      <Route path="/dashboard/guidebook" element={<ProtectedRoute><Navigate to="/dashboard/local-guidebook" replace /></ProtectedRoute>} />
      <Route path="/dashboard/upsells" element={gated('upsells', <UpsellsPage />)} />
      <Route path="/dashboard/pricing" element={gated('pricing', <PricingDashboardPage />)} />
      <Route path="/dashboard/marketplace" element={gated('marketplace', <MarketplaceSettingsPage />)} />
      <Route path="/dashboard/marketplace/analytics" element={gated('marketplace_analytics', <MarketplaceAnalyticsPage />)} />
      <Route path="/dashboard/marketplace/onboarding" element={gated('marketplace', <MarketplaceOnboardingPage />)} />
      <Route path="/dashboard/integrations" element={gated('integrations', <IntegrationsPage />)} />
      <Route path="/dashboard/admin/domains" element={<ProtectedRoute><Navigate to="/admin/domains" replace /></ProtectedRoute>} />
      <Route path="/dashboard/settings" element={gated('settings', <SettingsPage />)} />
      <Route path="/dashboard/billing" element={<ProtectedRoute><Navigate to="/dashboard/billing-settings" replace /></ProtectedRoute>} />
      <Route path="/dashboard/billing-settings" element={gated('billing', <BillingSettingsPage />)} />
    </>
  );
}

/** Route tree shown when visiting a property subdomain (e.g. deloraine.staydirect.nz) */
function PropertySiteRoutes() {
  useKeepAlive();
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        {/* Public property website pages */}
        <Route path="/" element={<PropertySiteHomeEntry />} />
        <Route path="/about" element={<PropertySiteSectionEntry deloraineTarget="/#overview" fallback={<MyPropertyAbout />} />} />
        <Route path="/gallery" element={<PropertySiteSectionEntry deloraineTarget="/#gallery" fallback={<MyPropertyGallery />} />} />
        <Route path="/location" element={<PropertySiteSectionEntry deloraineTarget="/#map" fallback={<MyPropertyLocation />} />} />
        <Route path="/reviews" element={<PropertySiteSectionEntry deloraineTarget="/#overview" fallback={<MyPropertyReviews />} />} />
        <Route path="/booking" element={<BookingFlow />} />
        <Route path="/booking/confirmation" element={<BookingConfirmation />} />
        <Route path="/host" element={<HostLoginPage />} />
        <Route path="/account" element={<GuestAccountPage />} />
        <Route path="/review/:token" element={<ReviewSubmissionPage />} />

        {/* Auth routes — needed so the sign-in flow works from the subdomain */}
        <Route path="/signin" element={<Navigate to="/host" replace />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="/auth/callback" element={<AuthCallbackPage />} />
        <Route path="/auth/confirm" element={<AuthCallbackPage />} />

        {/* Dashboard — accessible at deloraine.staydirect.nz/dashboard */}
        {DashboardRoutes()}

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

/** Route tree shown on the main staydirect.nz domain */
function MainSiteRoutes() {
  useKeepAlive();
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        {/* Marketing */}
        <Route path="/" element={<HomePage />} />
        <Route path="/features" element={<FeaturesPage />} />
        <Route path="/how-it-works" element={<HowItWorksPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/faq" element={<FAQPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/preview" element={<GeneratedPreviewPage />} />
        <Route path="/website-options" element={<WebsiteOptionsPage />} />
        <Route path="/website-options/preview/:templateId" element={<TemplatePreviewPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/privacy" element={<PrivacyPolicyPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/help" element={<Navigate to="/help-centre" replace />} />
        <Route path="/help-centre" element={<HelpCentrePage />} />
        <Route path="/help-centre/:slug" element={<HelpArticlePage />} />
        <Route path="/help-center" element={<Navigate to="/help-centre" replace />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/blog/new" element={<BlogAdminPage />} />
        <Route path="/blog/:slug" element={<BlogArticlePage />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/cookies" element={<CookiePolicyPage />} />
        <Route path="/signin" element={<SignInPage />} />
        <Route path="/host" element={<HostLoginPage />} />
        <Route path="/account" element={<GuestAccountPage />} />
        <Route path="/admin" element={<AdminPanelPage />} />
        <Route path="/admin/test-data" element={<AdminPanelPage />} />
        <Route path="/admin/test-data/:testSection" element={<AdminPanelPage />} />
        <Route path="/admin/:section" element={<AdminPanelPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="/review/:token" element={<ReviewSubmissionPage />} />

        {/* Auth */}
        <Route path="/auth/callback" element={<AuthCallbackPage />} />
        <Route path="/auth/confirm" element={<AuthCallbackPage />} />

        {/* Demo Pages */}
        <Route path="/demo" element={<DemoPage />} />
        <Route path="/example" element={<ExamplePage />} />

        {/* Onboarding — protected */}
        <Route path="/onboarding" element={<ProtectedRoute><OnboardingWizard /></ProtectedRoute>} />

        {/* Dashboard — protected */}
        {DashboardRoutes()}

        {/* Property Website preview on main domain — slug-based for multi-property hosts */}
        <Route path="/my-property/:slug" element={<PropertyHomeEntry />} />
        <Route path="/my-property/:slug/about" element={<MyPropertyAbout />} />
        <Route path="/my-property/:slug/gallery" element={<MyPropertyGallery />} />
        <Route path="/my-property/:slug/location" element={<MyPropertyLocation />} />
        <Route path="/my-property/:slug/reviews" element={<MyPropertyReviews />} />
        {/* Legacy redirect for old /my-property without slug */}
        <Route path="/my-property" element={<LegacyMyPropertyRedirect />} />
        {/* Legacy deep links redirect to slug-based */}
        <Route path="/my-property/about" element={<LegacyMyPropertyDeepLinkRedirect />} />
        <Route path="/my-property/gallery" element={<LegacyMyPropertyDeepLinkRedirect />} />
        <Route path="/my-property/location" element={<LegacyMyPropertyDeepLinkRedirect />} />
        <Route path="/my-property/reviews" element={<LegacyMyPropertyDeepLinkRedirect />} />

        {/* Booking Flow is only available on property sites. Main-domain attempts go back to the Deloraine demo. */}
        <Route path="/booking" element={<Navigate to="/example#book" replace />} />
        <Route path="/booking/confirmation" element={<Navigate to="/example#book" replace />} />

        {/* Marketplace served at /marketplace/* when not on book.staydirect.nz, for example in Replit dev. */}
        <Route path="/marketplace/*" element={<Suspense fallback={<LoadingSpinner />}><MarketplaceRoutes /></Suspense>} />

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

function LegacyMyPropertyRedirect() {
  const { slug } = useParams();
  const navigate = useNavigate();
  useEffect(() => {
    if (slug) return;
    const stored = localStorage.getItem('staydirect_local_property');
    let parsed = null;
    try {
      parsed = stored ? JSON.parse(stored) : null;
    } catch {
      parsed = null;
    }
    const targetSlug = parsed?.slug || 'delorainecottage';
    navigate(`/my-property/${targetSlug}`, { replace: true });
  }, [slug, navigate]);
  return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner /></div>;
}

function LegacyMyPropertyDeepLinkRedirect() {
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => {
    const stored = localStorage.getItem('staydirect_local_property');
    let parsed = null;
    try {
      parsed = stored ? JSON.parse(stored) : null;
    } catch {
      parsed = null;
    }
    const targetSlug = parsed?.slug || 'delorainecottage';
    const subPath = location.pathname.replace(/^\/my-property/, '');
    navigate(`/my-property/${targetSlug}${subPath}`, { replace: true });
  }, [navigate, location.pathname]);
  return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner /></div>;
}

function AppRoutes() {
  if (isMarketplaceHost()) {
    return (
      <Suspense fallback={<LoadingSpinner />}>
        <MarketplaceRoutes />
      </Suspense>
    );
  }
  if (isMainPlatformHost()) {
    return <MainSiteRoutes />;
  }
  if (isPropertySubdomain()) {
    return <PropertySiteRoutes />;
  }
  return <MainSiteRoutes />;
}

function StayDirectChatbotMount() {
  const location = useLocation();
  const isPropertyPreview = location.pathname === '/example'
    || location.pathname.startsWith('/my-property')
    || location.pathname.startsWith('/booking')
    || location.pathname.startsWith('/website-options/preview');

  if (isPropertySubdomain() && !location.pathname.startsWith('/dashboard')) return null;
  if (isPropertyPreview) return null;
  return <SupportChatbot />;
}

function App() {
  const base = import.meta.env.BASE_URL?.replace(/\/$/, '') || '';

  useEffect(() => {
    const stored = localStorage.getItem('staydirect_theme_v3');
    const theme = stored || 'light';
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter
        basename={base}
        future={{
          v7_relativeSplatPath: true,
          v7_startTransition: true,
        }}
      >
        <AuthProvider>
          <ScrollToTop />
          <AppRoutes />
          <StayDirectChatbotMount />
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                borderRadius: '16px',
                border: '1px solid #FF5A5F33',
                boxShadow: '0 20px 45px rgba(72, 72, 72, 0.16)',
              },
              classNames: {
                success: '!bg-[#F0FFFE] !text-[#006B61] !border-[#00A69955]',
                error: '!bg-[#FFF1F2] !text-[#B42318] !border-[#FF5A5F55]',
                info: '!bg-[#FFF1F2] !text-[#D01744] !border-[#FF5A5F33]',
              },
            }}
          />
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
