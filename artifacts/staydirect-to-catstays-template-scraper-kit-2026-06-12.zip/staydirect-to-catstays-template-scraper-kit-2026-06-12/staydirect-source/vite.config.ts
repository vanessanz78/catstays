import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import type { IncomingMessage, ServerResponse } from "node:http";

const envDir = path.resolve(import.meta.dirname);
const loadedEnv = loadEnv(process.env.NODE_ENV || "development", envDir, "");

for (const [key, value] of Object.entries(loadedEnv)) {
  if (process.env[key] === undefined) process.env[key] = value;
}

const rawPort = process.env.STAYDIRECT_PORT ?? process.env.VITE_PORT ?? "5173";

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH ?? "/";
const PLACES_BASE_URL = "https://places.googleapis.com/v1";

async function mountStayDirectApi(server: any) {
  try {
    const module = await import("./api-server/src/app");
    server.middlewares.use(module.default);
  } catch (error) {
    console.warn("[staydirect] In-repo preview API not found. Google Places fallback still enabled.");
  }
  server.middlewares.use(createPreviewApiMiddleware());
}

function createPreviewApiMiddleware() {
  return async (req: IncomingMessage, res: ServerResponse, next: () => void) => {
    const url = new URL(req.url || "/", "http://localhost");
    if (url.pathname === "/api/health") {
      sendJson(res, 200, { ok: true, mode: "preview" });
      return;
    }
    if (url.pathname === "/api/scrape" && req.method === "GET") {
      await handlePreviewScrape(url, res);
      return;
    }
    if (url.pathname === "/api/export-image" && req.method === "GET") {
      await handleExportImage(url, res);
      return;
    }
    if (url.pathname === "/api/google-places/autocomplete" && req.method === "POST") {
      await handlePlacesAutocomplete(req, res);
      return;
    }
    if (url.pathname.startsWith("/api/google-places/details/") && req.method === "GET") {
      await handlePlaceDetails(url.pathname.split("/").pop() || "", url, res);
      return;
    }
    if (url.pathname === "/api/google-places/photo" && req.method === "GET") {
      await handlePlacePhoto(url, res);
      return;
    }
    if (url.pathname === "/api/google-places/nearby" && req.method === "POST") {
      await handlePlacesNearby(req, res);
      return;
    }
    next();
  };
}

async function handleExportImage(url: URL, res: ServerResponse) {
  const rawUrl = url.searchParams.get("url") || "";
  let target: URL;

  try {
    target = new URL(rawUrl);
  } catch {
    sendJson(res, 400, { error: "Missing or invalid image URL." });
    return;
  }

  if (!["http:", "https:"].includes(target.protocol)) {
    sendJson(res, 400, { error: "Only public http(s) images can be exported." });
    return;
  }

  try {
    const response = await fetch(target.toString(), {
      signal: AbortSignal.timeout(15000),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
      },
    });

    if (!response.ok) {
      sendJson(res, response.status >= 400 && response.status < 500 ? 422 : 502, {
        error: `Image returned ${response.status}.`,
      });
      return;
    }

    const contentType = response.headers.get("content-type") || "image/jpeg";
    if (!contentType.startsWith("image/")) {
      sendJson(res, 422, { error: "The requested URL is not an image." });
      return;
    }

    const arrayBuffer = await response.arrayBuffer();
    res.statusCode = 200;
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "public, max-age=86400");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.end(Buffer.from(arrayBuffer));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, message.toLowerCase().includes("timeout") ? 504 : 502, {
      error: "The image could not be prepared for export.",
      details: message,
    });
  }
}

async function handlePreviewScrape(url: URL, res: ServerResponse) {
  const rawUrl = url.searchParams.get("url") || "";
  let target: URL;

  try {
    target = new URL(rawUrl.startsWith("http") ? rawUrl : `https://${rawUrl}`);
  } catch {
    sendJson(res, 400, { error: "Paste a valid accommodation listing or website URL." });
    return;
  }

  try {
    const response = await fetch(target.toString(), {
      signal: AbortSignal.timeout(15000),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-NZ,en-GB;q=0.9,en-US;q=0.8,en;q=0.7",
      },
    });

    if (!response.ok) {
      sendJson(res, response.status >= 400 && response.status < 500 ? 422 : 502, {
        error: `That site returned ${response.status}. Try a public property page or paste the StayDirect/Deloraine demo URL.`,
      });
      return;
    }

    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("html")) {
      sendJson(res, 422, { error: "That URL does not look like a public website page." });
      return;
    }

    const html = await response.text();
    const result = buildScrapeResult(html, target);
    sendJson(res, 200, result);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, message.toLowerCase().includes("timeout") ? 504 : 502, {
      error: "The importer could not read that website from Replit. Try the public property website URL, or try again in a moment.",
      details: message,
    });
  }
}

/** Strip Airbnb's meta description prefix "5 Jun 2026 · Entire cottage · " and trailing truncation */
function cleanAirbnbMeta(text: string): string {
  let s = text;
  // Strip date prefix: "5 Jun 2026 · " or "5 June 2026 · "
  s = s.replace(/^\d{1,2}\s+\w+\s+\d{4}\s*[·•·]\s*/i, "");
  // Strip property type prefix: "Entire cottage · ", "Private room · ", "Entire home · " etc.
  s = s.replace(/^[^·•·]{2,45}[·•·]\s+/i, "");
  // Strip trailing truncation like "en..." or "..." (word fragment + ellipsis)
  s = s.replace(/\s*\w{0,6}\.{2,}$/, "");
  return s.trim();
}

/** Walk a plain object tree looking for a long natural-language description string */
function walkForDescription(obj: unknown, depth: number): string {
  if (depth > 8 || !obj || typeof obj !== "object") return "";
  const record = obj as Record<string, unknown>;
  for (const key of ["htmlDescription", "listingDescription", "descriptionItems"]) {
    const val = record[key];
    if (typeof val === "string" && val.length > 80) return val;
    if (val && typeof val === "object" && !Array.isArray(val)) {
      const inner = walkForDescription(val, depth + 1);
      if (inner.length > 80) return inner;
    }
    if (Array.isArray(val)) {
      const combined = (val as unknown[]).map((item) => {
        if (typeof item === "string") return item;
        if (item && typeof item === "object") {
          const r = item as Record<string, unknown>;
          return String(r.html ?? r.htmlText ?? r.title ?? r.body ?? "");
        }
        return "";
      }).filter(Boolean).join("\n\n");
      if (combined.length > 80) return combined;
    }
  }
  // Recurse into nested objects (but not arrays at the top level — too broad)
  for (const val of Object.values(record)) {
    if (val && typeof val === "object" && !Array.isArray(val)) {
      const found = walkForDescription(val, depth + 1);
      if (found.length > 80) return found;
    }
  }
  return "";
}

/** Try to extract the full "About this space" description from Airbnb's embedded JSON */
function extractAirbnbDescription(html: string): string {
  // Approach 1: Next.js __NEXT_DATA__ blob
  const nextDataMatch = html.match(/<script[^>]*id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
  if (nextDataMatch) {
    try {
      const data = JSON.parse(nextDataMatch[1]);
      const found = walkForDescription(data, 0);
      if (found.length > 80) return cleanText(found.replace(/<[^>]+>/g, " "));
    } catch {}
  }
  // Approach 2: any script tag containing an inline description field
  const longDescPattern = /"(?:htmlDescription|listingDescription|description)"\s*:\s*"((?:[^"\\]|\\.){100,})"/g;
  for (const match of html.matchAll(longDescPattern)) {
    try {
      const decoded = JSON.parse(`"${match[1]}"`);
      const cleaned = cleanText(decoded.replace(/<[^>]+>/g, " "));
      // Must look like natural language (contains letters + a sentence-ending punctuation)
      if (cleaned.length > 80 && /[a-z].*[.!?]/i.test(cleaned)) return cleaned;
    } catch {}
  }
  return "";
}

/** Generate a concise tagline from the first sentence of the description */
function generateDescriptionTagline(description: string): string {
  if (!description || description.length < 20) return "";
  // Take the first sentence (20–160 chars ending in .!?)
  const firstSentence = description.match(/^(.{20,160}?[.!?])(?:\s|$)/)?.[1];
  if (firstSentence) return firstSentence.trim();
  // Fallback: break at the last word boundary within 120 chars
  const short = description.slice(0, 120);
  const lastSpace = short.lastIndexOf(" ");
  return (lastSpace > 40 ? short.slice(0, lastSpace) : short).trim();
}

function buildScrapeResult(html: string, target: URL) {
  const jsonLd = extractJsonLd(html);
  const lodgingData = findLodgingJsonLd(jsonLd);
  const host = extractHostProfile(html, jsonLd, target);
  const isAirbnbUrl = target.hostname.includes("airbnb.");
  const pageTitle =
    stringFrom(lodgingData?.name) ||
    extractMeta(html, "og:title") ||
    extractMeta(html, "twitter:title") ||
    extractTag(html, "title") ||
    "Your Property";
  // For Airbnb, try to extract the full description from embedded JSON first
  const airbnbFullDesc = isAirbnbUrl ? extractAirbnbDescription(html) : "";
  const descriptionCandidates = [
    airbnbFullDesc,
    stringFrom(lodgingData?.description),
    extractMeta(html, "description"),
    extractMeta(html, "og:description"),
    extractMeta(html, "twitter:description"),
  ]
    .map((value) => cleanText(value))
    .filter((value) => value && value.toLowerCase() !== cleanText(pageTitle).toLowerCase() && value.length > 24);
  const rawDescription =
    descriptionCandidates.sort((a, b) => b.length - a.length)[0] ||
    "A direct booking website preview created from your public accommodation page.";
  // Strip Airbnb's "DD MMM YYYY · Entire [type] · " prefix and trailing truncation
  const description = isAirbnbUrl ? cleanAirbnbMeta(rawDescription) : rawDescription;
  const tagline = generateDescriptionTagline(description);
  const title = isAirbnbUrl && /^cottage in |^home in |^apartment in |^rental unit in |^guest suite in /i.test(pageTitle) && description.length < 80
    ? description
    : pageTitle;
  const address = addressFromJsonLd(lodgingData?.address);
  const images = curateImageUrls([
    ...arrayFrom(lodgingData?.image),
    extractMeta(html, "og:image"),
    extractMeta(html, "twitter:image"),
    ...collectHtmlImages(html, target),
  ], target);
  const amenities = extractAmenities(html);
  const location = locationFromJsonLd(lodgingData?.geo);
  const price = numberFromDeep(lodgingData, ["price", "lowPrice", "priceRange"]);
  const titleRating = title.match(/★\s*([0-5](?:\.\d{1,2})?)/)?.[1];

  return {
    name: cleanText(title),
    shortDescription: tagline || cleanText(description).slice(0, 120),
    fullDescription: cleanText(description),
    city: cityFromAddress(address) || (target.hostname.includes("airbnb.") ? "" : cityFromHost(target.hostname)),
    country: countryFromAddress(address) || "",
    phone: stringFrom(lodgingData?.telephone),
    hostName: host.hostName,
    hostPhoto: host.hostPhoto,
    images: images.length ? images : ["https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80"],
    amenities,
    amenityDetails: amenities,
    address,
    latitude: location.latitude,
    longitude: location.longitude,
    locationDescription: address || "",
    reviews: [],
    reviewSummary: titleRating ? { rating: Number(titleRating), count: null, source: target.hostname.includes("airbnb.") ? "Airbnb" : target.hostname } : undefined,
    brandColor: "#FF5A5F",
    fontFamily: "Inter, Arial, sans-serif",
    bedrooms: numberFromDeep(lodgingData, ["numberOfBedrooms", "bedrooms"]),
    bathrooms: numberFromDeep(lodgingData, ["numberOfBathrooms", "bathrooms"]),
    maxGuests: numberFromDeep(lodgingData, ["occupancy", "maximumAttendeeCapacity", "personCapacity"]),
    basePrice: price,
    sourceUrl: target.toString(),
    source: target.hostname.includes("airbnb.") ? "airbnb" : "generic",
  };
}

function extractMeta(html: string, name: string): string {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${escaped}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+property=["']${escaped}["']`, "i"),
    new RegExp(`<meta[^>]+name=["']${escaped}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+name=["']${escaped}["']`, "i"),
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) return decodeEntities(match[1]).trim();
  }
  return "";
}

function extractTag(html: string, tag: string): string {
  const match = html.match(new RegExp(`<${tag}[^>]*>([^<]+)<\\/${tag}>`, "i"));
  return match?.[1] ? decodeEntities(match[1]).trim() : "";
}

function extractJsonLd(html: string): Record<string, unknown>[] {
  const results: Record<string, unknown>[] = [];
  const matches = html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
  for (const match of matches) {
    try {
      const parsed = JSON.parse(match[1]);
      if (Array.isArray(parsed)) {
        results.push(...parsed.filter((item) => item && typeof item === "object"));
      } else if (parsed && typeof parsed === "object") {
        results.push(parsed);
      }
    } catch {
      // Ignore malformed structured data from third-party sites.
    }
  }
  return results;
}

function findLodgingJsonLd(records: Record<string, unknown>[]): Record<string, unknown> | null {
  const queue = [...records];
  while (queue.length) {
    const item = queue.shift();
    if (!item) continue;
    const type = arrayFrom(item["@type"]).join(" ").toLowerCase();
    if (/lodging|hotel|accommodation|house|apartment|resort|bedandbreakfast|localbusiness/.test(type)) return item;
    for (const value of Object.values(item)) {
      if (Array.isArray(value)) queue.push(...value.filter((child) => child && typeof child === "object") as Record<string, unknown>[]);
      if (value && typeof value === "object") queue.push(value as Record<string, unknown>);
    }
  }
  return records[0] || null;
}

function collectHtmlImages(html: string, baseUrl: URL): string[] {
  const images: string[] = [];
  const directUrls = html.matchAll(/https?:\/\/[^"'<>\s\\)]+\.(?:jpe?g|png|webp)(?:\?[^"'<>\s\\)]*)?/gi);
  for (const match of directUrls) images.push(match[0]);

  const imgTags = html.matchAll(/<img\b[^>]*>/gi);
  for (const tagMatch of imgTags) {
    const tag = tagMatch[0];
    const src = tag.match(/\ssrc=["']([^"']+)["']/i)?.[1];
    if (src) images.push(src);
    const srcSet = tag.match(/\ssrcset=["']([^"']+)["']/i)?.[1];
    if (srcSet) {
      for (const candidate of srcSet.split(",")) {
        const [candidateUrl] = candidate.trim().split(/\s+/);
        if (candidateUrl) images.push(candidateUrl);
      }
    }
  }
  return images.map((image) => absoluteImageUrl(image, baseUrl)).filter(Boolean) as string[];
}

function curateImageUrls(rawImages: unknown[], baseUrl: URL): string[] {
  const byKey = new Map<string, string>();
  for (const raw of rawImages.flatMap((item) => arrayFrom(item))) {
    const image = absoluteImageUrl(String(raw || ""), baseUrl);
    if (!image) continue;
    if (/\.(svg|gif)(\?|$)/i.test(image)) continue;
    if (/favicon|apple-touch-icon|logo|placeholder|avatar|profile|\/user\/|airbnb-platform-assets|review-ai-synthesis/i.test(image)) continue;
    const key = imageKey(image);
    const existing = byKey.get(key);
    if (!existing || imageWidth(image) > imageWidth(existing)) byKey.set(key, image);
  }
  return Array.from(byKey.values()).slice(0, 18);
}

function absoluteImageUrl(rawUrl: string, baseUrl: URL): string | null {
  const cleaned = decodeEntities(rawUrl).trim().replace(/[),.;}]+$/g, "");
  if (!cleaned || cleaned.startsWith("data:") || cleaned.startsWith("blob:")) return null;
  try {
    const absolute = new URL(cleaned, baseUrl.toString()).toString();
    if (!/^https?:\/\//i.test(absolute)) return null;
    if (!/\.(jpe?g|png|webp)(\?|$)/i.test(absolute) && !absolute.includes("images")) return null;
    return absolute;
  } catch {
    return null;
  }
}

function extractAmenities(html: string): string[] {
  const text = decodeEntities(html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").toLowerCase());
  const possible = [
    ["WiFi", /\bwifi\b|wireless internet/],
    ["Kitchen", /\bkitchen\b/],
    ["Parking", /\bparking\b/],
    ["Pool", /\bpool\b/],
    ["Hot tub", /hot tub|spa pool/],
    ["Air conditioning", /air conditioning|\baircon\b/],
    ["Heating", /\bheating\b/],
    ["Washing machine", /washing machine|\bwasher\b/],
    ["Dryer", /\bdryer\b/],
    ["BBQ", /\bbbq\b|barbecue/],
    ["Waterfront", /waterfront|beachfront|ocean view/],
    ["Pet friendly", /pet friendly|pets allowed/],
  ] as const;
  return possible.filter(([, pattern]) => pattern.test(text)).map(([label]) => label).slice(0, 12);
}

function addressFromJsonLd(address: unknown): string {
  if (!address) return "";
  if (typeof address === "string") return cleanText(address);
  if (typeof address !== "object") return "";
  const record = address as Record<string, unknown>;
  return [
    record.streetAddress,
    record.addressLocality,
    record.addressRegion,
    record.postalCode,
    record.addressCountry,
  ].map(stringFrom).filter(Boolean).join(", ");
}

function locationFromJsonLd(geo: unknown): { latitude: number | null; longitude: number | null } {
  if (!geo || typeof geo !== "object") return { latitude: null, longitude: null };
  const record = geo as Record<string, unknown>;
  const latitude = Number(record.latitude);
  const longitude = Number(record.longitude);
  return {
    latitude: Number.isFinite(latitude) ? latitude : null,
    longitude: Number.isFinite(longitude) ? longitude : null,
  };
}

function cityFromAddress(address: string): string {
  return address.split(",").map((part) => part.trim()).filter(Boolean).at(-3) || "";
}

function countryFromAddress(address: string): string {
  return address.split(",").map((part) => part.trim()).filter(Boolean).at(-1) || "";
}

function cityFromHost(hostname: string): string {
  return hostname.replace(/^www\./, "").split(".")[0]?.replace(/[-_]+/g, " ") || "";
}

function stringFrom(value: unknown): string {
  if (typeof value === "string") return cleanText(value);
  if (typeof value === "number") return String(value);
  if (Array.isArray(value)) return stringFrom(value[0]);
  if (value && typeof value === "object" && "text" in value) return stringFrom((value as { text?: unknown }).text);
  return "";
}

function extractHostProfile(html: string, records: Record<string, unknown>[], baseUrl: URL): { hostName: string; hostPhoto: string } {
  const structuredCandidates = records
    .flatMap((record) => [record.host, record.owner, record.creator, record.author, record.founder])
    .map((value) => {
      if (typeof value === "string") return value;
      if (value && typeof value === "object") return stringFrom((value as Record<string, unknown>).name);
      return "";
    });
  const hostName = [
    ...structuredCandidates,
    html.match(/hosted by\s+([A-Z][A-Za-z' -]{2,80})/i)?.[1] || "",
    html.match(/your host(?: is)?\s+([A-Z][A-Za-z' -]{2,80})/i)?.[1] || "",
  ]
    .map((value) => cleanText(value).replace(/^hosted by\s+/i, ""))
    .find((value) => value && !/^(host|owner|guest|airbnb|superhost)$/i.test(value)) || "";

  const hostImageTag = Array.from(html.matchAll(/<img\b[^>]*>/gi))
    .map((match) => match[0])
    .find((tag) => /\b(alt|class|src)=["'][^"']*(host|owner|profile|avatar)[^"']*["']/i.test(tag));
  const hostImageRaw = hostImageTag?.match(/\ssrc=["']([^"']+)["']/i)?.[1] || "";
  return {
    hostName,
    hostPhoto: hostImageRaw ? absoluteImageUrl(hostImageRaw, baseUrl) || "" : "",
  };
}

function arrayFrom(value: unknown): unknown[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function numberFromDeep(record: unknown, keys: string[]): number | null {
  if (!record || typeof record !== "object") return null;
  const queue = [record as Record<string, unknown>];
  while (queue.length) {
    const item = queue.shift();
    if (!item) continue;
    for (const key of keys) {
      const value = item[key];
      const numeric = typeof value === "string" ? Number(value.replace(/[^0-9.]/g, "")) : Number(value);
      if (Number.isFinite(numeric) && numeric > 0) return numeric;
    }
    for (const value of Object.values(item)) {
      if (Array.isArray(value)) queue.push(...value.filter((child) => child && typeof child === "object") as Record<string, unknown>[]);
      if (value && typeof value === "object") queue.push(value as Record<string, unknown>);
    }
  }
  return null;
}

function imageKey(rawUrl: string): string {
  try {
    const url = new URL(rawUrl);
    return `${url.hostname}${url.pathname}`;
  } catch {
    return rawUrl.split("?")[0];
  }
}

function imageWidth(rawUrl: string): number {
  try {
    const url = new URL(rawUrl);
    return Number(url.searchParams.get("w") || url.searchParams.get("width")) || 0;
  } catch {
    return 0;
  }
}

function cleanText(value: unknown): string {
  return decodeEntities(value).replace(/\s+/g, " ").trim();
}

function decodeEntities(value: unknown): string {
  return String(value ?? "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, "\"")
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, " ");
}

function googlePlacesKey() {
  return process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || "";
}

async function handlePlacesAutocomplete(req: IncomingMessage, res: ServerResponse) {
  const key = googlePlacesKey();
  if (!key) {
    sendJson(res, 503, { error: "Google Places is not configured. Add GOOGLE_PLACES_API_KEY or VITE_GOOGLE_MAPS_API_KEY in Replit Secrets." });
    return;
  }

  const body = await readJsonBody(req);
  const input = String(body.input || "").trim();
  if (input.length < 2) {
    sendJson(res, 200, { suggestions: [] });
    return;
  }

  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);
  const requestBody: Record<string, unknown> = {
    input,
    includedRegionCodes: ["nz"],
    languageCode: "en",
  };
  if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
    requestBody.locationBias = {
      circle: {
        center: { latitude, longitude },
        radius: 100000,
      },
    };
  }

  const response = await fetch(`${PLACES_BASE_URL}/places:autocomplete`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": key,
      "X-Goog-FieldMask": "suggestions.placePrediction.placeId,suggestions.placePrediction.text,suggestions.placePrediction.structuredFormat,suggestions.placePrediction.types",
    },
    body: JSON.stringify(requestBody),
  });
  const payload: any = await response.json();
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || "Google Places autocomplete failed", details: payload });
    return;
  }
  sendJson(res, 200, {
    suggestions: (payload.suggestions || [])
      .map((item: any) => item.placePrediction)
      .filter(Boolean)
      .map((prediction: any) => ({
        placeId: prediction.placeId,
        title: prediction.structuredFormat?.mainText?.text || prediction.text?.text || "",
        secondaryText: prediction.structuredFormat?.secondaryText?.text || "",
        description: prediction.text?.text || prediction.structuredFormat?.mainText?.text || "",
        placeTypes: prediction.types || [],
      })),
  });
}

async function handlePlaceDetails(placeId: string, url: URL, res: ServerResponse) {
  const key = googlePlacesKey();
  if (!key) {
    sendJson(res, 503, { error: "Google Places is not configured. Add GOOGLE_PLACES_API_KEY or VITE_GOOGLE_MAPS_API_KEY in Replit Secrets." });
    return;
  }

  const fieldMask = [
    "id",
    "displayName",
    "formattedAddress",
    "location",
    "types",
    "rating",
    "userRatingCount",
    "googleMapsUri",
    "websiteUri",
    "photos",
    "addressComponents",
    "nationalPhoneNumber",
  ].join(",");
  const response = await fetch(`${PLACES_BASE_URL}/places/${encodeURIComponent(placeId)}`, {
    headers: {
      "X-Goog-Api-Key": key,
      "X-Goog-FieldMask": fieldMask,
    },
  });
  const payload: any = await response.json();
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || "Google Place details failed", details: payload });
    return;
  }
  const requestedPhotoIndex = Math.max(0, Number(url.searchParams.get("photoIndex") || 0));
  const photos = payload.photos || [];
  const photoIndex = photos.length ? requestedPhotoIndex % photos.length : 0;
  const primaryPhoto = photos[photoIndex] || null;
  sendJson(res, 200, {
    id: payload.id || placeId,
    name: payload.displayName?.text || "",
    formattedAddress: payload.formattedAddress || "",
    latitude: payload.location?.latitude ?? null,
    longitude: payload.location?.longitude ?? null,
    types: payload.types || [],
    rating: payload.rating ?? null,
    userRatingsTotal: payload.userRatingCount ?? null,
    googleMapsUri: payload.googleMapsUri || "",
    websiteUri: payload.websiteUri || "",
    phone: payload.nationalPhoneNumber || "",
    addressComponents: payload.addressComponents || [],
    photoName: primaryPhoto?.name || null,
    photoAttribution: primaryPhoto?.authorAttributions?.[0]?.displayName || null,
    photos,
    photoIndex,
    photoCount: photos.length,
  });
}

async function handlePlacePhoto(url: URL, res: ServerResponse) {
  const key = googlePlacesKey();
  if (!key) {
    sendJson(res, 503, { error: "Google Places is not configured. Add GOOGLE_PLACES_API_KEY or VITE_GOOGLE_MAPS_API_KEY in Replit Secrets." });
    return;
  }
  const name = url.searchParams.get("name") || "";
  const maxWidthPx = Math.min(Math.max(Number(url.searchParams.get("maxWidthPx") || 1200), 100), 4800);
  if (!name) {
    sendJson(res, 400, { error: "Missing photo resource name" });
    return;
  }
  const response = await fetch(`${PLACES_BASE_URL}/${name}/media?${new URLSearchParams({
    key,
    maxWidthPx: String(maxWidthPx),
    skipHttpRedirect: "true",
  }).toString()}`);
  const contentType = response.headers.get("content-type") || "";
  if (response.ok && !contentType.includes("application/json")) {
    sendJson(res, 200, { photoUri: response.url || "" });
    return;
  }

  const body = await response.text();
  let payload: any = {};
  try {
    payload = body ? JSON.parse(body) : {};
  } catch {
    if (response.ok) {
      sendJson(res, 200, { photoUri: response.url || "" });
      return;
    }
    sendJson(res, response.status, { error: "Google Place photo failed", details: body });
    return;
  }
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || "Google Place photo failed", details: payload });
    return;
  }
  sendJson(res, 200, { photoUri: payload.photoUri || response.url || "" });
}

async function handlePlacesNearby(req: IncomingMessage, res: ServerResponse) {
  const key = googlePlacesKey();
  if (!key) {
    sendJson(res, 503, { error: "Google Places is not configured. Add GOOGLE_PLACES_API_KEY or VITE_GOOGLE_MAPS_API_KEY in Replit Secrets." });
    return;
  }

  const body = await readJsonBody(req);
  const textQuery = String(body.textQuery || "").trim();
  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);
  if (!textQuery) {
    sendJson(res, 400, { error: "A search query is required." });
    return;
  }
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    sendJson(res, 400, { error: "Valid latitude and longitude are required for a nearby search." });
    return;
  }
  const radius = Math.min(Math.max(Number(body.radius) || 25000, 500), 50000);
  const maxResultCount = Math.min(Math.max(Number(body.maxResultCount) || 8, 1), 20);

  const requestBody: Record<string, unknown> = {
    textQuery,
    languageCode: "en",
    regionCode: "NZ",
    maxResultCount,
    locationBias: {
      circle: {
        center: { latitude, longitude },
        radius,
      },
    },
  };

  let response: Response;
  try {
    response = await fetch(`${PLACES_BASE_URL}/places:searchText`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": [
          "places.id",
          "places.displayName",
          "places.formattedAddress",
          "places.location",
          "places.types",
          "places.primaryType",
          "places.rating",
          "places.userRatingCount",
          "places.googleMapsUri",
          "places.websiteUri",
          "places.photos",
          "places.addressComponents",
        ].join(","),
      },
      body: JSON.stringify(requestBody),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    sendJson(res, 502, { error: "Google Places nearby search is temporarily unavailable.", details: message });
    return;
  }

  const payload: any = await response.json().catch(() => ({}));
  if (!response.ok) {
    sendJson(res, response.status, { error: payload.error?.message || "Google Places nearby search failed", details: payload });
    return;
  }

  const places = (payload.places || []).map((place: any) => {
    const photo = (place.photos || [])[0] || null;
    const locality = (place.addressComponents || []).find((component: any) => component.types?.includes("locality"))?.longText
      || (place.addressComponents || []).find((component: any) => component.types?.includes("sublocality"))?.longText
      || "";
    return {
      id: place.id || "",
      name: place.displayName?.text || "",
      formattedAddress: place.formattedAddress || "",
      latitude: place.location?.latitude ?? null,
      longitude: place.location?.longitude ?? null,
      types: place.types || [],
      primaryType: place.primaryType || "",
      rating: place.rating ?? null,
      userRatingsTotal: place.userRatingCount ?? null,
      googleMapsUri: place.googleMapsUri || "",
      websiteUri: place.websiteUri || "",
      locality,
      photoName: photo?.name || null,
      photoAttribution: photo?.authorAttributions?.[0]?.displayName || null,
    };
  });

  sendJson(res, 200, { places });
}

function readJsonBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        resolve({});
      }
    });
  });
}

function sendJson(res: ServerResponse, status: number, payload: unknown) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(payload));
}

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
    {
      name: "staydirect-local-api",
      async configureServer(server) {
        await mountStayDirectApi(server);
      },
      async configurePreviewServer(server) {
        await mountStayDirectApi(server);
      },
    },
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname),
            }),
          ),
          await import("@replit/vite-plugin-dev-banner").then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    sourcemap: process.env.VITE_BUILD_SOURCEMAP === "true",
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes("node_modules")) return undefined;
          if (id.includes("@supabase")) return "supabase";
          if (id.includes("@stripe")) return "stripe";
          if (id.includes("@tanstack")) return "query";
          if (id.includes("recharts")) return "charts";
          return undefined;
        },
      },
    },
  },
  server: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
