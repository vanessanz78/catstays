# Prompt For The Catstays Codex Thread

Use the attached StayDirect transfer kit as source material for Catstays.

Goal: adapt StayDirect's preview importer and the three redesign templates into Catstays so Catstays can generate cattery/cat accommodation rendering pages from a pasted public URL.

Use these template IDs from `staydirect-source/src/lib/websiteDesignOptions.ts`:

- `modern-showcase`
- `conversion-focus`
- `editorial-guide`

Do not prioritize the `source-match` original template unless useful as a fallback.

Use `staydirect-source/api-server/src/preview.ts` as the scraper/API reference. It provides `/api/health`, `/api/scrape?url=...`, and `/api/export-image?url=...`. Port the scraper server-side, not browser-side.

Use `staydirect-source/src/pages/GeneratedPreviewPage.tsx` and `staydirect-source/src/pages/WebsiteOptionsPage.tsx` as the frontend reference. The important renderer functions are `contentFromImport`, `FullTemplateSite`, `ModernShowcaseSite`, `ConversionSite`, `EditorialSite`, and `TemplatePreviewPage`.

Adapt naming and copy for Catstays:

- StayDirect -> Catstays
- property/stay -> cattery/cat stay
- guest -> cat owner
- guests -> cats
- bedrooms/bathrooms -> Catstays capacity/facility fields
- amenities -> cattery facilities/services
- Deloraine demo data -> Catstays demo data
- `staydirect_*` browser storage keys -> `catstays_*`

If Catstays has Supabase preview persistence, create or adapt a `preview_sessions` table with `url`, `scraped_data`, `layout_previews`, `selected_template`, and `created_at`. If not, start with local browser storage and add persistence later.

Before implementing, inspect the current Catstays app structure and avoid overwriting unrelated uncommitted Catstays work. Build in small steps:

1. Add the server-side scraper endpoint.
2. Add or adapt the URL input preview page.
3. Add the three template option definitions.
4. Add the full template renderers.
5. Replace StayDirect/Deloraine wording and data with Catstays/cattery wording and fixtures.
6. Validate locally with at least one public cattery URL and one simple public website URL.
7. Document the Catstays implementation in Catstays GitHub docs before committing.
